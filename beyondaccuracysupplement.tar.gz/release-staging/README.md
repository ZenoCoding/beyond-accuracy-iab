# Beyond Accuracy: anonymized replication package

This package contains the data and code for the corrected analysis of 120
debates: 80 original six-player debates and 40 fresh eight-player debates. It
also preserves the original size-6 analyses. No model or API calls are required
to reproduce the paper tables.

## Reproduce the corrected paper tables

Use Python 3.11 or newer. Install the versions recorded for the corrected run:

```sh
python -m pip install numpy==2.3.5 pandas==2.2.3 PyYAML==6.0.3 Pillow==12.3.0
```

`uv.lock` preserves the original pipeline environment. The command above adds
the four analysis dependencies at the versions recorded in
`reports/analysis/fast-translation-cleanup-v1-2026-09-06/runtime-versions.json`.

From this directory, run:

```sh
python scripts/verify_release.py
PYTHONPATH=src python reports/analysis/fast-translation-cleanup-v1-2026-09-06/integrate_reviews.py
PYTHONPATH=src python reports/analysis/fast-translation-cleanup-v1-2026-09-06/recompute.py
PYTHONPATH=src python reports/analysis/fast-translation-cleanup-v1-2026-09-06/summarize_and_verify.py
python paper-analysis/reconcile_statistics.py
```

The first three commands verify and replay the source-level correction overlay,
regenerate the corrected 120-debate feature and AUC tables, and check the saved
cohort and edit invariants. The fourth reproduces the manuscript's 10,000-draw
puzzle-cluster intervals. The final command verifies the release inventory,
raw-run coverage, corrected cohort counts, and exact agreement between the
corrected AUC inputs and the manuscript reconciliation inputs. Run this
integrity check before regenerating outputs in place.

## Layout

    data/kks/v1/questions/{6,8}.jsonl    generated puzzles
    data/kks/v1/labels/{6,8}.jsonl       exhaustively verified solutions
    runs/...                             raw debate outputs for all 120 debates
    reports/analysis/formal-logic-minimal-v2/
                                         original size-6 translations
    reports/analysis/fast-translation-cleanup-v1-2026-09-06/
      frozen/                            immutable source and scoring inputs
      correction-ledger.jsonl            exact accepted source-record changes
      overlay/translations/              six complete corrected translation files
      corrected-inputs/                  corrected size-6 and size-8 scored data
      corrected/                         regenerated 120-debate tables
      pending-ambiguities.json           unresolved judgments retained explicitly
    paper-analysis/                      corrected inputs and puzzle-cluster bootstrap
    scripts/, src/                       scorer, analysis, and release verification code
    COMPUTE.md                           recorded execution and resource metadata
    MANIFEST.json                        SHA-256 inventory of release files

The size-8 raw runs contain 20 homogeneous GPT-OSS debates and 20 heterogeneous
Gemini, Mercury, and GPT-OSS debates. Each task directory includes the transcript,
prompts, model-call records, events, and final result; each run includes its exact
resolved configuration, manifest, aggregate events, predictions, and summary.

## Correction provenance and limits

The corrected translations are overlays on six immutable translation sources.
`correction-ledger.jsonl` records stable IDs, exact before/after objects, source
spans and hashes, rationales, and review provenance. Of 5,826 translated fields,
24 were changed and 5,802 remain byte-identical. The correction changes 75 claim
records across 22 debates; it is a bounded cleanup, not corpus-wide semantic
validation. Forty-three generic-closure candidates remain unreviewed, and the
explicit unresolved cases are in `pending-ambiguities.json`.
Two frozen scored-summary files had author workstation prefixes removed from
their `config` and `dataset` metadata fields; their release hashes are recorded
in `input-inventory.json`. No scientific field or raw model output was changed.

The final analysis contains 120 debates and 73 correct outcomes. The fresh
size-8 conditions contain 15/20 correct heterogeneous debates and 20/20 correct
homogeneous debates. Uptake selectivity and false-claim resistance use 71 and 77
eligible debates, respectively; zero-denominator debates are missing, not zero.
The paper's intervals resample 20 puzzle IDs independently within each size and
carry all conditions sharing a puzzle together.

## Data and code licenses

Code: MIT (`LICENSE-CODE`). Newly generated data: CC BY 4.0 (`LICENSE-DATA`).
Hosted model weights are not redistributed. Model outputs and provider metadata
are included only for the synthetic KKS tasks.
