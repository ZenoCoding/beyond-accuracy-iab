"""Benchmark-specific implementations."""
