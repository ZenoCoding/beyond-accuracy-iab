from __future__ import annotations

import hashlib
import itertools
import json
import math
import random
import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Any

from .logic import (
    Assignment,
    Expr,
    assignments,
    ast_depth,
    ast_nodes,
    canonical_hash,
    canonical_json,
    evaluate_expr,
    normalize,
    referenced_players,
    render,
    statement_dependencies,
    statement_values,
)

GENERATOR_VERSION = "1.2.0"
DEFAULT_SEED = 20260714


@dataclass(frozen=True)
class Candidate:
    size: int
    candidate_seed: int
    target: Assignment
    statements: tuple[Expr, ...]
    canonical_hash: str
    semantic_hash: str
    features: dict[str, float | int]
    difficulty_score: float
    spy_statement_true: bool


def _derived_seed(root_seed: int, *parts: object) -> int:
    raw = ":".join(map(str, (root_seed, *parts))).encode()
    return int.from_bytes(hashlib.sha256(raw).digest()[:8], "big")


def balanced_target(size: int, rng: random.Random, orientation: int) -> Assignment:
    spy = rng.randrange(size)
    remaining = [i for i in range(size) if i != spy]
    rng.shuffle(remaining)
    low = (size - 1) // 2
    knight_count = low if orientation == 0 else size - 1 - low
    roles = ["knave"] * size
    roles[spy] = "spy"
    for player in remaining[:knight_count]:
        roles[player] = "knight"
    return tuple(roles)


def random_atom(rng: random.Random, size: int, truth_refs: list[int]) -> Expr:
    choices = ["role_is"] * 5 + ["same_role"] * 2 + ["count_role"] * 4 + ["parity"] * 2
    if truth_refs:
        choices += ["statement_true"] * 2
    op = rng.choice(choices)
    if op == "role_is":
        return {"op": op, "player": rng.randrange(size), "role": rng.choice(("knight", "knave", "spy"))}
    if op == "same_role":
        return {"op": op, "players": rng.sample(range(size), 2)}
    if op == "statement_true":
        return {"op": op, "player": rng.choice(truth_refs)}
    subset_size = rng.randint(2, min(size, 5))
    players = sorted(rng.sample(range(size), subset_size))
    role = rng.choice(("knight", "knave", "spy"))
    if op == "parity":
        return {"op": op, "players": players, "role": role, "parity": rng.choice(("even", "odd"))}
    comparison = rng.choice(("exactly", "at_least", "at_most"))
    return {"op": op, "players": players, "role": role, "comparison": comparison, "count": rng.randint(0, subset_size)}


def random_expr(rng: random.Random, size: int, depth: int, truth_refs: list[int]) -> Expr:
    if depth <= 1 or rng.random() < 0.48:
        atom = random_atom(rng, size, truth_refs)
        return normalize({"op": "not", "arg": atom}) if rng.random() < 0.16 else normalize(atom)
    op = rng.choice(("and", "or", "xor", "iff"))
    return normalize(
        {
            "op": op,
            "left": random_expr(rng, size, depth - 1, truth_refs),
            "right": random_expr(rng, size, depth - 1, truth_refs),
        }
    )


def generate_statements(rng: random.Random, target: Assignment, spy_truth_target: bool) -> tuple[Expr, ...] | None:
    size = len(target)
    universe = list(assignments(size))
    full_mask = (1 << len(universe)) - 1
    options: list[list[tuple[Expr, int]]] = []
    for speaker in range(size):
        desired = spy_truth_target if target[speaker] == "spy" else target[speaker] == "knight"
        speaker_options: dict[str, tuple[Expr, int]] = {}
        for _ in range(320):
            depth = rng.choices((1, 2, 3), weights=(4, 4, 2))[0]
            # Truth-reference expressions are supported by the language and
            # validator, but generation uses independent role propositions so
            # candidate clue masks can be optimized exactly and cheaply.
            expr = random_expr(rng, size, depth, [])
            if any(node.get("players") == [] for node in _walk(expr)):
                continue
            value = evaluate_expr(expr, target)
            if desired is None or value == desired:
                key = canonical_json(expr)
                if key in speaker_options:
                    continue
                mask = 0
                for assignment_index, assignment in enumerate(universe):
                    truth = evaluate_expr(expr, assignment)
                    if assignment[speaker] == "spy" or (assignment[speaker] == "knight") == truth:
                        mask |= 1 << assignment_index
                speaker_options[key] = (expr, mask)
                if len(speaker_options) >= 24:
                    break
        if len(speaker_options) < 12:
            return None
        options.append(list(speaker_options.values()))

    order = list(range(size))
    rng.shuffle(order)
    selected: list[tuple[Expr, int] | None] = [None] * size
    survivors = full_mask
    for speaker in order:
        ranked = sorted(options[speaker], key=lambda item: ((survivors & item[1]).bit_count(), canonical_json(item[0])))
        best_count = (survivors & ranked[0][1]).bit_count()
        best = [item for item in ranked if (survivors & item[1]).bit_count() == best_count]
        selected[speaker] = rng.choice(best)
        survivors &= selected[speaker][1]  # type: ignore[index]

    # Coordinate descent lets the spy's otherwise-unconstrained utterance rule
    # out assignments in which that speaker would be a knight or knave.
    for _ in range(3):
        changed = False
        for speaker in order:
            other_mask = full_mask
            for other, choice in enumerate(selected):
                if other != speaker:
                    other_mask &= choice[1]  # type: ignore[index]
            replacement = min(options[speaker], key=lambda item: ((other_mask & item[1]).bit_count(), canonical_json(item[0])))
            if replacement != selected[speaker]:
                selected[speaker] = replacement
                changed = True
        survivors = full_mask
        for choice in selected:
            survivors &= choice[1]  # type: ignore[index]
        if survivors.bit_count() == 1 or not changed:
            break
    if survivors.bit_count() != 1:
        return None
    return tuple(choice[0] for choice in selected if choice is not None)


def _walk(expr: Expr):
    yield expr
    if expr["op"] == "not":
        yield from _walk(expr["arg"])
    elif expr["op"] in {"and", "or", "xor", "iff"}:
        yield from _walk(expr["left"])
        yield from _walk(expr["right"])


def analyze_candidate(statements: tuple[Expr, ...], target: Assignment) -> tuple[dict[str, float | int], float, str] | None:
    universe = list(assignments(len(statements)))
    clue_masks = [0] * len(statements)
    statement_truth_tables = [0] * len(statements)
    full_mask = (1 << len(universe)) - 1
    for assignment_index, assignment in enumerate(universe):
        values = statement_values(statements, assignment)
        bit = 1 << assignment_index
        for speaker, (role, value) in enumerate(zip(assignment, values, strict=True)):
            if value:
                statement_truth_tables[speaker] |= bit
            if role == "spy" or (role == "knight") == value:
                clue_masks[speaker] |= bit

    solution_mask = full_mask
    for mask in clue_masks:
        solution_mask &= mask
    if solution_mask.bit_count() != 1:
        return None
    solution_index = solution_mask.bit_length() - 1
    if universe[solution_index] != target:
        return None

    subset_intersections = [full_mask] * (1 << len(statements))
    survivors: list[int] = []
    minimal_unique = len(statements)
    for subset in range(1, 1 << len(statements)):
        least_bit = subset & -subset
        clue = least_bit.bit_length() - 1
        subset_intersections[subset] = subset_intersections[subset ^ least_bit] & clue_masks[clue]
        count = subset_intersections[subset].bit_count()
        survivors.append(count)
        if count == 1:
            minimal_unique = min(minimal_unique, subset.bit_count())

    refs = [referenced_players(expr) for expr in statements]
    deps = [statement_dependencies(expr) for expr in statements]

    def chain(node: int, memo: dict[int, int]) -> int:
        if node not in memo:
            memo[node] = 1 + max((chain(dep, memo) for dep in deps[node]), default=0)
        return memo[node]

    longest_chain = max(chain(i, {}) for i in range(len(statements)))
    nodes = sum(ast_nodes(expr) for expr in statements)
    depth = max(ast_depth(expr) for expr in statements)
    dependency_edges = sum(len(players) for players in refs)
    mean_survivors = sum(survivors) / len(survivors)
    normalized_ambiguity = mean_survivors / len(universe)
    features: dict[str, float | int] = {
        "ast_nodes": nodes,
        "max_ast_depth": depth,
        "dependency_edges": dependency_edges,
        "longest_truth_chain": longest_chain,
        "minimal_unique_clues": minimal_unique,
        "mean_subset_survivors": round(mean_survivors, 6),
        "normalized_subset_ambiguity": round(normalized_ambiguity, 8),
    }
    score = (
        nodes / len(statements)
        + depth * 1.5
        + dependency_edges / len(statements)
        + longest_chain * 1.25
        + minimal_unique * 2.5
        + math.log2(mean_survivors + 1) * 2.0
    )
    semantic_payload = canonical_json(statement_truth_tables).encode()
    semantic_hash = hashlib.sha256(semantic_payload).hexdigest()
    return features, round(score, 8), semantic_hash


def build_candidate(root_seed: int, size: int, attempt: int, orientation: int) -> Candidate | None:
    seed = _derived_seed(root_seed, size, attempt)
    rng = random.Random(seed)
    target = balanced_target(size, rng, orientation)
    spy_truth_target = bool((attempt // (2 if size % 2 == 0 else 1)) % 2)
    statements = generate_statements(rng, target, spy_truth_target)
    if statements is None:
        return None
    analysis = analyze_candidate(statements, target)
    if analysis is None:
        return None
    features, score, semantic_hash = analysis
    values = statement_values(statements, target)
    spy = target.index("spy")
    return Candidate(
        size=size,
        candidate_seed=seed,
        target=target,
        statements=statements,
        canonical_hash=canonical_hash(statements, target),
        semantic_hash=semantic_hash,
        features=features,
        difficulty_score=score,
        spy_statement_true=values[spy],
    )


def generate_pool(root_seed: int, size: int, pool_size: int = 360, max_attempts: int = 200_000) -> tuple[list[Candidate], Counter[str]]:
    pool: list[Candidate] = []
    canonical_seen: set[str] = set()
    semantic_seen: set[str] = set()
    stats: Counter[str] = Counter()
    for attempt in range(max_attempts):
        orientation = attempt % (2 if size % 2 == 0 else 1)
        candidate = build_candidate(root_seed, size, attempt, orientation)
        if candidate is None:
            stats["not_unique"] += 1
            continue
        if candidate.canonical_hash in canonical_seen:
            stats["structural_duplicate"] += 1
            continue
        if candidate.semantic_hash in semantic_seen:
            stats["semantic_duplicate"] += 1
            continue
        pool.append(candidate)
        canonical_seen.add(candidate.canonical_hash)
        semantic_seen.add(candidate.semantic_hash)
        stats["accepted_to_pool"] += 1
        if len(pool) >= pool_size:
            break
    if len(pool) < pool_size:
        raise RuntimeError(f"only generated {len(pool)} unique candidates for size {size} after {max_attempts} attempts")
    stats["attempts"] = sum(stats[key] for key in ("not_unique", "structural_duplicate", "semantic_duplicate", "accepted_to_pool"))
    return pool, stats


def select_structural_spread(pool: list[Candidate], per_size: int = 300) -> list[Candidate]:
    """Keep a broad score distribution without assigning difficulty classes.

    Player count is the benchmark's experimental difficulty variable. Within
    each size, this selection retains low, central, and high structural-score
    candidates so incidental clue variation is not collapsed.
    """
    by_stratum: dict[tuple[int, bool], list[Candidate]] = defaultdict(list)
    size = pool[0].size
    for candidate in pool:
        knights = candidate.target.count("knight")
        orientation = 0 if size % 2 else int(knights > (size - 1) // 2)
        by_stratum[orientation, candidate.spy_statement_true].append(candidate)

    selected: list[tuple[int, Candidate]] = []
    expected_group_count = (2 if size % 2 == 0 else 1) * 2
    if len(by_stratum) != expected_group_count:
        raise RuntimeError("candidate pool does not cover every role-composition and spy-truth stratum")
    group_count = len(by_stratum)
    if per_size % (group_count * 3):
        raise ValueError("per-size count must divide evenly across strata and three score regions")
    quota = per_size // (group_count * 3)
    for candidates in by_stratum.values():
        candidates.sort(key=lambda item: (item.difficulty_score, item.canonical_hash))
        if len(candidates) < quota * 3:
            raise RuntimeError("candidate pool cannot satisfy the requested structural spread")
        middle_start = (len(candidates) - quota) // 2
        regions = (candidates[:quota], candidates[middle_start : middle_start + quota], candidates[-quota:])
        for region_index, region in enumerate(regions):
            selected.extend((region_index, candidate) for candidate in region)
    selected.sort(key=lambda item: (item[0], item[1].difficulty_score, item[1].canonical_hash))
    return [candidate for _, candidate in selected]


def records_for_size(root_seed: int, size: int, per_size: int = 300, pool_size: int = 360) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    pool, rejection_stats = generate_pool(root_seed, size, pool_size=pool_size)
    selected = select_structural_spread(pool, per_size=per_size)
    labels = [f"Player {chr(65 + i)}" for i in range(size)]
    questions: list[dict[str, Any]] = []
    answers_out: list[dict[str, Any]] = []
    for item_number, candidate in enumerate(selected, start=1):
        item_id = f"kks-v1-n{size:02d}-{item_number:03d}"
        roles = {labels[i]: candidate.target[i] for i in range(size)}
        questions.append(
            {
                "schema_version": 1,
                "id": item_id,
                "size": size,
                "players": labels,
                "statements": [
                    {"speaker": labels[i], "ast": expr, "text": render(expr, labels) + "."}
                    for i, expr in enumerate(candidate.statements)
                ],
                "hint": "There is exactly one spy among the players.",
                "metadata": {
                    "candidate_seed": candidate.candidate_seed,
                    "canonical_hash": candidate.canonical_hash,
                    "semantic_hash": candidate.semantic_hash,
                    "role_composition": dict(Counter(candidate.target)),
                    "spy_statement_true": candidate.spy_statement_true,
                    "difficulty_score": candidate.difficulty_score,
                    "difficulty_features": candidate.features,
                },
            }
        )
        answers_out.append({"schema_version": 1, "id": item_id, "roles": roles})
    report = {
        "size": size,
        "candidate_pool_size": len(pool),
        "rejections": dict(sorted(rejection_stats.items())),
        "selected": len(selected),
        "spy_truth_counts": dict(Counter(str(candidate.spy_statement_true).lower() for candidate in selected)),
        "structural_score_summary": {
            "min": min(candidate.difficulty_score for candidate in selected),
            "median": round(statistics.median(candidate.difficulty_score for candidate in selected), 8),
            "mean": round(statistics.mean(candidate.difficulty_score for candidate in selected), 8),
            "max": max(candidate.difficulty_score for candidate in selected),
        },
        "operator_counts": dict(
            sorted(
                Counter(
                    node["op"]
                    for candidate in selected
                    for statement in candidate.statements
                    for node in _walk(statement)
                ).items()
            )
        ),
    }
    return questions, answers_out, report
