"""Deterministic Knight-Knave-Spy benchmark generator."""

from .logic import ROLES, evaluate_puzzle, solve

__all__ = ["ROLES", "evaluate_puzzle", "solve"]
