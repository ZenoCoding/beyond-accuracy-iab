from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path

from .dataset import (
    DEFAULT_SIZES,
    build_dataset,
    dataset_sizes,
    file_sha256,
    read_jsonl,
    sample_by_difficulty,
    validate_dataset,
    write_jsonl,
)
from .generator import DEFAULT_SEED
from .scoring import score_prediction

DEFAULT_OUTPUT = Path("data/kks/v1")


def _build(args: argparse.Namespace) -> int:
    manifest = build_dataset(
        args.output,
        args.seed,
        args.per_size,
        args.pool_size,
        resume=not args.no_resume,
        sizes=args.sizes,
    )
    validation = validate_dataset(args.output, args.per_size, sizes=args.sizes)
    report_path = args.output / "reports" / "validation.json"
    report_path.write_text(json.dumps(validation, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"manifest": manifest["total"], "validation": validation}, indent=2))
    return 0 if validation["valid"] else 1


def _validate(args: argparse.Namespace) -> int:
    result = validate_dataset(args.output, args.per_size, sizes=args.sizes)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["valid"] else 1


def _score(args: argparse.Namespace) -> int:
    questions: dict[str, dict] = {}
    labels: dict[str, dict] = {}
    for size in dataset_sizes(args.dataset):
        for record in read_jsonl(args.dataset / "questions" / f"{size}.jsonl"):
            questions[record["id"]] = record
        for record in read_jsonl(args.dataset / "labels" / f"{size}.jsonl"):
            labels[record["id"]] = record
    results = []
    for prediction in read_jsonl(args.predictions):
        item_id = prediction.get("id")
        if item_id not in questions:
            results.append({
                "id": item_id,
                "strict": 0.0,
                "smooth": 0.0,
                "semantic_strict": 0.0,
                "semantic_smooth": 0.0,
                "contract_strict": 0.0,
                "protocol_valid": False,
                "protocol_errors": ["unknown puzzle id"],
                "semantic_errors": ["expected answer is unavailable"],
                "errors": ["unknown puzzle id", "expected answer is unavailable"],
            })
            continue
        result = score_prediction(questions[item_id]["players"], labels[item_id]["roles"], prediction.get("roles"))
        results.append({"id": item_id, **result})
    strict = sum(record["strict"] for record in results) / len(results) if results else 0.0
    smooth = sum(record["smooth"] for record in results) / len(results) if results else 0.0
    contract_strict = sum(record["contract_strict"] for record in results) / len(results) if results else 0.0
    protocol = sum(record["protocol_valid"] for record in results) / len(results) if results else 0.0
    output = {
        "summary": {
            "count": len(results),
            "strict_accuracy": strict,
            "smooth_accuracy": smooth,
            "contract_strict_accuracy": contract_strict,
            "protocol_valid_rate": protocol,
        },
        "items": results,
    }
    if args.output:
        args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output["summary"], indent=2))
    return 0


def _calibration_sample(args: argparse.Namespace) -> int:
    sampled = []
    for size in dataset_sizes(args.dataset):
        records = read_jsonl(args.dataset / "questions" / f"{size}.jsonl")
        sampled.extend(sample_by_difficulty(records, args.per_size))
    write_jsonl(args.output, sampled)
    print(f"wrote {len(sampled)} preregistered calibration questions to {args.output}")
    return 0


def _reproducibility(args: argparse.Namespace) -> int:
    with tempfile.TemporaryDirectory(prefix="kks-repro-") as raw:
        temporary = Path(raw) / "v1"
        sizes = args.sizes or dataset_sizes(args.dataset)
        build_dataset(
            temporary,
            args.seed,
            args.per_size,
            args.pool_size,
            resume=False,
            sizes=sizes,
        )
        expected = {str(path.relative_to(args.dataset)): file_sha256(path) for path in args.dataset.rglob("*") if path.is_file() and path.name != "validation.json"}
        actual = {str(path.relative_to(temporary)): file_sha256(path) for path in temporary.rglob("*") if path.is_file()}
        ok = expected == actual
        if not ok:
            print(json.dumps({"missing_or_changed": sorted(set(expected) ^ set(actual) | {key for key in expected.keys() & actual.keys() if expected[key] != actual[key]})}, indent=2))
        else:
            print(f"byte-identical regeneration confirmed for {len(actual)} files")
        return 0 if ok else 1


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(prog="kks", description="Knight-Knave-Spy benchmark tools")
    sub = result.add_subparsers(dest="command", required=True)
    build = sub.add_parser("build", help="generate/resume, validate, and report the full dataset")
    build.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    build.add_argument("--seed", type=int, default=DEFAULT_SEED)
    build.add_argument("--per-size", type=int, default=300)
    build.add_argument("--pool-size", type=int, default=360)
    build.add_argument("--sizes", type=int, nargs="+", default=list(DEFAULT_SIZES))
    build.add_argument("--no-resume", action="store_true")
    build.set_defaults(func=_build)
    validate = sub.add_parser("validate", help="exhaustively validate a generated dataset")
    validate.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    validate.add_argument("--per-size", type=int, default=300)
    validate.add_argument("--sizes", type=int, nargs="+")
    validate.set_defaults(func=_validate)
    score = sub.add_parser("score", help="score JSONL role predictions")
    score.add_argument("predictions", type=Path)
    score.add_argument("--dataset", type=Path, default=DEFAULT_OUTPUT)
    score.add_argument("--output", type=Path)
    score.set_defaults(func=_score)
    sample = sub.add_parser("calibration-sample", help="sample evenly across structural scores within each size")
    sample.add_argument("--dataset", type=Path, default=DEFAULT_OUTPUT)
    sample.add_argument("--output", type=Path, default=Path("data/kks/calibration-sample.jsonl"))
    sample.add_argument("--per-size", type=int, default=60)
    sample.set_defaults(func=_calibration_sample)
    repro = sub.add_parser("reproducibility-check", help="regenerate in a temporary directory and compare bytes")
    repro.add_argument("--dataset", type=Path, default=DEFAULT_OUTPUT)
    repro.add_argument("--seed", type=int, default=DEFAULT_SEED)
    repro.add_argument("--per-size", type=int, default=300)
    repro.add_argument("--pool-size", type=int, default=360)
    repro.add_argument("--sizes", type=int, nargs="+")
    repro.set_defaults(func=_reproducibility)
    return result


def main() -> None:
    args = parser().parse_args()
    raise SystemExit(args.func(args))


if __name__ == "__main__":
    main()
