from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from .logic import ROLES


def _normalize_role(role: Any) -> str | None:
    if not isinstance(role, str):
        return None
    normalized = role.strip().casefold()
    return normalized if normalized in ROLES else None


def score_prediction(
    players: list[str],
    expected: dict[str, str],
    predicted: Any,
    *,
    protocol_errors: Sequence[str] = (),
) -> dict[str, Any]:
    """Score role semantics independently from response-contract validity.

    ``strict`` and ``smooth`` are semantic metrics.  ``contract_strict`` is the
    all-or-nothing metric for an answer that is both semantically exact and
    protocol-valid.  The explicit semantic aliases make that distinction
    discoverable while preserving the original metric keys for consumers.
    """

    errors = list(protocol_errors)
    semantic_errors: list[str] = []
    if not isinstance(predicted, dict):
        errors.append("prediction must be an object mapping players to roles")
        semantic_errors = ["no role mapping could be recovered"]
        return {
            "strict": 0.0,
            "smooth": 0.0,
            "semantic_strict": 0.0,
            "semantic_smooth": 0.0,
            "contract_strict": 0.0,
            "protocol_valid": False,
            "correct_players": 0,
            "total_players": len(players),
            "normalized_prediction": None,
            "protocol_errors": errors,
            "semantic_errors": semantic_errors,
            "errors": errors + semantic_errors,
        }

    missing = sorted(set(players) - set(predicted), key=str)
    extra = sorted(set(predicted) - set(players), key=str)
    noncanonical = sorted(
        (player for player, role in predicted.items() if not isinstance(role, str) or role not in ROLES),
        key=str,
    )
    normalized = {player: _normalize_role(role) for player, role in predicted.items()}
    unrecognized = sorted((player for player, role in normalized.items() if role is None), key=str)

    if missing:
        errors.append(f"missing players: {', '.join(map(str, missing))}")
    if extra:
        errors.append(f"unexpected players: {', '.join(map(str, extra))}")
    if noncanonical:
        errors.append(f"roles must use canonical lowercase labels for: {', '.join(map(str, noncanonical))}")
    if unrecognized:
        semantic_errors.append(f"unrecognized roles for: {', '.join(map(str, unrecognized))}")

    correct = sum(normalized.get(player) == expected[player] for player in players)
    semantic_strict = float(bool(players) and correct == len(players) and not missing and not extra)
    semantic_smooth = correct / len(players) if players else 0.0
    protocol_valid = not errors
    return {
        "strict": semantic_strict,
        "smooth": semantic_smooth,
        "semantic_strict": semantic_strict,
        "semantic_smooth": semantic_smooth,
        "contract_strict": float(protocol_valid and semantic_strict == 1.0),
        "protocol_valid": protocol_valid,
        "correct_players": correct,
        "total_players": len(players),
        "normalized_prediction": normalized,
        "protocol_errors": errors,
        "semantic_errors": semantic_errors,
        "errors": errors + semantic_errors,
    }
