"""ControlMAD clean-room replication."""
