"""Proof-v2 line format and structural checker for formal reasoning traces.

The format deliberately stays flat and repetitive so model output is easy to
constrain and repair. Proposition syntax remains the existing compact AST; this
module adds proof events, scope, and discourse attribution around it.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from controlmad.harness.config import ModelConfig
from controlmad.harness.models import ModelClient, model_client_for_config

from .formal_logic import ReasoningSource, _load_question

from .formal_logic_compact import (
    CompactParseError,
    expressions_entail,
    expressions_equivalent,
    expressions_satisfiable,
    format_compact_expression,
    parse_compact_expression,
)


NODE_ID = re.compile(r"n[1-9][0-9]*$")
EXTERNAL_REF = re.compile(r"@[A-Za-z0-9_.:/-]+$")
SCOPE = re.compile(r"IN\((root|n[1-9][0-9]*)\)$")
FROM = re.compile(r"FROM\(([^()]*)\)$")
KIND = re.compile(
    r"(CLAIM|ASSUME|DERIVE|CONTRADICTION|OPAQUE)"
    r"|DISCHARGE\((n[1-9][0-9]*)\)"
    r"|MODEL_CHECK\((SAT|UNSAT|UNIQUE)\)$"
)
STANCE = re.compile(
    r"(ASSERT|HYPOTHETICAL|ABSTAIN)"
    r"|(REPORT|ENDORSE|REJECT)\(((?:player|agent):[A-Za-z0-9_.-]+)\)$"
)


def _parse_kind(text: str) -> tuple[str, str | None]:
    match = KIND.fullmatch(text)
    if not match:
        raise ValueError("invalid proof event kind %r" % text)
    if match.group(2):
        return "discharge", match.group(2)
    if match.group(3):
        return "model_check", match.group(3).lower()
    return str(match.group(1)).lower(), None


def _parse_stance(text: str) -> tuple[str, str | None]:
    match = STANCE.fullmatch(text)
    if not match:
        raise ValueError("invalid proof stance %r" % text)
    if match.group(1):
        return str(match.group(1)).lower(), None
    return str(match.group(2)).lower(), str(match.group(3))


def _scope_ancestors(
    scope: str, scopes: Mapping[str, Mapping[str, Any]]
) -> list[str]:
    output = []
    current = scope
    while current != "root":
        output.append(current)
        current = str(scopes[current]["parent"])
    output.append("root")
    return output


def parse_proof_trace(
    content: str, source_text: str
) -> tuple[list[dict[str, Any]], list[str]]:
    """Parse proof-v2 lines, retaining valid nodes and reporting line errors.

    Line contract:
    ``id :: KIND :: STANCE :: IN(scope) :: EXPR :: FROM(ids) :: source``
    """
    nodes: list[dict[str, Any]] = []
    errors: list[str] = []
    by_id: dict[str, dict[str, Any]] = {}
    scopes: dict[str, dict[str, Any]] = {
        "root": {"id": "root", "parent": None, "opener": None}
    }

    for line_number, raw in enumerate(content.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("```"):
            continue
        parts = [part.strip() for part in line.split(" :: ", 6)]
        if len(parts) != 7:
            errors.append(
                "line %d: expected seven ' :: '-separated fields" % line_number
            )
            continue
        (
            node_id,
            kind_text,
            stance_text,
            scope_text,
            expression_text,
            from_text,
            source_span,
        ) = parts
        if not NODE_ID.fullmatch(node_id) or node_id in by_id:
            errors.append(
                "line %d: invalid or duplicate node id %r"
                % (line_number, node_id)
            )
            continue
        try:
            kind, kind_arg = _parse_kind(kind_text)
            stance, stance_target = _parse_stance(stance_text)
        except ValueError as exc:
            errors.append("line %d: %s" % (line_number, exc))
            continue
        scope_match = SCOPE.fullmatch(scope_text)
        if not scope_match or scope_match.group(1) not in scopes:
            errors.append("line %d: unknown or invalid scope" % line_number)
            continue
        scope = str(scope_match.group(1))
        from_match = FROM.fullmatch(from_text)
        if not from_match:
            errors.append("line %d: invalid dependency field" % line_number)
            continue
        dependencies = [
            item.strip()
            for item in re.split(r"[;,]", from_match.group(1))
            if item.strip() and item.strip() != "-"
        ]
        invalid_references = [
            item
            for item in dependencies
            if item not in by_id and not EXTERNAL_REF.fullmatch(item)
        ]
        if invalid_references:
            errors.append(
                "line %d: dependency must be earlier or an external @ reference: %s"
                % (line_number, ",".join(invalid_references))
            )
            continue
        if not source_span or source_span not in source_text:
            errors.append("line %d: source span is not verbatim" % line_number)
            continue
        if expression_text == "BOTTOM":
            expression = None
            expression_marker = "bottom"
        else:
            try:
                expression = parse_compact_expression(expression_text)
            except CompactParseError as exc:
                errors.append("line %d: %s" % (line_number, exc))
                continue
            expression_marker = "abstain" if expression is None else "expression"

        if kind == "opaque":
            if stance != "abstain" or expression_marker != "abstain":
                errors.append(
                    "line %d: OPAQUE requires ABSTAIN stance and expression"
                    % line_number
                )
                continue
        elif kind == "contradiction":
            local_dependencies = [item for item in dependencies if item in by_id]
            if expression_marker != "bottom" or len(local_dependencies) < 2:
                errors.append(
                    "line %d: CONTRADICTION requires BOTTOM and two local dependencies"
                    % line_number
                )
                continue
        elif expression is None:
            errors.append(
                "line %d: only OPAQUE may use ABSTAIN expression" % line_number
            )
            continue
        if kind != "opaque" and stance == "abstain":
            errors.append(
                "line %d: ABSTAIN stance requires OPAQUE event" % line_number
            )
            continue
        if scope != "root" and kind != "opaque" and stance != "hypothetical":
            errors.append(
                "line %d: nodes inside an assumption must use HYPOTHETICAL stance"
                % line_number
            )
            continue
        if kind == "assume" and (stance != "hypothetical" or dependencies):
            errors.append(
                "line %d: ASSUME must be hypothetical and dependency-free"
                % line_number
            )
            continue

        if kind == "discharge":
            discharged = str(kind_arg)
            if discharged not in scopes or scopes[discharged]["parent"] != scope:
                errors.append(
                    "line %d: DISCHARGE must close a direct child scope"
                    % line_number
                )
                continue
            contradiction_dependencies = [
                by_id[item]
                for item in dependencies
                if item in by_id
                and by_id[item]["kind"] == "contradiction"
                and by_id[item]["scope"] == discharged
            ]
            if not contradiction_dependencies:
                errors.append(
                    "line %d: DISCHARGE requires a contradiction in the closed scope"
                    % line_number
                )
                continue
        else:
            visible_scopes = set(_scope_ancestors(scope, scopes))
            invisible = [
                item
                for item in dependencies
                if item in by_id
                and (
                    item
                    if by_id[item]["kind"] == "assume"
                    else by_id[item]["scope"]
                )
                not in visible_scopes
            ]
            if invisible:
                errors.append(
                    "line %d: dependency is outside the active scope: %s"
                    % (line_number, ",".join(invisible))
                )
                continue

        node = {
            "id": node_id,
            "kind": kind,
            "kind_arg": kind_arg,
            "stance": stance,
            "stance_target": stance_target,
            "scope": scope,
            "expression": expression,
            "expression_marker": expression_marker,
            "dependencies": dependencies,
            "source_span": source_span,
        }
        nodes.append(node)
        by_id[node_id] = node
        if kind == "assume":
            scopes[node_id] = {
                "id": node_id,
                "parent": scope,
                "opener": node_id,
            }
    return nodes, errors


def _active_assumption_expressions(
    scope: str,
    by_id: Mapping[str, Mapping[str, Any]],
    scopes: Mapping[str, Mapping[str, Any]],
) -> list[Mapping[str, Any]]:
    expressions = []
    for scope_id in reversed(_scope_ancestors(scope, scopes)):
        if scope_id == "root":
            continue
        expression = by_id[scope_id].get("expression")
        if isinstance(expression, Mapping):
            expressions.append(expression)
    return expressions


def check_proof_trace(nodes: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Run proposition-only proof checks with explicit non-explosion semantics.

    KKS-specific statement truthfulness and solver-backed MODEL_CHECK events are
    intentionally separate adapters. This checker establishes scope,
    contradiction, discharge, and generic propositional behavior first.
    """
    by_id = {str(node["id"]): node for node in nodes}
    scopes: dict[str, dict[str, Any]] = {
        "root": {"id": "root", "parent": None, "opener": None}
    }
    for node in nodes:
        if node["kind"] == "assume":
            scopes[str(node["id"])] = {
                "id": str(node["id"]),
                "parent": str(node["scope"]),
                "opener": str(node["id"]),
            }

    verdicts: dict[str, str] = {}
    output = []
    tainting = {
        "opaque",
        "tainted",
        "contingent",
        "invalid_contradiction",
        "invalid_discharge",
        "inconsistent_context",
        "uncheckable_external",
        "uncheckable_model_check",
    }
    for node in nodes:
        node_id = str(node["id"])
        kind = str(node["kind"])
        local_dependencies = [
            by_id[item]
            for item in node.get("dependencies", [])
            if item in by_id
        ]
        external = [
            item
            for item in node.get("dependencies", [])
            if item not in by_id
        ]
        dependency_verdicts = [
            verdicts[str(item["id"])] for item in local_dependencies
        ]
        active = _active_assumption_expressions(
            str(node["scope"]), by_id, scopes
        )
        dependency_expressions = [
            item["expression"]
            for item in local_dependencies
            if isinstance(item.get("expression"), Mapping)
        ]
        premises = [*active, *dependency_expressions]

        if kind == "opaque":
            verdict = "opaque"
        elif external:
            verdict = "uncheckable_external"
        elif any(value in tainting for value in dependency_verdicts):
            verdict = "tainted"
        elif kind in {"claim", "assume"}:
            verdict = "declared"
        elif kind == "derive":
            if not expressions_satisfiable(premises):
                verdict = "inconsistent_context"
            elif expressions_entail(premises, node["expression"]):
                verdict = "entailed"
            else:
                verdict = "contingent"
        elif kind == "contradiction":
            parent = str(scopes[str(node["scope"])]["parent"])
            parent_active = _active_assumption_expressions(
                parent, by_id, scopes
            )
            if (
                not expressions_satisfiable(premises)
                and expressions_satisfiable(parent_active)
            ):
                verdict = "valid_contradiction"
            else:
                verdict = "invalid_contradiction"
        elif kind == "discharge":
            discharged = str(node["kind_arg"])
            opener = by_id[discharged]["expression"]
            expected = {"op": "not", "arg": opener}
            has_valid_contradiction = any(
                verdicts.get(str(item["id"])) == "valid_contradiction"
                and item["scope"] == discharged
                for item in local_dependencies
            )
            if has_valid_contradiction and expressions_equivalent(
                node["expression"], expected
            ):
                verdict = "valid_discharge"
            else:
                verdict = "invalid_discharge"
        elif kind == "model_check":
            verdict = "uncheckable_model_check"
        else:
            verdict = "uncheckable"
        verdicts[node_id] = verdict
        output.append({"id": node_id, "verdict": verdict})
    return output


def proof_trace_format() -> str:
    """Return the model-facing proof-v2 line contract."""
    return """Return one plain-text line per proof event:
<id> :: <kind> :: <stance> :: IN(<scope>) :: <expression> :: FROM(<ids>) :: <exact source span>

Kinds:
CLAIM, ASSUME, DERIVE, CONTRADICTION, DISCHARGE(<assumption-id>),
MODEL_CHECK(SAT|UNSAT|UNIQUE), or OPAQUE.

Stances:
ASSERT, HYPOTHETICAL, REPORT(player:A), REPORT(agent:agent-1),
ENDORSE(agent:agent-1), REJECT(agent:agent-1), or ABSTAIN.

Scopes:
IN(root), or IN(<ASSUME node id>). ASSUME opens a scope named by its own id.

Expressions use the existing compact language. CONTRADICTION uses BOTTOM.
OPAQUE uses ABSTAIN. Dependencies may be earlier local node IDs or supplied
external references such as @agent-1:r0:n3.

Strict syntax rules:
- IDs are n1, n2, ... in order. Never use c1, p1, or another prefix.
- KIND is only one listed kind. Reporting is a STANCE: use CLAIM with
  REPORT(player:A), never REPORT(player:A) as KIND or expression.
- Write ROLE(A,knight), never KNIGHT(A), knight(A), or logical symbols.
- Write NOT(expr), AND(expr;expr), and OR(expr;expr), never words, Unicode
  operators, TRUE, FALSE, SAT(...), UNIQUE(...), or DISCHARGE as expressions.
- CONTRADICTION has expression BOTTOM. OPAQUE has expression ABSTAIN.
- MODEL_CHECK uses the compact expression describing the checked case.
- An empty dependency list is FROM(-), never FROM().
- Nodes inside an assumption use HYPOTHETICAL stance."""


def proof_trace_prompt(
    question: Mapping[str, Any],
    *,
    source_text: str,
    location: Mapping[str, Any],
    submitted_roles: Mapping[str, str],
    external_claims: Sequence[Mapping[str, Any]] = (),
) -> str:
    """Build a proof-v2 prompt for either an initial or debate reasoning field."""
    statements = []
    for index, statement in enumerate(question["statements"]):
        speaker = str(statement.get("speaker") or chr(ord("A") + index)).strip()
        speaker_ref = re.sub(r"^Player\s+", "", speaker, flags=re.IGNORECASE)
        speaker_ref = re.sub(r"[^A-Za-z0-9_.-]+", "-", speaker_ref).strip("-")
        if not speaker_ref:
            speaker_ref = chr(ord("A") + index)
        statements.append(
            "@ctx:stmt-%s :: %s :: %s :: %s"
            % (
                speaker_ref,
                speaker,
                statement["text"],
                format_compact_expression(statement["ast"]),
            )
        )
    references = []
    for item in external_claims:
        references.append(
            "%s :: %s :: %s"
            % (
                item["id"],
                item.get("speaker", "unknown"),
                format_compact_expression(item.get("expression")),
            )
        )
    reference_text = "\n".join(references) or "none"
    metadata = ", ".join(
        "%s=%s" % item for item in sorted(location.items())
    )
    submitted = ", ".join(
        "%s=%s" % item for item in sorted(submitted_roles.items())
    ) or "none"
    return f"""Translate one KKS reasoning field into a scoped proof trace.

Canonical puzzle statements:
{chr(10).join(statements)}

Context references:
@ctx:rule-role-exclusivity
@ctx:rule-exactly-one-spy
@ctx:rule-speaker-truthfulness

Supplied prior debate references:
{reference_text}

Field metadata: {metadata}
Submitted roles (context only, never automatic proof nodes): {submitted}

Source field:
{source_text}

Inventory every proposition-bearing and proof-bearing source span. A report of
a puzzle statement is REPORT(player:A), not an assertion that its content is
true. Use REPORT/ENDORSE/REJECT(agent:...) for debate attribution. Open each
assumption with ASSUME and keep derived nodes in that scope. Represent an
explicit contradiction with CONTRADICTION and close only the rejected
assumption with DISCHARGE. Use MODEL_CHECK for explicit consistency,
no-solution, or uniqueness claims. Use OPAQUE only for meaningful residue that
cannot be represented; never silently omit it.

Use FROM(...) for exact local support and supplied @ references. Do not grant a
step the whole solved puzzle as an implicit premise. Copy one exact contiguous
source span per line. Return only the proof lines, without Markdown or prose.

Two syntax examples (copy their field roles, not their facts):
n1 :: CLAIM :: REPORT(player:A) :: IN(root) :: COUNT(exactly,3,knave,A,B,C,D) :: FROM(@ctx:stmt-A) :: Player A says exactly 3 are knaves
n2 :: ASSUME :: HYPOTHETICAL :: IN(root) :: ROLE(A,knight) :: FROM(-) :: Assume A is knight
n3 :: DERIVE :: HYPOTHETICAL :: IN(n2) :: NOT(ROLE(A,knave)) :: FROM(n2) :: A is not knave
n4 :: CONTRADICTION :: HYPOTHETICAL :: IN(n2) :: BOTTOM :: FROM(n3) :: Contradiction
n5 :: DISCHARGE(n2) :: ASSERT :: IN(root) :: NOT(ROLE(A,knight)) :: FROM(n4) :: Therefore A is not knight

For “the only consistent assignment is A spy and B knight”:
n1 :: MODEL_CHECK(UNIQUE) :: ASSERT :: IN(root) :: AND(ROLE(A,spy);ROLE(B,knight)) :: FROM(@ctx:rule-role-exclusivity) :: the only consistent assignment is A spy and B knight

{proof_trace_format()}"""


def _source_span_coverage(source_text: str, nodes: Sequence[Mapping[str, Any]]) -> float:
    """Return the fraction of source characters covered by accepted node spans."""
    covered: set[int] = set()
    for node in nodes:
        span = str(node.get("source_span", ""))
        if not span:
            continue
        start = 0
        while True:
            index = source_text.find(span, start)
            if index < 0:
                break
            covered.update(range(index, index + len(span)))
            start = index + 1
    meaningful = {index for index, char in enumerate(source_text) if not char.isspace()}
    if not meaningful:
        return 1.0
    return len(covered & meaningful) / len(meaningful)


def load_proof_canary_cases(path: Path) -> list[dict[str, Any]]:
    """Load source cases without treating legacy claim annotations as proof gold."""
    cases = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        item = json.loads(line)
        source = item.get("source")
        if not isinstance(source, Mapping) or not source.get("task_id"):
            raise ValueError("case line %d has no source.task_id" % line_number)
        source_text = str(item.get("source_text", "")).strip()
        if not source_text:
            raise ValueError("case line %d has no source_text" % line_number)
        cases.append({
            "id": str(item.get("id") or "case-%d" % line_number),
            "source": dict(source),
            "source_text": source_text,
            "submitted_roles": dict(item.get("submitted_roles") or {}),
            "external_claims": list(item.get("external_claims") or []),
        })
    if not cases:
        raise ValueError("proof canary requires at least one case")
    return cases


async def generate_proof_canary(
    cases_path: Path,
    dataset_path: Path,
    model_config: Path,
    output: Path,
    *,
    timeout_seconds: float = 300,
    concurrency: int = 4,
    model_client: ModelClient | None = None,
) -> dict[str, Any]:
    """Run a small proof-v2 format/reliability canary without scoring accuracy."""
    if concurrency < 1:
        raise ValueError("concurrency must be positive")
    cases = load_proof_canary_cases(cases_path)
    model = ModelConfig(**(yaml.safe_load(model_config.read_text(encoding="utf-8")) or {}))
    client = model_client or model_client_for_config(model)
    questions: dict[str, dict[str, Any]] = {}
    semaphore = asyncio.Semaphore(concurrency)
    started = time.monotonic()

    async def translate(case: Mapping[str, Any]) -> dict[str, Any]:
        task_id = str(case["source"]["task_id"])
        question = questions.setdefault(
            task_id, _load_question(dataset_path.resolve(), task_id)
        )
        source = ReasoningSource(
            dict(case["source"]),
            str(case["source_text"]),
            dict(case["submitted_roles"]),
        )
        async with semaphore:
            response = await client.complete(
                model,
                [
                    {
                        "role": "system",
                        "content": (
                            "You are a literal proof-trace translator. Preserve "
                            "source meaning, proof scope, attribution, and uncertainty."
                        ),
                    },
                    {
                        "role": "user",
                        "content": proof_trace_prompt(
                            question,
                            source_text=source.text,
                            location=source.location,
                            submitted_roles=source.submitted_roles,
                            external_claims=case["external_claims"],
                        ),
                    },
                ],
                timeout_seconds,
            )
        nodes, errors = parse_proof_trace(response.content, source.text)
        checks = check_proof_trace(nodes)
        return {
            "id": case["id"],
            "format_version": "kks-proof-v2-draft",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "source": source.location,
            "source_text": source.text,
            "submitted_roles": source.submitted_roles,
            "nodes": nodes,
            "parse_errors": errors,
            "checks": checks,
            "source_span_coverage": _source_span_coverage(source.text, nodes),
            "model": response.model,
            "model_config_id": model.id,
            "model_metadata": response.response_metadata,
            "usage": response.usage,
            "raw_response": response.content,
        }

    records = await asyncio.gather(*(translate(case) for case in cases))
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in records),
        encoding="utf-8",
    )
    kinds = Counter(node["kind"] for record in records for node in record["nodes"])
    verdicts = Counter(check["verdict"] for record in records for check in record["checks"])
    parse_errors = sum(len(record["parse_errors"]) for record in records)
    return {
        "output": str(output),
        "case_count": len(records),
        "parse_clean_case_count": sum(not record["parse_errors"] for record in records),
        "node_count": sum(len(record["nodes"]) for record in records),
        "parse_error_count": parse_errors,
        "mean_source_span_coverage": sum(
            record["source_span_coverage"] for record in records
        ) / len(records),
        "kind_counts": dict(sorted(kinds.items())),
        "verdict_counts": dict(sorted(verdicts.items())),
        "model": model.model,
        "reasoning_effort": model.params.get("reasoning_effort"),
        "wall_time_seconds": time.monotonic() - started,
        "accuracy_scored": False,
    }


def run_proof_canary(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return asyncio.run(generate_proof_canary(*args, **kwargs))
