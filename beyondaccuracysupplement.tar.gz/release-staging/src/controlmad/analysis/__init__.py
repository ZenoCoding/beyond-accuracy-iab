"""Offline, paper-aligned statistical analysis for ControlMAD runs."""

from .pipeline import run_analysis

__all__ = ["run_analysis"]
