# Translate validated omitted spans

Source field:

$source_text

$fixed_inventory

Validated spans:

$spans

Return one `ADD` claim for each span only when it supports a compact expression without guessing. Do not change the span, translate content outside these spans, duplicate a fixed claim, or edit cases and relations. Return `NONE` when no safe addition exists.
