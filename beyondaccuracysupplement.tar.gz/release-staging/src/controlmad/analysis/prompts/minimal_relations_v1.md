# Task

Extract only explicitly stated local relations between fixed claims.

Source field:

$source_text

Fixed parsed claims (read-only):

$fixed_claims

Fixed parsed cases (read-only):

$fixed_cases

Return zero or more relation lines in source order, using only these shapes:

`e1 :: INFER :: FROM(c1,c2) :: TO(c3) :: exact full relation span`

`e2 :: CONTRADICT :: FROM(c1,c2) :: exact full relation span`

`e3 :: REDUCTIO :: ASSUME(c1) :: VIA(e2) :: TO(c3) :: exact full relation span`

- You cannot add, edit, renumber, or repeat claims or cases. Output eN lines only.
- Use only claim IDs listed above. Every TO contains exactly one fixed claim ID.
- INFER means the source presents every FROM claim as a reason for the TO claim.
- CONTRADICT means the source says the FROM claims cannot jointly hold.
- REDUCTIO is strict: an ASSUME claim leads through a stated CONTRADICT relation to a fixed claim that is exactly the negation of that assumption.
- Do not use REDUCTIO merely to choose a remaining role after rejecting one.
- Do not invent missing premises or edges that are merely logically valid.
- The relation span is the smallest exact contiguous source substring containing every referenced claim span, every referenced relation span, and the connective language. If no such substring exists, omit the relation.
- Do not reconstruct a complete proof or add transitive/unstated edges.

If the source states no relations between the fixed claims, return exactly `NONE`. Otherwise return only relation lines, without Markdown or explanation.
