Extract explicit atomic commitments and flat hypothetical cases only. Preserve negation and attribution. Do not output reasoning relations. Every source span must be copied verbatim.
