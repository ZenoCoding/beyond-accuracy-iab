# Task

Extract only explicitly stated discourse relations between fixed claims.

Source field:

$source_text

Fixed parsed claims (read-only).

Fixed parsed cases (read-only):

$fixed_inventory

Return relations in source order:

Output eN lines only.

`e1 :: INFER :: FROM(c1,c2) :: TO(c3) :: exact connector or relation span`

`e2 :: CONTRADICT :: FROM(c1,c2) :: exact connector or relation span`

`e3 :: REDUCTIO :: ASSUME(c1) :: VIA(e2) :: TO(c3) :: exact connector or relation span`

Rules:

- Extract only moves explicitly signaled by “so,” “therefore,” “because,” “hence,” “contradiction,” “must,” or an unmistakable premise-to-conclusion construction.
- Preserve invalid and incomplete reasoning exactly as stated.
- Cite only salient premises the speaker explicitly invokes in that move. Never add hidden background premises needed to make it valid.
- Do not emit arithmetic-normalization, component-to-compound, compound-to-statement-truth, transitive, or proof-completion edges unless the source explicitly argues that step.
- Do not reconstruct a complete proof.
- Neutral attributed content records what someone said; it is not itself a true premise.
- Do not edit, add, renumber, or repeat claims or cases. Use only listed claim IDs.
- Every `TO` has exactly one fixed claim ID.
- `REDUCTIO` requires an assumption, an explicit contradiction, and the exact negation of that assumption.
- The span may be the exact connective phrase or shortest exact relation phrase. The host will expand it to cover endpoint spans when a unique covering span exists.
- If no explicit relation connects fixed claims, return `NONE`.

Return relation lines only, without Markdown or explanation.
