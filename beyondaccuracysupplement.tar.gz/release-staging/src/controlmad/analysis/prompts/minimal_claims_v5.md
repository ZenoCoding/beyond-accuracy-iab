# Task

Translate one KKS reasoning field into atomic claims and explicit local relations.

Puzzle statements (`speaker :: text :: canonical expression`):

$statements

Rules: each player has exactly one role; exactly one is a spy; knights speak truthfully; knaves falsely; spies may say either.

Field metadata: $location

Debate agents: $debate_agents

Submitted roles (context only; do not add claims that the source does not state): $submitted

Source field:

$source_text

Return one line per explicit proposition, in source order:

`c1 :: COMMITMENT :: EXPRESSION :: exact verbatim source span`

COMMITMENT is exactly one of:

- `ASSERT`: the current speaker presents the proposition as unconditionally true.
- `ASSUME(h1)`: the proposition opens or defines hypothetical case h1.
- `HYPOTHETICAL(h1)`: the proposition is claimed only within case h1.
- `REPORT(player:A,player:B)` or `REPORT(agent:agent-1,agent:agent-2)`: attributed without endorsement. List every target when the same proposition is reported for several players or agents. The reporting speaker is already field metadata. “All agents agree/assign/conclude P” is REPORT of P to every listed debate agent, never ASSERT. Include the field speaker too when the source says “all”. “All peers” means every listed debate agent except the field speaker. Its expression may be ABSTAIN only when the reported content is unrepresentable.
- `ENDORSE(agent:agent-1)`: the current speaker accepts that agent's proposition.
- `REJECT(agent:agent-1)`: encode the proposition being rejected, not its negation.
- `OPAQUE`: a meaningful proposition that cannot be represented; expression ABSTAIN.

ASSUME(hN), HYPOTHETICAL(hN), and REPORT(...) may use ABSTAIN when their proposition is meaningful but unrepresentable. This retains case or attribution metadata while marking expression translation as unavailable.

Optionally record each explicit case outcome on a separate line:

`h1 :: CASE(REJECTED|ACCEPTED|UNRESOLVED) :: exact verbatim outcome span`

REJECTED means the source says the case is impossible or fails; ACCEPTED means the source says it works or adopts it; UNRESOLVED means the source explicitly leaves it open or uncertain. Do not infer an outcome from the verified answer.

Flat cases only: reuse one h-ID for all claims inside the same case. If the prose gives no explicit outcome, omit the case line.

Optionally record a local reasoning relation only when the source explicitly connects already translated claims:

`e1 :: INFER :: FROM(c1,c2) :: TO(c3) :: exact full relation span`

`e2 :: CONTRADICT :: FROM(c1,c2) :: exact full relation span`

`e3 :: REDUCTIO :: ASSUME(c1) :: VIA(e2) :: TO(c3) :: exact full relation span`

- INFER means the source presents the FROM claims as reasons for the TO claim.
- CONTRADICT means the source says the listed claims cannot jointly hold.
- REDUCTIO means an ASSUME claim leads through a stated CONTRADICT relation to the negation of that assumption. The TO claim must be exactly that negation.
- Every TO(...) contains exactly one claim ID. If the conclusion is “P or Q”, translate one OR(P;Q) claim and point TO it. If the source separately concludes both P and Q, emit two INFER lines, each with one TO claim.
- Do not use REDUCTIO merely to choose another role after one role is rejected. For “C is knave or spy; not knave; therefore spy”, use an OR claim, the negated knave claim, and ordinary INFER. REDUCTIO is only assumption-to-exact-negation.
- The relation span is the smallest exact contiguous source span containing all referenced claim spans and the connective language such as because, so, thus, impossible, or contradiction. Do not emit character offsets.
- Do not invent missing premises or connect claims merely because the puzzle makes the inference valid. A malformed or invalid relation does not erase its claims.
- Before emitting a relation, verify that the exact source span of every cited claim occurs inside the relation span. Similar wording elsewhere is not enough. If the source repeats a proposition in new wording, translate that occurrence as a new claim or omit the relation.

Inventory rules:

- “If”, “assume”, “suppose”, and counterfactual “were” clauses that introduce a case use ASSUME(hN), not merely HYPOTHETICAL(hN). Consequences use the same hN.
- ASSUME is only for a genuine case opener. A premise or parenthetical such as “(only one spy)” inside an active case is HYPOTHETICAL in that existing case; it does not open a nested case.
- Restrictive language such as “P only fits if A is knave” asserts the required condition when the prose presents P as established; it does not open a new case.
- A case remains active until the prose explicitly rejects, accepts, or exits it. A period alone does not close a case. Subsequent deductions and summaries stay HYPOTHETICAL(hN) until the source explicitly returns to an unconditional result. After a nested case closes, subsequent provisional claims return to the outer case.
- Every proposition inside an active case inherits that case, including short parentheticals such as “(true)” and conclusions after a nested case closes. The one exception is the fixed content of a puzzle character's statement: keep that as REPORT(player:X), because the character said the same thing in every case. Its truth evaluation and any deductions from it do inherit hN.
- Descriptions such as “the consistent solution where A is knave” or “a solution with D as spy” are assertions about that solution, not hypothetical cases. Do not use HYPOTHETICAL unless the source actually opens an if/assume/suppose case.
- Translate every explicit truth evaluation separately from statement content: “C says P, which is false” contains REPORT(player:C) of P and ASSERT of NOT(STMT_TRUE(C)). Do the same for “which is true”.
- Split explicit role lists and conjunctions into all of their atomic claims. Never omit “A is knave” or “B is knight” because they occur in one sentence.
- Never split alternatives into separate assertions. “C is either knave or spy” is one OR(ROLE(C,knave);ROLE(C,spy)) claim, not two role claims.
- Preserve explicit parenthetical claims such as “C is knave (not knight)” as both ROLE(C,knave) and NOT(ROLE(C,knight)).
- Emit explicit rules and premises introduced by “since”, “because”, or “with”. Do not duplicate an earlier claim merely because it is restated. Create a new occurrence only when its commitment/case/attribution changes or a relation needs that exact repeated span as an endpoint.

Expressions:

`ROLE(A,knight)`, `STMT_TRUE(D)`, `NOT(expr)`, `SAME_ROLE(A,B)`, `AND(expr;expr)`, `OR(expr;expr)`, `XOR(expr;expr)`, `IFF(expr;expr)`, `IMPLIES(expr;expr)`, `COUNT(exactly,1,spy,A,B,C,D)`, `PARITY(even,knave,A,C)`, or `ABSTAIN`.

Meaning rules:

- Preserve every negation and its scope literally.
- “D cannot be knight” is NOT(ROLE(D,knight)).
- “B's statement is false” is NOT(STMT_TRUE(B)); it is not the negation of a convenient fragment of B's statement.
- “Condition (1) is false” negates condition (1), not the speaker's whole statement.
- A puzzle character saying P is REPORT(player:X) of P, not ASSERT of P.
- Use IMPLIES(P;Q) only when the source explicitly asserts the conditional proposition “if P, then Q”. When the source actually reasons “because P, Q”, emit P and Q as claims plus INFER FROM(P) TO(Q), not IMPLIES(P;Q).
- A conclusion after a rejected case is ASSERT only when the source explicitly adopts it outside the case.
- Copy one exact contiguous source span. Never paraphrase the span.
- Never shorten copied text with `...` or an ellipsis character. If a span is long, copy the entire exact substring anyway.
- ABSTAIN is never paired with ASSERT, ENDORSE, or REJECT. Use OPAQUE for an unconditional meaningful proposition that cannot be expressed. Use ABSTAIN with ASSUME, HYPOTHETICAL, or REPORT only to preserve that metadata.

Example source: `Assume A is knight. Then B is knave. Impossible, so A is not knight.`

```text
c1 :: ASSUME(h1) :: ROLE(A,knight) :: Assume A is knight
c2 :: HYPOTHETICAL(h1) :: ROLE(B,knave) :: Then B is knave
h1 :: CASE(REJECTED) :: Impossible
c3 :: ASSERT :: NOT(ROLE(A,knight)) :: so A is not knight
e1 :: CONTRADICT :: FROM(c1,c2) :: Assume A is knight. Then B is knave. Impossible
e2 :: REDUCTIO :: ASSUME(c1) :: VIA(e1) :: TO(c3) :: Assume A is knight. Then B is knave. Impossible, so A is not knight
```

Example source: `Player C says B is spy, which is false, so C is knave.`

```text
c1 :: REPORT(player:C) :: ROLE(B,spy) :: Player C says B is spy
c2 :: ASSERT :: NOT(STMT_TRUE(C)) :: which is false
c3 :: ASSERT :: ROLE(C,knave) :: so C is knave
e1 :: INFER :: FROM(c2) :: TO(c3) :: which is false, so C is knave
```

Example source: `If A's statement is true, A is knight; if false, A is knave.`

```text
c1 :: ASSUME(h1) :: STMT_TRUE(A) :: If A's statement is true
c2 :: HYPOTHETICAL(h1) :: ROLE(A,knight) :: A is knight
c3 :: ASSUME(h2) :: NOT(STMT_TRUE(A)) :: if false
c4 :: HYPOTHETICAL(h2) :: ROLE(A,knave) :: A is knave
```

Example source: `Assume A is knight. If C is knave, contradiction. So C is spy.`

```text
c1 :: ASSUME(h1) :: ROLE(A,knight) :: Assume A is knight
c2 :: ASSUME(h2) :: ROLE(C,knave) :: If C is knave
h2 :: CASE(REJECTED) :: contradiction
c3 :: HYPOTHETICAL(h1) :: ROLE(C,spy) :: So C is spy
```

Example source: `Agents 1 and 2 say B is knight. B's statement is true because exactly one spy exists.`

```text
c1 :: REPORT(agent:agent-1,agent:agent-2) :: ROLE(B,knight) :: Agents 1 and 2 say B is knight
c2 :: ASSERT :: STMT_TRUE(B) :: B's statement is true
c3 :: ASSERT :: COUNT(exactly,1,spy,A,B,C,D) :: exactly one spy exists
e1 :: INFER :: FROM(c3) :: TO(c2) :: B's statement is true because exactly one spy exists
```

Return only claim, case, and relation lines, without Markdown or explanation.
