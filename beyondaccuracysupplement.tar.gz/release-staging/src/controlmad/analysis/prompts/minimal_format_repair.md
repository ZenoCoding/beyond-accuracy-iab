# Format-only repair

Source field:

$source_text

Prior translation:

$raw_response

Parser errors:

$errors

Preserve every valid claim, case, relation, expression, commitment, attribution, and endpoint. Do not improve the reasoning, add missing meaning, insert premises, or remove logically dubious relations. Correct only listed syntax, exact-span, or reference failures. If an invalid relation cannot satisfy containment without changing endpoints, omit that relation but keep all claims.

Every TO has one claim ID.

Return the complete repaired translation only, without Markdown or explanation.
