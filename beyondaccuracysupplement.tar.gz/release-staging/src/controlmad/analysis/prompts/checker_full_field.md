# Conservative claim audit

Source field—the only evidence allowed:

$source_text

Fixed claims (read-only; IDs and unchanged fields must be preserved), followed by fixed cases and relations:

$fixed_inventory

Return zero or more lines:

`REPLACE :: cN :: COMMITMENT :: EXPRESSION :: exact verbatim source span`

`ADD :: cN :: COMMITMENT :: EXPRESSION :: exact verbatim source span`

`REMOVE :: cN :: short reason`

Commitments are `ASSERT`, `OPAQUE`, `ASSUME(hN)`, `HYPOTHETICAL(hN)`, and `ATTRIBUTED(NEUTRAL|ENDORSE|REJECT;targets)`. Neutral attribution records quoted content and does not assert it as true.

Replace only a concrete mismatch with the claim's own span. Add only an omitted explicit atomic proposition. Remove only an unsupported duplicate or item with no source proposition. Never edit cases; never edit or add relations. Do not add a derived or merely implied claim, insert hidden premises, paraphrase a span, or erase structure into `ABSTAIN`.

Return `NONE` when no patch is justified. Return lines only.
