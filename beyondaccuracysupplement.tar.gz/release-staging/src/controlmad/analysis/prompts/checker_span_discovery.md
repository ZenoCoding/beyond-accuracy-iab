# Omitted-span discovery

Source field—the only evidence allowed:

$source_text

$fixed_inventory

Return each omitted explicit atomic proposition as:

`SPAN :: exact verbatim source substring`

The span must independently contain its subject, predicate, and any count/parity role and domain. Reject bare numbers, pronouns, connectors, and unresolved cross-references. Do not return implied conclusions, summaries outside the DSL, duplicates, cases, or relations. Return `NONE` when nothing is omitted.
