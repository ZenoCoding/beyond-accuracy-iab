# Resolve one routed translation suspect

Source field—the only evidence allowed:

$source_text

Canonical puzzle statements are context only. Use them only when the source explicitly refers to that player's statement:

$puzzle_context

$fixed_inventory

Target claim: `$target_claim`

Suspect types: $suspect_types

Return one `REPLACE` line for `$claim_id` only when a source-supported correction is necessary; otherwise return `NONE`. Cases, relations, and non-target claims are immutable. Never replace a structured expression with `ABSTAIN`. A scope-sensitive replacement may use canonical content only when the source explicitly links to it.

$uncertain_instruction

Return one line only.
