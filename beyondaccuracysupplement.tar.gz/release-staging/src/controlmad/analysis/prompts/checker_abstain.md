# Resolve one uncertain expression

Source field—the only evidence allowed:

$source_text

$fixed_inventory

Target uncertain claim: `$target_claim`

If the exact proposition supports a compact expression, return one structured `REPLACE` line for `$claim_id`. Preserve proposition granularity and commitment. You may expand the span only to a verbatim substring directly stating that same proposition. If representation requires guessing, return `NONE`. Never edit another claim, case, or relation.

Return one line only.
