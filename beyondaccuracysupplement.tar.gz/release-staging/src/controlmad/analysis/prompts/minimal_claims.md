# Task

Translate one KKS reasoning field into atomic claims, flat cases, and explicitly stated reasoning moves.

## Context

Puzzle statements (`speaker :: text :: canonical expression`):

$statements

Rules: each player has exactly one role; exactly one is a spy; knights speak truthfully; knaves falsely; spies may say either.

Field metadata: $location

Debate agents: $debate_agents

Submitted roles (context only; do not add claims absent from the source): $submitted

Source field:

$source_text

## Claim output

Return one line per explicit proposition, in source order:

`c1 :: COMMITMENT :: EXPRESSION :: exact verbatim source span`

Commitments:

- `ASSERT`: the current speaker presents the proposition as unconditionally true.
- `ASSUME(h1)`: the proposition opens hypothetical case `h1`.
- `HYPOTHETICAL(h1)`: the proposition is claimed only inside case `h1`.
- `ATTRIBUTED(NEUTRAL;TARGETS)`: quoted, paraphrased, assigned, or mentioned content. It records content but does not assert that content is true.
- `ATTRIBUTED(ENDORSE;TARGETS)`: the current speaker explicitly accepts the attributed content.
- `ATTRIBUTED(REJECT;TARGETS)`: the current speaker explicitly rejects the attributed content. Rejection does not automatically assert its logical negation.
- `OPAQUE`: meaningful content outside the expression language; pair it with `ABSTAIN`.

Targets are `player:B`, `agent:agent-1`, or comma-separated lists. “All agents” includes the field speaker; “all peers” excludes the field speaker.

Canonical neutral-attribution form: `ATTRIBUTED(NEUTRAL;player:X)`.
General attribution syntax: `ATTRIBUTED(ATTITUDE;TARGETS)`.

Supported expressions:

`ROLE`, `STMT_TRUE`, `SAME_ROLE`, `NOT`, `AND`, `OR`, `XOR`, `IFF`, `IMPLIES`, `COUNT`, `PARITY`, and `ABSTAIN`.

Examples:

- “B's statement is false” → `NOT(STMT_TRUE(B))`, not the negation of a convenient fragment.
- “B's statement says X” → neutral attributed `X`; it does not assert `X`.
- “B, whose statement says X, is true” → neutral attributed `X` plus `ASSERT :: STMT_TRUE(B)`; do not assert `X`.
- “B says X, but X is false” → neutral attributed `X` plus `ASSERT :: NOT(X)`.
- “Condition (1) is false” negates condition (1), not the whole statement.
- “If A's statement is false” → `ASSUME(h2) :: NOT(STMT_TRUE(A))`.

Inventory rules:

- Split explicit role lists and explicit truth evaluations into atomic claims.
- Never split alternatives into separate assertions.
- Preserve every negation and its scope literally.
- A puzzle character's fixed statement content remains neutral attributed content even inside a hypothetical; its truth evaluation inherits the case.
- A case stays active until explicitly accepted, rejected, or exited. Do not invent nested cases that the flat schema cannot represent.
- Use `IMPLIES(P;Q)` only when the source asserts the conditional proposition itself.
- Copy one exact contiguous source span. Never paraphrase or use ellipses.
- Do not emit character offsets.
- `ASSUME`, `HYPOTHETICAL`, and neutral attributed content may use `ABSTAIN` for an explicit but unresolved reference. Do not guess a narrower domain.
- ABSTAIN is never paired with ASSERT.

## Case output

Optionally record an explicit outcome:

`h1 :: CASE(REJECTED|ACCEPTED|UNRESOLVED) :: exact verbatim outcome span`

Do not infer an outcome from the verified answer.

## Relation output

Only translate an explicit discourse move signaled by language such as “so,” “therefore,” “because,” “hence,” “contradiction,” “must,” or an unmistakable premise-to-conclusion construction:

`e1 :: INFER :: FROM(c1,c2) :: TO(c3) :: exact connector or relation span`

`e2 :: CONTRADICT :: FROM(c1,c2) :: exact connector or relation span`

`e3 :: REDUCTIO :: ASSUME(c1) :: VIA(e2) :: TO(c3) :: exact connector or relation span`

Canonical shapes include `INFER :: FROM(c1,c2) :: TO(c3)`, `CONTRADICT :: FROM(c1,c2)`, and `REDUCTIO :: ASSUME(c1)`.

Relation rules:

- Preserve the reasoning actually stated, including invalid or incomplete reasoning.
- Cite only salient premises the speaker explicitly uses in that move. Never insert an unstated premise merely because it is required for validity.
- Do not emit arithmetic-normalization edges such as zero-count → even parity.
- Do not emit component-to-`AND`/`XOR`/`IFF` or compound-to-`STMT_TRUE` proof-completion edges unless the source explicitly argues that step.
- Neutral attributed content is quoted content, not a truth premise. Do not use it as the sole logical reason for a conclusion.
- Every `TO` has one claim ID. If both P and Q are separately concluded, emit two relations.
- Every TO(...) contains exactly one claim ID.
- `REDUCTIO` is only assumption → stated contradiction → exact negation of that assumption.
- REDUCTIO is only assumption-to-exact-negation through an explicit contradiction.
- The span may be the exact connective phrase or shortest exact relation phrase. The host expands it deterministically to cover endpoint spans when possible.
- Do not reconstruct a complete proof or add transitive edges.

## Compact examples

Source: `Player C says B is spy, which is false, so C is knave.`

```text
c1 :: ATTRIBUTED(NEUTRAL;player:C) :: ROLE(B,spy) :: Player C says B is spy
c2 :: ASSERT :: NOT(STMT_TRUE(C)) :: which is false
c3 :: ASSERT :: ROLE(C,knave) :: so C is knave
e1 :: INFER :: FROM(c2) :: TO(c3) :: which is false, so C is knave
```

Source: `B's statement says A is knight. It is true, so B is knight.`

```text
c1 :: ATTRIBUTED(NEUTRAL;player:B) :: ROLE(A,knight) :: B's statement says A is knight
c2 :: ASSERT :: STMT_TRUE(B) :: It is true
c3 :: ASSERT :: ROLE(B,knight) :: so B is knight
e1 :: INFER :: FROM(c2) :: TO(c3) :: It is true, so B is knight
```

Return only claim, case, and relation lines, without Markdown or explanation.
