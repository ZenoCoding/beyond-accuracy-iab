## STAGE 1 OUTPUT OVERRIDE

- Return only cN claim lines and optional hN case lines.
- Do not return any eN relation lines in this pass. A separate call extracts relations after claims and cases are fixed.
- Do not repeat a claim solely to serve as a relation endpoint.

Return only claim and case lines, without Markdown or explanation.
