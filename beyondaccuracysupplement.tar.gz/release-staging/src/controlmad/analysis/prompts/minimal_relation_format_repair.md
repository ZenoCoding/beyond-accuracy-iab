# Relation format-only repair

$relation_instructions

Prior relation output:

$raw_response

Parser errors:

$errors

Preserve every valid relation exactly. Add only repaired `eN` IDs from rejected lines. Do not add claims, cases, new meaning, hidden premises, or missing relations.

Return the complete repaired relation output only, without Markdown or explanation.
