"""Conservative secondary checks for minimal formal-logic translations.

The checker is deliberately a patch protocol rather than a second free-form
translation.  A model may propose claim replacements, additions, or removals;
the host applies a patch only when every changed span and expression passes
deterministic checks and the patch improves a conservative source-coverage
score.  Relations and cases are immutable in this pass.
"""

from __future__ import annotations

import asyncio
import copy
import json
import re
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from controlmad.harness.config import ModelConfig
from controlmad.harness.models import ModelClient, model_client_for_config

from .formal_logic_compact import CompactParseError, format_compact_expression, parse_compact_expression
from .formal_logic_minimal import (
    FORMAT_VERSION,
    _canonical_source_span,
    _load_dataset_context,
    _parse_commitment,
)
from .prompt_templates import load_prompt, render_prompt


CHECKER_VERSION = "kks-minimal-claim-checker-v3"
CHECKER_PROMPT_VERSION = "kks-minimal-claim-checker-prompt-v3"
CHECKER_ARCHITECTURES = {
    "full_field",
    "suspect_routed",
    "abstain_resolution",
    "span_first",
    "context_routed",
}
CHECKER_SYSTEM_PROMPT = load_prompt("checker_system.md")

_CLAIM_ID = re.compile(r"c[1-9][0-9]*$")


def _claim_line(claim: Mapping[str, Any]) -> str:
    commitment = str(claim.get("commitment", "")).lower()
    if commitment in {"assume", "hypothetical"}:
        commitment_text = "%s(%s)" % (commitment.upper(), claim.get("case_id"))
    elif commitment in {"report", "endorse", "reject"}:
        attitude = {
            "report": "NEUTRAL",
            "endorse": "ENDORSE",
            "reject": "REJECT",
        }[commitment]
        commitment_text = "ATTRIBUTED(%s;%s)" % (
            attitude, ",".join(map(str, claim.get("attributions") or []))
        )
    else:
        commitment_text = commitment.upper()
    expression = (
        format_compact_expression(claim["expression"])
        if claim.get("expression") is not None
        else "ABSTAIN"
    )
    return "%s :: %s :: %s :: %s" % (
        claim["id"], commitment_text, expression, claim.get("source_span", "")
    )


def _case_line(case: Mapping[str, Any]) -> str:
    span = case.get("source_span")
    if not case.get("explicit") or not span:
        return ""
    return "%s :: CASE(%s) :: %s" % (
        case["id"], str(case.get("disposition", "unresolved")).upper(), span
    )


def _relation_line(relation: Mapping[str, Any]) -> str:
    kind = str(relation.get("kind", "")).lower()
    if kind == "infer":
        body = "INFER :: FROM(%s) :: TO(%s)" % (
            ",".join(map(str, relation.get("from") or [])), relation.get("to")
        )
    elif kind == "contradict":
        body = "CONTRADICT :: FROM(%s)" % ",".join(
            map(str, relation.get("from") or [])
        )
    elif kind == "reductio":
        body = "REDUCTIO :: ASSUME(%s) :: VIA(%s) :: TO(%s)" % (
            relation.get("assume"), relation.get("via"), relation.get("to")
        )
    else:
        return ""
    return "%s :: %s :: %s" % (relation["id"], body, relation.get("source_span", ""))


def checker_prompt(
    source_text: str,
    claims: Sequence[Mapping[str, Any]],
    cases: Sequence[Mapping[str, Any]],
    relations: Sequence[Mapping[str, Any]] = (),
) -> str:
    """Build the read-only inventory prompt for the secondary checker."""
    return render_prompt(
        "checker_full_field.md",
        source_text=source_text,
        fixed_inventory=_fixed_inventory(claims, cases, relations),
    )


def _fixed_inventory(
    claims: Sequence[Mapping[str, Any]],
    cases: Sequence[Mapping[str, Any]],
    relations: Sequence[Mapping[str, Any]],
) -> str:
    claim_lines = "\n".join(_claim_line(claim) for claim in claims) or "(none)"
    case_lines = "\n".join(
        line for line in (_case_line(case) for case in cases) if line
    ) or "(none)"
    relation_lines = "\n".join(
        line for line in (_relation_line(relation) for relation in relations) if line
    ) or "(none)"
    return (
        "Fixed claims:\n%s\n\nFixed cases:\n%s\n\nFixed relations:\n%s"
        % (claim_lines, case_lines, relation_lines)
    )


def detect_checker_suspects(record: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Deterministically route only claims with an observable surface conflict."""
    source_text = str(record.get("source_text") or "")
    suspects: list[dict[str, Any]] = []
    for claim in record.get("claims") or []:
        kinds: list[str] = []
        span = str(claim.get("source_span") or "")
        expression = claim.get("expression")
        commitment = str(claim.get("commitment") or "")
        if _canonical_source_span(span, source_text) is None:
            kinds.append("invalid_span")
        if expression is None:
            kinds.append("invalid_abstain")
        elif isinstance(expression, Mapping):
            op = str(expression.get("op") or "")
            argument = expression.get("arg") if op == "not" else None
            atomic_op = (
                str(argument.get("op") or "")
                if isinstance(argument, Mapping)
                else op
            )
            if atomic_op == "role_is":
                atom = argument if isinstance(argument, Mapping) else expression
                expected_negative = op == "not"
                if _role_polarity_supported(
                    span, atom.get("player"), atom.get("role"), not expected_negative
                ):
                    kinds.append("polarity")
            elif atomic_op == "statement_true":
                atom = argument if isinstance(argument, Mapping) else expression
                expected_true = op != "not"
                if _statement_polarity_supported(
                    span, atom.get("player"), not expected_true
                ):
                    kinds.append("polarity")
            if op in {"count_role", "parity"}:
                mentioned_players = {
                    ord(match.group(0).upper()) - ord("A")
                    for match in re.finditer(r"(?<![A-Za-z0-9_])[A-Z](?![A-Za-z0-9_])", span)
                }
                expression_players = set(map(int, expression.get("players") or []))
                # Route only an explicit enumerated-domain disagreement. Short
                # contextual spans such as "one spy" do not expose a domain
                # and therefore are not deterministic suspects.
                if len(mentioned_players) >= 2 and mentioned_players != expression_players:
                    kinds.append("count_parity_domain")
        if commitment == "assert" and bool(re.search(
            r"\b(?:says?|reports?|reported|claims?|according to|assigned)\b",
            span,
            re.I,
        )) and not _commitment_surface_supported(claim, span):
            kinds.append("report_assert")
        if kinds:
            suspects.append({
                "claim_id": str(claim.get("id")),
                "kinds": sorted(set(kinds)),
                "claim": copy.deepcopy(dict(claim)),
            })
    return suspects


def _walk_expressions(expression: Any):
    if not isinstance(expression, Mapping):
        return
    yield expression
    for key in ("arg", "left", "right"):
        yield from _walk_expressions(expression.get(key))


def _scope_shape(expression: Mapping[str, Any]) -> tuple[Any, ...] | None:
    op = str(expression.get("op") or "")
    if op == "parity":
        return op, expression.get("parity"), expression.get("role")
    if op == "count_role":
        return (
            op,
            expression.get("comparison"),
            expression.get("count"),
            expression.get("role"),
        )
    return None


def _puzzle_context_text(question: Mapping[str, Any] | None) -> str:
    if not question:
        return "(not supplied; do not infer a missing scope)"
    return "\n".join(
        "%s :: %s :: %s" % (
            item["speaker"],
            item["text"],
            format_compact_expression(item["ast"]),
        )
        for item in question.get("statements") or []
    )


def _nearby_statement_speakers(source_text: str, span: str) -> set[int]:
    start = source_text.find(span)
    if start < 0:
        return set()
    window = source_text[max(0, start - 80):start + len(span) + 120]
    return {
        ord(match.group(1).upper()) - ord("A")
        for match in re.finditer(
            r"(?:Player\s+)?([A-Z])(?:'s)?\s+(?:first\s+|second\s+)?(?:claim|statement)",
            window,
            re.I,
        )
    }


def detect_scope_suspects(
    record: Mapping[str, Any],
    question: Mapping[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Route count/parity claims whose domain depends on a nearby statement reference."""
    source_text = str(record.get("source_text") or "")
    suspects: list[dict[str, Any]] = []
    statements = list(question.get("statements") or []) if question else []
    for claim in record.get("claims") or []:
        expression = claim.get("expression")
        if not isinstance(expression, Mapping) or _scope_shape(expression) is None:
            continue
        span = str(claim.get("source_span") or "")
        speakers = _nearby_statement_speakers(source_text, span)
        if not speakers:
            continue
        kinds: list[str] = []
        if question:
            candidates = [
                candidate
                for speaker in speakers
                if 0 <= speaker < len(statements)
                for candidate in _walk_expressions(statements[speaker].get("ast"))
                if _scope_shape(candidate) == _scope_shape(expression)
            ]
            if candidates and not any(candidate == expression for candidate in candidates):
                kinds.append("scope_domain")
        elif not all(
            _player_supported(span, player)
            for player in expression.get("players") or []
        ):
            kinds.append("scope_uncertain")
        if kinds:
            suspects.append({
                "claim_id": str(claim.get("id")),
                "kinds": kinds,
                "claim": copy.deepcopy(dict(claim)),
            })
    return suspects


def context_routed_suspects(
    record: Mapping[str, Any],
    question: Mapping[str, Any] | None = None,
) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    for suspect in [
        *detect_checker_suspects(record),
        *detect_scope_suspects(record, question),
    ]:
        claim_id = str(suspect["claim_id"])
        if claim_id not in merged:
            merged[claim_id] = copy.deepcopy(dict(suspect))
        else:
            merged[claim_id]["kinds"] = sorted(set(
                list(merged[claim_id]["kinds"]) + list(suspect["kinds"])
            ))
    return list(merged.values())


def suspect_checker_prompt(
    record: Mapping[str, Any],
    suspect: Mapping[str, Any],
    question: Mapping[str, Any] | None = None,
    *,
    allow_uncertain: bool = False,
) -> str:
    """Build a single-claim review prompt with field context."""
    claim = suspect["claim"]
    uncertain_instruction = (
        "If canonical context is unavailable and the target is genuinely ambiguous, "
        "return `UNCERTAIN :: %s :: short reason`; this is metadata only." % claim["id"]
        if allow_uncertain else "Do not return uncertainty metadata in this route."
    )
    return render_prompt(
        "checker_suspect.md",
        source_text=record.get("source_text", ""),
        puzzle_context=_puzzle_context_text(question),
        fixed_inventory=_fixed_inventory(
            record.get("claims") or [],
            record.get("cases") or [],
            record.get("relations") or [],
        ),
        target_claim=_claim_line(claim),
        suspect_types=", ".join(map(str, suspect.get("kinds") or [])),
        claim_id=claim["id"],
        uncertain_instruction=uncertain_instruction,
    )


def abstain_checker_prompt(
    record: Mapping[str, Any], claim: Mapping[str, Any]
) -> str:
    """Ask a stronger model to resolve one explicitly uncertain expression."""
    return render_prompt(
        "checker_abstain.md",
        source_text=record.get("source_text", ""),
        fixed_inventory=_fixed_inventory(
            record.get("claims") or [],
            record.get("cases") or [],
            record.get("relations") or [],
        ),
        target_claim=_claim_line(claim),
        claim_id=claim["id"],
    )


def span_discovery_prompt(record: Mapping[str, Any]) -> str:
    """Find omitted explicit proposition spans without translating them yet."""
    return render_prompt(
        "checker_span_discovery.md",
        source_text=record.get("source_text", ""),
        fixed_inventory=_fixed_inventory(
            record.get("claims") or [],
            record.get("cases") or [],
            record.get("relations") or [],
        ),
    )


def _span_is_self_contained_proposition(span: str) -> bool:
    """Reject context fragments before a model is allowed to translate them."""
    if len(span.split()) < 3 or not re.search(r"[A-Za-z]", span):
        return False
    return bool(re.search(
        r"\b(?:knights?|knaves?|sp(?:y|ies)|true|false|same role|count|"
        r"exactly|at least|at most|even|odd|parity)\b",
        span,
        re.I,
    ))


def parse_discovered_spans(content: str, source_text: str) -> tuple[list[str], list[str]]:
    spans: list[str] = []
    errors: list[str] = []
    if content.strip() == "NONE":
        return spans, errors
    for line_number, raw in enumerate(content.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("```"):
            continue
        if not line.startswith("SPAN :: "):
            errors.append("line %d: expected SPAN" % line_number)
            continue
        canonical = _canonical_source_span(line.removeprefix("SPAN :: ").strip(), source_text)
        if canonical is None:
            errors.append("line %d: span is not a unique source substring" % line_number)
            continue
        if not _span_is_self_contained_proposition(canonical):
            errors.append("line %d: span is not a self-contained proposition" % line_number)
            continue
        if canonical not in spans:
            spans.append(canonical)
    return spans, errors


def span_translation_prompt(
    record: Mapping[str, Any], spans: Sequence[str]
) -> str:
    """Translate only host-validated proposition spans."""
    return render_prompt(
        "checker_span_translation.md",
        source_text=record.get("source_text", ""),
        fixed_inventory=_fixed_inventory(
            record.get("claims") or [],
            record.get("cases") or [],
            record.get("relations") or [],
        ),
        spans="\n".join("- " + span for span in spans),
    )


def parse_checker_patch(content: str) -> tuple[list[dict[str, str]], list[str]]:
    """Parse the small line-oriented checker patch protocol."""
    operations: list[dict[str, str]] = []
    errors: list[str] = []
    if content.strip() == "NONE":
        return operations, errors
    for line_number, raw in enumerate(content.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("```"):
            continue
        parts = [part.strip() for part in line.split(" :: ", 4)]
        operation = parts[0].upper() if parts else ""
        if operation in {"REPLACE", "ADD"}:
            if len(parts) != 5:
                errors.append(
                    "line %d: %s requires id, commitment, expression, and span"
                    % (line_number, operation)
                )
                continue
            operations.append({
                "op": operation.lower(),
                "id": parts[1],
                "commitment": parts[2],
                "expression": parts[3],
                "source_span": parts[4],
                "line": str(line_number),
            })
        elif operation == "REMOVE":
            parts = [part.strip() for part in line.split(" :: ", 2)]
            if len(parts) != 3:
                errors.append("line %d: REMOVE requires id and reason" % line_number)
                continue
            operations.append({
                "op": "remove",
                "id": parts[1],
                "reason": parts[2],
                "line": str(line_number),
            })
        else:
            errors.append("line %d: unknown checker operation" % line_number)
    return operations, errors


def parse_checker_uncertainties(content: str) -> list[dict[str, str]]:
    uncertainties: list[dict[str, str]] = []
    for line_number, raw in enumerate(content.splitlines(), start=1):
        line = raw.strip()
        if not line.startswith("UNCERTAIN :: "):
            continue
        parts = [part.strip() for part in line.split(" :: ", 2)]
        if len(parts) == 3 and _CLAIM_ID.fullmatch(parts[1]):
            uncertainties.append({
                "id": parts[1], "reason": parts[2], "line": str(line_number)
            })
    return uncertainties


def _patch_content_without_uncertainties(content: str) -> str:
    lines = [
        line for line in content.splitlines()
        if not line.strip().startswith("UNCERTAIN :: ")
    ]
    return "\n".join(lines).strip() or "NONE"


def classify_abstain_claim(claim: Mapping[str, Any]) -> str:
    """Separate likely format limits from unresolved model uncertainty."""
    if claim.get("expression") is not None:
        return "structured"
    span = str(claim.get("source_span") or "")
    if re.search(
        r"\b(?:allow(?:s|ed)?|consistent|fit|fits|match(?:es|ed)?|"
        r"satisf(?:y|ies|ied|ying)|solution|summary|uniquely)\b",
        span,
        re.I,
    ):
        return "unrepresentable"
    return "uncertain"


def _word(text: str, token: str) -> bool:
    return bool(re.search(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(token), text, re.I))


def _player_supported(span: str, player: Any) -> bool:
    letter = chr(ord("A") + int(player))
    # Requiring a standalone letter avoids treating the A in "Assume" as a
    # player while still accepting ordinary KKS prose such as "A is knight".
    return _word(span, letter) or bool(re.search(r"\bplayer\s+%s\b" % letter, span, re.I))


def _role_word_supported(span: str, role: Any) -> bool:
    role_patterns = {
        "knight": r"knights?",
        "knave": r"knaves?",
        "spy": r"sp(?:y|ies)",
    }
    role_pattern = role_patterns.get(str(role).lower(), re.escape(str(role)))
    return bool(
        re.search(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % role_pattern, span, re.I)
    )


def _role_supported(span: str, player: Any, role: Any) -> bool:
    return _player_supported(span, player) and _role_word_supported(span, role)


def _role_polarity_supported(span: str, player: Any, role: Any, negated: bool) -> bool:
    """Check whether a role mention is locally positive or negated.

    This is not a natural-language parser.  The short local window merely
    prevents an easy polarity error (``A is knight`` versus ``A is not
    knight``) from scoring as equally well as its correction.
    """
    if not _role_supported(span, player, role):
        return False
    letter = chr(ord("A") + int(player))
    role_word = {
        "knight": r"knights?",
        "knave": r"knaves?",
        "spy": r"sp(?:y|ies)",
    }.get(str(role).lower(), re.escape(str(role)))
    phrase = re.compile(
        r"\b%s\b[^.!?;:]{0,45}\b%s\b" % (letter, role_word), re.I
    )
    matches = list(phrase.finditer(span))
    if not matches:
        return False
    for match in matches:
        has_negation = bool(re.search(
            r"\b(?:not|cannot|can't|never|isn't|isnt|impossible)\b",
            match.group(0),
            re.I,
        ))
        # Do not borrow a role word from a neighboring player in a list.  For
        # example, ``A is knight and B is knave`` must not support
        # ROLE(A,knave).
        other_player = re.search(
            r"\b(?!%s\b)[A-Z]\b" % re.escape(letter),
            match.group(0)[1:],
            re.I,
        )
        if other_player:
            continue
        if has_negation == negated:
            return True
    return False


def _statement_polarity_supported(span: str, player: Any, truth: bool) -> bool:
    if not _player_supported(span, player):
        return False
    # Require the truth word to occur near the referenced player's statement;
    # otherwise a neighboring claim's "true/false" can create a false match.
    letter = chr(ord("A") + int(player))
    phrase = re.compile(
        r"\b%s\b[^.!?;:]{0,55}\b(?:statement|claim|proposition|says?)\b[^.!?;:]{0,35}\b(?:true|false|truth|correct|accurate|valid)\b"
        % letter,
        re.I,
    )
    candidates = [match.group(0) for match in phrase.finditer(span)]
    if not candidates:
        # Reported-proposition form: "C says B is spy, which is false." The
        # truth predicate applies to what C says even though the noun
        # "statement" is absent.
        reported = re.compile(
            r"\b%s\b[^.!?;:]{0,12}\b(?:says?|claims?)\b[^.!?;:]{0,80}\b(?:true|false|correct|incorrect|valid|invalid)\b"
            % letter,
            re.I,
        )
        candidates = [match.group(0) for match in reported.finditer(span)]
    if not candidates:
        # Also accept the common possessive order: "B's statement is true".
        direct_subject = re.compile(
            r"\b%s\b(?:'s)?\s+(?:statement|claim|proposition)\b" % letter,
            re.I,
        )
        if direct_subject.search(span):
            candidates = [span]
    for candidate in candidates:
        false_word = bool(re.search(r"\b(?:false|not|untrue|incorrect|invalid)\b", candidate, re.I))
        true_word = bool(re.search(r"\b(?:true|truth|correct|accurate|valid)\b", candidate, re.I))
        if truth and true_word and not false_word:
            return True
        if not truth and (false_word or (true_word and _negation_supported(candidate))):
            return True
    return False


def _negation_supported(span: str) -> bool:
    return bool(re.search(
        r"\b(?:not|cannot|can't|never|false|impossible|isn't|isnt|reject(?:ed)?)\b",
        span,
        re.I,
    ))


def _expression_surface_supported(expression: Any, span: str) -> bool:
    """Conservative lexical alignment, not a semantic truth checker.

    This intentionally accepts only explicit surface cues.  It is used as a
    gate against adding an unanchored claim and as a relative quality signal
    for replacements; it never proves that a claim is logically correct.
    """
    if expression is None or not isinstance(expression, Mapping):
        return False
    op = str(expression.get("op", ""))
    if op == "role_is":
        return _role_polarity_supported(
            span, expression.get("player"), expression.get("role"), False
        )
    if op == "statement_true":
        return _statement_polarity_supported(
            span, expression.get("player"), True
        )
    if op == "same_role":
        return all(_player_supported(span, player) for player in expression.get("players", [])) and bool(
            re.search(r"\b(?:same|both)\b", span, re.I)
        )
    if op == "not":
        argument = expression.get("arg")
        if isinstance(argument, Mapping) and argument.get("op") == "role_is":
            return _role_polarity_supported(
                span, argument.get("player"), argument.get("role"), True
            )
        if isinstance(argument, Mapping) and argument.get("op") == "statement_true":
            return _statement_polarity_supported(
                span, argument.get("player"), False
            )
        return _negation_supported(span) and _expression_surface_supported(argument, span)
    if op in {"and", "or", "xor", "iff", "implies"}:
        left = expression.get("left")
        right = expression.get("right")
        cue = {
            "and": r"\b(?:and|also|both|as well as)\b",
            "or": r"\b(?:or|either|alternative)\b",
            "xor": r"\b(?:but not both|exactly one|either)\b",
            "iff": r"\b(?:iff|if and only if|equivalent)\b",
            "implies": r"\b(?:if|then|therefore|thus|so|implies)\b",
        }[op]
        return bool(re.search(cue, span, re.I)) and _expression_surface_supported(
            left, span
        ) and _expression_surface_supported(right, span)
    if op in {"count_role", "parity"}:
        role = expression.get("role")
        players = expression.get("players", [])
        if not _role_word_supported(span, role):
            return False
        all_players_explicit = all(
            _player_supported(span, player) for player in players
        )
        if op == "count_role":
            count_cue = bool(re.search(
                r"\b(?:count|exactly|at least|at most|one|two|three|four)\b",
                span,
                re.I,
            ))
            if all_players_explicit and count_cue:
                return True
            role_subject = {
                "knight": "knights?",
                "knave": "knaves?",
                "spy": "sp(?:y|ies)",
            }.get(str(role).lower(), re.escape(str(role)))
            roster = re.search(
                r"\b%s\s+are\s+([A-Z](?:\s*(?:,|and)\s*[A-Z])*)"
                % role_subject,
                span,
                re.I,
            )
            count = expression.get("count")
            if roster and re.search(
                r"(?<!\d)%s(?!\d)" % re.escape(str(count)), span
            ):
                listed = {
                    ord(letter.upper()) - ord("A")
                    for letter in re.findall(r"\b[A-Z]\b", roster.group(1), re.I)
                }
                return bool(listed) and listed.issubset(set(map(int, players)))
            return False
        return all_players_explicit and bool(
            re.search(r"\b(?:even|odd|parity)\b", span, re.I)
        )
    return False


def _attributions_surface_supported(claim: Mapping[str, Any], span: str) -> bool:
    commitment = str(claim.get("commitment", ""))
    if commitment not in {"report", "endorse", "reject"}:
        return True
    for attribution in claim.get("attributions") or []:
        value = str(attribution)
        if value.startswith("agent:"):
            suffix = value.removeprefix("agent:")
            label = re.sub(r"^agent[- ]?", "", suffix, flags=re.I)
            if label and re.search(
                r"\bagents?[- ]?%s\b" % re.escape(label), span, re.I
            ):
                continue
            if _word(span, suffix):
                continue
            return False
        if value.startswith("player:") and not _player_supported(
            span, ord(value.removeprefix("player:" ).upper()) - ord("A")
        ):
            return False
    return True


def _commitment_surface_supported(claim: Mapping[str, Any], span: str) -> bool:
    """Check obvious stance/reporting cues without treating prose as proof."""
    commitment = str(claim.get("commitment", ""))
    if commitment == "assert":
        expression = claim.get("expression")
        truth_status = bool(
            isinstance(expression, Mapping)
            and (
                expression.get("op") == "statement_true"
                or (
                    expression.get("op") == "not"
                    and isinstance(expression.get("arg"), Mapping)
                    and expression["arg"].get("op") == "statement_true"
                )
            )
        )
        # "C says ..., which is false" reports C's proposition but asserts
        # the evaluator's truth-status judgment. The reporting verb therefore
        # does not turn the truth-status claim itself into REPORT.
        if truth_status and re.search(
            r"\b(?:true|false|correct|incorrect|valid|invalid)\b", span, re.I
        ):
            return True
        # A report is not an assertion by the current speaker.  This catches
        # the most common precision error while allowing ordinary uses of
        # "statement" and "because".
        return not bool(re.search(
            r"\b(?:says?|reports?|reported|claims?|according to|assigned)\b",
            span,
            re.I,
        ))
    if commitment == "assume":
        return bool(re.search(r"\b(?:assume|suppose|if|were)\b", span, re.I))
    if commitment == "report":
        return bool(re.search(
            r"\b(?:says?|reports?|reported|claims?|according to|assigned|agree|consensus)\b",
            span,
            re.I,
        ))
    if commitment == "endorse":
        return bool(re.search(
            r"\b(?:endorse|agree|accept|adopt|support|concur)\b", span, re.I
        ))
    if commitment == "reject":
        return bool(re.search(
            r"\b(?:reject|rejects|rejected|disagree|deny|denies|refute)\b",
            span,
            re.I,
        ))
    # HYPOTHETICAL claims inherit an already-open case and often have no local
    # opener ("Then B is knave"); OPAQUE has no expression to align.
    return True


def _alignment_score(claim: Mapping[str, Any]) -> int:
    span = str(claim.get("source_span", ""))
    expression = claim.get("expression")
    if not span or expression is None:
        return 0
    return int(
        _expression_surface_supported(expression, span)
        and _commitment_surface_supported(claim, span)
        and _attributions_surface_supported(claim, span)
    )


def _is_atomic_expression(expression: Any) -> bool:
    """Return whether an expression is one atomic proposition (optionally negated)."""
    if not isinstance(expression, Mapping):
        return False
    if expression.get("op") == "not":
        return _is_atomic_expression(expression.get("arg"))
    return expression.get("op") in {"role_is", "statement_true", "same_role", "count_role", "parity"}


def _claim_signature(claim: Mapping[str, Any]) -> tuple[Any, ...]:
    return (
        str(claim.get("commitment")),
        str(claim.get("case_id")),
        tuple(sorted(map(str, claim.get("attributions") or []))),
        json.dumps(claim.get("expression"), sort_keys=True, separators=(",", ":")),
        str(claim.get("source_span")),
    )


def _quality(
    claims: Sequence[Mapping[str, Any]], source_text: str | None = None
) -> tuple[int, int, int]:
    invalid = sum(
        bool(
            claim.get("expression") is not None
            and (
                _alignment_score(claim) == 0
                or (
                    source_text is not None
                    and _canonical_source_span(
                        str(claim.get("source_span", "")), source_text
                    ) is None
                )
            )
        )
        for claim in claims
    )
    counts = Counter(_claim_signature(claim) for claim in claims)
    duplicate_extras = sum(max(0, count - 1) for count in counts.values())
    alignment = sum(_alignment_score(claim) for claim in claims)
    # Lower is better.  Alignment is only consulted after invalid claims and
    # exact duplicates, making the acceptance rule intentionally conservative.
    return invalid, duplicate_extras, -alignment


def _relation_references(relations: Sequence[Mapping[str, Any]]) -> set[str]:
    references: set[str] = set()
    for relation in relations:
        references.update(map(str, relation.get("from") or []))
        for key in ("to", "assume"):
            if relation.get(key):
                references.add(str(relation[key]))
    return references


def _validate_claim(claim: Mapping[str, Any], source_text: str, case_ids: set[str]) -> list[str]:
    errors: list[str] = []
    claim_id = str(claim.get("id", ""))
    if not _CLAIM_ID.fullmatch(claim_id):
        errors.append("invalid claim id %s" % claim_id)
    span = _canonical_source_span(str(claim.get("source_span", "")), source_text)
    if span is None:
        errors.append("source span is not an exact or safe-normalized source substring")
    commitment = str(claim.get("commitment", ""))
    if commitment in {"assume", "hypothetical"}:
        case_id = str(claim.get("case_id") or "")
        if not re.fullmatch(r"h[1-9][0-9]*", case_id) or case_id not in case_ids:
            errors.append("claim references unknown case %s" % case_id)
        commitment_text = "%s(%s)" % (commitment.upper(), case_id)
    elif commitment in {"report", "endorse", "reject"}:
        attributions = list(map(str, claim.get("attributions") or []))
        if not attributions:
            errors.append("attribution commitment has no targets")
        for attribution in attributions:
            if not re.fullmatch(r"(?:player:[A-Za-z]|agent:agent-[A-Za-z0-9_.-]+)", attribution):
                errors.append("invalid attribution target %s" % attribution)
        commitment_text = "%s(%s)" % (commitment.upper(), ",".join(attributions))
    else:
        commitment_text = commitment.upper()
    try:
        parsed_commitment, parsed_case, parsed_attrs = _parse_commitment(commitment_text)
        if parsed_commitment != commitment:
            errors.append("commitment does not round-trip")
        if commitment in {"assume", "hypothetical"} and parsed_case != claim.get("case_id"):
            errors.append("case ID does not round-trip")
        if commitment in {"report", "endorse", "reject"} and parsed_attrs != list(claim.get("attributions") or []):
            errors.append("attributions do not round-trip")
    except (TypeError, ValueError) as exc:
        errors.append(str(exc))
    expression = claim.get("expression")
    if commitment == "opaque" and expression is not None:
        errors.append("OPAQUE requires ABSTAIN")
    if commitment not in {"opaque", "report", "assume", "hypothetical"} and expression is None:
        errors.append("ABSTAIN is not allowed for %s" % commitment.upper())
    if expression is not None:
        try:
            # Round-trip through the compact language to reject hand-built ASTs
            # and operators outside the supported expression boundary.
            parsed = parse_compact_expression(format_compact_expression(expression))
            if parsed != expression:
                errors.append("expression is not canonical")
        except (CompactParseError, KeyError, TypeError, ValueError) as exc:
            errors.append("unsupported expression: %s" % exc)
    return errors


def apply_checker_patch(
    claims: Sequence[Mapping[str, Any]],
    cases: Sequence[Mapping[str, Any]],
    relations: Sequence[Mapping[str, Any]],
    source_text: str,
    operations: Sequence[Mapping[str, str]],
) -> tuple[list[dict[str, Any]], list[str]]:
    """Apply and validate operations, returning a candidate or rejection errors."""
    candidate = [copy.deepcopy(dict(claim)) for claim in claims]
    baseline_ids = {str(claim.get("id")) for claim in candidate}
    case_ids = {str(case.get("id")) for case in cases}
    relation_refs = _relation_references(relations)
    seen_ops: set[str] = set()
    errors: list[str] = []
    by_id = {str(claim.get("id")): claim for claim in candidate}
    for operation in operations:
        operation_id = str(operation.get("id", ""))
        if operation_id in seen_ops:
            errors.append("duplicate patch operation for %s" % operation_id)
            continue
        seen_ops.add(operation_id)
        kind = str(operation.get("op", "")).lower()
        if kind == "remove":
            if operation_id not in by_id:
                errors.append("cannot remove unknown claim %s" % operation_id)
            elif operation_id in relation_refs:
                errors.append("cannot remove relation-referenced claim %s" % operation_id)
            elif sum(
                _claim_signature(claim) == _claim_signature(by_id[operation_id])
                for claim in candidate
            ) < 2:
                # A checker cannot prove that a merely surprising claim is
                # false.  Restrict removals to exact duplicate records; a
                # human or gold audit can handle genuine semantic false
                # positives later.
                errors.append("cannot remove a non-duplicate claim %s" % operation_id)
            else:
                candidate = [claim for claim in candidate if str(claim.get("id")) != operation_id]
                by_id.pop(operation_id, None)
            continue
        if kind not in {"add", "replace"}:
            errors.append("unknown patch operation %s" % kind)
            continue
        if not _CLAIM_ID.fullmatch(operation_id):
            errors.append("invalid patch claim ID %s" % operation_id)
            continue
        if kind == "add" and operation_id in by_id:
            errors.append("ADD reuses claim ID %s" % operation_id)
            continue
        if kind == "replace" and operation_id not in by_id:
            errors.append("REPLACE targets unknown claim %s" % operation_id)
            continue
        try:
            commitment, case_id, attributions = _parse_commitment(operation["commitment"])
            expression = parse_compact_expression(operation["expression"])
        except (CompactParseError, TypeError, ValueError) as exc:
            errors.append("%s %s: %s" % (kind.upper(), operation_id, exc))
            continue
        if kind == "add" and expression is not None and not _is_atomic_expression(expression):
            errors.append("ADD %s must contain one atomic expression" % operation_id)
            continue
        claim = {
            "id": operation_id,
            "commitment": commitment,
            "case_id": case_id,
            "attributions": attributions,
            "expression": expression,
            "source_span": operation["source_span"],
        }
        claim_errors = _validate_claim(claim, source_text, case_ids)
        if claim_errors:
            errors.extend("%s %s: %s" % (kind.upper(), operation_id, error) for error in claim_errors)
            continue
        canonical_span = _canonical_source_span(operation["source_span"], source_text)
        assert canonical_span is not None
        claim["source_span"] = canonical_span
        if kind == "replace":
            old = by_id[operation_id]
            # The checker may correct a structured translation, but it cannot
            # improve its score merely by erasing semantic content into
            # OPAQUE/ABSTAIN. Whether an explicit proposition is truly
            # untranslatable requires human adjudication, not this lexical
            # safety gate.
            if old.get("expression") is not None and claim.get("expression") is None:
                errors.append(
                    "REPLACE %s cannot erase a structured expression" % operation_id
                )
                continue
            # A replacement can change translation fields, but it may not move
            # an endpoint outside any immutable relation span.
            for relation in relations:
                relation_span = str(relation.get("source_span", ""))
                if operation_id in set(map(str, relation.get("from") or [])) | {
                    str(relation.get("to")), str(relation.get("assume"))
                } and claim["source_span"] not in relation_span:
                    errors.append("REPLACE %s leaves relation span containment" % operation_id)
                    break
            else:
                index = candidate.index(old)
                candidate[index] = claim
                by_id[operation_id] = claim
        else:
            candidate.append(claim)
            by_id[operation_id] = claim
    if errors:
        return candidate, errors
    if {str(claim.get("id")) for claim in candidate} != (baseline_ids | {
        str(operation.get("id")) for operation in operations if operation.get("op") == "add"
    }) - {
        str(operation.get("id")) for operation in operations if operation.get("op") == "remove"
    }:
        errors.append("candidate claim IDs are not stable")
    for claim in candidate:
        errors.extend("%s: %s" % (claim.get("id"), error) for error in _validate_claim(claim, source_text, case_ids))
    return candidate, errors


def validate_checker_candidate(
    before_claims: Sequence[Mapping[str, Any]],
    candidate_claims: Sequence[Mapping[str, Any]],
    cases: Sequence[Mapping[str, Any]],
    relations: Sequence[Mapping[str, Any]],
    source_text: str,
    operations: Sequence[Mapping[str, str]],
    parse_errors: Sequence[str] = (),
) -> tuple[bool, list[str]]:
    """Apply conservative acceptance rules after patch parsing."""
    reasons: list[str] = []
    if parse_errors:
        reasons.extend("patch: %s" % error for error in parse_errors)
    before_by_id = {str(claim["id"]): claim for claim in before_claims}
    after_by_id = {str(claim["id"]): claim for claim in candidate_claims}
    changed_ids = {str(operation.get("id")) for operation in operations}
    for claim_id, claim in before_by_id.items():
        if claim_id not in changed_ids and after_by_id.get(claim_id) != claim:
            reasons.append("unaffected claim changed: %s" % claim_id)
    for case in cases:
        if not case.get("id"):
            reasons.append("case without ID")
    if any(
        str(operation.get("op")) == "remove"
        and str(operation.get("id")) in _relation_references(relations)
        for operation in operations
    ):
        reasons.append("patch removes a relation endpoint")
    # Explicit additions/replacements need a positive surface anchor.  This is
    # stricter than mere substring containment and catches invented formulas.
    for operation in operations:
        claim = after_by_id.get(str(operation.get("id")))
        if claim is None or claim.get("expression") is None:
            continue
        if _alignment_score(claim) == 0:
            reasons.append("%s %s has no explicit surface support" % (
                str(operation.get("op", "")).upper(), operation.get("id")
            ))
    before_quality = _quality(before_claims, source_text)
    after_quality = _quality(candidate_claims, source_text)
    if not operations:
        reasons.append("empty patch")
    elif after_quality >= before_quality:
        reasons.append(
            "patch does not improve conservative quality (%s -> %s)"
            % (before_quality, after_quality)
        )
    return not reasons, reasons


def evaluate_checker_patch(
    record: Mapping[str, Any],
    patch_text: str,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Parse, apply, and gate a model patch for one saved translation record."""
    claims = list(record.get("claims") or [])
    cases = list(record.get("cases") or [])
    relations = list(record.get("relations") or [])
    source_text = str(record.get("source_text") or "")
    operations, parse_errors = parse_checker_patch(patch_text)
    candidate, apply_errors = apply_checker_patch(
        claims, cases, relations, source_text, operations
    )
    candidate_before_gate = copy.deepcopy(candidate)
    accepted, rejection_reasons = validate_checker_candidate(
        claims, candidate, cases, relations, source_text, operations,
        [*parse_errors, *apply_errors],
    )
    if not accepted:
        candidate = [copy.deepcopy(dict(claim)) for claim in claims]
    return candidate, {
        "operations": operations,
        "patch_parse_errors": parse_errors,
        "patch_apply_errors": apply_errors,
        "accepted": accepted,
        "rejection_reasons": rejection_reasons,
        "before_quality": _quality(claims, source_text),
        "candidate_quality": _quality(candidate, source_text),
        "candidate_claims": candidate_before_gate,
    }


def _operation_line(operation: Mapping[str, str]) -> str:
    kind = str(operation.get("op", "")).upper()
    if kind == "REMOVE":
        return "REMOVE :: %s :: %s" % (
            operation.get("id", ""), operation.get("reason", "")
        )
    return "%s :: %s :: %s :: %s :: %s" % (
        kind,
        operation.get("id", ""),
        operation.get("commitment", ""),
        operation.get("expression", ""),
        operation.get("source_span", ""),
    )


def _contextually_supported_scope_replacement(
    before_claim: Mapping[str, Any],
    after_claim: Mapping[str, Any],
    record: Mapping[str, Any],
    question: Mapping[str, Any] | None,
) -> bool:
    """Accept a scope repair only when source linkage and canonical context agree."""
    if not question:
        return False
    before_expression = before_claim.get("expression")
    after_expression = after_claim.get("expression")
    if not isinstance(before_expression, Mapping) or not isinstance(after_expression, Mapping):
        return False
    if _scope_shape(before_expression) != _scope_shape(after_expression):
        return False
    if before_expression.get("players") == after_expression.get("players"):
        return False
    if any(
        before_claim.get(key) != after_claim.get(key)
        for key in ("commitment", "case_id", "attributions")
    ):
        return False
    source_text = str(record.get("source_text") or "")
    before_span = str(before_claim.get("source_span") or "")
    after_span = str(after_claim.get("source_span") or "")
    if before_span not in after_span:
        return False
    speakers = _nearby_statement_speakers(source_text, before_span)
    statements = list(question.get("statements") or [])
    canonical_matches = [
        candidate
        for speaker in speakers
        if 0 <= speaker < len(statements)
        for candidate in _walk_expressions(statements[speaker].get("ast"))
        if candidate == after_expression
    ]
    if not canonical_matches:
        return False
    role = str(after_expression.get("role") or "")
    if not _role_word_supported(after_span, role):
        return False
    if after_expression.get("op") == "parity":
        return bool(re.search(r"\b(?:even|odd|parity)\b", after_span, re.I))
    count = after_expression.get("count")
    return bool(re.search(
        r"\b(?:count|exactly|at least|at most|one|two|three|four)\b|"
        r"(?<!\d)%s(?!\d)" % re.escape(str(count)),
        after_span,
        re.I,
    ))


def evaluate_checker_operations(
    record: Mapping[str, Any],
    patch_text: str,
    *,
    allowed_ids: set[str] | None = None,
    allowed_ops: set[str] | None = None,
    allowed_spans: set[str] | None = None,
    require_structured: bool = False,
    question: Mapping[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Gate operations independently so one bad proposal cannot mask a good one."""
    current = copy.deepcopy(dict(record))
    current["claims"] = copy.deepcopy(list(record.get("claims") or []))
    uncertainties = parse_checker_uncertainties(patch_text)
    if allowed_ids is not None:
        uncertainties = [item for item in uncertainties if item["id"] in allowed_ids]
    operations, parse_errors = parse_checker_patch(
        _patch_content_without_uncertainties(patch_text)
    )
    accepted_operations: list[dict[str, str]] = []
    rejected_operations: list[dict[str, Any]] = []
    for operation in operations:
        reasons: list[str] = []
        operation_id = str(operation.get("id") or "")
        operation_kind = str(operation.get("op") or "").lower()
        if allowed_ids is not None and operation_id not in allowed_ids:
            reasons.append("operation targets a non-routed claim")
        if allowed_ops is not None and operation_kind not in allowed_ops:
            reasons.append("operation kind is not allowed in this route")
        if allowed_spans is not None and operation_kind in {"add", "replace"}:
            canonical = _canonical_source_span(
                str(operation.get("source_span") or ""),
                str(record.get("source_text") or ""),
            )
            if canonical not in allowed_spans:
                reasons.append("operation uses a span not validated by discovery")
        if require_structured and str(operation.get("expression") or "").upper() == "ABSTAIN":
            reasons.append("route requires a structured expression")
        before_claim = next(
            (
                claim for claim in current.get("claims") or []
                if str(claim.get("id")) == operation_id
            ),
            None,
        )
        if (
            require_structured
            and operation_kind == "replace"
            and before_claim is not None
            and before_claim.get("expression") is None
        ):
            old_span = _canonical_source_span(
                str(before_claim.get("source_span") or ""),
                str(record.get("source_text") or ""),
            )
            new_span = _canonical_source_span(
                str(operation.get("source_span") or ""),
                str(record.get("source_text") or ""),
            )
            if old_span != new_span:
                reasons.append("ABSTAIN resolution cannot move to a different proposition")
            if re.search(
                r"\b(?:allow(?:s|ed)?|consistent|fit|fits|match(?:es|ed)?|"
                r"satisf(?:y|ies|ied|ying)|solution|summary|uniquely)\b",
                str(before_claim.get("source_span") or ""),
                re.I,
            ):
                reasons.append(
                    "ABSTAIN span is a modal or summary proposition, not an atomic expression"
                )
        if reasons:
            rejected_operations.append({"operation": operation, "reasons": reasons})
            continue
        claims, decision = evaluate_checker_patch(current, _operation_line(operation))
        if decision["accepted"]:
            current["claims"] = claims
            accepted_operations.append(operation)
            continue
        contextual_reasons = list(decision["rejection_reasons"])
        contextual_only = all(
            "has no explicit surface support" in reason
            or "does not improve conservative quality" in reason
            for reason in contextual_reasons
        )
        candidate, apply_errors = apply_checker_patch(
            list(current.get("claims") or []),
            list(current.get("cases") or []),
            list(current.get("relations") or []),
            str(current.get("source_text") or ""),
            [operation],
        )
        before_claim = next(
            (claim for claim in current["claims"] if str(claim.get("id")) == operation_id),
            None,
        )
        after_claim = next(
            (claim for claim in candidate if str(claim.get("id")) == operation_id),
            None,
        )
        if (
            contextual_only
            and not apply_errors
            and before_claim is not None
            and after_claim is not None
            and _contextually_supported_scope_replacement(
                before_claim, after_claim, current, question
            )
        ):
            current["claims"] = candidate
            accepted_operations.append({
                **operation,
                "acceptance_basis": "canonical_puzzle_scope",
            })
            continue
        rejected_operations.append({
            "operation": operation,
            "reasons": decision["rejection_reasons"],
        })
    return list(current["claims"]), {
        "operations": operations,
        "parse_errors": parse_errors,
        "uncertainties": uncertainties,
        "accepted_operations": accepted_operations,
        "rejected_operations": rejected_operations,
        "accepted": bool(accepted_operations),
    }


async def _model_check(
    prompt: str,
    model: ModelConfig,
    client: ModelClient,
    semaphore: asyncio.Semaphore,
    timeout_seconds: float,
):
    async with semaphore:
        return await client.complete(
            model,
            [
                {"role": "system", "content": CHECKER_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            timeout_seconds,
        )


async def _check_record_architecture(
    record: Mapping[str, Any],
    model: ModelConfig,
    client: ModelClient,
    semaphore: asyncio.Semaphore,
    timeout_seconds: float,
    architecture: str,
    question: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Run one review architecture while retaining every proposal and decision."""
    working = copy.deepcopy(dict(record))
    working["claims"] = copy.deepcopy(list(record.get("claims") or []))
    reviews: list[dict[str, Any]] = []

    async def review(
        route: str,
        prompt: str,
        **gate: Any,
    ) -> None:
        response = await _model_check(
            prompt, model, client, semaphore, timeout_seconds
        )
        claims, decision = evaluate_checker_operations(
            working, response.content, **gate
        )
        working["claims"] = claims
        reviews.append({
            "route": route,
            "raw_response": response.content,
            "model": response.model,
            "usage": response.usage,
            "model_metadata": response.response_metadata,
            **decision,
        })

    if architecture == "full_field":
        await review(
            "full_field",
            checker_prompt(
                str(working.get("source_text") or ""),
                list(working.get("claims") or []),
                list(working.get("cases") or []),
                list(working.get("relations") or []),
            ),
        )
    elif architecture == "suspect_routed":
        for suspect in detect_checker_suspects(working):
            await review(
                "suspect:%s:%s" % (
                    suspect["claim_id"], ",".join(suspect["kinds"])
                ),
                suspect_checker_prompt(working, suspect),
                allowed_ids={str(suspect["claim_id"])},
                allowed_ops={"replace"},
                require_structured=True,
            )
    elif architecture == "abstain_resolution":
        abstains = [
            copy.deepcopy(dict(claim))
            for claim in working.get("claims") or []
            if claim.get("expression") is None
        ]
        for claim in abstains:
            await review(
                "abstain:%s" % claim["id"],
                abstain_checker_prompt(working, claim),
                allowed_ids={str(claim["id"])},
                allowed_ops={"replace"},
                require_structured=True,
            )
    elif architecture == "span_first":
        discovery = await _model_check(
            span_discovery_prompt(working), model, client, semaphore, timeout_seconds
        )
        spans, span_errors = parse_discovered_spans(
            discovery.content, str(working.get("source_text") or "")
        )
        reviews.append({
            "route": "span_discovery",
            "raw_response": discovery.content,
            "model": discovery.model,
            "usage": discovery.usage,
            "model_metadata": discovery.response_metadata,
            "discovered_spans": spans,
            "parse_errors": span_errors,
            "operations": [],
            "accepted_operations": [],
            "rejected_operations": [],
            "accepted": False,
        })
        if spans:
            await review(
                "span_translation",
                span_translation_prompt(working, spans),
                allowed_ops={"add"},
                allowed_spans=set(spans),
                require_structured=True,
            )
    elif architecture == "context_routed":
        for suspect in context_routed_suspects(working, question):
            await review(
                "context:%s:%s" % (
                    suspect["claim_id"], ",".join(suspect["kinds"])
                ),
                suspect_checker_prompt(
                    working,
                    suspect,
                    question,
                    allow_uncertain=True,
                ),
                allowed_ids={str(suspect["claim_id"])},
                # Without canonical puzzle statements this route is triage
                # only. The model may record uncertainty but cannot reinterpret
                # a scope-sensitive claim from local prose alone.
                allowed_ops={"replace"} if question else set(),
                require_structured=True,
                question=question,
            )
    else:
        raise ValueError("unknown checker architecture %r" % architecture)

    usage: dict[str, float] = {}
    for item in reviews:
        for key, value in (item.get("usage") or {}).items():
            if isinstance(value, (int, float)):
                usage[key] = usage.get(key, 0.0) + float(value)
    accepted_operations = [
        operation
        for item in reviews
        for operation in item.get("accepted_operations") or []
    ]
    rejected_operations = [
        operation
        for item in reviews
        for operation in item.get("rejected_operations") or []
    ]
    uncertainties = [
        uncertainty
        for item in reviews
        for uncertainty in item.get("uncertainties") or []
    ]
    output = dict(record)
    output.update({
        "claims": working["claims"],
        "checker_version": CHECKER_VERSION,
        "checker_prompt_version": CHECKER_PROMPT_VERSION,
        "checker_architecture": architecture,
        "checker_attempted": bool(reviews),
        "checker_accepted": bool(accepted_operations),
        "checker_reviews": reviews,
        "checker_raw_response": reviews[-1].get("raw_response") if reviews else None,
        "checker_after_raw_response": reviews[-1].get("raw_response") if reviews else None,
        "checker_rejection_reasons": [
            reason
            for item in reviews
            for rejected in item.get("rejected_operations") or []
            for reason in rejected.get("reasons") or []
        ],
        "checker_operations": [
            operation
            for item in reviews
            for operation in item.get("operations") or []
        ],
        "checker_accepted_operations": accepted_operations,
        "checker_rejected_operations": rejected_operations,
        "checker_uncertainties": uncertainties,
        "checker_abstain_metadata": [
            {
                "id": str(claim.get("id")),
                "status": classify_abstain_claim(claim),
                "source_span": str(claim.get("source_span") or ""),
            }
            for claim in record.get("claims") or []
            if claim.get("expression") is None
        ],
        "checker_before_claims": copy.deepcopy(list(record.get("claims") or [])),
        "checker_applied_claims": copy.deepcopy(working["claims"]),
        "checker_model_config_id": model.id,
        "checker_usage": usage,
        "checker_finished_at": datetime.now(timezone.utc).isoformat(),
    })
    return output


async def _check_record(
    record: Mapping[str, Any],
    model: ModelConfig,
    client: ModelClient,
    semaphore: asyncio.Semaphore,
    timeout_seconds: float,
) -> dict[str, Any]:
    async with semaphore:
        response = await client.complete(
            model,
            [
                {"role": "system", "content": CHECKER_SYSTEM_PROMPT},
                {"role": "user", "content": checker_prompt(
                    str(record.get("source_text") or ""),
                    list(record.get("claims") or []),
                    list(record.get("cases") or []),
                    list(record.get("relations") or []),
                )},
            ],
            timeout_seconds,
        )
    claims, decision = evaluate_checker_patch(record, response.content)
    output = dict(record)
    before_claims = copy.deepcopy(list(record.get("claims") or []))
    output.update({
        "claims": claims,
        "checker_version": CHECKER_VERSION,
        "checker_prompt_version": CHECKER_PROMPT_VERSION,
        "checker_attempted": True,
        "checker_accepted": decision["accepted"],
        "checker_rejection_reasons": decision["rejection_reasons"],
        "checker_operations": decision["operations"],
        "checker_before_quality": decision["before_quality"],
        "checker_candidate_quality": decision["candidate_quality"],
        "checker_before_claims": before_claims,
        "checker_candidate_claims": decision["candidate_claims"],
        "checker_before_raw_response": (
            record.get("raw_response") or record.get("initial_raw_response")
        ),
        "checker_raw_response": response.content,
        "checker_after_raw_response": response.content,
        "checker_applied_claims": copy.deepcopy(claims),
        "checker_model": response.model,
        "checker_model_config_id": model.id,
        "checker_model_metadata": response.response_metadata,
        "checker_usage": response.usage,
        "checker_finished_at": datetime.now(timezone.utc).isoformat(),
    })
    return output


async def generate_minimal_checker(
    input_path: Path,
    model_config: Path,
    output: Path,
    *,
    timeout_seconds: float = 300,
    concurrency: int = 5,
    architecture: str = "full_field",
    dataset_path: Path | None = None,
    model_client: ModelClient | None = None,
) -> dict[str, Any]:
    """Run the secondary claim checker over saved JSONL translations."""
    if concurrency < 1:
        raise ValueError("concurrency must be positive")
    if architecture not in CHECKER_ARCHITECTURES:
        raise ValueError(
            "architecture must be one of %s" % ", ".join(sorted(CHECKER_ARCHITECTURES))
        )
    records = [
        json.loads(line)
        for line in input_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    for index, record in enumerate(records, start=1):
        if record.get("format_version") not in {None, FORMAT_VERSION}:
            raise ValueError("record %d is not a %s translation" % (index, FORMAT_VERSION))
        if not isinstance(record.get("claims"), list) or not isinstance(record.get("cases"), list):
            raise ValueError("record %d requires parsed claims and cases" % index)
        if not isinstance(record.get("source_text"), str) or not record.get("source_text"):
            raise ValueError("record %d requires source_text" % index)
    model = ModelConfig(**(yaml.safe_load(model_config.read_text(encoding="utf-8")) or {}))
    questions = _load_dataset_context(dataset_path)[0] if dataset_path else {}
    client = model_client or model_client_for_config(model)
    semaphore = asyncio.Semaphore(concurrency)
    started = time.monotonic()
    results = await asyncio.gather(*(
        _check_record_architecture(
            record,
            model,
            client,
            semaphore,
            timeout_seconds,
            architecture,
            questions.get(str((record.get("source") or {}).get("task_id", ""))),
        )
        for record in records
    ), return_exceptions=True)
    output_records: list[dict[str, Any]] = []
    failures = 0
    for record, result in zip(records, results, strict=True):
        if not isinstance(result, BaseException):
            output_records.append(result)
            continue
        failures += 1
        output_records.append({
            **record,
            "checker_version": CHECKER_VERSION,
            "checker_prompt_version": CHECKER_PROMPT_VERSION,
            "checker_architecture": architecture,
            "checker_attempted": True,
            "checker_accepted": False,
            "checker_rejection_reasons": [
                "checker_model_error: %s: %s" % (type(result).__name__, result)
            ],
            "checker_operations": [],
            "checker_accepted_operations": [],
            "checker_rejected_operations": [],
            "checker_uncertainties": [],
            "checker_abstain_metadata": [
                {
                    "id": str(claim.get("id")),
                    "status": classify_abstain_claim(claim),
                    "source_span": str(claim.get("source_span") or ""),
                }
                for claim in record.get("claims") or []
                if claim.get("expression") is None
            ],
            "checker_reviews": [],
            "checker_before_quality": _quality(
                record.get("claims") or [], str(record.get("source_text") or "")
            ),
            "checker_candidate_quality": _quality(
                record.get("claims") or [], str(record.get("source_text") or "")
            ),
            "checker_before_claims": copy.deepcopy(record.get("claims") or []),
            "checker_candidate_claims": copy.deepcopy(record.get("claims") or []),
            "checker_before_raw_response": (
                record.get("raw_response") or record.get("initial_raw_response")
            ),
            "checker_raw_response": None,
            "checker_after_raw_response": None,
            "checker_applied_claims": copy.deepcopy(record.get("claims") or []),
            "checker_model": None,
            "checker_model_config_id": model.id,
            "checker_model_metadata": {},
            "checker_usage": {},
            "checker_model_error": "%s: %s" % (type(result).__name__, result),
            "checker_finished_at": datetime.now(timezone.utc).isoformat(),
        })
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in output_records),
        encoding="utf-8",
    )
    accepted = sum(bool(record.get("checker_accepted")) for record in output_records)
    usage: dict[str, float] = {}
    for record in output_records:
        for key, value in (record.get("checker_usage") or {}).items():
            if isinstance(value, (int, float)):
                usage[key] = usage.get(key, 0.0) + float(value)
    accepted_operations = sum(
        len(record.get("checker_accepted_operations") or [])
        for record in output_records
    )
    rejected_operations = sum(
        len(record.get("checker_rejected_operations") or [])
        for record in output_records
    )
    return {
        "input": str(input_path),
        "output": str(output),
        "checker_version": CHECKER_VERSION,
        "architecture": architecture,
        "dataset_context": str(dataset_path) if dataset_path else None,
        "model": model.model,
        "reasoning_effort": model.params.get("reasoning_effort"),
        "field_count": len(output_records),
        "attempted_count": len(output_records),
        "accepted_count": accepted,
        "accepted_operation_count": accepted_operations,
        "rejected_operation_count": rejected_operations,
        "uncertainty_count": sum(
            len(record.get("checker_uncertainties") or [])
            for record in output_records
        ),
        "model_call_count": sum(
            len(record.get("checker_reviews") or []) for record in output_records
        ),
        "acceptance_rate": accepted / len(output_records) if output_records else None,
        "model_failure_count": failures,
        "usage": usage,
        "wall_time_seconds": time.monotonic() - started,
    }


def run_minimal_checker(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return asyncio.run(generate_minimal_checker(*args, **kwargs))
