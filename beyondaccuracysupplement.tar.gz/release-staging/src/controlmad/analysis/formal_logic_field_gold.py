"""Evaluate compact translations against model-independent whole-field gold."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from .formal_logic_compact import expression_contains


def load_field_gold(path: Path) -> list[dict[str, Any]]:
    fields = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    ids = [str(field["id"]) for field in fields]
    if len(ids) != len(set(ids)):
        raise ValueError("field gold IDs must be unique")
    for field in fields:
        claim_ids = [str(claim["id"]) for claim in field["required_claims"]]
        if len(claim_ids) != len(set(claim_ids)):
            raise ValueError("required claim IDs must be unique within a field")
        known = set(claim_ids)
        for claim in field["required_claims"]:
            if set(claim.get("depends_on", [])) - known:
                raise ValueError("gold dependency references an unknown claim")
        relation_ids = [
            str(relation["id"])
            for relation in field.get("required_relations", [])
        ]
        if len(relation_ids) != len(set(relation_ids)):
            raise ValueError("required relation IDs must be unique within a field")
        known_relations: set[str] = set()
        for relation in field.get("required_relations", []):
            kind = relation.get("kind")
            if kind not in {"infer", "contradict", "reductio"}:
                raise ValueError("unknown gold relation kind")
            from_options = relation.get("from_options") or [
                relation.get("from", [])
            ]
            claim_refs = [claim_id for option in from_options for claim_id in option]
            if kind == "infer":
                claim_refs.append(relation.get("to"))
            elif kind == "reductio":
                claim_refs.extend([relation.get("assume"), relation.get("to")])
                if str(relation.get("via")) not in known_relations:
                    raise ValueError("gold reductio VIA must reference an earlier relation")
            if set(map(str, claim_refs)) - known:
                raise ValueError("gold relation references an unknown claim")
            known_relations.add(str(relation["id"]))
        for case in field.get("required_cases", []):
            case_refs = {
                str(case.get("assumption_claim")),
                *map(str, case.get("member_claims", [])),
            }
            if case_refs - known:
                raise ValueError("gold case references an unknown claim")
    return fields


def load_compact_fields(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def _source_matches(actual: Mapping[str, Any], anchor: str) -> bool:
    span = str(actual.get("source_span", ""))
    return bool(span) and (anchor in span or span in anchor)


def _expression_matches(actual: Any, expected: Any) -> bool:
    return actual is not None and expression_contains(actual, expected)


def _and_atoms(expression: Any) -> list[Any]:
    if isinstance(expression, dict) and expression.get("op") == "and":
        return _and_atoms(expression["left"]) + _and_atoms(expression["right"])
    return [expression]


def _alignment_metadata_rank(
    claim: Mapping[str, Any], gold: Mapping[str, Any]
) -> tuple[int, int]:
    """Prefer metadata-faithful edges without changing expression recall."""
    stances = set(gold.get("stances", [gold.get("stance", "assert")]))
    stance_mismatch = int(claim.get("stance") not in stances)
    actual_agents = set(map(str, claim.get("agents", [])))
    expected_agents = set(gold.get("agents", []))
    if gold.get("agent_match") == "union":
        agent_mismatch = int(not actual_agents <= expected_agents)
    else:
        agent_mismatch = int(actual_agents != expected_agents)
    return stance_mismatch, agent_mismatch


def _align_required_claims(
    claims: Sequence[Mapping[str, Any]],
    required: Sequence[Mapping[str, Any]],
) -> dict[tuple[str, int], Mapping[str, Any]]:
    """Align gold atoms to explicit actual conjunct slots one-to-one.

    Flattening only AND preserves the useful ability for one compound line to
    express several claims while preventing OR from asserting either branch.
    Each actual conjunct slot can satisfy at most one gold atom.
    """
    slots: list[tuple[int, int, Mapping[str, Any], Any]] = []
    for claim_index, claim in enumerate(claims):
        expression = claim.get("expression")
        if expression is None:
            continue
        for atom_index, atom in enumerate(_and_atoms(expression)):
            slots.append((claim_index, atom_index, claim, atom))

    units: list[tuple[int, int, Mapping[str, Any], Any]] = []
    candidates: dict[tuple[int, int], list[int]] = {}
    for gold_index, gold in enumerate(required):
        for atom_index, atom in enumerate(_and_atoms(gold["expression"])):
            unit = (gold_index, atom_index, gold, atom)
            units.append(unit)
            key = (gold_index, atom_index)
            matching = [
                slot_index
                for slot_index, (_, _, claim, actual_atom) in enumerate(slots)
                if _source_matches(claim, str(gold["source_span"]))
                and _expression_matches(actual_atom, atom)
            ]
            candidates[key] = sorted(
                matching,
                key=lambda slot_index: (
                    _alignment_metadata_rank(slots[slot_index][2], gold),
                    slots[slot_index][0],
                    slots[slot_index][1],
                ),
            )

    # Scarce units choose first. The augmenting path preserves maximum
    # cardinality while the candidate order favors metadata-faithful matches.
    ordered = sorted(
        units,
        key=lambda unit: (
            len(candidates[(unit[0], unit[1])]),
            unit[0],
            unit[1],
        ),
    )
    slot_owner: dict[int, tuple[int, int]] = {}
    unit_slot: dict[tuple[int, int], int] = {}

    def assign(unit_key: tuple[int, int], seen: set[int]) -> bool:
        for slot_index in candidates[unit_key]:
            if slot_index in seen:
                continue
            seen.add(slot_index)
            owner = slot_owner.get(slot_index)
            if owner is None or assign(owner, seen):
                slot_owner[slot_index] = unit_key
                unit_slot[unit_key] = slot_index
                return True
        return False

    for gold_index, atom_index, _, _ in ordered:
        assign((gold_index, atom_index), set())

    return {
        (str(required[gold_index]["id"]), atom_index): slots[slot_index][2]
        for (gold_index, atom_index), slot_index in unit_slot.items()
    }


def _align_required_metadata(
    claims: Sequence[Mapping[str, Any]],
    required: Sequence[Mapping[str, Any]],
) -> tuple[
    dict[tuple[str, int, str | None], Mapping[str, Any]],
    dict[str, int],
]:
    """Align metadata-bearing atom slots, expanding union attribution by agent."""
    slots: list[tuple[int, int, Mapping[str, Any], Any]] = []
    for claim_index, claim in enumerate(claims):
        expression = claim.get("expression")
        if expression is None:
            continue
        for atom_index, atom in enumerate(_and_atoms(expression)):
            slots.append((claim_index, atom_index, claim, atom))

    units: list[tuple[int, int, str | None, Mapping[str, Any], Any]] = []
    candidates: dict[tuple[int, int, str | None], list[int]] = {}
    required_units: dict[str, int] = {}
    for gold_index, gold in enumerate(required):
        gold_id = str(gold["id"])
        expected_agents = sorted(map(str, gold.get("agents", [])))
        stances = set(gold.get("stances", [gold.get("stance", "assert")]))
        count = 0
        for atom_index, atom in enumerate(_and_atoms(gold["expression"])):
            agent_units: list[str | None]
            if gold.get("agent_match") == "union" and expected_agents:
                agent_units = expected_agents
            else:
                agent_units = [None]
            for expected_agent in agent_units:
                unit = (gold_index, atom_index, expected_agent, gold, atom)
                units.append(unit)
                count += 1
                key = (gold_index, atom_index, expected_agent)
                matching = []
                for slot_index, (_, _, claim, actual_atom) in enumerate(slots):
                    if not _source_matches(claim, str(gold["source_span"])):
                        continue
                    if not _expression_matches(actual_atom, atom):
                        continue
                    if claim.get("stance") not in stances:
                        continue
                    actual_agents = set(map(str, claim.get("agents", [])))
                    expected_set = set(expected_agents)
                    if gold.get("agent_match") == "union":
                        if not actual_agents <= expected_set:
                            continue
                        if expected_agent is not None and expected_agent not in actual_agents:
                            continue
                    elif actual_agents != expected_set:
                        continue
                    matching.append(slot_index)
                candidates[key] = sorted(
                    matching,
                    key=lambda slot_index: (slots[slot_index][0], slots[slot_index][1]),
                )
        required_units[gold_id] = count

    ordered = sorted(
        units,
        key=lambda unit: (
            len(candidates[(unit[0], unit[1], unit[2])]),
            unit[0],
            unit[1],
            unit[2] or "",
        ),
    )
    slot_owner: dict[int, tuple[int, int, str | None]] = {}
    unit_slot: dict[tuple[int, int, str | None], int] = {}

    def assign(
        unit_key: tuple[int, int, str | None], seen: set[int]
    ) -> bool:
        for slot_index in candidates[unit_key]:
            if slot_index in seen:
                continue
            seen.add(slot_index)
            owner = slot_owner.get(slot_index)
            if owner is None or assign(owner, seen):
                slot_owner[slot_index] = unit_key
                unit_slot[unit_key] = slot_index
                return True
        return False

    for gold_index, atom_index, expected_agent, _, _ in ordered:
        assign((gold_index, atom_index, expected_agent), set())

    return (
        {
            (
                str(required[gold_index]["id"]),
                atom_index,
                expected_agent,
            ): slots[slot_index][2]
            for (
                gold_index,
                atom_index,
                expected_agent,
            ), slot_index in unit_slot.items()
        },
        required_units,
    )


def _expression_candidates(
    claims: Sequence[Mapping[str, Any]],
    gold: Mapping[str, Any],
    *,
    require_source: bool = True,
) -> list[Mapping[str, Any]]:
    anchor = str(gold["source_span"])
    source_candidates = [
        claim
        for claim in claims
        if not require_source or _source_matches(claim, anchor)
    ]
    atoms = _and_atoms(gold["expression"])
    if not all(
        any(_expression_matches(claim.get("expression"), atom) for claim in source_candidates)
        for atom in atoms
    ):
        return []
    return [
        claim
        for claim in source_candidates
        if any(
            _expression_matches(claim.get("expression"), atom)
            for atom in atoms
        )
    ]


def _metadata_matches(
    candidates: Sequence[Mapping[str, Any]], gold: Mapping[str, Any]
) -> bool:
    stances = set(gold.get("stances", [gold.get("stance", "assert")]))
    expected_agents = set(gold.get("agents", []))
    for atom in _and_atoms(gold["expression"]):
        atom_candidates = [
            claim
            for claim in candidates
            if claim.get("stance") in stances
            and _expression_matches(claim.get("expression"), atom)
        ]
        if gold.get("agent_match") == "union":
            if expected_agents != {
                str(agent)
                for claim in atom_candidates
                for agent in claim.get("agents", [])
            }:
                return False
        elif not any(
            set(map(str, claim.get("agents", []))) == expected_agents
            for claim in atom_candidates
        ):
            return False
    return True


def _claim_metadata_shape_matches(
    claim: Mapping[str, Any], gold: Mapping[str, Any]
) -> bool:
    stances = set(gold.get("stances", [gold.get("stance", "assert")]))
    if claim.get("stance") not in stances:
        return False
    actual_agents = set(map(str, claim.get("agents", [])))
    expected_agents = set(gold.get("agents", []))
    if gold.get("agent_match") == "union":
        return actual_agents <= expected_agents
    return actual_agents == expected_agents


def _dependency_matches(
    candidates: Sequence[Mapping[str, Any]],
    gold: Mapping[str, Any],
    matched_actual_ids: Mapping[str, set[str]],
    claims: Sequence[Mapping[str, Any]],
) -> bool:
    required = list(gold.get("depends_on", []))
    if not required:
        return True
    by_id = {str(claim["id"]): claim for claim in claims}

    def ancestors(claim: Mapping[str, Any]) -> set[str]:
        pending = list(map(str, claim.get("dependencies", [])))
        found: set[str] = set()
        while pending:
            dependency = pending.pop()
            if dependency in found:
                continue
            found.add(dependency)
            parent = by_id.get(dependency)
            if parent is not None:
                pending.extend(map(str, parent.get("dependencies", [])))
        return found

    for candidate in candidates:
        dependencies = ancestors(candidate)
        if all(
            dependencies & matched_actual_ids.get(parent, set())
            for parent in required
        ):
            return True
    return False


def _forbidden_matches(
    claims: Sequence[Mapping[str, Any]], forbidden: Mapping[str, Any]
) -> list[str]:
    matches = []
    for claim in claims:
        if not _source_matches(claim, str(forbidden["source_span"])):
            continue
        if "stance" in forbidden and claim.get("stance") != forbidden["stance"]:
            continue
        if "expression" in forbidden and not _expression_matches(
            claim.get("expression"), forbidden["expression"]
        ):
            continue
        matches.append(str(claim["id"]))
    return matches


def _record_matches_field(
    record: Mapping[str, Any], field: Mapping[str, Any]
) -> bool:
    if "formalization_id_prefix" in field:
        return str(record.get("formalization_id", "")).startswith(
            str(field["formalization_id_prefix"])
        )
    selector = field.get("source")
    if not isinstance(selector, Mapping):
        raise ValueError(
            "field gold requires formalization_id_prefix or source selector"
        )
    source = record.get("source") or {}
    return all(str(source.get(key)) == str(value) for key, value in selector.items())


def evaluate_field_gold(
    records: Sequence[Mapping[str, Any]],
    fields: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    required_count = expression_pass = metadata_pass = dependency_pass = full_pass = 0
    parse_error_count = forbidden_violation_count = 0
    field_pass_count = 0
    for field in fields:
        matches = [
            record
            for record in records
            if _record_matches_field(record, field)
        ]
        if len(matches) != 1:
            rows.append({"id": field["id"], "error": "missing_or_duplicate_field"})
            required_count += len(field["required_claims"])
            continue
        record = matches[0]
        if record.get("source_text") != field["source_text"]:
            rows.append({"id": field["id"], "error": "source_text_drift"})
            required_count += len(field["required_claims"])
            continue
        claims = list(record.get("claims", []))
        parse_errors = list(record.get("parse_errors", []))
        parse_error_count += len(parse_errors)
        alignment = _align_required_claims(claims, field["required_claims"])
        metadata_alignment, metadata_unit_counts = _align_required_metadata(
            claims, field["required_claims"]
        )
        matched_actual_ids: dict[str, set[str]] = {}
        aligned_candidates: dict[str, list[Mapping[str, Any]]] = {}
        metadata_candidates: dict[str, list[Mapping[str, Any]]] = {}
        for gold in field["required_claims"]:
            gold_id = str(gold["id"])
            atom_count = len(_and_atoms(gold["expression"]))
            candidates = [
                alignment[(gold_id, atom_index)]
                for atom_index in range(atom_count)
                if (gold_id, atom_index) in alignment
            ]
            aligned_candidates[gold_id] = candidates
            expression_ok = len(candidates) == atom_count
            matched_metadata = [
                claim
                for (candidate_gold_id, _, _), claim in metadata_alignment.items()
                if candidate_gold_id == gold_id
            ]
            metadata_candidates[gold_id] = matched_metadata
            metadata_ok = (
                expression_ok
                and len(matched_metadata) == metadata_unit_counts[gold_id]
                and _metadata_matches(matched_metadata, gold)
            )
            if metadata_ok:
                # A repeated, metadata-compatible occurrence may be the one a
                # downstream claim actually cites. Preserve those reviewed
                # semantic alternatives for dependency matching while keeping
                # expression scoring one-to-one.
                semantic_candidates = _expression_candidates(
                    claims, gold, require_source=False
                )
                matched_actual_ids[gold_id] = {
                    str(candidate["id"])
                    for candidate in semantic_candidates
                    if _claim_metadata_shape_matches(candidate, gold)
                }
            else:
                matched_actual_ids[gold_id] = set()

        claim_rows = []
        for gold in field["required_claims"]:
            required_count += 1
            gold_id = str(gold["id"])
            candidates = aligned_candidates[gold_id]
            expression_ok = len(candidates) == len(_and_atoms(gold["expression"]))
            matched_metadata = metadata_candidates[gold_id]
            metadata_ok = (
                expression_ok
                and len(matched_metadata) == metadata_unit_counts[gold_id]
                and _metadata_matches(matched_metadata, gold)
            )
            dependency_candidates = [
                candidate
                for candidate in _expression_candidates(claims, gold)
                if _claim_metadata_shape_matches(candidate, gold)
            ]
            dependency_ok = (
                metadata_ok
                and _dependency_matches(
                    dependency_candidates, gold, matched_actual_ids, claims
                )
            )
            expression_pass += expression_ok
            metadata_pass += metadata_ok
            dependency_pass += dependency_ok
            full_pass += dependency_ok
            claim_rows.append({
                "id": gold_id,
                "expression_pass": expression_ok,
                "metadata_pass": metadata_ok,
                "dependency_pass": dependency_ok,
                "actual_claim_ids": list(dict.fromkeys(
                    str(candidate["id"]) for candidate in candidates
                )),
            })
        forbidden_rows = []
        for forbidden in field.get("forbidden_claims", []):
            actual_ids = _forbidden_matches(claims, forbidden)
            if actual_ids:
                forbidden_violation_count += 1
            forbidden_rows.append({
                "id": forbidden["id"],
                "passed": not actual_ids,
                "actual_claim_ids": actual_ids,
            })
        field_passed = (
            not parse_errors
            and all(item["dependency_pass"] for item in claim_rows)
            and all(item["passed"] for item in forbidden_rows)
        )
        field_pass_count += field_passed
        rows.append({
            "id": field["id"],
            "formalization_id": record["formalization_id"],
            "parse_errors": parse_errors,
            "required_claims": claim_rows,
            "forbidden_claims": forbidden_rows,
            "passed": field_passed,
        })
    return {
        "field_count": len(fields),
        "required_claim_count": required_count,
        "expression_pass_count": expression_pass,
        "metadata_pass_count": metadata_pass,
        "dependency_pass_count": dependency_pass,
        "full_pass_count": full_pass,
        "expression_recall": expression_pass / required_count if required_count else None,
        "metadata_recall": metadata_pass / required_count if required_count else None,
        "dependency_recall": dependency_pass / required_count if required_count else None,
        "full_recall": full_pass / required_count if required_count else None,
        "field_pass_count": field_pass_count,
        "field_pass_rate": field_pass_count / len(fields) if fields else None,
        "missing_expression_count": required_count - expression_pass,
        "metadata_failure_count": expression_pass - metadata_pass,
        "dependency_failure_count": metadata_pass - dependency_pass,
        "parse_error_count": parse_error_count,
        "forbidden_violation_count": forbidden_violation_count,
        "rows": rows,
    }


def evaluate_field_gold_files(
    records_path: Path, gold_path: Path
) -> dict[str, Any]:
    return evaluate_field_gold(
        load_compact_fields(records_path),
        load_field_gold(gold_path),
    )
