"""Whole-field KKS translation into a compact, attribution-aware claim trace."""

from __future__ import annotations

import asyncio
import json
import re
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from controlmad.harness.config import ModelConfig
from controlmad.harness.models import ModelClient, model_client_for_config
from controlmad.harness.runner import config_from_resolved_dict
from controlmad.harness.storage import ExperimentStorage

from .core import completed_results
from .formal_logic import ReasoningSource, _load_question, extract_reasoning_sources
from .formal_logic_compact import CompactParseError, parse_compact_expression


FORMAT_VERSION = "kks-compact-field-v1"
PROMPT_VERSION = "kks-compact-field-prompt-v2"
CLAIM_ID = re.compile(r"c[1-9][0-9]*$")
STANCE = re.compile(r"(ASSERT|HYPOTHETICAL|REPORT|ENDORSE|REJECT|ABSTAIN)(?:\(([^()]*)\))?$")
FROM = re.compile(r"FROM\(([^()]*)\)$")


def parse_compact_field(content: str, source_text: str) -> tuple[list[dict[str, Any]], list[str]]:
    claims: list[dict[str, Any]] = []
    errors: list[str] = []
    seen: set[str] = set()
    for line_number, raw in enumerate(content.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("```"):
            continue
        parts = [part.strip() for part in line.split(" :: ", 4)]
        if len(parts) != 5:
            errors.append("line %d: expected five ' :: '-separated fields" % line_number)
            continue
        claim_id, stance_text, expression_text, from_text, source_span = parts
        if not CLAIM_ID.fullmatch(claim_id) or claim_id in seen:
            errors.append("line %d: invalid or duplicate claim id %r" % (line_number, claim_id))
            continue
        stance_match = STANCE.fullmatch(stance_text)
        if not stance_match:
            errors.append("line %d: invalid stance %r" % (line_number, stance_text))
            continue
        stance, agents_text = stance_match.groups()
        agents = [item.strip() for item in (agents_text or "").split(",") if item.strip()]
        if stance in {"REPORT", "ENDORSE", "REJECT"} and not agents:
            errors.append("line %d: %s requires at least one attributed agent" % (line_number, stance))
            continue
        if stance in {"ASSERT", "HYPOTHETICAL", "ABSTAIN"} and agents:
            errors.append("line %d: %s cannot name attributed agents" % (line_number, stance))
            continue
        from_match = FROM.fullmatch(from_text)
        if not from_match:
            errors.append("line %d: invalid dependency field" % line_number)
            continue
        dependencies = [
            item.strip()
            for item in re.split(r"[;,]", from_match.group(1))
            if item.strip() and item.strip() != "-"
        ]
        unknown = [item for item in dependencies if item not in seen]
        if unknown:
            errors.append("line %d: dependency must reference an earlier claim: %s" % (line_number, ",".join(unknown)))
            continue
        if not source_span or source_span not in source_text:
            errors.append("line %d: source span is not verbatim" % line_number)
            continue
        try:
            expression = parse_compact_expression(expression_text)
        except CompactParseError as exc:
            errors.append("line %d: %s" % (line_number, exc))
            continue
        if stance == "ABSTAIN" and expression is not None:
            errors.append("line %d: ABSTAIN stance requires ABSTAIN expression" % line_number)
            continue
        if stance != "ABSTAIN" and expression is None:
            errors.append("line %d: ABSTAIN expression requires ABSTAIN stance" % line_number)
            continue
        claims.append({
            "id": claim_id,
            "stance": stance.lower(),
            "agents": agents,
            "expression": expression,
            "dependencies": dependencies,
            "source_span": source_span,
        })
        seen.add(claim_id)
    return claims, errors


def compact_field_prompt(question: Mapping[str, Any], source: ReasoningSource) -> str:
    players = ", ".join("%s=%d" % (name, index) for index, name in enumerate(question["players"]))
    statements = "\n".join(
        "%s: %s" % (item["speaker"], item["text"])
        for item in question["statements"]
    )
    location = ", ".join("%s=%s" % item for item in sorted(source.location.items()))
    submitted = ", ".join("%s=%s" % item for item in sorted(source.submitted_roles.items())) or "none"
    return f"""Extract the logical claims from one complete KKS reasoning field.

Context:
- Players: {players}
- Puzzle statements:
{statements}
- Rules: each player has exactly one role; exactly one is a spy; knights speak truthfully; knaves falsely; spies may say either.
- Field metadata: {location}
- Roles submitted with this field (context, not an automatic claim): {submitted}

Compact expressions:
ROLE(A,knight), STMT_TRUE(D), NOT(expr), SAME_ROLE(A,B),
AND(expr;expr), OR(expr;expr), XOR(expr;expr), IFF(expr;expr),
COUNT(exactly,1,spy,A,B,C,D), PARITY(even,knave,A,C), or ABSTAIN.

Stance:
- ASSERT: the current speaker presents the proposition as true.
- HYPOTHETICAL: it is only assumed or considered in a case.
- REPORT(agent-1,agent-2): the field says those other agents claim it, without endorsing it.
- ENDORSE(agent-1): the current speaker explicitly accepts that agent's claim.
- REJECT(agent-1): the current speaker explicitly rejects that agent's proposition. Encode the proposition being rejected, not its negation.
- ABSTAIN: the source makes a claim that the compact expression language cannot represent; use ABSTAIN as its expression too.

Important distinctions:
- REPORT/ENDORSE/REJECT apply only when the field explicitly names a debate participant such as Agent-1. A puzzle character such as “B says” is not a debate-agent attribution.
- “B's statement is false”, “B lies”, and “B must lie” are NOT(STMT_TRUE(B)). The corresponding true forms are STMT_TRUE(B).
- “D cannot be knight” is NOT(ROLE(D,knight)). Preserve every explicit negative word and construction.
- Use ABSTAIN only after checking that no listed expression can represent the proposition. Never use ABSTAIN merely because a statement is false, compound, reported, or hypothetical.

Output one line per distinct claim, in textual order:
c1 :: STANCE :: EXPRESSION :: FROM(-) :: exact verbatim source span
c2 :: STANCE :: EXPRESSION :: FROM(c1) :: exact verbatim source span

Dependencies may reference only earlier claim IDs. Preserve negation literally. Do not infer that a reported claim is true. Do not add the submitted roles, verified solution, or unstated bridge claims. Use ABSTAIN when the proposition cannot be represented faithfully. The source span must occur verbatim in the field. Return only plain-text claim lines: no JSON, Markdown, explanations, or confidence.

Complete field:
{source.text}"""


def compact_initial_prompt(
    question: Mapping[str, Any],
    source: ReasoningSource,
    *,
    prompt_version: str = "v3",
) -> str:
    players = ", ".join(
        "%s=%d" % (name, index)
        for index, name in enumerate(question["players"])
    )
    statements = "\n".join(
        "%s: %s" % (item["speaker"], item["text"])
        for item in question["statements"]
    )
    submitted = (
        ", ".join("%s=%s" % item for item in sorted(source.submitted_roles.items()))
        or "none"
    )
    if prompt_version == "v2":
        return f"""Translate one self-contained initial KKS explanation into compact logical claims.

Context:
- Players: {players}
- Puzzle statements:
{statements}
- Rules: each player has exactly one role; exactly one is a spy; knights speak truthfully; knaves falsely; spies may say either.
- Roles submitted with this explanation (context only, not automatic claims): {submitted}

Expressions:
ROLE(A,knight), STMT_TRUE(D), NOT(expr), SAME_ROLE(A,B),
AND(expr;expr), OR(expr;expr), XOR(expr;expr), IFF(expr;expr),
COUNT(exactly,1,spy,A,B,C,D), PARITY(even,knave,A,C), or ABSTAIN.

Stance:
- ASSERT: the explanation presents the proposition unconditionally.
- HYPOTHETICAL: the proposition occurs inside an assumption, case, or counterfactual.
- ABSTAIN: the source claim cannot be represented by the expression language.

HYPOTHETICAL applies only while an assumption, case, or counterfactual remains open. When the prose rejects a case or adopts a conclusion with “so”, “thus”, “therefore”, “solution”, or a final assignment, that resulting conclusion is ASSERT unless another assumption still contains it. Do not mark the rest of an explanation hypothetical merely because it began by testing an assumption.

Example:
Assume A is knight. Then C is knave, contradiction. So A cannot be knight.
c1 :: HYPOTHETICAL :: ROLE(A,knight) :: FROM(-) :: Assume A is knight
c2 :: HYPOTHETICAL :: ROLE(C,knave) :: FROM(c1) :: Then C is knave
c3 :: ASSERT :: NOT(ROLE(A,knight)) :: FROM(c2) :: So A cannot be knight

“B's statement is false”, “B lies”, and “B must lie” mean NOT(STMT_TRUE(B)). “D cannot be knight” means NOT(ROLE(D,knight)). Puzzle characters saying something is not debate-agent attribution.

Output one line per distinct claim in textual order:
c1 :: STANCE :: EXPRESSION :: FROM(-) :: exact verbatim source span
c2 :: STANCE :: EXPRESSION :: FROM(c1) :: exact verbatim source span

Dependencies may reference only earlier claim IDs. Do not add submitted roles, a verified answer, or unstated bridge claims. Use ABSTAIN only when no listed expression is faithful. Return only plain-text claim lines, without JSON, Markdown, confidence, or explanation.

Initial explanation:
{source.text}"""
    if prompt_version not in {"v3", "v4"}:
        raise ValueError("initial prompt version must be v2, v3, or v4")
    targeted_v4 = ""
    if prompt_version == "v4":
        targeted_v4 = r"""

Targeted rules for dense case analysis:
- Emit every explicit assumption and intermediate conclusion, even when the same
  role later appears inside a compound or final assignment. Do not collapse a
  branch into only its last assignment.
- A numbered condition such as “condition (1) is false” is not the same as the
  speaker's whole statement being false. Formalize the condition's content.
  Use NOT(STMT_TRUE(B)) only when the prose explicitly evaluates B's complete
  statement, says B lies, or says B tells the truth.
- Preserve an explicit global rule or count as its own claim when the prose uses
  it in the reasoning, even if the same rule was supplied in the puzzle context.
  “With exactly one spy” is a COUNT claim, not merely background text.
- A role does not by itself determine a spy's statement truth. If the prose
  explicitly says a spy's statement is false or true, emit that statement-truth
  claim as well as the spy role.
- For a conclusion supported by several explicit premises, FROM must name every
  premise actually used. Do not substitute a nearby consequence for a premise.

Worked example 6 — preserve the whole rejected case:
Source: If C is knave, C's statement is false, so B is knave. Contradiction. Therefore C cannot be knave.
c1 :: HYPOTHETICAL :: ROLE(C,knave) :: FROM(-) :: If C is knave
c2 :: HYPOTHETICAL :: NOT(STMT_TRUE(C)) :: FROM(c1) :: C's statement is false
c3 :: HYPOTHETICAL :: ROLE(B,knave) :: FROM(c2) :: so B is knave
c4 :: ABSTAIN :: ABSTAIN :: FROM(c3) :: Contradiction
c5 :: ASSERT :: NOT(ROLE(C,knave)) :: FROM(c4) :: Therefore C cannot be knave

Worked example 7 — use all explicit premises:
Source: With exactly one spy, C is not knight and C is not knave, so C must be spy.
c1 :: ASSERT :: COUNT(exactly,1,spy,A,B,C,D) :: FROM(-) :: With exactly one spy
c2 :: ASSERT :: NOT(ROLE(C,knight)) :: FROM(-) :: C is not knight
c3 :: ASSERT :: NOT(ROLE(C,knave)) :: FROM(-) :: C is not knave
c4 :: ASSERT :: ROLE(C,spy) :: FROM(c1,c2,c3) :: so C must be spy

Worked example 8 — subcondition versus whole-statement truth:
Source: Condition (1), at most one knight among B,C,D, is false. Therefore B's whole statement is false.
c1 :: ASSERT :: NOT(COUNT(at_most,1,knight,B,C,D)) :: FROM(-) :: Condition (1), at most one knight among B,C,D, is false
c2 :: ASSERT :: NOT(STMT_TRUE(B)) :: FROM(c1) :: B's whole statement is false

Worked example 9 — a spy's explicitly evaluated statement:
Source: D is spy. D's statement is false, which a spy may do.
c1 :: ASSERT :: ROLE(D,spy) :: FROM(-) :: D is spy
c2 :: ASSERT :: NOT(STMT_TRUE(D)) :: FROM(-) :: D's statement is false
c3 :: ABSTAIN :: ABSTAIN :: FROM(c1,c2) :: which a spy may do
"""
    return f"""Translate one self-contained initial KKS explanation into compact logical claims.

Context:
- Players: {players}
- Puzzle statements:
{statements}
- Rules: each player has exactly one role; exactly one is a spy; knights speak truthfully; knaves falsely; spies may say either.
- Roles submitted with this explanation (context only, not automatic claims): {submitted}

Expressions:
ROLE(A,knight), STMT_TRUE(D), NOT(expr), SAME_ROLE(A,B),
AND(expr;expr), OR(expr;expr), XOR(expr;expr), IFF(expr;expr),
COUNT(exactly,1,spy,A,B,C,D), PARITY(even,knave,A,C), or ABSTAIN.

Stance:
- ASSERT: the explanation presents the proposition unconditionally.
- HYPOTHETICAL: the proposition occurs inside an assumption, case, or counterfactual.
- ABSTAIN: the source claim cannot be represented by the expression language.

Core distinctions:
- A bare restatement such as “Player C says B is not spy” is already supplied in the puzzle statements. Do not emit ASSERT(NOT(ROLE(B,spy))) merely because C says it. Emit STMT_TRUE(C) or NOT(STMT_TRUE(C)) only when the explanation evaluates C's statement as true or false.
- HYPOTHETICAL applies only while an assumption, case, or counterfactual remains open. When the prose rejects a case or adopts a final conclusion, solution, or role assignment, that resulting conclusion is ASSERT unless another assumption still contains it.
- A final assignment must preserve every explicitly listed role. The phrase “satisfies all” or “is consistent” is a meta-claim: use ABSTAIN for that phrase and never invent AND, IFF, or another expression to represent satisfaction.
- FROM contains only claims that logically support the conclusion. Never link to the previous claim merely because it came earlier. Separate components copied from an explicit role list do not depend on one another.
- Copy each source span as one exact contiguous substring, including the original words and punctuation. Never rewrite or shorten it.

Worked example 1 — statement content versus statement truth:
Source: Player C says B is not spy. Since B is spy, C's statement is false, so C is knave.
c1 :: ASSERT :: ROLE(B,spy) :: FROM(-) :: B is spy
c2 :: ASSERT :: NOT(STMT_TRUE(C)) :: FROM(c1) :: C's statement is false
c3 :: ASSERT :: ROLE(C,knave) :: FROM(c2) :: so C is knave
Do not emit the content “B is not spy” as an asserted fact.

Worked example 2 — assumption discharge and adopted assignment:
Source: Assume A is knight. Then B's statement is false, so B is knave. This works. Thus A=knight, B=knave, C=spy, D=knight.
c1 :: HYPOTHETICAL :: ROLE(A,knight) :: FROM(-) :: Assume A is knight
c2 :: HYPOTHETICAL :: NOT(STMT_TRUE(B)) :: FROM(c1) :: B's statement is false
c3 :: HYPOTHETICAL :: ROLE(B,knave) :: FROM(c2) :: so B is knave
c4 :: ABSTAIN :: ABSTAIN :: FROM(c3) :: This works
c5 :: ASSERT :: AND(ROLE(A,knight);ROLE(B,knave);ROLE(C,spy);ROLE(D,knight)) :: FROM(-) :: A=knight, B=knave, C=spy, D=knight

Worked example 3 — causal dependencies:
Source: A is knight. Therefore B's statement is false. Therefore B is knave.
c1 :: ASSERT :: ROLE(A,knight) :: FROM(-) :: A is knight
c2 :: ASSERT :: NOT(STMT_TRUE(B)) :: FROM(c1) :: B's statement is false
c3 :: ASSERT :: ROLE(B,knave) :: FROM(c2) :: B is knave

Worked example 4 — supported counts:
“at most one knight among A,C” is COUNT(at_most,1,knight,A,C).
“at least two knaves among A,B,C” is COUNT(at_least,2,knave,A,B,C).
“exactly one spy” is COUNT(exactly,1,spy,A,B,C,D).

Worked example 5 — preserve the statement-truth bridge:
Source: D is knight, so D's statement is true; therefore A and C have the same role.
c1 :: ASSERT :: ROLE(D,knight) :: FROM(-) :: D is knight
c2 :: ASSERT :: STMT_TRUE(D) :: FROM(c1) :: D's statement is true
c3 :: ASSERT :: SAME_ROLE(A,C) :: FROM(c2) :: A and C have the same role

“B's statement is false”, “B lies”, and “B must lie” mean NOT(STMT_TRUE(B)). “D cannot be knight” means NOT(ROLE(D,knight)).
{targeted_v4}

Output one line per distinct claim in textual order:
c1 :: STANCE :: EXPRESSION :: FROM(-) :: exact verbatim source span
c2 :: STANCE :: EXPRESSION :: FROM(c1) :: exact verbatim source span

Dependencies may reference only earlier claim IDs. Do not add submitted roles, a verified answer, or unstated bridge claims. Use ABSTAIN only when no listed expression is faithful. Return only plain-text claim lines, without JSON, Markdown, confidence, or explanation.

Initial explanation:
{source.text}"""


def load_initial_manifest(path: Path) -> list[dict[str, str]]:
    items = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    keys = []
    for item in items:
        if set(item) != {"task_id", "agent_id"}:
            raise ValueError("initial manifest entries require task_id and agent_id")
        key = (str(item["task_id"]), str(item["agent_id"]))
        if key in keys:
            raise ValueError("initial manifest entries must be unique")
        keys.append(key)
    return [
        {"task_id": task_id, "agent_id": agent_id}
        for task_id, agent_id in keys
    ]


def _summarize(records: Sequence[Mapping[str, Any]], wall_time: float) -> dict[str, Any]:
    stance_counts: Counter[str] = Counter()
    usage: dict[str, float] = {}
    claims = 0
    errors = 0
    dependencies = 0
    for record in records:
        errors += len(record["parse_errors"])
        claims += len(record["claims"])
        dependencies += sum(len(claim["dependencies"]) for claim in record["claims"])
        stance_counts.update(claim["stance"] for claim in record["claims"])
        for key, value in record["usage"].items():
            if isinstance(value, (int, float)):
                usage[key] = usage.get(key, 0.0) + float(value)
    return {
        "format": FORMAT_VERSION,
        "json_model_output": False,
        "field_count": len(records),
        "claim_count": claims,
        "parse_error_count": errors,
        "dependency_count": dependencies,
        "stance_counts": dict(sorted(stance_counts.items())),
        "wall_time_seconds": wall_time,
        "usage": usage,
    }


async def generate_compact_fields(
    run_dir: Path,
    task_id: str,
    model_config: Path,
    output: Path,
    *,
    timeout_seconds: float = 300,
    concurrency: int = 5,
    model_client: ModelClient | None = None,
) -> dict[str, Any]:
    if concurrency < 1:
        raise ValueError("concurrency must be positive")
    storage = ExperimentStorage(str(run_dir))
    resolved = config_from_resolved_dict(storage.load_resolved_config())
    if resolved.benchmark.kind != "kks":
        raise ValueError("compact field translation supports only KKS")
    dataset_path = Path(resolved.benchmark.path)
    if not dataset_path.is_absolute():
        dataset_path = Path(resolved.config_root) / dataset_path
    question = _load_question(dataset_path.resolve(), task_id)
    results = [value for (candidate, _), value in completed_results(run_dir).items() if candidate == task_id]
    if not results:
        raise ValueError("No completed result for task %s" % task_id)
    model = ModelConfig(**(yaml.safe_load(model_config.read_text(encoding="utf-8")) or {}))
    client = model_client or model_client_for_config(model)
    sources: list[ReasoningSource] = []
    for result in sorted(results, key=lambda value: int(value.get("repetition", 1))):
        for source in extract_reasoning_sources(result):
            location = {"run_id": result["run_id"], "task_id": task_id, "repetition": int(result.get("repetition", 1)), **source.location}
            sources.append(ReasoningSource(location, source.text, source.submitted_roles))
    semaphore = asyncio.Semaphore(concurrency)
    started = time.monotonic()

    async def translate(source: ReasoningSource) -> dict[str, Any]:
        async with semaphore:
            response = await client.complete(
                model,
                [
                    {"role": "system", "content": "You are a literal formal-logic claim extractor. Preserve polarity, attribution, and uncertainty exactly."},
                    {"role": "user", "content": compact_field_prompt(question, source)},
                ],
                timeout_seconds,
            )
        claims, errors = parse_compact_field(response.content, source.text)
        return {
            "formalization_id": source.id,
            "format_version": FORMAT_VERSION,
            "prompt_version": PROMPT_VERSION,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "source": source.location,
            "source_text": source.text,
            "submitted_roles": source.submitted_roles,
            "claims": claims,
            "parse_errors": errors,
            "model": response.model,
            "model_config_id": model.id,
            "model_metadata": response.response_metadata,
            "usage": response.usage,
            "raw_response": response.content,
        }

    records = await asyncio.gather(*(translate(source) for source in sources))
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("".join(json.dumps(record, sort_keys=True) + "\n" for record in records), encoding="utf-8")
    return {"output": str(output), "model": model.model, "reasoning_effort": model.params.get("reasoning_effort"), **_summarize(records, time.monotonic() - started)}


def run_compact_fields(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return asyncio.run(generate_compact_fields(*args, **kwargs))


async def generate_compact_initials(
    run_dir: Path,
    manifest_path: Path,
    model_config: Path,
    output: Path,
    *,
    timeout_seconds: float = 300,
    concurrency: int = 5,
    prompt_version: str = "v3",
    model_client: ModelClient | None = None,
) -> dict[str, Any]:
    if concurrency < 1:
        raise ValueError("concurrency must be positive")
    if prompt_version not in {"v2", "v3", "v4"}:
        raise ValueError("initial prompt version must be v2, v3, or v4")
    manifest = load_initial_manifest(manifest_path)
    storage = ExperimentStorage(str(run_dir))
    resolved = config_from_resolved_dict(storage.load_resolved_config())
    if resolved.benchmark.kind != "kks":
        raise ValueError("compact initial translation supports only KKS")
    dataset_path = Path(resolved.benchmark.path)
    if not dataset_path.is_absolute():
        dataset_path = Path(resolved.config_root) / dataset_path
    completed = completed_results(run_dir)
    model = ModelConfig(
        **(yaml.safe_load(model_config.read_text(encoding="utf-8")) or {})
    )
    client = model_client or model_client_for_config(model)
    selected: list[tuple[Mapping[str, Any], ReasoningSource]] = []
    questions: dict[str, dict[str, Any]] = {}
    for item in manifest:
        task_id, agent_id = item["task_id"], item["agent_id"]
        candidates = [
            value
            for (candidate, _), value in completed.items()
            if candidate == task_id
        ]
        if len(candidates) != 1:
            raise ValueError(
                "manifest task %s must have exactly one completed result" % task_id
            )
        result = candidates[0]
        proposal = (result.get("initial_proposals") or {}).get(agent_id)
        if not isinstance(proposal, Mapping):
            raise ValueError("missing initial proposal for %s/%s" % (task_id, agent_id))
        text = str(proposal.get("explanation", "")).strip()
        if not text:
            raise ValueError("empty initial explanation for %s/%s" % (task_id, agent_id))
        location = {
            "run_id": result["run_id"],
            "task_id": task_id,
            "repetition": int(result.get("repetition", 1)),
            "stage": "initial_proposal",
            "agent_id": agent_id,
            "field": "explanation",
        }
        source = ReasoningSource(
            location, text, dict(proposal.get("roles") or {})
        )
        selected.append((result, source))
        questions.setdefault(
            task_id, _load_question(dataset_path.resolve(), task_id)
        )
    semaphore = asyncio.Semaphore(concurrency)
    started = time.monotonic()

    async def translate(
        result: Mapping[str, Any], source: ReasoningSource
    ) -> dict[str, Any]:
        question = questions[str(source.location["task_id"])]
        async with semaphore:
            response = await client.complete(
                model,
                [
                    {
                        "role": "system",
                        "content": (
                            "You are a literal formal-logic translator for a "
                            "self-contained initial explanation. Preserve polarity, "
                            "hypothetical scope, and dependencies exactly."
                        ),
                    },
                    {
                        "role": "user",
                        "content": compact_initial_prompt(
                            question, source, prompt_version=prompt_version
                        ),
                    },
                ],
                timeout_seconds,
            )
        claims, errors = parse_compact_field(response.content, source.text)
        return {
            "formalization_id": source.id,
            "format_version": FORMAT_VERSION,
            "prompt_version": "kks-compact-initial-prompt-%s" % prompt_version,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "source": source.location,
            "source_text": source.text,
            "submitted_roles": source.submitted_roles,
            "claims": claims,
            "parse_errors": errors,
            "model": response.model,
            "model_config_id": model.id,
            "model_metadata": response.response_metadata,
            "usage": response.usage,
            "raw_response": response.content,
        }

    records = await asyncio.gather(
        *(translate(result, source) for result, source in selected)
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        "".join(
            json.dumps(record, sort_keys=True) + "\n"
            for record in records
        ),
        encoding="utf-8",
    )
    return {
        "output": str(output),
        "manifest": str(manifest_path),
        "model": model.model,
        "reasoning_effort": model.params.get("reasoning_effort"),
        **_summarize(records, time.monotonic() - started),
    }


def run_compact_initials(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return asyncio.run(generate_compact_initials(*args, **kwargs))


def rescore_compact_fields(path: Path) -> dict[str, Any]:
    """Reparse saved raw field responses without making model calls."""
    records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    for record in records:
        claims, errors = parse_compact_field(record["raw_response"], record["source_text"])
        record["claims"] = claims
        record["parse_errors"] = errors
    path.write_text("".join(json.dumps(record, sort_keys=True) + "\n" for record in records), encoding="utf-8")
    report = _summarize(records, 0.0)
    report["rescored_from_stored_responses"] = True
    return report
