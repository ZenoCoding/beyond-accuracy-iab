"""Gold-aware comparison reports for compact KKS formalizations."""

from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from controlmad.harness.storage import ExperimentStorage

from .formal_logic_field_gold import (
    evaluate_field_gold,
    load_compact_fields,
    load_field_gold,
)


OUTCOMES = (
    "full_pass",
    "dependency_failure",
    "metadata_failure",
    "missing_expression",
)
OUTCOME_COLORS = {
    "full_pass": "#2F7D4A",
    "dependency_failure": "#8F2D3A",
    "metadata_failure": "#D79A24",
    "missing_expression": "#8793A0",
}


def _resolve(base: Path, value: str | Path) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _source_models(run_dir: Path | None) -> dict[str, dict[str, Any]]:
    if run_dir is None:
        return {}
    config = ExperimentStorage(str(run_dir)).load_resolved_config()
    output = {}
    for agent in config.get("debate", {}).get("agents", []):
        model = agent.get("model", {})
        params = model.get("params", {})
        reasoning = params.get("reasoning_effort")
        nested = params.get("extra_body", {}).get("reasoning", {})
        if reasoning is None and nested.get("enabled") is False:
            reasoning = "disabled"
        output[str(agent["id"])] = {
            "source_model_id": model.get("id"),
            "source_model": model.get("model"),
            "source_reasoning_effort": reasoning,
        }
    return output


def _outcome(row: Mapping[str, Any]) -> str:
    if row["dependency_pass"]:
        return "full_pass"
    if row["metadata_pass"]:
        return "dependency_failure"
    if row["expression_pass"]:
        return "metadata_failure"
    return "missing_expression"


def _record_by_id(records: Sequence[Mapping[str, Any]]) -> dict[str, Mapping[str, Any]]:
    output = {}
    for record in records:
        identifier = str(record["formalization_id"])
        if identifier in output:
            raise ValueError("duplicate formalization_id: %s" % identifier)
        output[identifier] = record
    return output


def _asserted_role_rows(record: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Extract only positive role atoms asserted alone or inside conjunctions."""
    submitted = dict(record.get("submitted_roles") or {})

    def atoms(expression: Any) -> list[Mapping[str, Any]]:
        if not isinstance(expression, Mapping):
            return []
        if expression.get("op") == "role_is":
            return [expression]
        if expression.get("op") == "and":
            return atoms(expression.get("left")) + atoms(expression.get("right"))
        return []

    rows = []
    for claim in record.get("claims", []):
        if claim.get("stance") != "assert":
            continue
        for atom in atoms(claim.get("expression")):
            player = "Player %s" % chr(ord("A") + int(atom["player"]))
            claimed = str(atom["role"])
            submitted_role = submitted.get(player)
            rows.append({
                "actual_claim_id": claim.get("id"),
                "source_span": claim.get("source_span"),
                "player": player,
                "claimed_role": claimed,
                "submitted_role": submitted_role,
                "role_consistency": (
                    "match" if submitted_role == claimed
                    else "mismatch" if submitted_role is not None
                    else "submitted_role_missing"
                ),
            })
    return rows


def _variant_rows(
    variant: Mapping[str, Any],
    records: Sequence[Mapping[str, Any]],
    gold: Sequence[Mapping[str, Any]],
    source_models: Mapping[str, Mapping[str, Any]],
) -> tuple[
    dict[str, Any], list[dict[str, Any]], list[dict[str, Any]],
    list[dict[str, Any]], list[dict[str, Any]],
]:
    report = evaluate_field_gold(records, gold)
    records_by_id = _record_by_id(records)
    gold_by_id = {str(field["id"]): field for field in gold}
    claim_rows: list[dict[str, Any]] = []
    field_rows: list[dict[str, Any]] = []
    forbidden_rows: list[dict[str, Any]] = []
    role_rows: list[dict[str, Any]] = []
    for evaluated in report["rows"]:
        field_id = str(evaluated["id"])
        field = gold_by_id[field_id]
        source = dict(field.get("source") or {})
        record = records_by_id.get(str(evaluated.get("formalization_id", "")), {})
        if not source:
            source = dict(record.get("source") or {})
        agent_id = str(source.get("agent_id") or "unknown")
        source_model = dict(source_models.get(agent_id, {}))
        required = {str(item["id"]): item for item in field["required_claims"]}
        evaluated_claims = list(evaluated.get("required_claims", []))
        for item in evaluated_claims:
            gold_claim = required[str(item["id"])]
            claim_rows.append({
                "variant_id": variant["id"],
                "formalizer_model": variant["model"],
                "formalizer_reasoning_effort": variant["reasoning_effort"],
                "prompt_version": variant["prompt_version"],
                "field_id": field_id,
                "task_id": source.get("task_id"),
                "agent_id": agent_id,
                **source_model,
                "claim_id": item["id"],
                "source_span": gold_claim.get("source_span"),
                "gold_stance": gold_claim.get("stance"),
                "gold_expression": json.dumps(gold_claim.get("expression"), sort_keys=True),
                "expression_pass": int(item["expression_pass"]),
                "metadata_pass": int(item["metadata_pass"]),
                "dependency_pass": int(item["dependency_pass"]),
                "outcome": _outcome(item),
                "actual_claim_ids": ";".join(map(str, item.get("actual_claim_ids", []))),
            })
        for item in evaluated.get("forbidden_claims", []):
            forbidden_rows.append({
                "variant_id": variant["id"],
                "formalizer_reasoning_effort": variant["reasoning_effort"],
                "prompt_version": variant["prompt_version"],
                "field_id": field_id,
                "task_id": source.get("task_id"),
                "agent_id": agent_id,
                **source_model,
                "forbidden_claim_id": item["id"],
                "passed": int(item["passed"]),
                "actual_claim_ids": ";".join(map(str, item.get("actual_claim_ids", []))),
            })
        outcomes = Counter(_outcome(item) for item in evaluated_claims)
        usage = dict(record.get("usage") or {})
        claims = list(record.get("claims") or [])
        record_roles = _asserted_role_rows(record)
        for role_row in record_roles:
            role_rows.append({
                "variant_id": variant["id"],
                "formalizer_model": variant["model"],
                "formalizer_reasoning_effort": variant["reasoning_effort"],
                "prompt_version": variant["prompt_version"],
                "field_id": field_id,
                "task_id": source.get("task_id"),
                "agent_id": agent_id,
                **source_model,
                **role_row,
            })
        field_rows.append({
            "variant_id": variant["id"],
            "formalizer_model": variant["model"],
            "formalizer_reasoning_effort": variant["reasoning_effort"],
            "prompt_version": variant["prompt_version"],
            "field_id": field_id,
            "formalization_id": evaluated.get("formalization_id"),
            "task_id": source.get("task_id"),
            "agent_id": agent_id,
            **source_model,
            "required_claims": len(evaluated_claims),
            "extracted_claims": len(claims),
            "abstained_claims": sum(claim.get("stance") == "abstain" for claim in claims),
            "full_pass_claims": outcomes["full_pass"],
            "dependency_failures": outcomes["dependency_failure"],
            "metadata_failures": outcomes["metadata_failure"],
            "missing_expressions": outcomes["missing_expression"],
            "parse_errors": len(evaluated.get("parse_errors", [])),
            "forbidden_violations": sum(not item["passed"] for item in evaluated.get("forbidden_claims", [])),
            "asserted_role_claims": len(record_roles),
            "role_mismatch_claims": sum(row["role_consistency"] == "mismatch" for row in record_roles),
            "has_role_mismatch": int(any(row["role_consistency"] == "mismatch" for row in record_roles)),
            "field_passed": int(bool(evaluated.get("passed"))),
            "input_tokens": usage.get("input_tokens"),
            "output_tokens": usage.get("output_tokens"),
            "reasoning_output_tokens": usage.get("reasoning_output_tokens"),
            "latency_seconds": usage.get("latency_seconds"),
        })
    summary = {
        "variant_id": variant["id"],
        "formalizer_model": variant["model"],
        "formalizer_reasoning_effort": variant["reasoning_effort"],
        "prompt_version": variant["prompt_version"],
        **{key: value for key, value in report.items() if key != "rows"},
        "extracted_claim_count": sum(row["extracted_claims"] for row in field_rows),
        "abstained_claim_count": sum(row["abstained_claims"] for row in field_rows),
        "input_tokens": sum(int(row["input_tokens"] or 0) for row in field_rows),
        "output_tokens": sum(int(row["output_tokens"] or 0) for row in field_rows),
        "reasoning_output_tokens": sum(int(row["reasoning_output_tokens"] or 0) for row in field_rows),
        "latency_seconds": sum(float(row["latency_seconds"] or 0) for row in field_rows),
        "asserted_role_claims": sum(row["asserted_role_claims"] for row in field_rows),
        "role_mismatch_claims": sum(row["role_mismatch_claims"] for row in field_rows),
        "fields_with_role_mismatch": sum(row["has_role_mismatch"] for row in field_rows),
    }
    return summary, claim_rows, field_rows, forbidden_rows, role_rows


def _group_map(
    claim_rows: Sequence[Mapping[str, Any]],
    field_rows: Sequence[Mapping[str, Any]],
    key: str,
) -> list[dict[str, Any]]:
    claims: dict[tuple[str, str], list[Mapping[str, Any]]] = defaultdict(list)
    fields: dict[tuple[str, str], list[Mapping[str, Any]]] = defaultdict(list)
    for row in claim_rows:
        claims[(str(row["variant_id"]), str(row.get(key) or "unknown"))].append(row)
    for row in field_rows:
        fields[(str(row["variant_id"]), str(row.get(key) or "unknown"))].append(row)
    output = []
    for (variant_id, name), rows in sorted(claims.items()):
        related_fields = fields[(variant_id, name)]
        counts = Counter(str(row["outcome"]) for row in rows)
        total = len(rows)
        first = rows[0]
        output.append({
            "variant_id": variant_id,
            "formalizer_model": first["formalizer_model"],
            "formalizer_reasoning_effort": first["formalizer_reasoning_effort"],
            "prompt_version": first["prompt_version"],
            key: name,
            "source_model_id": first.get("source_model_id"),
            "source_model": first.get("source_model"),
            "source_reasoning_effort": first.get("source_reasoning_effort"),
            "required_claims": total,
            "expression_recall": sum(int(row["expression_pass"]) for row in rows) / total,
            "metadata_recall": sum(int(row["metadata_pass"]) for row in rows) / total,
            "dependency_recall": counts["full_pass"] / total,
            "field_count": len(related_fields),
            "field_pass_count": sum(int(row["field_passed"]) for row in related_fields),
            "field_pass_rate": sum(int(row["field_passed"]) for row in related_fields) / len(related_fields),
            **{outcome + "_claims": counts[outcome] for outcome in OUTCOMES},
            "parse_errors": sum(int(row["parse_errors"]) for row in related_fields),
            "forbidden_violations": sum(int(row["forbidden_violations"]) for row in related_fields),
            "asserted_role_claims": sum(int(row["asserted_role_claims"]) for row in related_fields),
            "role_mismatch_claims": sum(int(row["role_mismatch_claims"]) for row in related_fields),
            "fields_with_role_mismatch": sum(int(row["has_role_mismatch"]) for row in related_fields),
        })
    return output


def _transitions(
    claim_rows: Sequence[Mapping[str, Any]], comparisons: Sequence[Mapping[str, Any]]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    by_variant: dict[str, dict[tuple[str, str], Mapping[str, Any]]] = defaultdict(dict)
    for row in claim_rows:
        key = (str(row["field_id"]), str(row["claim_id"]))
        by_variant[str(row["variant_id"])][key] = row
    rows = []
    summaries = []
    for comparison in comparisons:
        left_id, right_id = str(comparison["left"]), str(comparison["right"])
        left, right = by_variant[left_id], by_variant[right_id]
        if set(left) != set(right):
            raise ValueError("comparison %s variants do not cover identical gold claims" % comparison["id"])
        counts: Counter[str] = Counter()
        agent_counts: dict[str, Counter[str]] = defaultdict(Counter)
        for key in sorted(left):
            before, after = left[key], right[key]
            before_pass = before["outcome"] == "full_pass"
            after_pass = after["outcome"] == "full_pass"
            transition = {
                (True, True): "stable_pass",
                (True, False): "regression",
                (False, True): "rescue",
                (False, False): "stable_fail",
            }[(before_pass, after_pass)]
            counts[transition] += 1
            agent_counts[str(before["agent_id"])][transition] += 1
            rows.append({
                "comparison_id": comparison["id"],
                "comparison_label": comparison.get("label", comparison["id"]),
                "left_variant": left_id,
                "right_variant": right_id,
                "field_id": key[0],
                "claim_id": key[1],
                "task_id": before["task_id"],
                "agent_id": before["agent_id"],
                "source_model": before.get("source_model"),
                "left_outcome": before["outcome"],
                "right_outcome": after["outcome"],
                "transition": transition,
            })
        total = len(left)
        summaries.append({
            "comparison_id": comparison["id"],
            "comparison_label": comparison.get("label", comparison["id"]),
            "left_variant": left_id,
            "right_variant": right_id,
            "required_claims": total,
            "stable_pass": counts["stable_pass"],
            "rescue": counts["rescue"],
            "regression": counts["regression"],
            "stable_fail": counts["stable_fail"],
            "net_rescues": counts["rescue"] - counts["regression"],
            "agents": {agent: dict(values) for agent, values in sorted(agent_counts.items())},
        })
    return rows, summaries


def _fonts():
    from PIL import ImageFont
    try:
        return (
            ImageFont.truetype("DejaVuSans.ttf", 13),
            ImageFont.truetype("DejaVuSans-Bold.ttf", 19),
            ImageFont.truetype("DejaVuSans.ttf", 11),
        )
    except OSError:
        fallback = ImageFont.load_default()
        return fallback, fallback, fallback


def _charts(
    output_dir: Path,
    summaries: Sequence[Mapping[str, Any]],
    agent_rows: Sequence[Mapping[str, Any]],
    transition_summaries: Sequence[Mapping[str, Any]],
    benchmark_id: str,
    required_claims: int,
) -> list[str]:
    from PIL import Image, ImageDraw
    font, title, small = _fonts()
    artifacts = []

    metrics = (
        ("expression_recall", "expression", "#3D78B4"),
        ("metadata_recall", "metadata", "#69A7C8"),
        ("dependency_recall", "dependencies", "#E18463"),
        ("field_pass_rate", "complete fields", "#6E9F72"),
    )
    width, height = max(980, 185 * len(summaries) + 180), 570
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    draw.text((18, 14), "%d-claim benchmark" % required_claims, fill="#243447", font=title)
    draw.text((18, 43), "%s · gold-standard recall and complete-field rate" % benchmark_id, fill="#526170", font=small)
    left, top, bottom, chart_h = 72, 82, 455, 345
    draw.line((left, top, left, bottom), fill="#8793A0", width=1)
    draw.line((left, bottom, width - 20, bottom), fill="#8793A0", width=1)
    for tick in range(0, 101, 20):
        y = bottom - chart_h * tick / 100
        draw.line((left, y, width - 20, y), fill="#E5E9ED", width=1)
        draw.text((30, y - 7), "%d%%" % tick, fill="#526170", font=small)
    group_w = (width - left - 35) / len(summaries)
    bar_w = min(28, (group_w - 20) / len(metrics))
    for index, row in enumerate(summaries):
        center = left + group_w * (index + .5)
        for metric_index, (key, _, color) in enumerate(metrics):
            value = float(row[key])
            x = center + (metric_index - 1.5) * bar_w
            y = bottom - chart_h * value
            draw.rectangle((x, y, x + bar_w - 2, bottom), fill=color)
        label = "%s\n%s" % (row["formalizer_reasoning_effort"], row["prompt_version"].rsplit("-", 1)[-1].upper())
        for line_index, line in enumerate(label.splitlines()):
            box = draw.textbbox((0, 0), line, font=small)
            draw.text((center - (box[2] - box[0]) / 2, bottom + 10 + 16 * line_index), line, fill="#243447", font=small)
    cursor = 80
    for _, label, color in metrics:
        draw.rectangle((cursor, 522, cursor + 12, 534), fill=color)
        draw.text((cursor + 17, 519), label, fill="#243447", font=small)
        cursor += 190
    path = output_dir / "variant-metrics.png"
    image.save(path)
    artifacts.append(path.name)

    variants = [str(row["variant_id"]) for row in summaries]
    agents = sorted({str(row["agent_id"]) for row in agent_rows})
    lookup = {(str(row["variant_id"]), str(row["agent_id"])): row for row in agent_rows}
    cell_w, cell_h, left, top = 150, 58, 330, 80
    width, height = left + cell_w * len(variants) + 25, top + cell_h * len(agents) + 45
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    draw.text((18, 14), "Dependency recall by source agent", fill="#243447", font=title)
    draw.text((18, 43), "Agent models come from the frozen source debate run", fill="#526170", font=small)
    for column, variant in enumerate(variants):
        x = left + column * cell_w + cell_w / 2
        box = draw.textbbox((0, 0), variant, font=small)
        draw.text((x - (box[2] - box[0]) / 2, 63), variant, fill="#243447", font=small)
    for row_index, agent in enumerate(agents):
        y = top + row_index * cell_h
        model_row = next((row for row in agent_rows if row["agent_id"] == agent), {})
        draw.text((18, y + 8), agent, fill="#243447", font=font)
        draw.text((18, y + 30), str(model_row.get("source_model") or "model unavailable"), fill="#526170", font=small)
        for column, variant in enumerate(variants):
            row = lookup.get((variant, agent))
            x = left + column * cell_w
            if row is None:
                draw.rectangle((x + 3, y + 3, x + cell_w - 3, y + cell_h - 3), fill="#F1F3F5")
                value = "n/a"
            else:
                rate = float(row["dependency_recall"])
                base = (47, 125, 74)
                alpha = .12 + .78 * rate
                color = tuple(round(255 * (1 - alpha) + part * alpha) for part in base)
                draw.rectangle((x + 3, y + 3, x + cell_w - 3, y + cell_h - 3), fill=color)
                value = "%.1f%% · n=%d" % (100 * rate, row["required_claims"])
            box = draw.textbbox((0, 0), value, font=small)
            draw.text((x + cell_w / 2 - (box[2] - box[0]) / 2, y + 22), value, fill="#243447", font=small)
    path = output_dir / "agent-recall-map.png"
    image.save(path)
    artifacts.append(path.name)

    if transition_summaries:
        transitions = ("stable_pass", "rescue", "regression", "stable_fail")
        colors = ("#2F7D4A", "#69A7C8", "#C94F4F", "#8793A0")
        width, height = 930, 175 + 95 * len(transition_summaries)
        image = Image.new("RGB", (width, height), "white")
        draw = ImageDraw.Draw(image)
        draw.text((18, 14), "Matched claim transitions", fill="#243447", font=title)
        draw.text((18, 43), "Same prompt version; higher effort is the right-hand variant", fill="#526170", font=small)
        for index, row in enumerate(transition_summaries):
            y = 82 + index * 95
            label = str(row["comparison_label"]).replace("→", "to")
            draw.text((18, y + 13), label, fill="#243447", font=small)
            cursor = 280.0
            total = int(row["required_claims"])
            for key, color in zip(transitions, colors, strict=True):
                segment = 600 * int(row[key]) / total
                draw.rectangle((round(cursor), y, round(cursor + segment), y + 42), fill=color)
                cursor += segment
            draw.text((885, y + 13), "n=%d" % total, fill="#243447", font=small)
        cursor = 210
        for key, color in zip(transitions, colors, strict=True):
            draw.rectangle((cursor, height - 33, cursor + 12, height - 21), fill=color)
            draw.text((cursor + 17, height - 35), key.replace("_", " "), fill="#243447", font=small)
            cursor += 170
        path = output_dir / "matched-transitions.png"
        image.save(path)
        artifacts.append(path.name)
    return artifacts


def _markdown(
    benchmark_id: str,
    summaries: Sequence[Mapping[str, Any]],
    transition_summaries: Sequence[Mapping[str, Any]],
    output_dir: Path,
) -> str:
    lines = [
        "# Compact Formal-Logic Benchmark Analysis",
        "",
        "Benchmark: `%s`" % benchmark_id,
        "",
        "## Variant comparison",
        "",
        "| Variant | Model | Effort | Prompt | Expression | Metadata | Dependencies | Complete fields | Parse errors | Forbidden | Role conflicts |",
        "|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summaries:
        lines.append(
            "| %s | `%s` | %s | %s | %.1f%% | %.1f%% | %.1f%% | %d/%d | %d | %d | %d |"
            % (
                row["variant_id"], row["formalizer_model"], row["formalizer_reasoning_effort"],
                row["prompt_version"], 100 * row["expression_recall"],
                100 * row["metadata_recall"], 100 * row["dependency_recall"],
                row["field_pass_count"], row["field_count"], row["parse_error_count"],
                row["forbidden_violation_count"], row["role_mismatch_claims"],
            )
        )
    lines.extend(["", "![Variant metrics](%s)" % (output_dir / "variant-metrics.png").resolve().as_posix(), "", "![Agent recall map](%s)" % (output_dir / "agent-recall-map.png").resolve().as_posix()])
    if transition_summaries:
        lines.extend([
            "", "## Matched effort transitions", "",
            "| Comparison | Stable pass | Rescues | Regressions | Stable fail | Net rescues |",
            "|---|---:|---:|---:|---:|---:|",
        ])
        for row in transition_summaries:
            lines.append("| %s | %d | %d | %d | %d | %+d |" % (
                row["comparison_label"], row["stable_pass"], row["rescue"],
                row["regression"], row["stable_fail"], row["net_rescues"],
            ))
        lines.extend(["", "![Matched transitions](%s)" % (output_dir / "matched-transitions.png").resolve().as_posix()])
    lines.extend([
        "", "## Interpretation guardrails", "",
        "- These scores measure translation fidelity against expert-required claims, not whether the source explanation is logically correct.",
        "- Same-prompt comparisons are the closest available effort contrasts; cross-prompt variant differences are not causal.",
        "- Prompt-version comparisons mix instruction changes with model behavior and are diagnostic.",
        "- Agent rows have unequal numbers of gold claims, so compare rates with their displayed denominators.",
        "- Role conflicts compare asserted positive role atoms with submitted roles; intermediate revisions can therefore appear as conflicts.",
        "- This is a frozen, small benchmark and not a population estimate.",
        "",
    ])
    return "\n".join(lines)


def analyze_compact_benchmark(config_path: Path, output_dir: Path) -> dict[str, Any]:
    config = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    if int(config.get("schema_version", 0)) != 1:
        raise ValueError("compact benchmark report requires schema_version 1")
    base = config_path.parent
    gold_path = _resolve(base, config["gold"])
    source_run = _resolve(base, config["source_run_dir"]) if config.get("source_run_dir") else None
    gold = load_field_gold(gold_path)
    source_models = _source_models(source_run)
    variants = []
    seen = set()
    all_claims: list[dict[str, Any]] = []
    all_fields: list[dict[str, Any]] = []
    all_forbidden: list[dict[str, Any]] = []
    all_roles: list[dict[str, Any]] = []
    for value in config.get("variants", []):
        variant_id = str(value["id"])
        if variant_id in seen:
            raise ValueError("duplicate variant id: %s" % variant_id)
        seen.add(variant_id)
        records = load_compact_fields(_resolve(base, value["input"]))
        first = records[0]
        variant = {
            "id": variant_id,
            "model": first.get("model"),
            "reasoning_effort": first.get("model_metadata", {}).get("reasoning_effort"),
            "prompt_version": first.get("prompt_version"),
        }
        if any(
            record.get("model") != variant["model"]
            or record.get("prompt_version") != variant["prompt_version"]
            or record.get("model_metadata", {}).get("reasoning_effort") != variant["reasoning_effort"]
            for record in records
        ):
            raise ValueError("variant %s mixes model metadata" % variant_id)
        summary, claims, fields, forbidden, roles = _variant_rows(
            variant, records, gold, source_models
        )
        variants.append(summary)
        all_claims.extend(claims)
        all_fields.extend(fields)
        all_forbidden.extend(forbidden)
        all_roles.extend(roles)
    if not variants:
        raise ValueError("compact benchmark report requires at least one variant")
    comparisons = list(config.get("comparisons", []))
    unknown = {
        str(value[key])
        for value in comparisons for key in ("left", "right")
        if str(value[key]) not in seen
    }
    if unknown:
        raise ValueError("comparison references unknown variants: %s" % sorted(unknown))
    transition_rows, transition_summaries = _transitions(all_claims, comparisons)
    agent_rows = _group_map(all_claims, all_fields, "agent_id")
    task_rows = _group_map(all_claims, all_fields, "task_id")
    output_dir.mkdir(parents=True, exist_ok=True)
    _write_csv(output_dir / "variant-summary.csv", variants)
    _write_csv(output_dir / "claim-results.csv", all_claims)
    _write_csv(output_dir / "field-results.csv", all_fields)
    _write_csv(output_dir / "forbidden-results.csv", all_forbidden)
    _write_csv(output_dir / "role-consistency.csv", all_roles)
    _write_csv(output_dir / "agent-map.csv", agent_rows)
    _write_csv(output_dir / "task-map.csv", task_rows)
    _write_csv(output_dir / "matched-transitions.csv", transition_rows)
    _write_csv(output_dir / "matched-transition-summary.csv", transition_summaries)
    benchmark_id = str(config.get("benchmark_id", config_path.stem))
    chart_artifacts = _charts(
        output_dir, variants, agent_rows, transition_summaries,
        benchmark_id, int(variants[0]["required_claim_count"]),
    )
    payload = {
        "schema_version": 1,
        "benchmark_id": benchmark_id,
        "gold": str(gold_path),
        "source_run_dir": str(source_run) if source_run else None,
        "variants": variants,
        "agents": agent_rows,
        "tasks": task_rows,
        "comparisons": transition_summaries,
        "limitations": [
            "Translation fidelity is not source-reasoning validity.",
            "Only same-prompt comparisons isolate reasoning effort.",
            "The frozen regression set is not a population estimate.",
        ],
    }
    (output_dir / "summary.json").write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (output_dir / "README.md").write_text(
        _markdown(str(payload["benchmark_id"]), variants, transition_summaries, output_dir),
        encoding="utf-8",
    )
    return {
        "output_dir": str(output_dir),
        "benchmark_id": payload["benchmark_id"],
        "variant_count": len(variants),
        "required_claims_per_variant": variants[0]["required_claim_count"],
        "artifacts": [
            "README.md", "summary.json", "variant-summary.csv", "claim-results.csv",
            "field-results.csv", "forbidden-results.csv", "agent-map.csv", "task-map.csv",
            "role-consistency.csv", "matched-transitions.csv",
            "matched-transition-summary.csv", *chart_artifacts,
        ],
    }
