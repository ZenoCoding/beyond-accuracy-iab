"""Load analysis prompts from reviewable Markdown templates."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from string import Template


PROMPT_DIR = Path(__file__).with_name("prompts")


@lru_cache(maxsize=None)
def load_prompt(name: str) -> str:
    path = PROMPT_DIR / name
    if path.parent != PROMPT_DIR or path.suffix != ".md":
        raise ValueError("prompt name must be one Markdown filename")
    return path.read_text(encoding="utf-8").strip()


def render_prompt(name: str, **values: object) -> str:
    return Template(load_prompt(name)).substitute(
        {key: str(value) for key, value in values.items()}
    )
