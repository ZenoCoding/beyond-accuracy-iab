"""Descriptive reports for formalized KKS debate reasoning."""

from __future__ import annotations

import html
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from controlmad.harness.benchmark import benchmark_from_config
from controlmad.harness.runner import config_from_resolved_dict
from controlmad.harness.storage import ExperimentStorage

from .core import write_csv


VERDICTS = (
    "entailed",
    "contingent",
    "contradicted",
    "inconsistent_premises",
    "ambiguous",
    "unformalizable",
)
SATISFIABLE_VERDICTS = ("entailed", "contingent", "contradicted")
MACHINE_VERDICTS = (*SATISFIABLE_VERDICTS, "inconsistent_premises")
STAGE_ORDER = {
    "initial_proposal": 0,
    "debate_argument": 1,
    "self_adjustment": 2,
    "second_proposal": 3,
    "final_decision": 4,
    "consensus_supervisor": 5,
    "supervisor": 6,
}
VERDICT_COLORS = {
    "entailed": "#2F7D4A",
    "contingent": "#D79A24",
    "contradicted": "#C94F4F",
    "inconsistent_premises": "#8F2D3A",
    "ambiguous": "#6F63A8",
    "unformalizable": "#8793A0",
}


def _load(path: Path) -> list[dict[str, Any]]:
    rows = []
    seen = set()
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        value = json.loads(line)
        formalization_id = str(value["formalization_id"])
        if formalization_id in seen:
            raise ValueError("duplicate formalization_id on line %d" % line_number)
        seen.add(formalization_id)
        rows.append(value)
    if not rows:
        raise ValueError("formalization input is empty")
    return rows


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def flatten_steps(records: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for record in records:
        source = record["source"]
        for step_index, step in enumerate(record.get("steps", []), start=1):
            check = step["check"]
            rows.append({
                "formalization_id": record["formalization_id"],
                "task_id": source.get("task_id"),
                "run_id": source.get("run_id"),
                "repetition": source.get("repetition"),
                "agent_id": source.get("agent_id"),
                "stage": source.get("stage"),
                "round_index": source.get("round_index"),
                "player": source.get("player"),
                "reasoning_field": source.get("field"),
                "step_index": step_index,
                "source_span": step.get("source_span"),
                "field_translation_status": record.get("translation_status"),
                "step_translation_status": step.get("translation_status"),
                "confidence": step.get("confidence"),
                "rule": step.get("rule"),
                "axioms": _canonical(step.get("axioms", [])),
                "assumptions": _canonical(step.get("assumptions", [])),
                "premises": _canonical(step.get("premises", [])),
                "conclusion": _canonical(step.get("conclusion")),
                "claim_key": _canonical(step.get("conclusion")) if step.get("conclusion") else "",
                "verdict": check.get("verdict"),
                "model_count": check.get("model_count"),
                "true_count": check.get("true_count"),
                "false_count": check.get("false_count"),
                "role_consistency": record.get("role_consistency", {}).get("status"),
                "submitted_roles": _canonical(record.get("submitted_roles", {})),
                "claimed_roles": _canonical(record.get("claimed_roles", {})),
            })
    return rows


def flatten_fields(records: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for record in records:
        source = record["source"]
        counts = Counter(step["check"]["verdict"] for step in record.get("steps", []))
        satisfiable = sum(counts[name] for name in SATISFIABLE_VERDICTS)
        machine = sum(counts[name] for name in MACHINE_VERDICTS)
        row = {
            "formalization_id": record["formalization_id"],
            "task_id": source.get("task_id"),
            "run_id": source.get("run_id"),
            "repetition": source.get("repetition"),
            "agent_id": source.get("agent_id"),
            "stage": source.get("stage"),
            "round_index": source.get("round_index"),
            "player": source.get("player"),
            "reasoning_field": source.get("field"),
            "translation_status": record.get("translation_status"),
            "role_consistency": record.get("role_consistency", {}).get("status"),
            "step_count": sum(counts.values()),
            "machine_evaluated_steps": machine,
            "satisfiable_premise_steps": satisfiable,
            "entailed_share_satisfiable": counts["entailed"] / satisfiable if satisfiable else None,
            "contradicted_share_satisfiable": counts["contradicted"] / satisfiable if satisfiable else None,
            "contingent_share_satisfiable": counts["contingent"] / satisfiable if satisfiable else None,
            "source_text": record.get("source_text", ""),
        }
        for verdict in VERDICTS:
            row[verdict + "_steps"] = counts[verdict]
            row["any_" + verdict] = int(counts[verdict] > 0)
        rows.append(row)
    return rows


def _group_map(field_rows: Sequence[Mapping[str, Any]], key: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for row in field_rows:
        grouped[str(row.get(key) or "unknown")].append(row)
    output = []
    for name, rows in sorted(grouped.items()):
        counts = Counter()
        for row in rows:
            for verdict in VERDICTS:
                counts[verdict] += int(row[verdict + "_steps"])
        satisfiable = sum(counts[name] for name in SATISFIABLE_VERDICTS)
        machine = sum(counts[name] for name in MACHINE_VERDICTS)
        total = sum(counts.values())
        result = {
            key: name,
            "field_count": len(rows),
            "step_count": total,
            "machine_evaluated_steps": machine,
            "machine_evaluated_rate": machine / total if total else 0.0,
            "satisfiable_premise_steps": satisfiable,
            "entailed_share_satisfiable": counts["entailed"] / satisfiable if satisfiable else None,
            "contingent_share_satisfiable": counts["contingent"] / satisfiable if satisfiable else None,
            "contradicted_share_satisfiable": counts["contradicted"] / satisfiable if satisfiable else None,
            "fields_with_contradiction": sum(int(row["any_contradicted"]) for row in rows),
            "fields_with_inconsistent_premises": sum(
                int(row["any_inconsistent_premises"]) for row in rows
            ),
            "role_mismatch_fields": sum(row["role_consistency"] == "mismatch" for row in rows),
        }
        for verdict in VERDICTS:
            result[verdict + "_steps"] = counts[verdict]
            result[verdict + "_share_all_steps"] = counts[verdict] / total if total else 0.0
        output.append(result)
    return output


def _source_order(row: Mapping[str, Any]) -> tuple[Any, ...]:
    return (
        str(row.get("task_id")),
        int(row.get("repetition") or 1),
        STAGE_ORDER.get(str(row.get("stage")), 99),
        int(row.get("round_index") or 0),
        str(row.get("agent_id")),
        int(row.get("step_index") or 0),
    )


def claim_map(step_rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Map repeated formal conclusions without claiming causal influence."""
    prior: dict[tuple[str, str], list[Mapping[str, Any]]] = defaultdict(list)
    output = []
    for row in sorted(step_rows, key=_source_order):
        claim_key = str(row.get("claim_key") or "")
        key = (str(row.get("task_id")), claim_key)
        earlier = prior[key] if claim_key else []
        peer_agents = sorted({
            str(item["agent_id"]) for item in earlier
            if item.get("agent_id") != row.get("agent_id")
        })
        contradicted_peers = sorted({
            str(item["agent_id"]) for item in earlier
            if item.get("agent_id") != row.get("agent_id")
            and item.get("verdict") == "contradicted"
        })
        output.append({
            "task_id": row.get("task_id"),
            "claim_key": claim_key,
            "agent_id": row.get("agent_id"),
            "stage": row.get("stage"),
            "round_index": row.get("round_index"),
            "verdict": row.get("verdict"),
            "source_span": row.get("source_span"),
            "seen_previously": int(bool(earlier)),
            "seen_from_prior_peer": int(bool(peer_agents)),
            "prior_peer_agents": ";".join(peer_agents),
            "seen_after_peer_contradiction": int(bool(contradicted_peers)),
            "prior_contradicted_peer_agents": ";".join(contradicted_peers),
        })
        if claim_key:
            prior[key].append(row)
    return output


def _answer_maps(run_dir: Path | None) -> dict[str, dict[str, str]]:
    if run_dir is None:
        return {}
    storage = ExperimentStorage(str(run_dir))
    resolved = config_from_resolved_dict(storage.load_resolved_config())
    return {
        task.id: dict(task.answer or {})
        for task in benchmark_from_config(resolved.benchmark, resolved.config_root).load()
    }


def _agent_models(run_dir: Path | None) -> dict[str, dict[str, Any]]:
    if run_dir is None:
        return {}
    config = ExperimentStorage(str(run_dir)).load_resolved_config()
    output = {}
    for agent in config.get("debate", {}).get("agents", []):
        model = agent.get("model", {})
        params = model.get("params", {})
        provider = model.get("provider")
        model_name = model.get("model")
        if not provider and isinstance(model_name, str) and "/" in model_name:
            provider = model_name.split("/", 1)[0]
        reasoning_effort = params.get("reasoning_effort")
        reasoning_config = params.get("extra_body", {}).get("reasoning", {})
        if reasoning_effort is None and reasoning_config.get("enabled") is False:
            reasoning_effort = "disabled"
        output[str(agent.get("id"))] = {
            "model_id": model.get("id"),
            "model": model_name,
            "provider": provider,
            "reasoning_effort": reasoning_effort,
        }
    return output


def final_decision_audit(
    records: Sequence[Mapping[str, Any]],
    answers: Mapping[str, Mapping[str, str]],
) -> list[dict[str, Any]]:
    output = []
    for record in records:
        source = record["source"]
        if source.get("stage") != "final_decision":
            continue
        verdicts = Counter(step["check"]["verdict"] for step in record.get("steps", []))
        submitted = dict(record.get("submitted_roles", {}))
        answer = dict(answers.get(str(source.get("task_id")), {}))
        output.append({
            "task_id": source.get("task_id"),
            "agent_id": source.get("agent_id"),
            "submitted_roles": _canonical(submitted),
            "answer_available": int(bool(answer)),
            "answer_correct": int(submitted == answer) if answer else None,
            "role_consistency": record.get("role_consistency", {}).get("status"),
            "has_contradicted_step": int(verdicts["contradicted"] > 0),
            "has_contingent_step": int(verdicts["contingent"] > 0),
            "has_inconsistent_premises": int(verdicts["inconsistent_premises"] > 0),
            "entailed_steps": verdicts["entailed"],
            "step_count": sum(verdicts.values()),
        })
    return output


def _overall_summary(
    records: Sequence[Mapping[str, Any]],
    fields: Sequence[Mapping[str, Any]],
    steps: Sequence[Mapping[str, Any]],
    expected_fields: int | None,
) -> dict[str, Any]:
    verdicts = Counter(str(row["verdict"]) for row in steps)
    translations = Counter(str(record.get("translation_status")) for record in records)
    satisfiable = sum(verdicts[name] for name in SATISFIABLE_VERDICTS)
    machine = sum(verdicts[name] for name in MACHINE_VERDICTS)
    claim_bearing = sum(bool(record.get("claimed_roles")) for record in records)
    return {
        "expected_fields": expected_fields,
        "analyzed_nonempty_fields": len(records),
        "empty_or_missing_fields": (
            expected_fields - len(records) if expected_fields is not None else None
        ),
        "nonempty_field_coverage": (
            len(records) / expected_fields if expected_fields else None
        ),
        "translation_status_counts": dict(translations),
        "step_count": len(steps),
        "verdict_counts": {name: verdicts[name] for name in VERDICTS},
        "machine_evaluated_steps": machine,
        "machine_evaluated_rate": machine / len(steps) if steps else 0.0,
        "satisfiable_premise_steps": satisfiable,
        "entailed_share_satisfiable": verdicts["entailed"] / satisfiable if satisfiable else None,
        "contingent_share_satisfiable": verdicts["contingent"] / satisfiable if satisfiable else None,
        "contradicted_share_satisfiable": verdicts["contradicted"] / satisfiable if satisfiable else None,
        "fields_with_contradicted_step": sum(int(row["any_contradicted"]) for row in fields),
        "fields_with_contingent_step": sum(int(row["any_contingent"]) for row in fields),
        "fields_with_inconsistent_premises": sum(
            int(row["any_inconsistent_premises"]) for row in fields
        ),
        "claim_bearing_fields": claim_bearing,
        "role_mismatch_fields": sum(
            record.get("role_consistency", {}).get("status") == "mismatch"
            for record in records
        ),
    }


def _heatmap(path: Path, agent_rows: Sequence[Mapping[str, Any]]) -> None:
    cell_w, cell_h, left, top = 138, 66, 320, 74
    width = left + cell_w * len(VERDICTS) + 24
    height = top + cell_h * len(agent_rows) + 58
    parts = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d">'
        % (width, height, width, height),
        '<rect width="100%" height="100%" fill="#fff"/>',
        '<style>text{font-family:DejaVu Sans,Arial,sans-serif;fill:#243447}.title{font-size:18px;font-weight:600}.label{font-size:12px}.value{font-size:12px;font-weight:600}</style>',
        '<text class="title" x="16" y="28">Agent × formal verdict map</text>',
        '<text class="label" x="16" y="48">Cells show count and share of each agent’s extracted steps; model labels come from the source run.</text>',
    ]
    for column, verdict in enumerate(VERDICTS):
        x = left + column * cell_w + cell_w / 2
        label = verdict.replace("_", " ")
        parts.append('<text class="label" text-anchor="middle" x="%.1f" y="68">%s</text>' % (x, html.escape(label)))
    for row_index, row in enumerate(agent_rows):
        y = top + row_index * cell_h
        total = int(row["step_count"])
        parts.append('<text class="value" x="16" y="%.1f">%s</text>' % (
            y + 24,
            html.escape(str(row["agent_id"])),
        ))
        model_label = str(row.get("model") or row.get("model_id") or "model unavailable")
        effort = row.get("reasoning_effort")
        if effort:
            model_label += " · reasoning=" + str(effort)
        parts.append('<text class="label" x="16" y="%.1f">%s</text>' % (
            y + 43, html.escape(model_label),
        ))
        for column, verdict in enumerate(VERDICTS):
            count = int(row[verdict + "_steps"])
            share = count / total if total else 0.0
            x = left + column * cell_w
            color = VERDICT_COLORS[verdict]
            opacity = 0.12 + 0.78 * share
            parts.append('<rect x="%d" y="%d" width="%d" height="%d" rx="4" fill="%s" fill-opacity="%.3f"/>' % (
                x + 3, y + 4, cell_w - 6, cell_h - 8, color, opacity,
            ))
            parts.append('<text class="value" text-anchor="middle" x="%.1f" y="%.1f">%d · %.1f%%</text>' % (
                x + cell_w / 2, y + cell_h / 2 + 4, count, 100 * share,
            ))
    parts.append('</svg>')
    path.write_text("\n".join(parts) + "\n", encoding="utf-8")


def _stage_chart(path: Path, stage_rows: Sequence[Mapping[str, Any]]) -> None:
    stages = sorted(stage_rows, key=lambda row: STAGE_ORDER.get(str(row["stage"]), 99))
    width, left, bar_w, bar_h = 1040, 175, 820, 42
    height = 75 + len(stages) * 66 + 58
    parts = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d">' % (width, height, width, height),
        '<rect width="100%" height="100%" fill="#fff"/>',
        '<style>text{font-family:DejaVu Sans,Arial,sans-serif;fill:#243447}.title{font-size:18px;font-weight:600}.label{font-size:12px}</style>',
        '<text class="title" x="16" y="28">Formal verdict distribution by debate stage</text>',
    ]
    for index, row in enumerate(stages):
        y = 58 + index * 66
        total = int(row["step_count"])
        parts.append('<text class="label" x="16" y="%d">%s</text>' % (y + 26, html.escape(str(row["stage"]).replace("_", " "))))
        cursor = left
        for verdict in VERDICTS:
            count = int(row[verdict + "_steps"])
            segment = bar_w * count / total if total else 0
            if segment:
                parts.append('<rect x="%.1f" y="%d" width="%.1f" height="%d" fill="%s"/>' % (
                    cursor, y, segment, bar_h, VERDICT_COLORS[verdict],
                ))
            cursor += segment
        parts.append('<text class="label" x="%d" y="%d">n=%d</text>' % (left + bar_w + 8, y + 26, total))
    legend_y = height - 28
    cursor = 16
    for verdict in VERDICTS:
        parts.append('<rect x="%d" y="%d" width="12" height="12" fill="%s"/>' % (cursor, legend_y - 10, VERDICT_COLORS[verdict]))
        parts.append('<text class="label" x="%d" y="%d">%s</text>' % (cursor + 17, legend_y, html.escape(verdict.replace("_", " "))))
        cursor += 155
    parts.append('</svg>')
    path.write_text("\n".join(parts) + "\n", encoding="utf-8")


def _png_charts(
    output_dir: Path,
    agent_rows: Sequence[Mapping[str, Any]],
    stage_rows: Sequence[Mapping[str, Any]],
) -> None:
    """Write broadly renderable PNG companions to the editable SVG charts."""
    from PIL import Image, ImageDraw, ImageFont

    try:
        font = ImageFont.truetype("DejaVuSans.ttf", 15)
        small = ImageFont.truetype("DejaVuSans.ttf", 12)
        title = ImageFont.truetype("DejaVuSans-Bold.ttf", 20)
    except OSError:
        font = small = title = ImageFont.load_default()

    cell_w, cell_h, left, top = 138, 66, 320, 78
    width = left + cell_w * len(VERDICTS) + 24
    height = top + cell_h * len(agent_rows) + 58
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    draw.text((16, 14), "Agent × formal verdict map", fill="#243447", font=title)
    draw.text((16, 43), "Count and share of each agent's extracted steps", fill="#243447", font=small)
    for column, verdict in enumerate(VERDICTS):
        label = verdict.replace("_", " ")
        x = left + column * cell_w + cell_w / 2
        box = draw.textbbox((0, 0), label, font=small)
        draw.text((x - (box[2] - box[0]) / 2, 62), label, fill="#243447", font=small)
    for row_index, row in enumerate(agent_rows):
        y = top + row_index * cell_h
        total = int(row["step_count"])
        draw.text((16, y + 10), str(row["agent_id"]), fill="#243447", font=font)
        model_label = str(row.get("model") or row.get("model_id") or "model unavailable")
        effort = row.get("reasoning_effort")
        if effort:
            model_label += " · reasoning=" + str(effort)
        draw.text((16, y + 34), model_label, fill="#243447", font=small)
        for column, verdict in enumerate(VERDICTS):
            count = int(row[verdict + "_steps"])
            share = count / total if total else 0.0
            x = left + column * cell_w
            base = tuple(bytes.fromhex(VERDICT_COLORS[verdict][1:]))
            alpha = 0.12 + 0.78 * share
            color = tuple(round(255 * (1 - alpha) + value * alpha) for value in base)
            draw.rounded_rectangle((x + 3, y + 4, x + cell_w - 3, y + cell_h - 4), 4, fill=color)
            value = "%d · %.1f%%" % (count, 100 * share)
            box = draw.textbbox((0, 0), value, font=small)
            draw.text((x + cell_w / 2 - (box[2] - box[0]) / 2, y + 25), value, fill="#243447", font=small)
    image.save(output_dir / "agent-verdict-heatmap.png")

    stages = sorted(stage_rows, key=lambda row: STAGE_ORDER.get(str(row["stage"]), 99))
    width, left, bar_w, bar_h = 1100, 190, 820, 42
    height = 75 + len(stages) * 66 + 58
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    draw.text((16, 14), "Formal verdict distribution by debate stage", fill="#243447", font=title)
    for index, row in enumerate(stages):
        y = 58 + index * 66
        total = int(row["step_count"])
        draw.text((16, y + 13), str(row["stage"]).replace("_", " "), fill="#243447", font=small)
        cursor = float(left)
        for verdict in VERDICTS:
            count = int(row[verdict + "_steps"])
            segment = bar_w * count / total if total else 0
            if segment:
                draw.rectangle((round(cursor), y, round(cursor + segment), y + bar_h), fill=VERDICT_COLORS[verdict])
            cursor += segment
        draw.text((left + bar_w + 8, y + 13), "n=%d" % total, fill="#243447", font=small)
    legend_y, cursor = height - 31, 16
    for verdict in VERDICTS:
        draw.rectangle((cursor, legend_y, cursor + 12, legend_y + 12), fill=VERDICT_COLORS[verdict])
        draw.text((cursor + 17, legend_y - 2), verdict.replace("_", " "), fill="#243447", font=small)
        cursor += 168
    image.save(output_dir / "stage-verdict-stacked.png")


def _markdown(
    summary: Mapping[str, Any],
    agent_rows: Sequence[Mapping[str, Any]],
    output_dir: Path,
) -> str:
    verdicts = summary["verdict_counts"]
    lines = [
        "# Formal Logic Analysis",
        "",
        "## Summary",
        "",
        "- Fields analyzed: %d%s" % (
            summary["analyzed_nonempty_fields"],
            " of %d slots" % summary["expected_fields"] if summary["expected_fields"] else "",
        ),
        "- Extracted steps: %d" % summary["step_count"],
        "- Mechanically evaluated: %d (%.1f%%)" % (
            summary["machine_evaluated_steps"], 100 * summary["machine_evaluated_rate"],
        ),
        "- Satisfiable-premise verdicts: %d entailed, %d contingent, %d contradicted" % (
            verdicts["entailed"], verdicts["contingent"], verdicts["contradicted"],
        ),
        "- Inconsistent-premise steps: %d" % verdicts["inconsistent_premises"],
        "- Role-mismatch fields: %d of %d claim-bearing fields" % (
            summary["role_mismatch_fields"], summary["claim_bearing_fields"],
        ),
        "",
        "## Agent map",
        "",
        "| Agent | Model | Reasoning | Fields | Steps | Entailed | Contingent | Contradicted | Inconsistent | Role mismatches |",
        "|---|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in agent_rows:
        lines.append("| %s | `%s` | %s | %d | %d | %d | %d | %d | %d | %d |" % (
            row["agent_id"], row.get("model") or row.get("model_id") or "unavailable",
            row.get("reasoning_effort") or "not specified",
            row["field_count"], row["step_count"],
            row["entailed_steps"], row["contingent_steps"], row["contradicted_steps"],
            row["inconsistent_premises_steps"], row["role_mismatch_fields"],
        ))
    heatmap = (output_dir / "agent-verdict-heatmap.png").resolve()
    stage_chart = (output_dir / "stage-verdict-stacked.png").resolve()
    lines.extend([
        "",
        "![Agent verdict map](%s)" % heatmap.as_posix(),
        "",
        "![Stage verdict distribution](%s)" % stage_chart.as_posix(),
        "",
        "## Interpretation guardrails",
        "",
        "- `contingent` means unsupported by the translated local premises, not necessarily false.",
        "- `inconsistent_premises` may be a real contradiction or a translation-composition error.",
        "- Agent raw counts are verbosity-sensitive; compare field-level rates and validate a human sample before inferential use.",
        "- Claim-map peer reuse is descriptive string-equivalence evidence, not proof that one agent caused another to adopt a claim.",
        "",
    ])
    return "\n".join(lines)


def analyze_formalizations(
    input_path: Path,
    output_dir: Path,
    *,
    expected_fields: int | None = None,
    run_dir: Path | None = None,
) -> dict[str, Any]:
    if expected_fields is not None and expected_fields < 1:
        raise ValueError("expected_fields must be positive")
    records = _load(input_path)
    steps = flatten_steps(records)
    fields = flatten_fields(records)
    agents = _group_map(fields, "agent_id")
    models = _agent_models(run_dir)
    for row in agents:
        row.update(models.get(str(row["agent_id"]), {}))
    stages = _group_map(fields, "stage")
    claims = claim_map(steps)
    finals = final_decision_audit(records, _answer_maps(run_dir))
    summary = _overall_summary(records, fields, steps, expected_fields)
    summary["agents"] = agents
    summary["stages"] = stages
    summary["final_decisions"] = finals
    summary["claim_map"] = {
        "repeated_claim_occurrences": sum(int(row["seen_previously"]) for row in claims),
        "peer_reuse_occurrences": sum(int(row["seen_from_prior_peer"]) for row in claims),
        "occurrences_after_peer_contradiction": sum(
            int(row["seen_after_peer_contradiction"]) for row in claims
        ),
    }

    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir / "steps.csv", steps)
    write_csv(output_dir / "fields.csv", fields)
    write_csv(output_dir / "agent-map.csv", agents)
    write_csv(output_dir / "stage-map.csv", stages)
    write_csv(output_dir / "claim-map.csv", claims)
    write_csv(output_dir / "final-decision-audit.csv", finals)
    (output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    _heatmap(output_dir / "agent-verdict-heatmap.svg", agents)
    _stage_chart(output_dir / "stage-verdict-stacked.svg", stages)
    _png_charts(output_dir, agents, stages)
    (output_dir / "README.md").write_text(
        _markdown(summary, agents, output_dir), encoding="utf-8"
    )
    return {
        "output_dir": str(output_dir),
        "field_count": len(fields),
        "step_count": len(steps),
        "agent_count": len(agents),
        "artifacts": [
            "summary.json", "README.md", "steps.csv", "fields.csv",
            "agent-map.csv", "stage-map.csv", "claim-map.csv",
            "final-decision-audit.csv", "agent-verdict-heatmap.svg",
            "stage-verdict-stacked.svg", "agent-verdict-heatmap.png",
            "stage-verdict-stacked.png",
        ],
    }
