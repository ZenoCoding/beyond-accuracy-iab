"""Generate a self-contained HTML reader for compact and proof-v2 translations."""

from __future__ import annotations

from html import escape
import json
from pathlib import Path
import tempfile
from typing import Any, Mapping, Optional, Sequence, Tuple


_PLAYER_NAMES = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    "Invalid JSON on line %d of %s" % (line_number, path)
                ) from exc
            if isinstance(value, dict) and (
                isinstance(value.get("claims"), list)
                or isinstance(value.get("nodes"), list)
            ):
                records.append(value)
    return records


def _record_label(record: Mapping[str, Any]) -> str:
    source = record.get("source") if isinstance(record.get("source"), Mapping) else {}
    return "%s / %s / %s" % (
        source.get("task_id", "unknown task"),
        source.get("agent_id", "unknown agent"),
        record.get("formalization_id") or record.get("id", "unknown id"),
    )


def load_formalization(
    input_path: Path,
    *,
    task: Optional[str] = None,
    agent: Optional[str] = None,
    formalization_id: Optional[str] = None,
) -> dict[str, Any]:
    """Select one compact or proof-v2 translation using source fields."""
    records = _read_jsonl(Path(input_path))
    matches = []
    for record in records:
        source = record.get("source") if isinstance(record.get("source"), Mapping) else {}
        if task is not None and source.get("task_id") != task:
            continue
        if agent is not None and source.get("agent_id") != agent:
            continue
        record_id = record.get("formalization_id") or record.get("id")
        if formalization_id is not None and record_id != formalization_id:
            continue
        matches.append(record)
    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise ValueError("No formalization matched the requested selection")
    choices = "; ".join(_record_label(record) for record in matches[:12])
    raise ValueError(
        "%d formalizations matched; choose one with --task and --agent or --id. "
        "First matches: %s" % (len(matches), choices)
    )


def _player(value: Any) -> str:
    try:
        index = int(value)
    except (TypeError, ValueError):
        return str(value)
    return _PLAYER_NAMES[index] if 0 <= index < len(_PLAYER_NAMES) else str(index)


def format_expression(expression: Any) -> str:
    """Render the compact expression AST in the translator's source syntax."""
    if expression is None:
        return "ABSTAIN"
    if not isinstance(expression, Mapping):
        return str(expression)
    op = expression.get("op")
    if op == "role_is":
        return "ROLE(%s,%s)" % (_player(expression.get("player")), expression.get("role"))
    if op == "statement_true":
        return "STMT_TRUE(%s)" % _player(expression.get("player"))
    if op == "same_role":
        return "SAME_ROLE(%s)" % ",".join(_player(value) for value in expression.get("players", []))
    if op == "not":
        return "NOT(%s)" % format_expression(expression.get("arg"))
    if op in {"and", "or", "xor", "iff"}:
        return "%s(%s;%s)" % (
            str(op).upper(),
            format_expression(expression.get("left")),
            format_expression(expression.get("right")),
        )
    if op == "count_role":
        values = [
            expression.get("comparison"),
            expression.get("count"),
            expression.get("role"),
            *(_player(value) for value in expression.get("players", [])),
        ]
        return "COUNT(%s)" % ",".join(map(str, values))
    if op == "parity":
        values = [
            expression.get("parity"),
            expression.get("role"),
            *(_player(value) for value in expression.get("players", [])),
        ]
        return "PARITY(%s)" % ",".join(map(str, values))
    return json.dumps(expression, ensure_ascii=False, sort_keys=True)


def _source_intervals(source_text: str, claims: Sequence[Mapping[str, Any]]) -> list[tuple[int, int, str]]:
    """Locate each verbatim source span, preferring textual claim order."""
    intervals: list[tuple[int, int, str]] = []
    cursor = 0
    for claim in claims:
        claim_id = str(claim.get("id", ""))
        span = str(claim.get("source_span", ""))
        if not claim_id or not span:
            continue
        start = source_text.find(span, cursor)
        if start < 0:
            start = source_text.find(span)
        if start < 0:
            continue
        intervals.append((start, start + len(span), claim_id))
        cursor = start + len(span)
    return intervals


def _source_html(source_text: str, claims: Sequence[Mapping[str, Any]]) -> str:
    intervals = _source_intervals(source_text, claims)
    boundaries = sorted({0, len(source_text), *(value for start, end, _ in intervals for value in (start, end))})
    parts = []
    for start, end in zip(boundaries, boundaries[1:]):
        text = escape(source_text[start:end])
        ids = [claim_id for left, right, claim_id in intervals if left <= start and end <= right]
        if ids:
            parts.append(
                '<button type="button" class="source-span" data-claims="%s">%s</button>'
                % (escape(" ".join(ids), quote=True), text)
            )
        else:
            parts.append(text)
    return "".join(parts)


def _event_label(claim: Mapping[str, Any]) -> str:
    kind = str(claim.get("kind", "claim")).upper()
    argument = claim.get("kind_arg")
    return "%s(%s)" % (kind, argument) if argument else kind


_EXTERNAL_LABELS = {
    "@ctx:rule-role-exclusivity": "Each player has one role",
    "@ctx:rule-exactly-one-spy": "Exactly one player is the spy",
    "@ctx:rule-speaker-truthfulness": "Knights tell truth; knaves lie",
}


def _external_label(value: str) -> str:
    if value in _EXTERNAL_LABELS:
        return _EXTERNAL_LABELS[value]
    if value.startswith("@ctx:stmt-"):
        return "Puzzle statement %s" % value.removeprefix("@ctx:stmt-")
    return value


def _plain_event_label(claim: Mapping[str, Any]) -> str:
    kind = str(claim.get("kind", "claim"))
    stance = str(claim.get("stance", ""))
    argument = str(claim.get("kind_arg") or "")
    if kind == "claim" and stance == "report":
        return "Reported statement"
    if kind == "claim":
        return "Stated claim"
    if kind == "assume":
        return "Assumption"
    if kind == "derive":
        return "Derived claim"
    if kind == "contradiction":
        return "Contradiction"
    if kind == "discharge":
        return "Rejected assumption"
    if kind == "opaque":
        return "Not formalized"
    if kind == "model_check":
        return {
            "sat": "Consistency check",
            "unsat": "No-solution check",
            "unique": "Uniqueness check",
        }.get(argument, "Model check")
    return kind.replace("_", " ").title()


def _verdict_summary(verdict: str | None) -> tuple[str, str, str]:
    summaries = {
        "declared": (
            "Recorded",
            "This is a stated or assumed step, so no inference was tested.",
            "neutral",
        ),
        "uncheckable_external": (
            "Not checked — puzzle context",
            "The checker cannot test this step until its referenced puzzle statements and rules are modeled. This is not itself an error.",
            "neutral",
        ),
        "uncheckable": (
            "Not mechanically checked",
            "The current checker does not cover this kind of step.",
            "neutral",
        ),
        "uncheckable_model_check": (
            "Solver not connected",
            "The translator recorded a model check, but the puzzle solver is not connected yet.",
            "attention",
        ),
        "opaque": (
            "Not formalized",
            "The translator preserved this source span but did not convert it into logic.",
            "attention",
        ),
        "tainted": (
            "Depends on unresolved support",
            "At least one supporting step could not be mechanically established.",
            "attention",
        ),
        "contingent": (
            "Does not follow",
            "The conclusion is possible, but the cited support does not entail it.",
            "problem",
        ),
        "contradicted": (
            "Conflicts with support",
            "The cited support entails the opposite conclusion.",
            "problem",
        ),
        "valid_contradiction": (
            "Contradiction validated",
            "The cited steps are jointly inconsistent in this assumption scope.",
            "positive",
        ),
        "valid_discharge": (
            "Discharge validated",
            "The contradiction supports rejecting the stated assumption.",
            "positive",
        ),
        "invalid_contradiction": (
            "Contradiction not established",
            "The cited steps do not mechanically establish a contradiction.",
            "problem",
        ),
        "invalid_discharge": (
            "Rejection not established",
            "The cited contradiction does not justify this discharged conclusion.",
            "problem",
        ),
        "entailed": (
            "Follows from support",
            "The cited support mechanically entails this conclusion.",
            "positive",
        ),
    }
    return summaries.get(
        str(verdict),
        (str(verdict or "Not checked").replace("_", " ").title(), "No explanation is available for this checker result.", "neutral"),
    )


def _claim_html(
    claim: Mapping[str, Any],
    claims_by_id: Mapping[str, Mapping[str, Any]],
    verdict: str | None = None,
) -> str:
    claim_id = str(claim.get("id", "?"))
    dependencies = [str(value) for value in claim.get("dependencies", [])]
    dependency_parts = []
    for value in dependencies:
        if value in claims_by_id:
            dependency = claims_by_id[value]
            dependency_source = str(dependency.get("source_span", ""))
            dependency_parts.append(
                '<button type="button" class="claim-link" data-target="%s">'
                '<span>%s</span><q>%s</q></button>'
                % (
                    escape(value, quote=True),
                    escape(value),
                    escape(dependency_source),
                )
            )
        else:
            dependency_parts.append(
                '<span class="external-ref" title="%s">%s</span>'
                % (escape(value, quote=True), escape(_external_label(value)))
            )
    if dependency_parts:
        dependency_links = '<span class="relation-label">Based on</span>' + "".join(dependency_parts)
    elif str(claim.get("kind")) == "assume":
        dependency_links = '<span class="root-label">Starts a case</span>'
    else:
        dependency_links = '<span class="root-label">No support cited</span>'
    marker = claim.get("expression_marker")
    expression = "BOTTOM" if marker == "bottom" else format_expression(claim.get("expression"))
    scope = str(claim.get("scope", "root"))
    detail = _plain_event_label(claim)
    status_label, status_explanation, status_level = _verdict_summary(verdict)
    status = '<span class="claim-verdict" data-level="%s" title="%s">%s</span>' % (
        escape(status_level, quote=True),
        escape(status_explanation, quote=True),
        escape(status_label),
    )
    source_span = str(claim.get("source_span", ""))
    scope_html = ""
    if scope != "root" and scope in claims_by_id:
        opener = claims_by_id[scope]
        scope_html = (
            '<span class="scope-note">Inside <button type="button" class="claim-link" '
            'data-target="%s">%s <q>%s</q></button></span>'
            % (
                escape(scope, quote=True),
                escape(scope),
                escape(str(opener.get("source_span", ""))),
            )
        )
    return (
        '<li class="claim-row" data-claim="%(id_attr)s" data-dependencies="%(deps_attr)s" data-scope="%(scope_attr)s">'
        '<button type="button" class="claim-main" data-target="%(id_attr)s">'
        '<span class="claim-id">%(id)s</span><span class="claim-copy">'
        '<span class="claim-source">%(source)s</span>'
        '<code class="claim-expression">%(expression)s</code></span>'
        '<span class="claim-stance">%(detail)s</span></button>'
        '<div class="claim-from">%(scope_html)s%(dependencies)s%(status)s</div></li>'
    ) % {
        "id_attr": escape(claim_id, quote=True),
        "deps_attr": escape(" ".join(dependencies), quote=True),
        "id": escape(claim_id),
        "expression": escape(expression),
        "source": escape(source_span),
        "detail": escape(detail),
        "scope": escape(scope),
        "scope_attr": escape(scope, quote=True),
        "dependencies": dependency_links,
        "scope_html": scope_html,
        "status": status,
    }


def render_formalization_html(record: Mapping[str, Any]) -> str:
    """Render one compact or proof-v2 translation as offline HTML."""
    source = record.get("source") if isinstance(record.get("source"), Mapping) else {}
    source_text = str(record.get("source_text", ""))
    proof_v2 = isinstance(record.get("nodes"), list)
    raw_claims = record.get("nodes", []) if proof_v2 else record.get("claims", [])
    claims = [claim for claim in raw_claims if isinstance(claim, Mapping)]
    claims_by_id = {str(claim.get("id")): claim for claim in claims}
    verdicts = {
        str(check.get("id")): str(check.get("verdict"))
        for check in record.get("checks", [])
        if isinstance(check, Mapping) and check.get("id")
    }
    parse_errors = [str(value) for value in record.get("parse_errors", [])]
    task = str(source.get("task_id", "Formal logic trace"))
    agent = str(source.get("agent_id", "unknown agent"))
    model = str(record.get("model", "unknown model"))
    effort = record.get("model_metadata", {})
    effort = effort.get("reasoning_effort") if isinstance(effort, Mapping) else None
    meta = [agent, model]
    if effort:
        meta.append("%s reasoning" % effort)
    unit_name = "events" if proof_v2 else "claims"
    meta.extend(["%d words" % len(source_text.split()), "%d %s" % (len(claims), unit_name)])
    if proof_v2 and isinstance(record.get("source_span_coverage"), (int, float)):
        meta.append("%.1f%% accepted span coverage" % (100 * record["source_span_coverage"]))
    errors = ""
    if parse_errors:
        errors = (
            '<details class="errors"><summary>%d translator syntax issue%s</summary><ul>%s</ul></details>'
            % (
                len(parse_errors),
                "" if len(parse_errors) == 1 else "s",
                "".join("<li>%s</li>" % escape(value) for value in parse_errors),
            )
        )
    claim_data = {
        str(claim.get("id")): {
            "expression": (
                "BOTTOM" if claim.get("expression_marker") == "bottom"
                else format_expression(claim.get("expression"))
            ),
            "source": str(claim.get("source_span", "")),
            "stance": str(claim.get("stance", "unknown")),
            "kind": _event_label(claim),
            "plainKind": _plain_event_label(claim),
            "scope": str(claim.get("scope", "root")),
            "verdict": verdicts.get(str(claim.get("id")), ""),
            "status": _verdict_summary(verdicts.get(str(claim.get("id"))))[0],
            "statusExplanation": _verdict_summary(verdicts.get(str(claim.get("id"))))[1],
            "dependencies": [str(value) for value in claim.get("dependencies", [])],
        }
        for claim in claims
    }
    external_labels = {
        dependency: _external_label(dependency)
        for claim in claims
        for dependency in claim.get("dependencies", [])
        if str(dependency).startswith("@")
    }
    return """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>%(title)s · logic trace</title>
<style>
:root{color-scheme:light dark;--page:#f5f4f0;--surface:#fcfbf8;--ink:#232520;--muted:#646961;--line:#d9dbd4;--accent:#1e6355;--accent-soft:#dcece6;--support:#835f20;--support-soft:#f1e7d1;--dependent:#455d85;--dependent-soft:#e2e7f1;--attention:#8a5b18;--problem:#963c32;--problem-soft:#f4e2de;--positive:#286548}
*{box-sizing:border-box}::selection{background:var(--accent-soft);color:var(--ink)}body{margin:0;background:var(--page);color:var(--ink);font:15px/1.55 ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}button{font:inherit;color:inherit}button:focus-visible,summary:focus-visible{outline:2px solid var(--accent);outline-offset:3px}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.shell{width:min(1180px,calc(100%% - 40px));margin:0 auto;padding:38px 0 72px}h1{font-size:clamp(26px,4vw,38px);line-height:1.12;letter-spacing:-.025em;margin:0 0 6px;font-weight:680}.meta{color:var(--muted);margin:0;font-variant-numeric:tabular-nums}.guide{display:flex;justify-content:space-between;gap:24px;align-items:baseline;margin:24px 0 18px;padding-bottom:14px;border-bottom:1px solid var(--line);color:var(--muted);font-size:13px}.guide p{margin:0}.legend{display:flex;gap:14px;flex-wrap:wrap}.legend span::before{content:"";display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:6px;background:var(--accent-soft)}.legend .premise::before{background:var(--support-soft)}.legend .dependent::before{background:var(--dependent-soft)}.workspace{display:grid;grid-template-columns:minmax(330px,.8fr) minmax(480px,1.2fr);gap:40px;align-items:start}.source-panel{position:sticky;top:20px}.source-copy{font:18px/1.82 ui-serif,Georgia,serif;margin:0;max-width:68ch}.source-span{display:inline;padding:2px 1px;border:0;border-radius:3px;background:var(--accent-soft);color:inherit;cursor:pointer;text-align:left;box-decoration-break:clone;-webkit-box-decoration-break:clone}.source-span:hover,.source-span.is-active{background:color-mix(in srgb,var(--accent) 23%%,var(--surface));text-decoration:underline;text-decoration-thickness:1px;text-underline-offset:3px}.selection{margin-top:24px;border-top:1px solid var(--line);padding-top:16px;min-height:116px}.selection-id{font-weight:680;color:var(--accent)}.selection-source{font-size:15px;margin:4px 0 8px}.selection-expression{font:12px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace;overflow-wrap:anywhere;margin:0;color:var(--muted)}.selection-context{font-size:12px;color:var(--muted);margin:8px 0 0}.selection-uses{margin:8px 0 0;padding-left:18px;font-size:12px;color:var(--muted)}.claims{list-style:none;padding:0;margin:0}.claim-row{border-top:1px solid var(--line);padding:14px 0 12px;transition:background-color .12s ease}.claim-row:last-child{border-bottom:1px solid var(--line)}.claim-main{display:grid;grid-template-columns:34px minmax(0,1fr) auto;width:100%%;gap:10px;align-items:start;border:0;background:transparent;padding:0 6px;text-align:left;cursor:pointer}.claim-id{font-weight:680;color:var(--accent);font-variant-numeric:tabular-nums}.claim-copy{display:grid;gap:5px}.claim-source{font-size:14px;font-weight:580;line-height:1.4}.claim-expression{font:11.5px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace;color:var(--muted);overflow-wrap:anywhere}.claim-stance{font-size:11px;color:var(--muted);white-space:nowrap}.claim-from{display:flex;gap:6px 10px;align-items:center;flex-wrap:wrap;padding:8px 6px 0 50px;color:var(--muted);font-size:11.5px;min-height:24px}.relation-label{font-weight:650;color:var(--ink)}.claim-link{display:inline-flex;gap:5px;align-items:baseline;border:0;background:transparent;color:var(--accent);padding:0;text-decoration:underline;text-decoration-color:color-mix(in srgb,var(--accent) 35%%,transparent);text-underline-offset:3px;cursor:pointer}.claim-link q{max-width:24ch;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--muted);text-decoration:none}.external-ref{color:var(--muted)}.scope-note{flex-basis:100%%}.claim-verdict{margin-left:auto;color:var(--muted)}.claim-verdict[data-level="attention"]{color:var(--attention)}.claim-verdict[data-level="problem"]{color:var(--problem);font-weight:650}.claim-verdict[data-level="positive"]{color:var(--positive)}.root-label{color:var(--muted)}.claim-row.is-active{background:var(--accent-soft)}.claim-row.is-premise{background:var(--support-soft)}.claim-row.is-dependent{background:var(--dependent-soft)}.errors{margin:18px 0;color:var(--problem);font-size:13px}.errors summary{cursor:pointer;font-weight:650}.errors ul{margin:8px 0 0;padding-left:20px;color:var(--muted)}.empty{color:var(--muted);padding:24px 0}.hint{color:var(--muted);font-size:12px;margin:12px 0 0;max-width:68ch}
@media(max-width:860px){.shell{width:min(100%% - 24px,720px);padding-top:26px}.guide{display:block}.legend{margin-top:8px}.workspace{grid-template-columns:1fr;gap:28px}.source-panel{position:static}.selection{min-height:0}.claim-main{grid-template-columns:30px minmax(0,1fr)}.claim-stance{grid-column:2}.claim-from{padding-left:46px}.claim-verdict{margin-left:0}}
@media(prefers-color-scheme:dark){:root{--page:#181916;--surface:#20211e;--ink:#eceee8;--muted:#adb0a8;--line:#3b3d37;--accent:#9acdbd;--accent-soft:#243c35;--support:#dec083;--support-soft:#413620;--dependent:#adbbe0;--dependent-soft:#2c3448;--attention:#e0b66f;--problem:#f0aaa0;--problem-soft:#472925;--positive:#9bd2b1}}
</style></head><body><main class="shell">
<h1>%(task)s</h1><p class="meta">%(meta)s</p>%(errors)s
<div class="guide"><p>Select a step to see what supports it and what uses it. Checker status is diagnostic, not an accuracy score.</p><div class="legend" aria-label="Highlight key"><span>selected</span><span class="premise">supports this step</span><span class="dependent">uses this step</span></div></div>
<div class="workspace"><section class="source-panel" aria-labelledby="source-heading"><h2 id="source-heading" class="sr-only">Explanation</h2>
<p class="source-copy">%(source_html)s</p>
<div class="selection" aria-live="polite"><div class="selection-id">Select a highlighted span or translated step</div><p class="selection-context">Its meaning, formal expression, and cited support will appear here.</p></div>
</section><section aria-labelledby="claims-heading"><h2 id="claims-heading" class="sr-only">Translated claims</h2>
<ol class="claims">%(claims)s</ol>%(empty)s<p class="hint">“Based on” means the translator cited that step or puzzle rule. It does not mean the checker proved the inference.</p></section></div>
</main><script>
const claimData=%(claim_data)s;
const externalLabels=%(external_labels)s;
const rows=new Map([...document.querySelectorAll('.claim-row')].map(row=>[row.dataset.claim,row]));
const reverse=new Map([...rows.keys()].map(id=>[id,[]]));
for(const [id,row] of rows){for(const dep of row.dataset.dependencies.split(' ').filter(Boolean)){if(reverse.has(dep))reverse.get(dep).push(id);}}
let pinned=[];
function closure(start,next){const seen=new Set(),stack=[...start];while(stack.length){const id=stack.pop();for(const value of next(id)){if(!seen.has(value)&&!start.includes(value)){seen.add(value);stack.push(value);}}}return seen;}
function dependencyLabel(id){if(claimData[id])return id+' — “'+claimData[id].source+'”';return externalLabels[id]||id;}
function show(ids){ids=ids.filter(id=>rows.has(id));const premises=closure(ids,id=>(claimData[id]||{}).dependencies||[]),dependents=closure(ids,id=>reverse.get(id)||[]);for(const [id,row] of rows){row.classList.toggle('is-active',ids.includes(id));row.classList.toggle('is-premise',premises.has(id));row.classList.toggle('is-dependent',dependents.has(id));}document.querySelectorAll('.source-span').forEach(span=>span.classList.toggle('is-active',span.dataset.claims.split(' ').some(id=>ids.includes(id))));const id=ids[0],data=claimData[id],box=document.querySelector('.selection');if(!data){box.innerHTML='<div class="selection-id">Select a highlighted span or translated step</div><p class="selection-context">Its meaning, formal expression, and cited support will appear here.</p>';return;}const scope=data.scope==='root'?'Main argument':'Inside assumption '+dependencyLabel(data.scope);const uses=data.dependencies.length?'<ul class="selection-uses">'+data.dependencies.map(dep=>'<li>'+escapeHtml(dependencyLabel(dep))+'</li>').join('')+'</ul>':'<p class="selection-context">No supporting step was cited.</p>';box.innerHTML='<div class="selection-id">'+escapeHtml(id)+' · '+escapeHtml(data.plainKind)+'</div><p class="selection-source">“'+escapeHtml(data.source)+'”</p><code class="selection-expression">'+escapeHtml(data.expression)+'</code><p class="selection-context">'+escapeHtml(scope)+' · '+escapeHtml(data.status)+'. '+escapeHtml(data.statusExplanation)+'</p>'+uses;}
function escapeHtml(value){const node=document.createElement('span');node.textContent=value;return node.innerHTML;}
function idsFor(element){return element.dataset.claims?element.dataset.claims.split(' '):[element.dataset.target||element.closest('.claim-row').dataset.claim];}
document.querySelectorAll('.source-span,.claim-main,.claim-link').forEach(element=>{element.addEventListener('mouseenter',()=>show(idsFor(element)));element.addEventListener('mouseleave',()=>show(pinned));element.addEventListener('focus',()=>show(idsFor(element)));element.addEventListener('blur',()=>show(pinned));element.addEventListener('click',event=>{event.stopPropagation();pinned=idsFor(element);show(pinned);if(element.classList.contains('claim-link'))rows.get(pinned[0])?.querySelector('.claim-main').focus();});});
document.addEventListener('keydown',event=>{if(event.key==='Escape'){pinned=[];show([]);}});show([]);
</script></body></html>""" % {
        "title": escape(task),
        "task": escape(task),
        "meta": escape(" · ".join(meta)),
        "errors": errors,
        "source_html": _source_html(source_text, claims),
        "claims": "".join(
            _claim_html(claim, claims_by_id, verdicts.get(str(claim.get("id"))))
            for claim in claims
        ),
        "empty": '<div class="empty">No translated claims were recorded.</div>' if not claims else "",
        "claim_data": json.dumps(claim_data, ensure_ascii=False).replace("</", "<\\/"),
        "external_labels": json.dumps(external_labels, ensure_ascii=False).replace("</", "<\\/"),
    }


def write_formalization_html(
    input_path: Path,
    *,
    task: Optional[str] = None,
    agent: Optional[str] = None,
    formalization_id: Optional[str] = None,
    output: Optional[Path] = None,
) -> Tuple[Path, dict[str, Any]]:
    """Select and write one formalization reader."""
    record = load_formalization(
        Path(input_path), task=task, agent=agent, formalization_id=formalization_id
    )
    source = record.get("source") if isinstance(record.get("source"), Mapping) else {}
    if output is None:
        slug = "%s-%s" % (source.get("task_id", "trace"), source.get("agent_id", "agent"))
        output = Path(tempfile.gettempdir()) / "controlmad-logic-traces" / (slug + ".html")
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_formalization_html(record), encoding="utf-8")
    return output.resolve(), record
