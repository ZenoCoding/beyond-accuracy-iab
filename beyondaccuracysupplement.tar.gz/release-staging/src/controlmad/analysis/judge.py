from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import yaml

from controlmad.harness.benchmark import benchmark_from_config
from controlmad.harness.config import ModelConfig
from controlmad.harness.models import ModelClient, model_client_for_config
from controlmad.harness.runner import config_from_resolved_dict
from controlmad.harness.storage import ExperimentStorage

from .config import AnalysisConfig, load_analysis_config
from .core import completed_results, discover_run_dirs


RUBRIC_VERSION = "paper-deepseek-soundness-v1"


def _parse_rating(content: str) -> dict[str, int]:
    value = json.loads(content)
    result = {}
    for key in ("agree_reasoning_soundness", "disagree_reasoning_soundness"):
        rating = int(value[key])
        if rating < 0 or rating > 4:
            raise ValueError("%s must be between 0 and 4" % key)
        result[key] = rating
    return result


def _prompt(
    task_prompt: str,
    answer: dict[str, str],
    player: str,
    argument: dict[str, Any],
) -> str:
    return """Evaluate the logical soundness of one anonymized debate contribution.

Puzzle:
%s

Verified solution:
%s

Debated player: %s
Agree reasoning: %s
Disagree reasoning: %s

Rate each reasoning field from 1 (chaotic/unsupported) to 4 (logically solid).
Use 0 only when the corresponding field has no applicable peers.
Return only:
{"agree_reasoning_soundness": <0-4>, "disagree_reasoning_soundness": <0-4>}
""" % (
        task_prompt,
        json.dumps(answer, sort_keys=True),
        player,
        argument.get("agree_reasoning", ""),
        argument.get("disagree_reasoning", ""),
    )


async def generate_judge_ratings(
    config_or_path: AnalysisConfig | Path,
    *,
    model_client: ModelClient | None = None,
) -> dict[str, Any]:
    config = (
        config_or_path
        if isinstance(config_or_path, AnalysisConfig)
        else load_analysis_config(config_or_path)
    )
    judge = config.judge
    if not judge.get("model"):
        raise ValueError("analysis config judge.model is required")
    model_path = Path(str(judge["model"]))
    if not model_path.is_absolute():
        model_path = (config.config_path.parent / model_path).resolve()
    model = ModelConfig(**(yaml.safe_load(model_path.read_text(encoding="utf-8")) or {}))
    client = model_client or model_client_for_config(model)
    output_dir = config.output_dir / config.analysis_id
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "judge-ratings.jsonl"
    completed = set()
    if output_path.exists():
        for line in output_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                completed.add(json.loads(line)["rating_id"])
    written = 0
    usage: dict[str, float] = {}
    for run_dir in discover_run_dirs(config):
        storage = ExperimentStorage(str(run_dir))
        resolved = config_from_resolved_dict(storage.load_resolved_config())
        if resolved.debate is None:
            continue
        tasks = {
            task.id: task
            for task in benchmark_from_config(resolved.benchmark, resolved.config_root).load()
        }
        for (_, _), result in completed_results(run_dir).items():
            task = tasks[result["task_id"]]
            for round_index, round_data in enumerate(result.get("rounds", []), start=1):
                for argument_index, (_, argument) in enumerate(
                    sorted(round_data.get("arguments", {}).items()), start=1
                ):
                    rating_id = "%s:%s:%s:%s:%s" % (
                        resolved.experiment_id,
                        result["run_id"],
                        round_index,
                        argument_index,
                        RUBRIC_VERSION,
                    )
                    if rating_id in completed:
                        continue
                    prompt = _prompt(
                        task.prompt, task.answer, round_data["player"], argument
                    )
                    response = await client.complete(
                        model,
                        [
                            {"role": "system", "content": "You are a blinded logic-quality evaluator."},
                            {"role": "user", "content": prompt},
                        ],
                        float(judge.get("timeout_seconds", 300)),
                    )
                    rating = _parse_rating(response.content)
                    record = {
                        "rating_id": rating_id,
                        "rubric_version": RUBRIC_VERSION,
                        "experiment_id": resolved.experiment_id,
                        "task_id": result["task_id"],
                        "repetition": result.get("repetition", 1),
                        "round_index": round_index,
                        "player": round_data["player"],
                        "judge_model": response.model,
                        "rating": rating,
                        "prompt": prompt,
                        "raw_response": response.content,
                        "usage": response.usage,
                    }
                    with output_path.open("a", encoding="utf-8") as handle:
                        handle.write(json.dumps(record, sort_keys=True) + "\n")
                    completed.add(rating_id)
                    written += 1
                    for key, value in response.usage.items():
                        if isinstance(value, (int, float)):
                            usage[key] = usage.get(key, 0.0) + float(value)
    return {
        "output": str(output_path),
        "new_ratings": written,
        "total_ratings": len(completed),
        "usage": usage,
    }


def run_judge(config_path: Path) -> dict[str, Any]:
    return asyncio.run(generate_judge_ratings(config_path))
