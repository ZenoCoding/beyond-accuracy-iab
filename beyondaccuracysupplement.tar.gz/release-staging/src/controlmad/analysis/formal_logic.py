"""Post-run formalization and mechanical checking of KKS reasoning."""

from __future__ import annotations

import asyncio
import hashlib
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import yaml

from controlmad.harness.config import ModelConfig
from controlmad.harness.models import ModelClient, model_client_for_config
from controlmad.harness.runner import config_from_resolved_dict
from controlmad.harness.storage import ExperimentStorage
from controlmad_replication.benchmarks.kks.dataset import dataset_sizes, read_jsonl
from controlmad_replication.benchmarks.kks.logic import (
    Assignment,
    assignments,
    evaluate_expr,
    statement_values,
)

from .core import completed_results


FORMALIZATION_VERSION = "kks-formalization-v1"
PROMPT_VERSION = "kks-formalization-prompt-v1"
ROLES = ("knight", "knave", "spy")
TRANSLATION_STATUSES = {"complete", "partial", "ambiguous", "unformalizable"}
VERDICTS = {
    "entailed",
    "contradicted",
    "contingent",
    "inconsistent_premises",
    "ambiguous",
    "unformalizable",
}


@dataclass(frozen=True)
class ReasoningSource:
    location: dict[str, Any]
    text: str
    submitted_roles: dict[str, str]

    @property
    def id(self) -> str:
        payload = {
            "version": FORMALIZATION_VERSION,
            "location": self.location,
            "text": self.text,
        }
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(encoded.encode()).hexdigest()


def _solution_sources(
    result: Mapping[str, Any],
    field: str,
    stage: str,
) -> Iterable[ReasoningSource]:
    solutions = result.get(field) or {}
    if not isinstance(solutions, Mapping):
        return
    for agent_id, solution in sorted(solutions.items()):
        if not isinstance(solution, Mapping):
            continue
        text = str(solution.get("explanation", "")).strip()
        if text:
            yield ReasoningSource(
                location={"stage": stage, "agent_id": str(agent_id), "field": "explanation"},
                text=text,
                submitted_roles=dict(solution.get("roles") or {}),
            )


def extract_reasoning_sources(result: Mapping[str, Any]) -> list[ReasoningSource]:
    """Return every non-empty explanation/reasoning field in stable order."""
    sources = list(_solution_sources(result, "initial_proposals", "initial_proposal"))
    for round_index, round_data in enumerate(result.get("rounds") or [], start=1):
        if not isinstance(round_data, Mapping):
            continue
        player = str(round_data.get("player", ""))
        for agent_id, argument in sorted((round_data.get("arguments") or {}).items()):
            if not isinstance(argument, Mapping):
                continue
            submitted = {player: str(argument["role"])} if player and argument.get("role") else {}
            for field in ("agree_reasoning", "disagree_reasoning"):
                text = str(argument.get(field, "")).strip()
                if text:
                    sources.append(ReasoningSource(
                        location={
                            "stage": "debate_argument",
                            "round_index": round_index,
                            "player": player,
                            "agent_id": str(agent_id),
                            "field": field,
                        },
                        text=text,
                        submitted_roles=submitted,
                    ))
        for agent_id, solution in sorted((round_data.get("adjustments") or {}).items()):
            if not isinstance(solution, Mapping):
                continue
            text = str(solution.get("explanation", "")).strip()
            if text:
                sources.append(ReasoningSource(
                    location={
                        "stage": "self_adjustment",
                        "round_index": round_index,
                        "player": player,
                        "agent_id": str(agent_id),
                        "field": "explanation",
                    },
                    text=text,
                    submitted_roles=dict(solution.get("roles") or {}),
                ))
    for field, stage in (
        ("second_proposals", "second_proposal"),
        ("final_decisions", "final_decision"),
    ):
        sources.extend(_solution_sources(result, field, stage))
    for field, stage in (
        ("consensus_supervisor_decision", "consensus_supervisor"),
        ("supervisor_decision", "supervisor"),
    ):
        solution = result.get(field)
        if isinstance(solution, Mapping):
            text = str(solution.get("explanation", "")).strip()
            if text:
                sources.append(ReasoningSource(
                    location={"stage": stage, "agent_id": "supervisor", "field": "explanation"},
                    text=text,
                    submitted_roles=dict(solution.get("roles") or {}),
                ))
    return sources


def _expr_schema() -> dict[str, Any]:
    def variant(op: str, properties: dict[str, Any]) -> dict[str, Any]:
        combined = {"op": {"type": "string", "enum": [op]}, **properties}
        return {
            "type": "object",
            "properties": combined,
            "required": list(combined),
            "additionalProperties": False,
        }

    player = {"type": "integer"}
    players = {"type": "array", "items": {"type": "integer"}}
    role = {"type": "string", "enum": list(ROLES)}
    expression = {"$ref": "#/$defs/expression"}
    return {
        "anyOf": [
            variant("role_is", {"player": player, "role": role}),
            variant("same_role", {"players": players}),
            variant("count_role", {
                "players": players,
                "role": role,
                "comparison": {"type": "string", "enum": ["exactly", "at_least", "at_most"]},
                "count": {"type": "integer", "minimum": 0},
            }),
            variant("parity", {
                "players": players,
                "role": role,
                "parity": {"type": "string", "enum": ["even", "odd"]},
            }),
            variant("statement_true", {"player": player}),
            variant("not", {"arg": expression}),
            *[
                variant(op, {"left": expression, "right": expression})
                for op in ("and", "or", "xor", "iff", "implies")
            ],
        ]
    }


def formalization_schema(players: Sequence[str]) -> dict[str, Any]:
    axioms = ["role_exclusivity", "exactly_one_spy"] + [
        "speaker_truthfulness:%d" % index for index in range(len(players))
    ]
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$defs": {"expression": _expr_schema()},
        "type": "object",
        "properties": {
            "translation_status": {"type": "string", "enum": sorted(TRANSLATION_STATUSES)},
            "steps": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "source_span": {"type": "string"},
                        "assumptions": {
                            "type": "array", "items": {"$ref": "#/$defs/expression"},
                        },
                        "premises": {
                            "type": "array", "items": {"$ref": "#/$defs/expression"},
                        },
                        "axioms": {
                            "type": "array",
                            "items": {"type": "string", "enum": axioms},
                        },
                        "conclusion": {
                            "anyOf": [{"$ref": "#/$defs/expression"}, {"type": "null"}],
                        },
                        "rule": {"type": "string"},
                        "translation_status": {
                            "type": "string", "enum": sorted(TRANSLATION_STATUSES),
                        },
                        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                    },
                    "required": [
                        "source_span", "assumptions", "premises", "axioms",
                        "conclusion", "rule", "translation_status", "confidence",
                    ],
                    "additionalProperties": False,
                },
            },
            "claimed_roles": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "player": {"type": "string", "enum": list(players)},
                        "role": {"type": "string", "enum": list(ROLES)},
                    },
                    "required": ["player", "role"],
                    "additionalProperties": False,
                },
            },
            "notes": {"type": "array", "items": {"type": "string"}},
        },
        "required": ["translation_status", "steps", "claimed_roles", "notes"],
        "additionalProperties": False,
    }


def _validate_expr(expr: Any, player_count: int) -> None:
    if not isinstance(expr, dict):
        raise ValueError("expression must be an object")
    op = expr.get("op")
    keys = set(expr)
    shapes = {
        "role_is": {"op", "player", "role"},
        "same_role": {"op", "players"},
        "count_role": {"op", "players", "role", "comparison", "count"},
        "parity": {"op", "players", "role", "parity"},
        "statement_true": {"op", "player"},
        "not": {"op", "arg"},
        "and": {"op", "left", "right"},
        "or": {"op", "left", "right"},
        "xor": {"op", "left", "right"},
        "iff": {"op", "left", "right"},
        "implies": {"op", "left", "right"},
    }
    if op not in shapes or keys != shapes[op]:
        raise ValueError("invalid %r expression shape" % op)
    if op in {"role_is", "statement_true"}:
        if not isinstance(expr["player"], int) or not 0 <= expr["player"] < player_count:
            raise ValueError("expression player is outside the puzzle")
    if op in {"same_role", "count_role", "parity"}:
        players = expr["players"]
        if not isinstance(players, list) or any(
            not isinstance(player, int) or not 0 <= player < player_count for player in players
        ):
            raise ValueError("expression players are outside the puzzle")
        if op == "same_role" and len(players) != 2:
            raise ValueError("same_role requires exactly two players")
    if op in {"role_is", "count_role", "parity"} and expr["role"] not in ROLES:
        raise ValueError("invalid expression role")
    if op == "count_role":
        if expr["comparison"] not in {"exactly", "at_least", "at_most"}:
            raise ValueError("invalid count comparison")
        if not isinstance(expr["count"], int) or expr["count"] < 0:
            raise ValueError("invalid count")
    if op == "parity" and expr["parity"] not in {"even", "odd"}:
        raise ValueError("invalid parity")
    if op == "not":
        _validate_expr(expr["arg"], player_count)
    if op in {"and", "or", "xor", "iff", "implies"}:
        _validate_expr(expr["left"], player_count)
        _validate_expr(expr["right"], player_count)


def parse_formalization(content: str, players: Sequence[str], source_text: str) -> dict[str, Any]:
    try:
        value = json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError("formalization response must be one JSON object") from exc
    if not isinstance(value, dict) or set(value) != {
        "translation_status", "steps", "claimed_roles", "notes"
    }:
        raise ValueError("formalization response has an invalid top-level shape")
    if value["translation_status"] not in TRANSLATION_STATUSES:
        raise ValueError("invalid translation_status")
    if not isinstance(value["steps"], list) or not isinstance(value["notes"], list):
        raise ValueError("steps and notes must be arrays")
    if any(not isinstance(note, str) for note in value["notes"]):
        raise ValueError("notes must contain strings")
    allowed_axioms = {"role_exclusivity", "exactly_one_spy"} | {
        "speaker_truthfulness:%d" % index for index in range(len(players))
    }
    for step in value["steps"]:
        required = {
            "source_span", "assumptions", "premises", "axioms", "conclusion",
            "rule", "translation_status", "confidence",
        }
        if not isinstance(step, dict) or set(step) != required:
            raise ValueError("formalization step has an invalid shape")
        if not step["source_span"] or step["source_span"] not in source_text:
            raise ValueError("source_span must occur verbatim in the explanation")
        if step["translation_status"] not in TRANSLATION_STATUSES:
            raise ValueError("invalid step translation_status")
        if not isinstance(step["confidence"], (int, float)) or not 0 <= step["confidence"] <= 1:
            raise ValueError("step confidence must be between 0 and 1")
        if not isinstance(step["rule"], str) or not step["rule"].strip():
            raise ValueError("step rule cannot be blank")
        if not isinstance(step["assumptions"], list) or not isinstance(step["premises"], list):
            raise ValueError("assumptions and premises must be arrays")
        if not isinstance(step["axioms"], list) or set(step["axioms"]) - allowed_axioms:
            raise ValueError("step contains an unknown axiom")
        for expr in step["assumptions"] + step["premises"]:
            _validate_expr(expr, len(players))
        if step["conclusion"] is not None:
            _validate_expr(step["conclusion"], len(players))
    if not isinstance(value["claimed_roles"], list):
        raise ValueError("claimed_roles must be an array")
    claimed: dict[str, str] = {}
    conflicting_claims: dict[str, set[str]] = {}
    for item in value["claimed_roles"]:
        if not isinstance(item, dict) or set(item) != {"player", "role"}:
            raise ValueError("claimed role has an invalid shape")
        player, role = item["player"], item["role"]
        if player not in players or role not in ROLES:
            raise ValueError("claimed roles contain an invalid player or role")
        if player in claimed and claimed[player] != role:
            conflicting_claims.setdefault(player, {claimed[player]}).add(role)
            continue
        claimed[player] = role
    for player, roles in conflicting_claims.items():
        claimed.pop(player, None)
        value["notes"].append(
            "Conflicting extracted roles for %s were omitted: %s"
            % (player, ", ".join(sorted(roles)))
        )
    if conflicting_claims:
        value["translation_status"] = "ambiguous"
    value["claimed_roles"] = claimed
    return value


def _axioms_hold(
    selected: Sequence[str],
    assignment: Assignment,
    statements: Sequence[dict[str, Any]],
) -> bool:
    values = statement_values(statements, assignment)
    for axiom in selected:
        if axiom.startswith("speaker_truthfulness:"):
            player = int(axiom.split(":", 1)[1])
            role = assignment[player]
            if role != "spy" and ((role == "knight") != values[player]):
                return False
    return True


def check_step(
    step: Mapping[str, Any],
    statements: Sequence[dict[str, Any]],
) -> dict[str, Any]:
    status = step["translation_status"]
    if status in {"ambiguous", "unformalizable"} or step["conclusion"] is None:
        verdict = "ambiguous" if status == "ambiguous" else "unformalizable"
        return {"verdict": verdict, "model_count": None, "true_count": None, "false_count": None}
    premises = list(step["assumptions"]) + list(step["premises"])
    models = []
    for assignment in assignments(len(statements)):
        if not _axioms_hold(step["axioms"], assignment, statements):
            continue
        if all(evaluate_expr(expr, assignment, statements) for expr in premises):
            models.append(assignment)
    if not models:
        return {"verdict": "inconsistent_premises", "model_count": 0, "true_count": 0, "false_count": 0}
    values = [evaluate_expr(step["conclusion"], item, statements) for item in models]
    true_count = sum(values)
    if true_count == len(values):
        verdict = "entailed"
    elif true_count == 0:
        verdict = "contradicted"
    else:
        verdict = "contingent"
    return {
        "verdict": verdict,
        "model_count": len(models),
        "true_count": true_count,
        "false_count": len(models) - true_count,
    }


def compare_claimed_roles(
    claimed: Mapping[str, str], submitted: Mapping[str, str]
) -> dict[str, Any]:
    mismatches = {
        player: {"claimed": role, "submitted": submitted[player]}
        for player, role in claimed.items()
        if player in submitted and submitted[player] != role
    }
    if not claimed:
        status = "no_claims"
    elif mismatches:
        status = "mismatch"
    elif set(claimed) == set(submitted):
        status = "match"
    else:
        status = "partial_match"
    return {"status": status, "mismatches": mismatches}


def _prompt(
    question: Mapping[str, Any],
    source: ReasoningSource,
) -> str:
    players = list(question["players"])
    indexed = "\n".join("%d = %s" % item for item in enumerate(players))
    statements = "\n".join(
        "%d. %s: %s\nAST: %s" % (
            index,
            statement["speaker"],
            statement["text"],
            json.dumps(statement["ast"], sort_keys=True),
        )
        for index, statement in enumerate(question["statements"])
    )
    return f"""Translate one KKS explanation into a faithful, locally checkable formal trace.

Player indexes:
{indexed}

Puzzle statements:
{statements}

Rules: every player has exactly one role; exactly one player is a spy; a knight's
statement is true; a knave's statement is false; a spy's truth value is unrestricted.

Submitted role data for this response (context only, never invent it as a premise):
{json.dumps(source.submitted_roles, sort_keys=True)}

Explanation:
{source.text}

Use only the supplied expression DSL. Use statement_true with the speaker's numeric
index for the truth value of that player's statement. For each distinct inference,
copy a non-empty exact source_span from the explanation, state all local assumptions
and premises explicitly, and cite only axioms actually used. Available axiom names are
role_exclusivity, exactly_one_spy, and speaker_truthfulness:<numeric player index>.
Do not silently repair incorrect logic or add the verified solution. Mark material that
cannot be represented as ambiguous or unformalizable and use a null conclusion.
claimed_roles must contain only roles explicitly concluded by the prose.
Return only the JSON object required by the output schema."""


def _load_question(dataset_path: Path, task_id: str) -> dict[str, Any]:
    for size in dataset_sizes(dataset_path):
        for question in read_jsonl(dataset_path / "questions" / ("%d.jsonl" % size)):
            if question["id"] == task_id:
                return question
    raise ValueError("Unknown KKS task id: %s" % task_id)


def _prepared_model(model: ModelConfig, players: Sequence[str]) -> ModelConfig:
    prepared = model.model_copy(deep=True) if hasattr(model, "model_copy") else model.copy(deep=True)
    prepared.params = dict(prepared.params)
    prepared.params["output_schema"] = formalization_schema(players)
    return prepared


async def generate_formalizations(
    run_dir: Path,
    task_id: str,
    model_config: Path,
    output: Path,
    *,
    model_client: ModelClient | None = None,
    timeout_seconds: float = 600,
    concurrency: int = 1,
) -> dict[str, Any]:
    if concurrency < 1:
        raise ValueError("concurrency must be positive")
    storage = ExperimentStorage(str(run_dir))
    resolved = config_from_resolved_dict(storage.load_resolved_config())
    if resolved.benchmark.kind != "kks":
        raise ValueError("formalize-reasoning supports only benchmark.kind=kks")
    dataset_path = Path(resolved.benchmark.path)
    if not dataset_path.is_absolute():
        dataset_path = Path(resolved.config_root) / dataset_path
    question = _load_question(dataset_path.resolve(), task_id)
    statements = [item["ast"] for item in question["statements"]]
    results = [
        value for (candidate, _), value in completed_results(run_dir).items()
        if candidate == task_id
    ]
    if not results:
        raise ValueError("No completed result for task %s in %s" % (task_id, run_dir))
    model = ModelConfig(**(yaml.safe_load(model_config.read_text(encoding="utf-8")) or {}))
    prepared = _prepared_model(model, question["players"])
    client = model_client or model_client_for_config(prepared)
    output.parent.mkdir(parents=True, exist_ok=True)
    completed: set[str] = set()
    if output.exists():
        for line in output.read_text(encoding="utf-8").splitlines():
            if line.strip():
                completed.add(str(json.loads(line)["formalization_id"]))
    sources: list[tuple[Mapping[str, Any], ReasoningSource]] = []
    for result in sorted(results, key=lambda value: int(value.get("repetition", 1))):
        for source in extract_reasoning_sources(result):
            location = {
                "run_id": result["run_id"],
                "task_id": task_id,
                "repetition": int(result.get("repetition", 1)),
                **source.location,
            }
            sources.append((location, ReasoningSource(location, source.text, source.submitted_roles)))
    skipped = sum(source.id in completed for _, source in sources)
    pending = [(location, source) for location, source in sources if source.id not in completed]
    usage: dict[str, float] = {}
    semaphore = asyncio.Semaphore(concurrency)

    async def formalize_one(location: Mapping[str, Any], source: ReasoningSource) -> None:
        async with semaphore:
            response = await client.complete(
                prepared,
                [
                    {"role": "system", "content": "You are a precise formal-logic translator. Preserve errors rather than correcting them."},
                    {"role": "user", "content": _prompt(question, source)},
                ],
                timeout_seconds,
            )
        formalization = parse_formalization(response.content, question["players"], source.text)
        checked_steps = [
            {**step, "check": check_step(step, statements)}
            for step in formalization["steps"]
        ]
        record = {
            "formalization_id": source.id,
            "formalization_version": FORMALIZATION_VERSION,
            "prompt_version": PROMPT_VERSION,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "source": location,
            "source_text": source.text,
            "submitted_roles": source.submitted_roles,
            "translation_status": formalization["translation_status"],
            "steps": checked_steps,
            "claimed_roles": formalization["claimed_roles"],
            "role_consistency": compare_claimed_roles(
                formalization["claimed_roles"], source.submitted_roles
            ),
            "notes": formalization["notes"],
            "model": response.model,
            "model_config_id": model.id,
            "model_metadata": response.response_metadata,
            "usage": response.usage,
            "raw_response": response.content,
        }
        # No await occurs while appending/updating counters, so concurrent
        # coroutines cannot interleave JSONL records in this event loop.
        with output.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, sort_keys=True) + "\n")
        completed.add(source.id)
        for key, value in response.usage.items():
            if isinstance(value, (int, float)):
                usage[key] = usage.get(key, 0.0) + float(value)

    await asyncio.gather(*(formalize_one(location, source) for location, source in pending))
    return {
        "output": str(output),
        "task_id": task_id,
        "eligible_fields": len(sources),
        "new_formalizations": len(pending),
        "skipped_existing": skipped,
        "total_formalizations": len(completed),
        "usage": usage,
    }


def run_formalizations(
    run_dir: Path,
    task_id: str,
    model_config: Path,
    output: Path,
    *,
    timeout_seconds: float = 600,
    concurrency: int = 1,
) -> dict[str, Any]:
    return asyncio.run(generate_formalizations(
        run_dir, task_id, model_config, output,
        timeout_seconds=timeout_seconds,
        concurrency=concurrency,
    ))
