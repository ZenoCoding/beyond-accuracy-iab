from __future__ import annotations

import html
import math
import textwrap
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable

from .core import wilson_interval


FIGURE_SPECS = [
    ("Outcomes", "debate-improvement-by-team.svg", "Does debate improve exact accuracy?"),
    ("Outcomes", "accuracy-by-size.svg", "Accuracy before and after debate by puzzle size"),
    ("Outcomes", "agent-improvement.svg", "Individual model improvement"),
    ("Controlled Factors", "controlled-settings-by-size.svg", "Controlled settings relative to the default anchor"),
    ("Controlled Factors", "controlled-contrasts.svg", "Controlled treatment contrasts"),
    ("Controlled Factors", "regression-coefficients.svg", "Adjusted regression estimates"),
    ("Debate Process", "agreement-dynamics.svg", "Agreement over debate"),
    ("Debate Process", "transition-correction-heatmap.svg", "Correction by initial debate state"),
    ("Debate Process", "transition-ridge-coefficients.svg", "Transition predictors"),
    ("Efficiency", "cost-effectiveness.svg", "Accuracy and cost"),
]

BLUE = "#356FB6"
LIGHT_BLUE = "#9ABDE5"
DARK_BLUE = "#174A7E"
RED = "#C94F4F"
LIGHT_RED = "#E7A09B"
DARK_RED = "#8F2D3A"
ORANGE = RED
GREEN = DARK_BLUE
INK = "#243447"
MUTED = "#627284"
GRID = "#DCE4EA"
PAPER = "#FFFFFF"
WASH = "#F7F9FB"
NEUTRAL = "#7B8794"
MARKER_SIZE = 48
LINE_WIDTH = 2.2
CI_LINE_WIDTH = 1.15
CI_LINE_STYLE = (0, (1.4, 1.8))


def _label(value: str, labels: dict[str, str]) -> str:
    return labels.get(value, value.replace("kks-debate-", "").replace("-", " ").title())


def _strip_graph_prefix(label: str) -> str:
    for prefix in (
        "Recalibrated · ",
        "Retained · ",
        "Recalibrated ",
        "Retained ",
    ):
        if label.startswith(prefix):
            return label.removeprefix(prefix)
    return label


def _graph_label(value: str, labels: dict[str, str]) -> str:
    return _strip_graph_prefix(_label(value, labels))


def _condition_text_order(label: str) -> tuple[int, int, int, str]:
    text = label.lower()
    strength = (
        0 if "weak" in text else
        1 if "medium" in text or "med " in text else
        2 if "strong" in text else 3
    )
    composition = 0 if "homogeneous" in text else 1
    if "balanced" in text and "heterogeneous" in text:
        group = 0
    elif "accuracy visible" in text:
        group = 1
    elif "verifier" in text:
        group = 2
    elif "homogeneous" in text or "heterogeneous" in text:
        group = 3
    elif "bias" in text:
        group = 4
    else:
        group = 5
    return group, strength, composition, text


def _condition_order(
    value: str, labels: dict[str, str]
) -> tuple[int, int, int, str]:
    return _condition_text_order(_label(value, labels))


def _mean_ci(values: list[float]) -> tuple[float, float, float]:
    if not values:
        return (0.0, 0.0, 0.0)
    mean = sum(values) / len(values)
    if len(values) == 1:
        return (mean, mean, mean)
    variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
    margin = 1.96 * math.sqrt(variance / len(values))
    return (mean, max(0.0, mean - margin), min(1.0, mean + margin))


def _style(plt: Any) -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 12,
        "axes.titlesize": 14,
        "axes.titleweight": "semibold",
        "axes.labelsize": 12,
        "xtick.labelsize": 11,
        "ytick.labelsize": 11,
        "legend.fontsize": 11,
        "figure.titlesize": 18,
        "figure.titleweight": "semibold",
        "figure.facecolor": PAPER,
        "axes.facecolor": PAPER,
        "axes.edgecolor": "#AEB8C2",
        "axes.linewidth": .8,
        "axes.labelcolor": INK,
        "axes.titlecolor": INK,
        "axes.titlepad": 11,
        "text.color": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "xtick.major.size": 3,
        "ytick.major.size": 3,
        "xtick.major.width": .7,
        "ytick.major.width": .7,
        "legend.frameon": False,
        "lines.linewidth": LINE_WIDTH,
        "lines.markersize": 6,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "savefig.facecolor": PAPER,
        "savefig.pad_inches": .12,
        "svg.fonttype": "none",
        "svg.hashsalt": "controlmad-analysis",
    })


def _percent_axis(axis: Any, orientation: str = "y") -> None:
    from matplotlib.ticker import PercentFormatter
    target = axis.yaxis if orientation == "y" else axis.xaxis
    target.set_major_formatter(PercentFormatter(1.0))


def _light_cmap(plt: Any, np: Any, name: str, low: float, high: float) -> Any:
    from matplotlib.colors import ListedColormap
    source = plt.get_cmap(name)
    return ListedColormap(source(np.linspace(low, high, 256)))


def _wrap_label(value: str, width: int = 32) -> str:
    return "\n".join(
        textwrap.wrap(value, width=width, break_long_words=False, break_on_hyphens=False)
    )


def _clean_axis(ax: Any, grid_axis: str | None = None) -> None:
    ax.set_axisbelow(True)
    if grid_axis:
        ax.grid(axis=grid_axis, color=GRID, lw=.75)
    ax.spines["left"].set_color("#AEB8C2")
    ax.spines["bottom"].set_color("#AEB8C2")


def _confidence_errorbar(ax: Any, *args: Any, **kwargs: Any) -> Any:
    container = ax.errorbar(*args, **kwargs)
    for collection in container.lines[2]:
        collection.set_linestyle(CI_LINE_STYLE)
    return container


def _contrast_text_color(value: float, low: float, high: float) -> str:
    if math.isnan(value):
        return INK
    position = (value - low) / max(high - low, 1e-12)
    return PAPER if position > .68 or position < .12 else INK


def _save(fig: Any, path: Path) -> str:
    title = path.stem.replace("-", " ").title()
    fig.savefig(
        path,
        format="svg",
        bbox_inches="tight",
        metadata={"Date": None, "Title": title},
    )
    fig.savefig(
        path.with_suffix(".jpg"),
        format="jpg",
        dpi=200,
        bbox_inches="tight",
        facecolor="white",
    )
    return str(path)


def _placeholder(plt: Any, path: Path, title: str, message: str) -> str:
    fig, ax = plt.subplots(figsize=(9, 3.8))
    ax.axis("off")
    ax.text(0.5, 0.62, title, ha="center", va="center", fontsize=17, weight="bold")
    ax.text(0.5, 0.40, message, ha="center", va="center", fontsize=11, color="#5B6875")
    fig.patch.set_facecolor("#F7F9FB")
    result = _save(fig, path)
    plt.close(fig)
    return result


def _debate_improvement(
    plt: Any, path: Path, paired: list[dict[str, Any]], labels: dict[str, str]
) -> str:
    if not paired:
        return _placeholder(plt, path, "Debate improvement", "No paired outcomes are available.")
    values = sorted(
        paired, key=lambda row: _condition_order(row["experiment_id"], labels)
    )
    fig, ax = plt.subplots(figsize=(11.5, max(5.5, 0.5 * len(values) + 1.8)))
    for y, row in enumerate(values):
        initial, final = row["initial_accuracy"], row["final_accuracy"]
        direction_color = DARK_BLUE if final >= initial else DARK_RED
        ax.plot(
            [initial, final], [y, y], color=direction_color, lw=LINE_WIDTH,
            solid_capstyle="round", zorder=1,
        )
        ax.scatter(
            initial, y, color=BLUE, s=MARKER_SIZE, edgecolor=PAPER,
            linewidth=.7, zorder=3,
        )
        low = min(final, max(0.0, initial + float(row["difference_ci_low"])))
        high = max(final, min(1.0, initial + float(row["difference_ci_high"])))
        _confidence_errorbar(
            ax,
            final, y, xerr=[[final - low], [high - final]], fmt="o",
            color=ORANGE, ecolor=ORANGE, capsize=3, capthick=CI_LINE_WIDTH,
            elinewidth=CI_LINE_WIDTH, markersize=6.5, markeredgecolor=PAPER,
            markeredgewidth=.7, zorder=3,
        )
        delta = row["accuracy_difference"]
        label_x = min(max(initial, final, high) + .015, 1.065)
        ax.text(
            label_x, y, f"{delta:+.1%}", va="center", ha="left",
            fontsize=9.5, weight="semibold", color=direction_color, clip_on=False,
        )
    ax.scatter([], [], color=BLUE, s=MARKER_SIZE, label="Initial")
    ax.scatter([], [], color=ORANGE, s=MARKER_SIZE, label="Final (95% CI)")
    ax.set_yticks(
        range(len(values)),
        [_wrap_label(_graph_label(row["experiment_id"], labels), 38) for row in values],
    )
    ax.invert_yaxis()
    ax.set_xlim(0, 1.1)
    _percent_axis(ax, "x")
    _clean_axis(ax, "x")
    ax.set_title("Exact puzzle accuracy before and after debate", loc="left")
    ax.set_xlabel("Strict accuracy")
    ax.legend(
        ncol=2, loc="lower right", bbox_to_anchor=(1, 1.01),
        borderaxespad=0, handletextpad=.5, columnspacing=1.4,
    )
    ax.set_xticks([value / 5 for value in range(6)])
    ax.text(
        0, -0.13,
        "Labels show paired change; whiskers are paired 95% bootstrap intervals.",
        transform=ax.transAxes, fontsize=9, color=MUTED,
    )
    fig.tight_layout(pad=1.2)
    result = _save(fig, path)
    plt.close(fig)
    return result


def _accuracy_by_size(
    plt: Any,
    path: Path,
    puzzles: list[dict[str, Any]],
    labels: dict[str, str],
) -> str:
    relevant = [row for row in puzzles if row["stage"] in {"initial_majority", "final_majority"}]
    sizes = sorted({int(row["size"]) for row in relevant})
    experiments = sorted(
        {row["experiment_id"] for row in relevant},
        key=lambda value: _condition_order(value, labels),
    )
    if not sizes or not experiments:
        return _placeholder(plt, path, "Accuracy by puzzle size", "No stage outcomes are available.")
    columns = 3
    rows = math.ceil(len(experiments) / columns)
    fig, axes = plt.subplots(
        rows, columns, figsize=(15, 3.45 * rows), sharex=True, sharey=True,
        squeeze=False,
    )
    for ax, experiment in zip(axes.flat, experiments):
        x = list(range(len(sizes)))
        for stage, color, name, offset in (
            ("initial_majority", BLUE, "Initial", -.08),
            ("final_majority", ORANGE, "Final", .08),
        ):
            stats = []
            for size in sizes:
                values = [
                    float(row["semantic_strict"])
                    for row in relevant
                    if row["experiment_id"] == experiment
                    and int(row["size"]) == size
                    and row["stage"] == stage
                ]
                stats.append(_mean_ci(values) if values else (float("nan"),) * 3)
            means = [item[0] for item in stats]
            positions = [value + offset for value in x]
            lower = [
                mean - item[1] if not math.isnan(mean) else 0
                for mean, item in zip(means, stats)
            ]
            upper = [
                item[2] - mean if not math.isnan(mean) else 0
                for mean, item in zip(means, stats)
            ]
            ax.plot(
                positions, means, color=color, alpha=.72, lw=1.5,
                label=name, zorder=2,
            )
            _confidence_errorbar(
                ax,
                positions, means, yerr=[lower, upper], fmt="o", color=color,
                ecolor=color, elinewidth=CI_LINE_WIDTH, capsize=2.5,
                markersize=5.5, markeredgecolor=PAPER, markeredgewidth=.6,
                zorder=3,
            )
        ax.set_title(
            _wrap_label(_graph_label(experiment, labels), 31),
            loc="left", fontsize=11.5,
        )
        ax.set_xticks(x, sizes)
        ax.set_ylim(0, 1.04)
        _percent_axis(ax)
        _clean_axis(ax, "y")
    for ax in list(axes.flat)[len(experiments):]:
        ax.axis("off")
    for ax in axes[-1]:
        if ax.axison:
            ax.set_xlabel("Game size")
    for ax in axes[:, 0]:
        ax.set_ylabel("Exact accuracy (95% CI)")
    handles, legend_labels = axes.flat[0].get_legend_handles_labels()
    fig.legend(
        handles, legend_labels, frameon=False, ncol=2,
        loc="upper right", bbox_to_anchor=(.98, .985),
    )
    fig.suptitle(
        "Exact accuracy before and after debate by treatment and puzzle size",
        x=.055, y=.995, ha="left", fontsize=16,
    )
    fig.tight_layout(rect=(0, 0, 1, .955), pad=1.1)
    result = _save(fig, path)
    plt.close(fig)
    return result


def _controlled_settings_by_size(
    plt: Any,
    path: Path,
    puzzles: list[dict[str, Any]],
    labels: dict[str, str],
) -> str:
    relevant = [row for row in puzzles if row["stage"] == "final_majority"]
    sizes = sorted({int(row["size"]) for row in relevant})
    experiment_by_label = {
        _label(experiment, labels): experiment
        for experiment in {row["experiment_id"] for row in relevant}
    }
    def experiment_for(condition_label: str) -> str | None:
        if condition_label in experiment_by_label:
            return experiment_by_label[condition_label]
        matches = [
            (
                0 if label.startswith("Recalibrated · ") else
                1 if label.startswith("Retained · ") else 2,
                label,
                experiment,
            )
            for label, experiment in experiment_by_label.items()
            if label.endswith(" · " + condition_label)
        ]
        return sorted(matches)[0][2] if matches else None

    anchor_label = "Balanced · heterogeneous"
    anchor = experiment_for(anchor_label)
    if not sizes or anchor is None:
        return _placeholder(
            plt,
            path,
            "Controlled settings by game size",
            "The balanced heterogeneous anchor is not available.",
        )

    panels = [
        (
            "Team strength × composition",
            [
                anchor_label,
                "Weak · homogeneous",
                "Weak · heterogeneous",
                "Medium · homogeneous",
                "Medium · heterogeneous",
                "Strong · homogeneous",
                "Strong · heterogeneous",
            ],
        ),
        (
            "Accuracy information",
            [anchor_label, "Accuracy visible"],
        ),
        (
            "Debate workflow",
            [anchor_label, "Verifier workflow"],
        ),
        (
            "Agent bias",
            [anchor_label, "Weak-agent bias", "Strong-agent bias"],
        ),
    ]
    style_by_label = {
        anchor_label: (INK, "", "Default anchor"),
        "Weak · homogeneous": (LIGHT_RED, "//", "Weak · homogeneous"),
        "Weak · heterogeneous": (LIGHT_RED, "", "Weak · heterogeneous"),
        "Medium · homogeneous": (DARK_RED, "//", "Medium · homogeneous"),
        "Medium · heterogeneous": (DARK_RED, "", "Medium · heterogeneous"),
        "Strong · homogeneous": (LIGHT_BLUE, "//", "Strong · homogeneous"),
        "Strong · heterogeneous": (LIGHT_BLUE, "", "Strong · heterogeneous"),
        "Weak-agent bias": (LIGHT_RED, "", "Weak-agent bias"),
        "Strong-agent bias": (LIGHT_BLUE, "", "Strong-agent bias"),
        "Accuracy visible": (BLUE, "", "Accuracy visible"),
        "Verifier workflow": (DARK_BLUE, "", "Verifier workflow"),
    }

    strength_panel = panels[0]
    compact_panels = panels[1:]
    fig = plt.figure(figsize=(18, 11))
    grid = fig.add_gridspec(
        2, 3, height_ratios=(1, 1.35), hspace=.48, wspace=.24
    )
    panel_axes = [
        (fig.add_subplot(grid[0, column]), panel)
        for column, panel in enumerate(compact_panels)
    ]
    panel_axes.append((fig.add_subplot(grid[1, :]), strength_panel))

    for ax, (title, panel_labels) in panel_axes:
        available = [
            condition_label
            for condition_label in panel_labels
            if experiment_for(condition_label) is not None
        ]
        width = .82 / max(1, len(available))
        x = list(range(len(sizes)))
        for index, condition_label in enumerate(available):
            experiment = experiment_for(condition_label)
            means, lows, highs = [], [], []
            for size in sizes:
                values = [
                    int(row["semantic_strict"])
                    for row in relevant
                    if row["experiment_id"] == experiment
                    and int(row["size"]) == size
                ]
                if values:
                    mean = sum(values) / len(values)
                    low, high = wilson_interval(sum(values), len(values))
                else:
                    mean = low = high = float("nan")
                means.append(mean)
                lows.append(mean - low)
                highs.append(high - mean)
            positions = [
                value + (index - (len(available) - 1) / 2) * width
                for value in x
            ]
            color, hatch, legend_label = style_by_label[condition_label]
            ax.bar(
                positions,
                means,
                width,
                color=color,
                alpha=.9,
                hatch=hatch,
                edgecolor="white",
                linewidth=.35,
                label=legend_label,
                zorder=3,
            )
            _confidence_errorbar(
                ax, positions, means, yerr=[lows, highs], fmt="none",
                ecolor=INK, elinewidth=.7, capsize=1.5, capthick=.7,
                zorder=4,
            )
        ax.set_title(title, loc="left", pad=17)
        ax.set_xlabel("Game size (task difficulty)")
        ax.set_ylabel("Final exact accuracy (95% CI)")
        ax.set_xticks(x, sizes)
        ax.set_ylim(-0.02, 1.02)
        _percent_axis(ax)
        _clean_axis(ax, "y")
        columns = 4 if title == strength_panel[0] else min(3, len(available))
        ax.legend(
            frameon=True, facecolor=PAPER, edgecolor=GRID, fontsize=9.5,
            ncol=columns,
            loc="lower right",
            bbox_to_anchor=(1, 1.015),
            borderaxespad=0,
        )

    fig.suptitle(
        "Overall accuracy across controlled debate settings",
        x=.055,
        y=.985,
        ha="left",
        fontsize=16,
    )
    fig.text(
        .055,
        .948,
        "Each panel isolates one factor and repeats the balanced heterogeneous default anchor. "
        "Bars show final exact accuracy; whiskers are 95% Wilson intervals (n=20 per game size).",
        ha="left",
        fontsize=9.5,
        color=MUTED,
    )
    fig.subplots_adjust(left=.065, right=.985, bottom=.075, top=.84)
    result = _save(fig, path)
    plt.close(fig)
    return result


def _treatment_by_size(
    plt: Any, np: Any, path: Path, puzzles: list[dict[str, Any]], labels: dict[str, str]
) -> str:
    experiments = sorted(
        {row["experiment_id"] for row in puzzles},
        key=lambda value: _condition_order(value, labels),
    )
    sizes = sorted({int(row["size"]) for row in puzzles})
    if not experiments or not sizes:
        return _placeholder(plt, path, "Treatment by size", "No treatment outcomes are available.")
    matrices = []
    for metric in ("final", "change"):
        matrix = np.full((len(experiments), len(sizes)), np.nan)
        for yi, experiment in enumerate(experiments):
            for xi, size in enumerate(sizes):
                initial = [float(r["semantic_strict"]) for r in puzzles if r["experiment_id"] == experiment and int(r["size"]) == size and r["stage"] == "initial_majority"]
                final = [float(r["semantic_strict"]) for r in puzzles if r["experiment_id"] == experiment and int(r["size"]) == size and r["stage"] == "final_majority"]
                if final and (metric == "final" or initial):
                    matrix[yi, xi] = sum(final) / len(final) if metric == "final" else sum(final) / len(final) - sum(initial) / len(initial)
        matrices.append(matrix)
    fig, axes = plt.subplots(1, 2, figsize=(13, max(5.5, .42 * len(experiments) + 1.5)))
    images = [
        axes[0].imshow(
            matrices[0], vmin=0, vmax=1,
            cmap=_light_cmap(plt, np, "Blues", .04, .56), aspect="auto",
        ),
        axes[1].imshow(
            matrices[1], vmin=-.25, vmax=.25,
            cmap=_light_cmap(plt, np, "RdBu", .25, .75), aspect="auto",
        ),
    ]
    for ax, title, matrix in zip(axes, ("Final exact accuracy", "Change after debate"), matrices):
        ax.set_xticks(range(len(sizes)), sizes)
        ax.set_yticks(
            range(len(experiments)),
            [_graph_label(value, labels) for value in experiments],
        )
        ax.set_xlabel("Game size")
        ax.set_title(title, loc="left", weight="bold")
        for y in range(len(experiments)):
            for x in range(len(sizes)):
                if not np.isnan(matrix[y, x]):
                    low, high = ((0, 1) if title == "Final exact accuracy" else (-.25, .25))
                    ax.text(
                        x, y, f"{matrix[y, x]:.0%}", ha="center", va="center",
                        fontsize=8.5, weight="medium",
                        color=_contrast_text_color(matrix[y, x], low, high),
                    )
        ax.tick_params(length=0)
    fig.colorbar(images[0], ax=axes[0], fraction=.035, label="Accuracy")
    fig.colorbar(images[1], ax=axes[1], fraction=.035, label="Percentage-point change")
    fig.suptitle("Treatment effects are not uniform across puzzle sizes", x=.04, ha="left", weight="bold")
    fig.tight_layout()
    result = _save(fig, path)
    plt.close(fig)
    return result


def _agent_improvement(
    plt: Any, path: Path, agents: list[dict[str, Any]], labels: dict[str, str]
) -> str:
    grouped: dict[tuple[str, str, str], dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for row in agents:
        grouped[(row["experiment_id"], row.get("agent_id", ""), row.get("model", ""))][row["phase"]].append(float(row["semantic_strict"]))
    values = []
    for key, phases in grouped.items():
        if phases["initial"] and phases["final"]:
            values.append((key, _mean_ci(phases["initial"]), _mean_ci(phases["final"])))
    if not values:
        return _placeholder(plt, path, "Individual model improvement", "No agent-level outcomes are available.")
    values.sort(
        key=lambda item: (
            _condition_order(item[0][0], labels), item[0][1]
        )
    )
    fig, ax = plt.subplots(figsize=(11, max(6, .31 * len(values) + 1.8)))
    for y, ((experiment, agent, model), initial_stats, final_stats) in enumerate(values):
        initial, final = initial_stats[0], final_stats[0]
        color = GREEN if final >= initial else RED
        ax.plot([initial, final], [y, y], color=color, lw=2)
        _confidence_errorbar(
            ax,
            initial, y,
            xerr=[[initial - initial_stats[1]], [initial_stats[2] - initial]],
            fmt="o", color=BLUE, capsize=2, markersize=4, zorder=3,
        )
        _confidence_errorbar(
            ax,
            final, y,
            xerr=[[final - final_stats[1]], [final_stats[2] - final]],
            fmt="o", color=ORANGE, capsize=2, markersize=4, zorder=3,
        )
    names = [
        f"{_graph_label(experiment, labels)} · {agent} · {model.split('/')[-1] or 'model'}"
        for (experiment, agent, model), _, _ in values
    ]
    ax.set_yticks(
        range(len(values)), [_wrap_label(name, 54) for name in names], fontsize=8.2
    )
    ax.invert_yaxis()
    ax.set_xlim(0, 1)
    _percent_axis(ax, "x")
    _clean_axis(ax, "x")
    ax.set_xlabel("Exact accuracy")
    ax.set_title("Each model’s initial-to-final accuracy change (95% CI)", loc="left")
    fig.tight_layout()
    result = _save(fig, path)
    plt.close(fig)
    return result


def _agreement(
    plt: Any, path: Path, stages: list[dict[str, Any]], regression: list[dict[str, Any]], labels: dict[str, str]
) -> str:
    if not stages:
        return _placeholder(plt, path, "Agreement dynamics", "No debate-stage records are available.")
    maxima: dict[tuple[str, str, int], int] = defaultdict(int)
    for row in stages:
        key = (row["experiment_id"], row["task_id"], int(row["repetition"]))
        maxima[key] = max(maxima[key], int(row["stage_order"]))
    bins: dict[float, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for row in stages:
        key = (row["experiment_id"], row["task_id"], int(row["repetition"]))
        progress = int(row["stage_order"]) / max(1, maxima[key])
        progress = round(progress, 2)
        bins[progress]["majority"].append(float(row["majority_agreement"]))
        bins[progress]["unanimous"].append(float(row["unanimous_agreement"]))
    auc: dict[str, list[float]] = defaultdict(list)
    for row in regression:
        if row.get("auc_agreement_major") is not None:
            auc[row["experiment_id"]].append(float(row["auc_agreement_major"]))
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    progress = sorted(bins)
    for metric, color, name in (("majority", BLUE, "Majority"), ("unanimous", ORANGE, "Unanimous")):
        axes[0].plot(progress, [sum(bins[x][metric]) / len(bins[x][metric]) for x in progress], marker="o", color=color, label=name)
    axes[0].set(xlabel="Normalized debate progress", ylabel="Characters with agreement", ylim=(0, 1))
    _percent_axis(axes[0])
    _percent_axis(axes[0], "x")
    _clean_axis(axes[0], "both")
    axes[0].legend(frameon=False)
    axes[0].set_title("Agreement trajectory", loc="left")
    ordered = sorted(auc, key=lambda value: _condition_order(value, labels))
    axes[1].barh(range(len(ordered)), [sum(auc[e]) / len(auc[e]) for e in ordered], color=BLUE)
    axes[1].set_yticks(
        range(len(ordered)),
        [_wrap_label(_graph_label(e, labels), 34) for e in ordered],
        fontsize=8.8,
    )
    axes[1].invert_yaxis()
    axes[1].set_xlim(.9, 1)
    _percent_axis(axes[1], "x")
    axes[1].set_xlabel("Majority-agreement AUC")
    _clean_axis(axes[1], "x")
    axes[1].set_title("Average agreement by treatment", loc="left")
    fig.suptitle("Debate increases consensus, but consensus is not correctness", x=.05, ha="left")
    fig.tight_layout()
    result = _save(fig, path)
    plt.close(fig)
    return result


def _controlled_contrasts(plt: Any, path: Path, contrasts: list[dict[str, Any]]) -> str:
    if not contrasts:
        return _placeholder(plt, path, "Controlled contrasts", "No paired contrasts were configured.")
    values = sorted(
        contrasts, key=lambda row: _condition_text_order(row["label"])
    )
    fig, ax = plt.subplots(figsize=(10, max(4.5, .55 * len(values) + 1.5)))
    for y, row in enumerate(values):
        estimate = float(row["right_minus_left_accuracy"])
        low, high = float(row["difference_ci_low"]), float(row["difference_ci_high"])
        color = DARK_BLUE if float(row["holm_adjusted_p"]) < .05 else NEUTRAL
        _confidence_errorbar(
            ax, estimate, y,
            xerr=[[estimate - low], [high - estimate]],
            fmt="o", color=color, capsize=4,
        )
        ax.text(high + .008, y, f"pHolm={row['holm_adjusted_p']:.3f}", va="center", fontsize=10)
    ax.axvline(0, color=INK, lw=1)
    ax.set_yticks(
        range(len(values)),
        [_strip_graph_prefix(row["label"]) for row in values],
    )
    ax.invert_yaxis()
    ax.set_xlabel("Right condition − left condition (exact accuracy)")
    _percent_axis(ax, "x")
    _clean_axis(ax, "x")
    ax.set_title("Paired treatment effects with 95% bootstrap intervals", loc="left")
    fig.tight_layout()
    result = _save(fig, path)
    plt.close(fig)
    return result


def _transition_heatmap(
    plt: Any, np: Any, path: Path, rows: list[dict[str, Any]], labels: dict[str, str]
) -> str:
    del labels  # This view intentionally pools each model across team conditions.
    model_strengths = {
        "gpt-4.1-mini-2025-04-14 · default": .025,
        "llama-4-maverick · default": .025,
        "gemini-3.1-flash-lite · default": .05,
        "gemini-3.5-flash-lite · medium": .36666666666666664,
        "mercury-2 · low": .475,
        "gpt-oss-20b · medium": .6083333333333333,
        "gpt-5-nano-2025-08-07 · medium": .8666666666666667,
        "step-3.7-flash · low": .8833333333333333,
        "gemini-3.1-flash-lite · high": .90,
    }
    known_efforts = {
        "gpt-4.1-mini-2025-04-14": "default",
        "llama-4-maverick": "default",
        "gemini-3.5-flash-lite": "medium",
        "mercury-2": "low",
        "gpt-oss-20b": "medium",
        "gpt-5-nano-2025-08-07": "medium",
        "step-3.7-flash": "low",
    }

    def model_label(row: dict[str, Any]) -> str:
        model = str(row.get("model") or row.get("agent_id", "unknown")).split("/")[-1]
        effort = str(row.get("reasoning_effort") or "")
        if not effort and model == "gemini-3.1-flash-lite":
            experiment = str(row.get("experiment_id", ""))
            effort = "high" if "strong-het" in experiment else "default"
        effort = effort or known_efforts.get(model, "")
        return f"{model} · {effort}" if effort else model

    grouped: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for row in rows:
        model = model_label(row)
        grouped[model][row["initial_state"]].append(float(row["after_correct"]))
    preferred_states = [
        "majority_correct",
        "minority_correct",
        "chaos_correct",
        "chaos_wrong",
        "minority_wrong",
        "majority_wrong",
    ]
    available_states = {state for values in grouped.values() for state in values}
    states = [state for state in preferred_states if state in available_states]
    states.extend(sorted(available_states - set(states)))
    models = sorted(grouped, key=lambda value: (model_strengths.get(value, math.inf), value))
    if not models or not states:
        return _placeholder(plt, path, "Transition correction rates", "No agent transitions are available.")
    matrix = np.full((len(models), len(states)), np.nan)
    for y, model in enumerate(models):
        for x, state in enumerate(states):
            if grouped[model][state]:
                matrix[y, x] = sum(grouped[model][state]) / len(grouped[model][state])
    fig, ax = plt.subplots(figsize=(10.5, max(5, .5 * len(models) + 1.8)))
    from matplotlib.colors import LinearSegmentedColormap
    palette = LinearSegmentedColormap.from_list(
        "controlmad_coral_blue", ["#E87E61", "#F5F6F8", "#68ACD0"]
    )
    image = ax.imshow(matrix, vmin=0, vmax=1, cmap=palette, aspect="auto")
    ax.set_xticks(range(len(states)), [state.replace("_", "\n") for state in states])
    ax.set_yticks(range(len(models)), models, fontsize=9)
    for y in range(len(models)):
        for x in range(len(states)):
            value = matrix[y, x]
            if not np.isnan(value):
                color = "white" if value <= .18 or value >= .78 else INK
                ax.text(
                    x, y, f"{value:.0%}", ha="center", va="center", color=color,
                    fontsize=8, fontfamily="Avenir Next",
                )
    correct_state_count = sum(state.endswith("_correct") for state in states)
    if 0 < correct_state_count < len(states):
        ax.axvline(correct_state_count - .5, color="white", lw=2.5)
    for boundary in (.30, .70):
        before = sum(model_strengths.get(model, math.inf) < boundary for model in models)
        if 0 < before < len(models):
            ax.axhline(before - .5, color="white", lw=2.5)
    ax.set_title(
        "Post-debate correctness by model and initial state", loc="left",
        weight="bold", pad=22, fontfamily="Avenir Next",
    )
    ax.text(
        0, 1.015,
        "Weak to medium to strong by matched initial accuracy · pooled across team conditions",
        transform=ax.transAxes, ha="left", va="bottom", fontsize=9, color="#5B6875",
        fontfamily="Avenir Next",
    )
    for tick in [*ax.get_xticklabels(), *ax.get_yticklabels()]:
        tick.set_fontfamily("Avenir Next")
    colorbar = fig.colorbar(image, ax=ax, fraction=.025)
    colorbar.set_label("Final correctness", fontfamily="Avenir Next")
    for tick in colorbar.ax.get_yticklabels():
        tick.set_fontfamily("Avenir Next")
    fig.tight_layout()
    result = _save(fig, path)
    plt.close(fig)
    return result


def _ridge(plt: Any, path: Path, ridge: dict[str, Any]) -> str:
    if ridge.get("status") != "estimated":
        return _placeholder(plt, path, "Transition predictors", ridge.get("reason", "The ridge model is unavailable."))
    coefficients = sorted(ridge["coefficients"], key=lambda item: abs(item["coefficient"]), reverse=True)[:16]
    coefficients.sort(key=lambda item: item["coefficient"])
    fig, ax = plt.subplots(figsize=(10, max(5, .38 * len(coefficients) + 1.5)))
    values = [item["coefficient"] for item in coefficients]
    ax.barh(range(len(coefficients)), values, color=[RED if value < 0 else GREEN for value in values])
    ax.set_yticks(range(len(coefficients)), [item["transition"].replace("__", " · ").replace("_", " ") for item in coefficients], fontsize=10)
    ax.axvline(0, color=INK, lw=1)
    ax.set_xlabel("Standardized ridge coefficient")
    ax.set_title("Transitions associated with final smooth accuracy", loc="left")
    _clean_axis(ax, "x")
    fig.tight_layout()
    result = _save(fig, path)
    plt.close(fig)
    return result


def _regressions(plt: Any, path: Path, models: dict[str, Any]) -> str:
    selected = [
        ("paper_final_smooth_ols", "Final smooth accuracy"),
        ("paper_agreement_ols", "Majority-agreement AUC"),
    ]
    estimated = [(models.get(key, {}), title) for key, title in selected if models.get(key, {}).get("status") == "estimated"]
    if not estimated:
        reasons = "; ".join(models.get(key, {}).get("reason", "unavailable") for key, _ in selected)
        return _placeholder(plt, path, "Adjusted regression estimates", reasons)
    fig, axes = plt.subplots(1, len(estimated), figsize=(6.5 * len(estimated), 6), squeeze=False)
    for ax, (model, title) in zip(axes[0], estimated):
        estimates = [item for item in model["estimates"] if item["term"] != "constant"]
        estimates.sort(key=lambda item: item["coefficient"])
        coefs = [item["coefficient"] for item in estimates]
        errors = [1.96 * item["cluster_robust_se"] for item in estimates]
        _confidence_errorbar(
            ax, coefs, range(len(estimates)), xerr=errors,
            fmt="o", color=BLUE, capsize=3,
        )
        ax.axvline(0, color=INK, lw=1)
        ax.set_yticks(range(len(estimates)), [item["term"].replace("_", " ") for item in estimates], fontsize=10)
        ax.set_title(title, loc="left")
        ax.set_xlabel("Coefficient (cluster-robust 95% CI)")
        _clean_axis(ax, "x")
    fig.suptitle("Adjusted associations from the paper-replication models", x=.04, ha="left")
    fig.tight_layout()
    result = _save(fig, path)
    plt.close(fig)
    return result


def _cost(
    plt: Any, path: Path, operational: list[dict[str, Any]], paired: list[dict[str, Any]], labels: dict[str, str]
) -> str:
    final = {row["experiment_id"]: row["final_accuracy"] for row in paired}
    values = sorted(
        [
            row for row in operational
            if float(row.get("cost_per_puzzle") or 0) > 0
            and row["experiment_id"] in final
        ],
        key=lambda row: _condition_order(row["experiment_id"], labels),
    )
    if not values:
        return _placeholder(plt, path, "Cost effectiveness", "Cost data were not recorded for these runs.")
    fig = plt.figure(figsize=(13.5, max(6.2, 4.2 + .31 * len(values))))
    grid = fig.add_gridspec(1, 2, width_ratios=(2.25, 1), wspace=.08)
    ax = fig.add_subplot(grid[0, 0])
    key_ax = fig.add_subplot(grid[0, 1])
    for index, row in enumerate(values, start=1):
        x, y = float(row["cost_per_puzzle"]), final[row["experiment_id"]]
        ax.scatter(
            x, y, s=155, color=BLUE, edgecolor=PAPER, linewidth=1.2, zorder=3,
        )
        ax.text(
            x, y, str(index), color=PAPER, ha="center", va="center",
            fontsize=8.5, weight="bold", zorder=4,
        )
        efficiency = row.get("correct_puzzles_per_dollar")
        label = _graph_label(row["experiment_id"], labels)
        detail = f"{efficiency:.1f} correct/$" if efficiency is not None else ""
        row_y = index * 1.5
        key_ax.scatter(
            .04, row_y, s=135, color=BLUE, edgecolor=PAPER, linewidth=1,
        )
        key_ax.text(
            .04, row_y, str(index), color=PAPER, ha="center", va="center",
            fontsize=8, weight="bold",
        )
        key_ax.text(
            .11, row_y, _wrap_label(label, 34), va="bottom", ha="left",
            fontsize=9.2, weight="semibold",
        )
        key_ax.text(
            .11, row_y + .16, detail, va="top", ha="left",
            fontsize=8.4, color=MUTED,
        )
    ax.set(
        xlabel="Cost per puzzle (USD)", ylabel="Final exact accuracy",
        ylim=(-.02, 1.02),
    )
    _percent_axis(ax)
    _clean_axis(ax, "both")
    ax.set_title("Accuracy versus inference cost", loc="left")
    x_values = [float(row["cost_per_puzzle"]) for row in values]
    x_span = max(x_values) - min(x_values)
    x_pad = max(.005, x_span * .07)
    ax.set_xlim(min(x_values) - x_pad, max(x_values) + x_pad)
    key_ax.set_xlim(0, 1)
    key_ax.set_ylim(len(values) * 1.5 + .9, .35)
    key_ax.axis("off")
    key_ax.set_title("Treatment · efficiency", loc="left")
    fig.suptitle(
        "Cost and final exact accuracy by debate treatment",
        x=.045, y=.99, ha="left",
    )
    fig.subplots_adjust(left=.075, right=.985, bottom=.12, top=.88)
    result = _save(fig, path)
    plt.close(fig)
    return result


def _reasoning(plt: Any, path: Path, ratings: list[dict[str, Any]]) -> str:
    applicable = [row for row in ratings if int(row.get("soundness", 0)) > 0]
    if not applicable:
        return _placeholder(
            plt, path, "Reasoning quality", "Ratings not collected — run controlmad judge-debates to populate this panel."
        )
    labels = ["1 · poor", "2", "3", "4 · strong"]
    counts = [sum(int(row["soundness"]) == score for row in applicable) for score in range(1, 5)]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar(labels, counts, color=BLUE)
    ax.set(xlabel="Blinded soundness rating", ylabel="Rated arguments")
    ax.set_title("Distribution of reasoning-quality ratings", loc="left")
    _clean_axis(ax, "y")
    fig.tight_layout()
    result = _save(fig, path)
    plt.close(fig)
    return result


def write_figures(
    output_dir: Path,
    rows: dict[str, list[dict[str, Any]]],
    summaries: dict[str, Any],
    contrasts: list[dict[str, Any]],
    models: dict[str, Any],
    rating_rows: list[dict[str, Any]] | None = None,
    condition_labels: dict[str, str] | None = None,
) -> list[str]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError:
        return []
    _style(plt)
    labels = condition_labels or {}
    figure_dir = output_dir / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)
    writers: list[tuple[str, Callable[[], str]]] = [
        ("debate-improvement-by-team.svg", lambda: _debate_improvement(plt, figure_dir / "debate-improvement-by-team.svg", summaries["paired_debate"], labels)),
        ("accuracy-by-size.svg", lambda: _accuracy_by_size(plt, figure_dir / "accuracy-by-size.svg", rows["puzzles"], labels)),
        ("treatment-by-size.svg", lambda: _treatment_by_size(plt, np, figure_dir / "treatment-by-size.svg", rows["puzzles"], labels)),
        ("agent-improvement.svg", lambda: _agent_improvement(plt, figure_dir / "agent-improvement.svg", rows["agents"], labels)),
        ("controlled-settings-by-size.svg", lambda: _controlled_settings_by_size(plt, figure_dir / "controlled-settings-by-size.svg", rows["puzzles"], labels)),
        ("agreement-dynamics.svg", lambda: _agreement(plt, figure_dir / "agreement-dynamics.svg", rows["stages"], rows["regression"], labels)),
        ("controlled-contrasts.svg", lambda: _controlled_contrasts(plt, figure_dir / "controlled-contrasts.svg", contrasts)),
        ("transition-correction-heatmap.svg", lambda: _transition_heatmap(plt, np, figure_dir / "transition-correction-heatmap.svg", rows["transitions"], labels)),
        ("transition-ridge-coefficients.svg", lambda: _ridge(plt, figure_dir / "transition-ridge-coefficients.svg", models.get("transition_ridge", {}))),
        ("regression-coefficients.svg", lambda: _regressions(plt, figure_dir / "regression-coefficients.svg", models)),
        ("cost-effectiveness.svg", lambda: _cost(plt, figure_dir / "cost-effectiveness.svg", summaries["operational"], summaries["paired_debate"], labels)),
        ("reasoning-quality.svg", lambda: _reasoning(plt, figure_dir / "reasoning-quality.svg", rating_rows or [])),
    ]
    return [writer() for _, writer in writers]


def write_dashboard(output_dir: Path, report: dict[str, Any]) -> Path:
    by_section: dict[str, list[tuple[str, str]]] = defaultdict(list)
    available = {Path(value).name for value in report.get("figures", [])}
    for section, filename, title in FIGURE_SPECS:
        if filename in available:
            by_section[section].append((filename, title))
    cards = []
    wide_figures = {
        "debate-improvement-by-team.svg",
        "accuracy-by-size.svg",
        "agent-improvement.svg",
        "controlled-settings-by-size.svg",
        "transition-correction-heatmap.svg",
        "cost-effectiveness.svg",
    }
    for section in ("Outcomes", "Controlled Factors", "Debate Process", "Efficiency"):
        items = "".join(
            f'<article class="card{" wide" if filename in wide_figures else ""}">'
            f'<h3>{html.escape(title)}</h3>'
            f'<a href="figures/{filename}"><img src="figures/{filename}" '
            f'alt="{html.escape(title)}"></a></article>'
            for filename, title in by_section.get(section, [])
        )
        cards.append(f"<section><h2>{section}</h2><div class=\"grid\">{items}</div></section>")
    warning_text = " ".join(report.get("warnings", [])) or "No analysis warnings."
    observed_count = int(report.get("row_counts", {}).get("regression", 0))
    methods = report.get("methods", {})
    overall_sizes = methods.get("overall_sizes", "all observed sizes")
    overall_sizes_text = (
        ", ".join(str(value) for value in overall_sizes)
        if isinstance(overall_sizes, list) else str(overall_sizes)
    )
    table_links = " · ".join(
        f'<a href="{name}">{name}</a>'
        for name in ("accuracy.csv", "paired-debate.csv", "contrasts.csv", "model-estimates.csv", "operational.csv", "transitions.csv")
        if (output_dir / name).exists()
    )
    document = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ControlMAD debate analysis</title>
<style>
:root{{--ink:#243447;--muted:#627284;--paper:#fff;--wash:#f5f7f9;--line:#dce4ea;--accent:#356fb6;--navy:#173f62}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--wash);color:var(--ink);font:16px/1.55 system-ui,-apple-system,sans-serif}}
main{{max-width:1580px;margin:auto;padding:clamp(16px,4vw,56px)}} header{{background:linear-gradient(135deg,var(--navy),#24597f);color:white;padding:clamp(28px,5vw,64px);border-radius:16px}}
h1{{font-size:clamp(2rem,5vw,4rem);line-height:1.05;letter-spacing:-.025em;margin:0 0 14px}} header p{{max-width:850px;color:#dceaf3}}
h2{{margin:48px 0 18px;font-size:1.55rem;letter-spacing:-.01em}} .grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}}
.card{{min-width:0;background:var(--paper);border:1px solid var(--line);border-radius:12px;padding:18px;box-shadow:0 6px 22px #23384a0a}}
.card.wide{{grid-column:1/-1}}
.card h3{{margin:0 0 12px;font-size:1rem;color:var(--muted);font-weight:650}} .card a{{display:block;overflow:auto}} img{{width:100%;height:auto;display:block}}
.notes{{margin-top:40px;background:white;border-left:4px solid var(--accent);padding:20px 24px;border-radius:8px}} .notes h2{{margin-top:0}} a{{color:#246aa2}}
@media(max-width:800px){{.grid{{grid-template-columns:1fr}} .card,.card.wide{{grid-column:1;padding:10px}} main{{padding:10px}} header{{border-radius:10px}} h2{{margin-top:34px}}}}
@media print{{
  @page{{size:landscape;margin:.35in}}
  body{{background:#fff;font-size:11pt}}
  main{{max-width:none;padding:0}}
  header{{box-shadow:none;break-after:page}}
  section{{break-before:page}}
  section h2{{margin:0 0 12px;break-after:avoid}}
  .grid{{display:block}}
  .card,.card.wide{{margin:0 0 18px;padding:12px;box-shadow:none;break-inside:avoid;page-break-inside:avoid}}
  .grid .card:not(:first-child){{break-before:page}}
  .card a{{overflow:visible}}
  .card img{{width:100%;max-height:6.65in;object-fit:contain}}
  .notes{{break-before:page;break-inside:avoid}}
}}
</style></head><body><main>
<header><p>ControlMAD replication</p><h1>Does debate improve LLM puzzle solving?</h1>
<p>Human-readable results for {observed_count:,} observed completed puzzle debates. Exact semantic accuracy is the headline outcome; smooth player-level accuracy is secondary.</p></header>
{''.join(cards)}
<aside class="notes"><h2>Methods and data</h2>
<p>Pooled overall accuracy, agent improvement, cost-effectiveness accuracy, controlled contrasts, and fitted models use game sizes {html.escape(overall_sizes_text)}. Size-specific charts retain every observed game size. Paired changes and controlled contrasts use 95% intervals with {methods.get('bootstrap_samples', 10000):,} bootstrap samples. Contrast p-values are Holm-adjusted within each configured family. Regression intervals use puzzle-cluster-robust standard errors. Unresolved strict-majority ties count as incorrect.</p>
<p><strong>Warnings:</strong> {html.escape(warning_text)}</p><p>{table_links} · <a href="report.json">report.json</a></p></aside>
</main></body></html>"""
    path = output_dir / "dashboard.html"
    path.write_text(document, encoding="utf-8")
    return path
