from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import AnalysisConfig, load_analysis_config
from .core import (
    completed_results,
    discover_run_dirs,
    exact_mcnemar,
    extract_rows,
    holm_adjust,
    paired_bootstrap_interval,
    summarize_rows,
    write_csv,
)
from .models import cluster_robust_ols, paired_logistic_gee, ridge_transition_model
from .plots import write_figures
from .ratings import load_ratings, summarize_ratings


def _contrast_results(
    puzzle_rows: list[dict[str, Any]], config: AnalysisConfig
) -> list[dict[str, Any]]:
    finals: dict[str, dict[tuple[str, int], int]] = defaultdict(dict)
    for row in puzzle_rows:
        if (
            row["stage"] == "final_majority"
            and (
                config.overall_sizes is None
                or int(row["size"]) in config.overall_sizes
            )
        ):
            finals[row["experiment_id"]][
                (row["task_id"], int(row["repetition"]))
            ] = int(row["semantic_strict"])
    results = []
    for contrast in config.contrasts:
        left = finals.get(contrast.left, {})
        right = finals.get(contrast.right, {})
        keys = sorted(set(left) & set(right))
        left_only = sum(left[key] == 1 and right[key] == 0 for key in keys)
        right_only = sum(left[key] == 0 and right[key] == 1 for key in keys)
        interval = paired_bootstrap_interval(
            [(left[key], right[key]) for key in keys],
            config.bootstrap_samples,
            config.seed,
        )
        results.append({
            "name": contrast.name,
            "label": contrast.name.replace("-", " ").title(),
            "family": contrast.family,
            "left": contrast.left,
            "right": contrast.right,
            "left_label": config.condition_labels.get(contrast.left, contrast.left),
            "right_label": config.condition_labels.get(contrast.right, contrast.right),
            "paired_count": len(keys),
            "right_minus_left_accuracy": (
                sum(right[key] - left[key] for key in keys) / len(keys)
                if keys else 0.0
            ),
            "left_only": left_only,
            "right_only": right_only,
            "p_value": exact_mcnemar(left_only, right_only),
            "difference_ci_low": interval[0],
            "difference_ci_high": interval[1],
        })
    by_family: dict[str, list[int]] = defaultdict(list)
    for index, result in enumerate(results):
        by_family[result["family"]].append(index)
    for indices in by_family.values():
        adjusted = holm_adjust([results[index]["p_value"] for index in indices])
        for index, value in zip(indices, adjusted):
            results[index]["holm_adjusted_p"] = value
    return results


def _run_inventory(config: AnalysisConfig) -> list[dict[str, Any]]:
    inventory = []
    for run_dir in discover_run_dirs(config):
        summary_path = run_dir / "summary.json"
        if not summary_path.exists():
            continue
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        selected = int(summary.get("selected_count", summary.get("completed_count", 0)))
        completed = len(completed_results(run_dir))
        source_experiment = summary.get("experiment_id", run_dir.name)
        experiment = config.experiment_aliases.get(
            source_experiment, source_experiment
        )
        inventory.append({
            "experiment_id": experiment,
            "source_experiment_id": source_experiment,
            "condition_label": config.condition_labels.get(
                experiment, experiment,
            ),
            "run_dir": str(run_dir),
            "treatment": summary.get("treatment"),
            "selected_count": selected,
            "completed_count": completed,
            "failed_count": max(
                int(summary.get("failed_count", 0)), selected - completed
            ),
            "completion_rate": completed / selected if selected else 0.0,
        })
    return inventory


def run_analysis(config_or_path: AnalysisConfig | Path) -> dict[str, Any]:
    config = (
        config_or_path
        if isinstance(config_or_path, AnalysisConfig)
        else load_analysis_config(config_or_path)
    )
    output_dir = config.output_dir / config.analysis_id
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = extract_rows(config)
    overall_rows = {
        name: [
            row for row in values
            if (
                config.overall_sizes is None
                or int(row["size"]) in config.overall_sizes
            )
        ]
        for name, values in rows.items()
    }
    inventory = _run_inventory(config)
    for name, values in rows.items():
        write_csv(output_dir / ("%s.csv" % name), values)
    summaries = summarize_rows(rows["puzzles"], config)
    contrasts = _contrast_results(rows["puzzles"], config)
    write_csv(output_dir / "accuracy.csv", summaries["accuracy"])
    write_csv(output_dir / "paired-debate.csv", summaries["paired_debate"])
    write_csv(output_dir / "operational.csv", summaries["operational"])
    write_csv(output_dir / "contrasts.csv", contrasts)
    write_csv(output_dir / "run-inventory.csv", inventory)

    models = {
        "paired_logistic_gee": paired_logistic_gee(overall_rows["puzzles"]),
        "paper_final_smooth_ols": cluster_robust_ols(
            overall_rows["regression"], "final_smooth"
        ),
        "paper_agreement_ols": cluster_robust_ols(
            overall_rows["regression"], "auc_agreement_major"
        ),
        "transition_ridge": ridge_transition_model(
            overall_rows["transitions"], overall_rows["regression"], config.seed
        ),
    }
    model_rows = []
    for model_name, result in models.items():
        for estimate in result.get("estimates", result.get("coefficients", [])):
            model_rows.append({"model": model_name, **estimate})
    write_csv(output_dir / "model-estimates.csv", model_rows)
    ratings_path = config.judge_ratings or (output_dir / "judge-ratings.jsonl")
    rating_rows = load_ratings(ratings_path)
    rating_summary = summarize_ratings(rating_rows)
    write_csv(output_dir / "reasoning-ratings.csv", rating_rows)
    figure_rows = {**rows, "agents": overall_rows["agents"]}
    figures = write_figures(
        output_dir,
        figure_rows,
        summaries,
        contrasts,
        models,
        rating_rows,
        config.condition_labels,
    )
    warnings = []
    if not rows["puzzles"]:
        warnings.append("no completed debate results were found")
    for name, result in models.items():
        if result.get("status") != "estimated":
            warnings.append("%s: %s" % (name, result.get("reason", result.get("status"))))
    report = {
        "schema_version": 1,
        "analysis_id": config.analysis_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "config": str(config.config_path),
        "output_dir": str(output_dir),
        "row_counts": {name: len(values) for name, values in rows.items()},
        "run_inventory": inventory,
        "summaries": summaries,
        "contrasts": contrasts,
        "models": models,
        "reasoning_quality": rating_summary,
        "figures": figures,
        "dashboard": str(output_dir / "dashboard.html"),
        "warnings": warnings,
        "methods": {
            "primary_metric": "semantic_strict",
            "primary_comparison": "post-debate strict majority versus initial strict majority",
            "tie_policy": "unresolved strict-majority ties count as incorrect",
            "overall_sizes": (
                list(config.overall_sizes)
                if config.overall_sizes is not None else "all observed sizes"
            ),
            "confidence_level": 0.95,
            "bootstrap_samples": config.bootstrap_samples,
            "bootstrap_seed": config.seed,
            "multiple_testing": "Holm within configured contrast family",
        },
    }
    temporary = output_dir / "report.tmp"
    temporary.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(output_dir / "report.json")
    from .plots import write_dashboard
    write_dashboard(output_dir, report)
    return report
