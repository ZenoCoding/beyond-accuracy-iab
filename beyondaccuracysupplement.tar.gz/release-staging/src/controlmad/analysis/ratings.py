from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


def load_ratings(path: Path | None) -> list[dict[str, Any]]:
    if path is None or not path.exists():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        record = json.loads(line)
        rating = record.get("rating", {})
        for kind in ("agree", "disagree"):
            rows.append({
                "rating_id": record.get("rating_id"),
                "item_id": "%s:%s:%s:%s:%s" % (
                    record.get("experiment_id"),
                    record.get("task_id"),
                    record.get("repetition", 1),
                    record.get("round_index"),
                    record.get("player"),
                ),
                "experiment_id": record.get("experiment_id"),
                "task_id": record.get("task_id"),
                "round_index": record.get("round_index"),
                "player": record.get("player"),
                "judge": record.get("judge_id", record.get("judge_model", "unknown")),
                "reasoning_kind": kind,
                "soundness": int(rating.get("%s_reasoning_soundness" % kind, 0)),
            })
    return rows


def weighted_kappa(left: list[int], right: list[int], maximum: int = 4) -> float | None:
    if len(left) != len(right) or not left:
        return None
    count = len(left)
    left_counts = Counter(left)
    right_counts = Counter(right)
    observed = sum(((a - b) / maximum) ** 2 for a, b in zip(left, right)) / count
    expected = sum(
        left_counts[a] * right_counts[b] / (count * count) * ((a - b) / maximum) ** 2
        for a in range(maximum + 1)
        for b in range(maximum + 1)
    )
    return 1 - observed / expected if expected else 1.0


def summarize_ratings(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        return {"count": 0, "high_quality_rate": None, "weighted_kappa": None}
    non_applicable = [row for row in rows if row["soundness"] > 0]
    judges = sorted({row["judge"] for row in rows})
    kappa = None
    if len(judges) == 2:
        values: dict[tuple[str, str], dict[str, int]] = defaultdict(dict)
        for row in rows:
            values[(row["item_id"], row["reasoning_kind"])][row["judge"]] = row["soundness"]
        paired = [value for value in values.values() if set(value) == set(judges)]
        kappa = weighted_kappa(
            [value[judges[0]] for value in paired],
            [value[judges[1]] for value in paired],
        )
    return {
        "count": len(rows),
        "applicable_count": len(non_applicable),
        "high_quality_rate": (
            sum(row["soundness"] >= 3 for row in non_applicable) / len(non_applicable)
            if non_applicable else None
        ),
        "judges": judges,
        "weighted_kappa": kappa,
    }
