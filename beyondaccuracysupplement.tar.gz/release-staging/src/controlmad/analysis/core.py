from __future__ import annotations

import csv
import json
import math
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

import yaml

from controlmad.harness.benchmark import benchmark_from_config
from controlmad.harness.runner import config_from_resolved_dict
from controlmad.harness.storage import ExperimentStorage
from controlmad_replication.benchmarks.kks.scoring import score_prediction

from .config import AnalysisConfig


def discover_run_dirs(config: AnalysisConfig) -> list[Path]:
    paths = {path.resolve() for path in config.run_dirs}
    for summary_path in config.suite_summaries:
        if not summary_path.exists():
            continue
        document = json.loads(summary_path.read_text(encoding="utf-8"))
        for experiment_id in document.get("experiments", {}):
            paths.add((config.runs_dir / experiment_id).resolve())
    return sorted(path for path in paths if (path / "resolved_config.yaml").exists())


def completed_results(run_dir: Path) -> dict[tuple[str, int], dict[str, Any]]:
    results: dict[tuple[str, int], dict[str, Any]] = {}
    values = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in sorted((run_dir / "tasks").glob("*/result.json"))
    ]
    jsonl_path = run_dir / "results.jsonl"
    if jsonl_path.exists():
        values.extend(
            json.loads(line)
            for line in jsonl_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        )
    for value in values:
        if value.get("status") != "completed":
            continue
        key = (str(value["task_id"]), int(value.get("repetition", 1)))
        if key not in results or int(value.get("attempt", 1)) > int(
            results[key].get("attempt", 1)
        ):
            results[key] = value
    return results


def aggregate(
    solutions: dict[str, dict[str, Any]], players: list[str]
) -> tuple[dict[str, str], list[str], dict[str, dict[str, int]]]:
    prediction: dict[str, str] = {}
    ties: list[str] = []
    votes: dict[str, dict[str, int]] = {}
    for player in players:
        counts = Counter(
            solution.get("roles", {}).get(player)
            for solution in solutions.values()
            if solution.get("roles", {}).get(player) is not None
        )
        votes[player] = dict(sorted(counts.items()))
        if not counts:
            ties.append(player)
            continue
        role, count = counts.most_common(1)[0]
        if count > len(solutions) / 2:
            prediction[player] = role
        else:
            ties.append(player)
    return prediction, ties, votes


def score(players: list[str], answer: dict[str, str], prediction: dict[str, str]) -> dict[str, Any]:
    return score_prediction(players, answer, prediction)


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if total <= 0:
        return (0.0, 0.0)
    p = successes / total
    denominator = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denominator
    radius = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denominator
    return max(0.0, center - radius), min(1.0, center + radius)


def exact_mcnemar(left_only: int, right_only: int) -> float:
    discordant = left_only + right_only
    if discordant == 0:
        return 1.0
    tail = sum(
        math.comb(discordant, k)
        for k in range(min(left_only, right_only) + 1)
    )
    return min(1.0, 2.0 * tail / (2 ** discordant))


def paired_bootstrap_interval(
    pairs: list[tuple[float, float]], samples: int, seed: int
) -> tuple[float, float]:
    if not pairs:
        return (0.0, 0.0)
    rng = random.Random(seed)
    values = []
    for _ in range(samples):
        drawn = [pairs[rng.randrange(len(pairs))] for _ in pairs]
        values.append(sum(right - left for left, right in drawn) / len(drawn))
    values.sort()
    return (
        values[int(0.025 * (samples - 1))],
        values[int(0.975 * (samples - 1))],
    )


def holm_adjust(p_values: list[float]) -> list[float]:
    order = sorted(range(len(p_values)), key=p_values.__getitem__)
    adjusted = [1.0] * len(p_values)
    running = 0.0
    count = len(p_values)
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (count - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted


def _initial_state(
    agent_role: str,
    correct_role: str,
    roles: list[str],
) -> str:
    counts = Counter(roles)
    largest = counts.most_common()
    has_majority = bool(largest and largest[0][1] > len(roles) / 2)
    correctness = "correct" if agent_role == correct_role else "wrong"
    if not has_majority:
        return "chaos_" + correctness
    if counts[agent_role] > len(roles) / 2:
        return "majority_" + correctness
    return "minority_" + correctness


def _usage_value(result: dict[str, Any], *keys: str) -> float:
    usage = result.get("usage", {})
    return float(sum(float(usage.get(key, 0) or 0) for key in keys))


def _model_call_latency(run_dir: Path, run_id: str) -> float:
    path = run_dir / "tasks" / run_id / "model_calls.jsonl"
    if not path.exists():
        return 0.0
    total = 0.0
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        value = json.loads(line)
        if value.get("status") == "completed":
            total += float(value.get("latency_seconds", 0) or 0)
    return total


def _canonical_model_id(value: str) -> str:
    result = value
    for marker in ("-constrained-json", "-openrouter", "-deepinfra", "-direct"):
        if marker in result:
            result = result.split(marker, 1)[0]
    return result


def _reasoning_effort(params: dict[str, Any]) -> str:
    effort = params.get("reasoning_effort") or params.get("model_reasoning_effort")
    if effort:
        return str(effort)
    reasoning = params.get("extra_body", {}).get("reasoning", {})
    if isinstance(reasoning, dict) and reasoning.get("effort"):
        return str(reasoning["effort"])
    return "default"


def _load_strengths(path: Path | None) -> dict[str, tuple[str, float]]:
    if path is None or not path.exists():
        return {}
    value = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    result = {}
    for group, items in value.get("groups", {}).items():
        for item in items:
            measurement = (str(group), float(item["accuracy"]))
            result[str(item["id"])] = measurement
            result[_canonical_model_id(str(item["id"]))] = measurement
            model_path = Path(str(item.get("model", "")))
            if model_path:
                model_path = (
                    model_path if model_path.is_absolute()
                    else (path.parent / model_path).resolve()
                )
                if model_path.is_file():
                    model_document = yaml.safe_load(
                        model_path.read_text(encoding="utf-8")
                    ) or {}
                    if model_document.get("id"):
                        result[str(model_document["id"])] = measurement
                        result[_canonical_model_id(str(model_document["id"]))] = measurement
                    if model_document.get("model"):
                        result[str(model_document["model"])] = measurement
    return result


def extract_rows(config: AnalysisConfig) -> dict[str, list[dict[str, Any]]]:
    puzzle_rows: list[dict[str, Any]] = []
    agent_rows: list[dict[str, Any]] = []
    stage_rows: list[dict[str, Any]] = []
    transition_rows: list[dict[str, Any]] = []
    regression_rows: list[dict[str, Any]] = []
    strengths = _load_strengths(config.model_groups)

    for run_dir in discover_run_dirs(config):
        storage = ExperimentStorage(str(run_dir))
        resolved = config_from_resolved_dict(storage.load_resolved_config())
        if resolved.treatment != "debate" or resolved.debate is None:
            continue
        tasks = {
            task.id: task
            for task in benchmark_from_config(resolved.benchmark, resolved.config_root).load()
        }
        debate = resolved.debate
        agent_efforts = {
            agent.id: _reasoning_effort(agent.model.params)
            for agent in debate.agents
        }
        experiment_id = config.experiment_aliases.get(
            resolved.experiment_id, resolved.experiment_id
        )
        for (task_id, repetition), result in completed_results(run_dir).items():
            task = tasks[task_id]
            players = list(task.metadata["players"])
            answer = task.answer
            base = {
                "experiment_id": experiment_id,
                "condition_label": config.condition_labels.get(
                    experiment_id, experiment_id
                ),
                "run_dir": str(run_dir),
                "task_id": task_id,
                "repetition": repetition,
                "size": int(task.metadata["size"]),
                "difficulty_score": float(task.metadata.get("difficulty_score", 0)),
                "workflow": debate.workflow,
                "passes": debate.passes,
                "accuracy_visible": int(debate.accuracy_visible),
                "agent_order": debate.agent_order,
                "num_agents": len(debate.agents),
            }
            initial_prediction, initial_ties, _ = aggregate(
                result["initial_proposals"], players
            )
            final_prediction, final_ties, _ = aggregate(
                result["final_decisions"], players
            )
            stages = [
                ("initial_majority", initial_prediction, initial_ties),
                ("final_majority", final_prediction, final_ties),
                ("operational_final", dict(result.get("prediction", {})), list(result.get("tied_players", []))),
            ]
            for stage, prediction, ties in stages:
                evaluation = score(players, answer, prediction)
                puzzle_rows.append({
                    **base,
                    "stage": stage,
                    "semantic_strict": evaluation["semantic_strict"],
                    "semantic_smooth": evaluation["semantic_smooth"],
                    "correct_players": evaluation["correct_players"],
                    "total_players": evaluation["total_players"],
                    "tie_count": len(ties),
                    "cost": _usage_value(result, "cost") if stage == "operational_final" else 0.0,
                    "tokens": _usage_value(
                        result, "total_tokens",
                    ) if stage == "operational_final" else 0.0,
                    "model_call_count": int(result.get("model_call_count", 0)) if stage == "operational_final" else 0,
                    "latency_seconds": (
                        _model_call_latency(run_dir, result["run_id"])
                        if stage == "operational_final" else 0.0
                    ),
                    "interaction_protocol_valid_rate": (
                        float(result.get("interaction_protocol", {}).get("valid_rate", 1.0))
                        if stage == "operational_final" else 0.0
                    ),
                    "format_protocol_valid_rate": (
                        float(result.get("format_protocol", {}).get("post_repair_valid_rate", 1.0))
                        if stage == "operational_final" else 0.0
                    ),
                })

            for phase, solutions in (
                ("initial", result["initial_proposals"]),
                ("final", result["final_decisions"]),
            ):
                for agent_id, solution in solutions.items():
                    evaluation = score(players, answer, solution["roles"])
                    agent_rows.append({
                        **base,
                        "phase": phase,
                        "agent_id": agent_id,
                        "model": result.get("models", {}).get(agent_id, ""),
                        "semantic_strict": evaluation["semantic_strict"],
                        "semantic_smooth": evaluation["semantic_smooth"],
                    })

            chronological: list[tuple[str, dict[str, dict[str, Any]]]] = [
                ("initial", result["initial_proposals"])
            ]
            for index, round_data in enumerate(result.get("rounds", []), start=1):
                solutions = round_data.get("solutions_after") or round_data.get("adjustments", {})
                chronological.append(("round_%04d" % index, solutions))
                before = round_data.get("solutions_before", {})
                after = round_data.get("solutions_after", solutions)
                for player in players:
                    before_roles = [
                        solution["roles"][player] for solution in before.values()
                    ]
                    for agent_id, before_solution in before.items():
                        before_role = before_solution["roles"][player]
                        after_role = after.get(agent_id, before_solution)["roles"][player]
                        transition_rows.append({
                            **base,
                            "round_index": index,
                            "pass": round_data.get("pass"),
                            "player": player,
                            "agent_id": agent_id,
                            "model": result.get("models", {}).get(agent_id, ""),
                            "reasoning_effort": agent_efforts.get(agent_id, "default"),
                            "initial_state": _initial_state(
                                before_role, answer[player], before_roles
                            ),
                            "before_correct": int(before_role == answer[player]),
                            "after_correct": int(after_role == answer[player]),
                            "transition": (
                                ("correct" if before_role == answer[player] else "wrong")
                                + "_to_"
                                + ("correct" if after_role == answer[player] else "wrong")
                            ),
                        })
            chronological.append(("final", result["final_decisions"]))
            auc_strict = []
            auc_smooth = []
            auc_unanimous = []
            auc_majority = []
            for order, (stage, solutions) in enumerate(chronological):
                prediction, ties, votes = aggregate(solutions, players)
                evaluation = score(players, answer, prediction)
                unanimous = sum(
                    max(counts.values(), default=0) == len(solutions)
                    for counts in votes.values()
                ) / len(players)
                majority = sum(
                    max(counts.values(), default=0) > len(solutions) / 2
                    for counts in votes.values()
                ) / len(players)
                stage_rows.append({
                    **base,
                    "stage_order": order,
                    "stage": stage,
                    "semantic_strict": evaluation["semantic_strict"],
                    "semantic_smooth": evaluation["semantic_smooth"],
                    "unanimous_agreement": unanimous,
                    "majority_agreement": majority,
                    "tie_count": len(ties),
                })
                if stage.startswith("round_"):
                    auc_strict.append(float(evaluation["semantic_strict"]))
                    auc_smooth.append(float(evaluation["semantic_smooth"]))
                    auc_unanimous.append(unanimous)
                    auc_majority.append(majority)

            initial_agent_scores = {
                agent_id: score(players, answer, solution["roles"])
                for agent_id, solution in result["initial_proposals"].items()
            }
            agent_strengths = {}
            for agent in debate.agents:
                found = (
                    strengths.get(agent.model.id)
                    or strengths.get(_canonical_model_id(agent.model.id))
                    or strengths.get(agent.model.model)
                )
                accuracy = (
                    found[1] if found else
                    float(agent.reference_accuracy) if agent.reference_accuracy is not None else
                    None
                )
                if accuracy is not None:
                    agent_strengths[agent.id] = accuracy
            strongest = max(agent_strengths, key=agent_strengths.get) if agent_strengths else None
            weakest = min(agent_strengths, key=agent_strengths.get) if agent_strengths else None
            initial_role_chaos = any(
                max(Counter(
                    proposal["roles"][player]
                    for proposal in result["initial_proposals"].values()
                ).values()) <= len(result["initial_proposals"]) / 2
                for player in players
            )
            final_eval = score(players, answer, final_prediction)
            regression_rows.append({
                **base,
                "final_smooth": final_eval["semantic_smooth"],
                "final_strict": final_eval["semantic_strict"],
                "initial_smooth": score(players, answer, initial_prediction)["semantic_smooth"],
                "initial_strict": score(players, answer, initial_prediction)["semantic_strict"],
                "strong_initial_smooth": (
                    initial_agent_scores[strongest]["semantic_smooth"] if strongest else None
                ),
                "strong_initial_strict": (
                    initial_agent_scores[strongest]["semantic_strict"] if strongest else None
                ),
                "weak_initial_smooth": (
                    initial_agent_scores[weakest]["semantic_smooth"] if weakest else None
                ),
                "weak_initial_strict": (
                    initial_agent_scores[weakest]["semantic_strict"] if weakest else None
                ),
                "initial_has_chaos": int(initial_role_chaos),
                "auc_strict": sum(auc_strict) / len(auc_strict) if auc_strict else None,
                "auc_smooth": sum(auc_smooth) / len(auc_smooth) if auc_smooth else None,
                "auc_agreement_all": sum(auc_unanimous) / len(auc_unanimous) if auc_unanimous else None,
                "auc_agreement_major": sum(auc_majority) / len(auc_majority) if auc_majority else None,
            })
    return {
        "puzzles": puzzle_rows,
        "agents": agent_rows,
        "stages": stage_rows,
        "transitions": transition_rows,
        "regression": regression_rows,
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def summarize_rows(
    rows: list[dict[str, Any]], config: AnalysisConfig
) -> dict[str, Any]:
    def included_overall(row: dict[str, Any]) -> bool:
        return (
            config.overall_sizes is None
            or int(row["size"]) in config.overall_sizes
        )

    grouped: dict[tuple[str, str, int | None], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        if included_overall(row):
            grouped[(row["experiment_id"], row["stage"], None)].append(row)
        grouped[(row["experiment_id"], row["stage"], int(row["size"]))].append(row)
    summaries = []
    for (experiment, stage, size), values in sorted(grouped.items(), key=str):
        strict_count = sum(int(value["semantic_strict"]) for value in values)
        low, high = wilson_interval(strict_count, len(values))
        summaries.append({
            "experiment_id": experiment,
            "condition_label": config.condition_labels.get(experiment, experiment),
            "stage": stage,
            "size": size,
            "count": len(values),
            "semantic_strict_accuracy": strict_count / len(values),
            "semantic_strict_ci_low": low,
            "semantic_strict_ci_high": high,
            "semantic_smooth_accuracy": sum(
                float(value["semantic_smooth"]) for value in values
            ) / len(values),
        })

    paired = []
    by_experiment: dict[str, dict[tuple[str, int], dict[str, dict[str, Any]]]] = defaultdict(
        lambda: defaultdict(dict)
    )
    for row in rows:
        if not included_overall(row):
            continue
        by_experiment[row["experiment_id"]][
            (row["task_id"], int(row["repetition"]))
        ][row["stage"]] = row
    for experiment, tasks in sorted(by_experiment.items()):
        pairs = [
            (
                float(stages["initial_majority"]["semantic_strict"]),
                float(stages["final_majority"]["semantic_strict"]),
            )
            for stages in tasks.values()
            if {"initial_majority", "final_majority"} <= set(stages)
        ]
        rescues = sum(left == 0 and right == 1 for left, right in pairs)
        regressions = sum(left == 1 and right == 0 for left, right in pairs)
        initial_accuracy = sum(left for left, _ in pairs) / len(pairs) if pairs else 0.0
        final_accuracy = sum(right for _, right in pairs) / len(pairs) if pairs else 0.0
        ci_low, ci_high = paired_bootstrap_interval(
            pairs, config.bootstrap_samples, config.seed
        )
        paired.append({
            "experiment_id": experiment,
            "condition_label": config.condition_labels.get(experiment, experiment),
            "paired_count": len(pairs),
            "initial_accuracy": initial_accuracy,
            "final_accuracy": final_accuracy,
            "accuracy_difference": final_accuracy - initial_accuracy,
            "relative_error_reduction": (
                (final_accuracy - initial_accuracy) / (1 - initial_accuracy)
                if initial_accuracy < 1 else 0.0
            ),
            "rescues": rescues,
            "regressions": regressions,
            "difference_ci_low": ci_low,
            "difference_ci_high": ci_high,
            "mcnemar_exact_two_sided_p": exact_mcnemar(rescues, regressions),
        })
    operational = []
    by_experiment_operational: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        if row["stage"] == "operational_final" and included_overall(row):
            by_experiment_operational[row["experiment_id"]].append(row)
    for experiment, values in sorted(by_experiment_operational.items()):
        total_cost = sum(float(value.get("cost", 0)) for value in values)
        correct = sum(float(value["semantic_strict"]) for value in values)
        operational.append({
            "experiment_id": experiment,
            "condition_label": config.condition_labels.get(experiment, experiment),
            "completed_puzzles": len(values),
            "total_cost": total_cost,
            "cost_per_puzzle": total_cost / len(values),
            "correct_puzzles_per_dollar": correct / total_cost if total_cost else None,
            "total_tokens": sum(float(value.get("tokens", 0)) for value in values),
            "model_call_count": sum(int(value.get("model_call_count", 0)) for value in values),
            "model_call_latency_seconds": sum(
                float(value.get("latency_seconds", 0)) for value in values
            ),
            "interaction_protocol_valid_rate": sum(
                float(value.get("interaction_protocol_valid_rate", 0)) for value in values
            ) / len(values),
            "format_protocol_valid_rate": sum(
                float(value.get("format_protocol_valid_rate", 0)) for value in values
            ) / len(values),
        })
    return {
        "accuracy": summaries,
        "paired_debate": paired,
        "operational": operational,
    }
