from __future__ import annotations

import math
from collections import Counter, defaultdict
from typing import Any


PAPER_PREDICTORS = [
    "size",
    "num_agents",
    "passes",
    "initial_smooth",
    "initial_strict",
    "strong_initial_smooth",
    "strong_initial_strict",
    "weak_initial_smooth",
    "weak_initial_strict",
    "accuracy_visible",
    "initial_has_chaos",
]


def _normal_two_sided_p(z: float) -> float:
    return math.erfc(abs(z) / math.sqrt(2))


def cluster_robust_ols(
    rows: list[dict[str, Any]],
    outcome: str,
    predictors: list[str] | None = None,
) -> dict[str, Any]:
    try:
        import numpy as np
    except ImportError:
        return {"status": "unavailable", "reason": "install analysis/requirements.txt"}
    predictors = predictors or PAPER_PREDICTORS
    usable_predictors = [
        predictor for predictor in predictors
        if any(row.get(predictor) is not None for row in rows)
        and len({row.get(predictor) for row in rows if row.get(predictor) is not None}) > 1
    ]
    complete = [
        row for row in rows
        if row.get(outcome) is not None
        and all(row.get(predictor) is not None for predictor in usable_predictors)
    ]
    if len(complete) <= len(usable_predictors) + 2:
        return {
            "status": "not_estimable",
            "reason": "insufficient complete observations",
            "observations": len(complete),
        }
    x = np.asarray([
        [1.0] + [float(row[predictor]) for predictor in usable_predictors]
        for row in complete
    ])
    y = np.asarray([float(row[outcome]) for row in complete])
    if np.linalg.matrix_rank(x) < x.shape[1]:
        return {
            "status": "not_estimable",
            "reason": "design matrix is rank deficient",
            "observations": len(complete),
        }
    inverse = np.linalg.inv(x.T @ x)
    coefficients = inverse @ x.T @ y
    residuals = y - x @ coefficients
    clusters: dict[tuple[str, int], list[int]] = defaultdict(list)
    for index, row in enumerate(complete):
        clusters[(str(row["task_id"]), int(row.get("repetition", 1)))].append(index)
    meat = np.zeros((x.shape[1], x.shape[1]))
    for indices in clusters.values():
        score = x[indices].T @ residuals[indices]
        meat += np.outer(score, score)
    cluster_count = len(clusters)
    n, k = x.shape
    correction = (
        cluster_count / (cluster_count - 1) * (n - 1) / (n - k)
        if cluster_count > 1 and n > k else 1.0
    )
    covariance = correction * inverse @ meat @ inverse
    errors = np.sqrt(np.maximum(np.diag(covariance), 0))
    names = ["constant"] + usable_predictors
    estimates = []
    for name, coefficient, error in zip(names, coefficients, errors):
        z = float(coefficient / error) if error > 0 else 0.0
        estimates.append({
            "term": name,
            "coefficient": float(coefficient),
            "cluster_robust_se": float(error),
            "p_value": _normal_two_sided_p(z),
        })
    total = float(((y - y.mean()) ** 2).sum())
    residual = float((residuals ** 2).sum())
    r_squared = 1 - residual / total if total else 0.0
    return {
        "status": "estimated",
        "outcome": outcome,
        "observations": n,
        "clusters": cluster_count,
        "r_squared": r_squared,
        "adjusted_r_squared": 1 - (1 - r_squared) * (n - 1) / (n - k),
        "estimates": estimates,
    }


def paired_logistic_gee(puzzle_rows: list[dict[str, Any]]) -> dict[str, Any]:
    try:
        import pandas as pd
        import statsmodels.api as sm
        import statsmodels.formula.api as smf
    except ImportError:
        return {"status": "unavailable", "reason": "install analysis/requirements.txt"}
    frame = pd.DataFrame([
        row for row in puzzle_rows
        if row["stage"] in {"initial_majority", "final_majority"}
    ])
    if len(frame) < 20 or frame["semantic_strict"].nunique() < 2:
        return {
            "status": "not_estimable",
            "reason": "at least 20 paired rows with outcome variation are required",
            "observations": len(frame),
        }
    frame["post_debate"] = (frame["stage"] == "final_majority").astype(int)
    frame["pair_id"] = (
        frame["task_id"].astype(str) + ":" +
        frame["repetition"].astype(str)
    )
    try:
        fit = smf.gee(
            "semantic_strict ~ post_debate * C(size)",
            groups="pair_id",
            data=frame,
            family=sm.families.Binomial(),
            cov_struct=sm.cov_struct.Exchangeable(),
        ).fit()
    except Exception as exc:
        return {"status": "not_estimable", "reason": str(exc)}
    return {
        "status": "estimated",
        "observations": int(fit.nobs),
        "estimates": [
            {
                "term": term,
                "coefficient": float(fit.params[term]),
                "robust_se": float(fit.bse[term]),
                "p_value": float(fit.pvalues[term]),
                "odds_ratio": math.exp(float(fit.params[term])),
            }
            for term in fit.params.index
        ],
    }


def ridge_transition_model(
    transition_rows: list[dict[str, Any]],
    regression_rows: list[dict[str, Any]],
    seed: int,
) -> dict[str, Any]:
    try:
        import numpy as np
        from sklearn.linear_model import RidgeCV
        from sklearn.model_selection import GroupKFold, cross_val_score
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
    except ImportError:
        return {"status": "unavailable", "reason": "install analysis/requirements.txt"}
    counts: dict[tuple[str, str, int], Counter[str]] = defaultdict(Counter)
    for row in transition_rows:
        key = (row["experiment_id"], row["task_id"], int(row["repetition"]))
        counts[key][row["initial_state"] + "__" + row["transition"]] += 1
    outcomes = {
        (row["experiment_id"], row["task_id"], int(row["repetition"])): row["final_smooth"]
        for row in regression_rows
    }
    keys = sorted(set(counts) & set(outcomes))
    features = sorted({feature for key in keys for feature in counts[key]})
    groups = [key[1] for key in keys]
    if len(keys) < 10 or len(set(groups)) < 3 or not features:
        return {
            "status": "not_estimable",
            "reason": "at least 10 observations across 3 puzzles are required",
            "observations": len(keys),
        }
    x = np.asarray([
        [counts[key][feature] / sum(counts[key].values()) for feature in features]
        for key in keys
    ])
    y = np.asarray([float(outcomes[key]) for key in keys])
    splits = min(5, len(set(groups)))
    cv = GroupKFold(n_splits=splits)
    model = make_pipeline(
        StandardScaler(),
        RidgeCV(alphas=np.logspace(-4, 4, 33)),
    )
    scores = cross_val_score(
        model, x, y, groups=groups, cv=cv, scoring="neg_mean_squared_error"
    )
    model.fit(x, y)
    ridge = model.named_steps["ridgecv"]
    return {
        "status": "estimated",
        "observations": len(keys),
        "grouped_cv_rmse": float(math.sqrt(-scores.mean())),
        "alpha": float(ridge.alpha_),
        "coefficients": [
            {"transition": feature, "coefficient": float(value)}
            for feature, value in zip(features, ridge.coef_)
        ],
    }
