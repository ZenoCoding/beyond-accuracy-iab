from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class Contrast:
    name: str
    left: str
    right: str
    family: str = "confirmatory"


@dataclass(frozen=True)
class AnalysisConfig:
    analysis_id: str
    output_dir: Path
    runs_dir: Path
    run_dirs: tuple[Path, ...] = ()
    suite_summaries: tuple[Path, ...] = ()
    model_groups: Path | None = None
    bootstrap_samples: int = 10_000
    seed: int = 20260725
    contrasts: tuple[Contrast, ...] = ()
    condition_labels: dict[str, str] = field(default_factory=dict)
    experiment_aliases: dict[str, str] = field(default_factory=dict)
    overall_sizes: tuple[int, ...] | None = None
    judge_ratings: Path | None = None
    config_path: Path = Path(".")
    judge: dict[str, Any] = field(default_factory=dict)


def _resolve(root: Path, value: str | None) -> Path | None:
    if value is None:
        return None
    path = Path(value)
    return path if path.is_absolute() else (root / path).resolve()


def load_analysis_config(path: Path) -> AnalysisConfig:
    document = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    allowed = {
        "analysis_id", "output_dir", "runs_dir", "run_dirs",
        "suite_summaries", "model_groups", "bootstrap_samples", "seed",
        "contrasts", "judge_ratings", "judge",
        "condition_labels", "experiment_aliases", "overall_sizes",
    }
    unknown = set(document) - allowed
    if unknown:
        raise ValueError("unknown analysis settings: %s" % ", ".join(sorted(unknown)))
    if not document.get("analysis_id"):
        raise ValueError("analysis_id is required")
    root = path.parent.resolve()
    bootstrap_samples = int(document.get("bootstrap_samples", 10_000))
    if bootstrap_samples < 100:
        raise ValueError("bootstrap_samples must be at least 100")
    contrasts = tuple(
        Contrast(
            name=str(item["name"]),
            left=str(item["left"]),
            right=str(item["right"]),
            family=str(item.get("family", "confirmatory")),
        )
        for item in document.get("contrasts", [])
    )
    return AnalysisConfig(
        analysis_id=str(document["analysis_id"]),
        output_dir=_resolve(root, document.get("output_dir", "../../runs/analysis")) or root,
        runs_dir=_resolve(root, document.get("runs_dir", "../../runs")) or root,
        run_dirs=tuple(
            _resolve(root, value) for value in document.get("run_dirs", [])
        ),
        suite_summaries=tuple(
            _resolve(root, value) for value in document.get("suite_summaries", [])
        ),
        model_groups=_resolve(root, document.get("model_groups")),
        bootstrap_samples=bootstrap_samples,
        seed=int(document.get("seed", 20260725)),
        contrasts=contrasts,
        condition_labels={
            str(key): str(value)
            for key, value in document.get("condition_labels", {}).items()
        },
        experiment_aliases={
            str(key): str(value)
            for key, value in document.get("experiment_aliases", {}).items()
        },
        overall_sizes=(
            tuple(sorted({int(value) for value in document["overall_sizes"]}))
            if document.get("overall_sizes") is not None else None
        ),
        judge_ratings=_resolve(root, document.get("judge_ratings")),
        config_path=path.resolve(),
        judge=dict(document.get("judge", {})),
    )
