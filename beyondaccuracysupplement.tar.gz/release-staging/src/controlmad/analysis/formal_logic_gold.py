"""Evaluate saved formal-logic translations against expert reference claims."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence


def load_gold_cases(path: Path) -> list[dict[str, Any]]:
    cases = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    ids = [str(case["id"]) for case in cases]
    if len(ids) != len(set(ids)):
        raise ValueError("translation gold cases must have unique ids")
    return cases


def load_formalizations(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _find_step(
    records: Sequence[Mapping[str, Any]], case: Mapping[str, Any]
) -> tuple[Mapping[str, Any], Mapping[str, Any]] | None:
    prefix = str(case["formalization_id_prefix"])
    index = int(case["step_index"])
    matches = [
        record
        for record in records
        if str(record.get("formalization_id", "")).startswith(prefix)
    ]
    if len(matches) != 1:
        return None
    steps = list(matches[0].get("steps", []))
    if not 1 <= index <= len(steps):
        return None
    return matches[0], steps[index - 1]


def evaluate_gold_cases(
    records: Sequence[Mapping[str, Any]],
    cases: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    rows = []
    error_counts: Counter[str] = Counter()
    for case in cases:
        found = _find_step(records, case)
        expected = case.get("expected_conclusion")
        if found is None:
            actual = None
            actual_status = "missing"
            passed = False
            error = "missing_step"
        else:
            record, step = found
            actual = step.get("conclusion")
            actual_status = str(step.get("translation_status"))
            source_matches = step.get("source_span") == case.get("source_span")
            passed = source_matches and _canonical(actual) == _canonical(expected)
            error = "" if passed else str(case.get("error_category", "conclusion_mismatch"))
        if error:
            error_counts[error] += 1
        rows.append({
            "id": case["id"],
            "passed": passed,
            "source_span": case.get("source_span"),
            "expected_conclusion": expected,
            "actual_conclusion": actual,
            "actual_translation_status": actual_status,
            "error_category": error,
            "rationale": case.get("rationale", ""),
        })
    passed_count = sum(bool(row["passed"]) for row in rows)
    return {
        "case_count": len(rows),
        "passed_count": passed_count,
        "failed_count": len(rows) - passed_count,
        "conclusion_fidelity": passed_count / len(rows) if rows else None,
        "error_counts": dict(sorted(error_counts.items())),
        "rows": rows,
    }


def evaluate_gold_files(
    formalizations_path: Path, gold_path: Path
) -> dict[str, Any]:
    return evaluate_gold_cases(
        load_formalizations(formalizations_path),
        load_gold_cases(gold_path),
    )
