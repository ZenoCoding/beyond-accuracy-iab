"""Evaluation boundaries used by the direct harness."""

from __future__ import annotations

import json
import re
from typing import Any, Dict

from controlmad_replication.benchmarks.kks.scoring import score_prediction

from .benchmark import BenchmarkTask


class Evaluator:
    def evaluate(self, task: BenchmarkTask, response: str) -> Dict[str, Any]:
        raise NotImplementedError


class ExactMatchEvaluator(Evaluator):
    def evaluate(self, task: BenchmarkTask, response: str) -> Dict[str, Any]:
        if task.answer is None:
            return {"status": "unknown", "expected": None}
        correct = response.strip().casefold() == str(task.answer).strip().casefold()
        return {"status": "correct" if correct else "incorrect", "expected": task.answer}


class KksEvaluator(Evaluator):
    def __init__(
        self,
        *,
        strict_json: bool = False,
        require_explanation: bool = False,
        max_explanation_words: int | None = None,
    ) -> None:
        self.strict_json = strict_json
        self.require_explanation = require_explanation
        self.max_explanation_words = max_explanation_words

    def evaluate(self, task: BenchmarkTask, response: str) -> Dict[str, Any]:
        protocol_errors: list[str] = []
        prediction: Any = None
        try:
            parsed = json.loads(response)
        except (json.JSONDecodeError, TypeError) as exc:
            protocol_errors.append("response is not valid bare JSON: %s" % exc)
            parsed = None if self.strict_json else self._recover_embedded_json(response)
            if parsed is None and not self.strict_json:
                protocol_errors.append("no recoverable answer JSON object found")

        if isinstance(parsed, dict) and "roles" in parsed:
            prediction = parsed["roles"]
            if self.require_explanation:
                explanation = parsed.get("explanation")
                if not isinstance(explanation, str):
                    protocol_errors.append(
                        "response must contain a string explanation"
                    )
                elif not explanation.strip():
                    protocol_errors.append(
                        "response explanation must not be empty"
                    )
                elif (
                    self.max_explanation_words is not None
                    and len(explanation.split()) > self.max_explanation_words
                ):
                    protocol_errors.append(
                        "response explanation must contain at most %d words"
                        % self.max_explanation_words
                    )
        elif parsed is not None:
            protocol_errors.append("response must be an object containing roles")

        score = score_prediction(
            task.metadata["players"],
            task.answer,
            prediction,
            protocol_errors=protocol_errors,
        )
        return {
            "status": "correct" if score["semantic_strict"] == 1.0 else "incorrect",
            "prediction": prediction,
            **score,
        }

    @staticmethod
    def _recover_embedded_json(response: str) -> Any:
        """Recover the final JSON object containing a role assignment.

        Some providers prepend reasoning even when asked for JSON.  That is a
        protocol violation, but discarding an otherwise machine-readable final
        answer also corrupts semantic accuracy.  Decode every object boundary
        and use the final object with a ``roles`` member.  Nested braces and
        braces inside JSON strings are handled by ``JSONDecoder.raw_decode``.
        """
        if not isinstance(response, str):
            return None
        recovered: list[dict[str, Any]] = []
        decoder = json.JSONDecoder()
        for match in re.finditer(r"{", response):
            try:
                parsed, _ = decoder.raw_decode(response[match.start():])
            except json.JSONDecodeError:
                continue
            if isinstance(parsed, dict) and "roles" in parsed:
                recovered.append(parsed)
        return recovered[-1] if recovered else None


class ProofInitialProposalEvaluator(Evaluator):
    """Evaluate the opt-in plain-text FINAL plus proof-v2 contract."""

    def evaluate(self, task: BenchmarkTask, response: str) -> Dict[str, Any]:
        from .proof_proposal import (
            parse_final_assignment,
            parse_initial_proof_proposal,
        )

        players = list(task.metadata.get("players", []))
        protocol_errors: list[str] = []
        prediction: Any = None
        proposal: Any = None
        lines = [line for line in response.splitlines() if line.strip()]
        if lines:
            try:
                prediction = parse_final_assignment(lines[0], players)
            except ValueError as exc:
                protocol_errors.append(str(exc))
        else:
            protocol_errors.append("response is empty")
        try:
            proposal = parse_initial_proof_proposal(response, players)
            prediction = proposal["roles"]
        except ValueError as exc:
            message = str(exc)
            if message not in protocol_errors:
                protocol_errors.append(message)

        score = score_prediction(
            players,
            task.answer,
            prediction,
            protocol_errors=protocol_errors,
        )
        return {
            "status": "correct" if score["semantic_strict"] == 1.0 else "incorrect",
            "prediction": prediction,
            "proposal": proposal,
            **score,
        }


def evaluator_for_kind(
    kind: str,
    *,
    strict_json: bool = False,
    require_explanation: bool = False,
    max_explanation_words: int | None = None,
) -> Evaluator:
    if kind == "kks":
        return KksEvaluator(
            strict_json=strict_json,
            require_explanation=require_explanation,
            max_explanation_words=max_explanation_words,
        )
    return ExactMatchEvaluator()
