"""Shared execution limits for long-running experiment suites."""

import asyncio
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Optional, Tuple

from .config import ModelConfig, SafetyConfig


class SafetyStop(RuntimeError):
    """Raised when an explicitly configured safety limit stops new calls."""


@dataclass
class ProviderHealth:
    attempts: int = 0
    failures: int = 0
    consecutive_failures: int = 0


def provider_name(model: ModelConfig) -> str:
    if model.provider:
        return model.provider.lower()
    return model.model.split("/", 1)[0].lower() if "/" in model.model else "default"


def _usage_tokens(usage: Dict[str, Any]) -> tuple[int, int, int]:
    input_tokens = int(usage.get("prompt_tokens", usage.get("input_tokens", 0)) or 0)
    output_tokens = int(usage.get("completion_tokens", usage.get("output_tokens", 0)) or 0)
    total_tokens = int(usage.get("total_tokens", input_tokens + output_tokens) or 0)
    return input_tokens, output_tokens, total_tokens


class ExecutionControl:
    """Own suite-wide semaphores, budgets, and provider circuit breakers."""

    def __init__(
        self,
        *,
        concurrency: Optional[int],
        provider_concurrency: Dict[str, int],
        safety: SafetyConfig,
    ) -> None:
        self.puzzle_semaphore = (
            asyncio.Semaphore(concurrency) if concurrency is not None else None
        )
        self.provider_semaphores = {
            name.lower(): asyncio.Semaphore(limit)
            for name, limit in provider_concurrency.items()
        }
        self.safety = safety
        self._lock = asyncio.Lock()
        self.model_calls = 0
        self.total_tokens = 0
        self.cost_usd = 0.0
        self.provider_health: Dict[str, ProviderHealth] = {}
        self.stop_reason: Optional[str] = None
        self._seeded_sources: set[str] = set()

    @asynccontextmanager
    async def puzzle_slot(self):
        if self.puzzle_semaphore is None:
            yield
        else:
            async with self.puzzle_semaphore:
                yield

    def provider_semaphore(self, provider: str) -> Optional[asyncio.Semaphore]:
        return self.provider_semaphores.get(provider.lower())

    async def before_call(self, model: ModelConfig) -> None:
        provider = provider_name(model)
        async with self._lock:
            if self.stop_reason:
                raise SafetyStop(self.stop_reason)
            health = self.provider_health.setdefault(provider, ProviderHealth())
            if (
                self.safety.provider_consecutive_failures
                and health.consecutive_failures
                >= self.safety.provider_consecutive_failures
            ):
                self.stop_reason = (
                    "provider circuit open for %s after %d consecutive failures"
                    % (provider, health.consecutive_failures)
                )
                raise SafetyStop(self.stop_reason)
            if (
                self.safety.provider_max_failure_rate is not None
                and health.attempts >= self.safety.provider_failure_rate_min_calls
                and health.failures / health.attempts
                > self.safety.provider_max_failure_rate
            ):
                self.stop_reason = (
                    "provider circuit open for %s: failure rate %.1f%% over %d calls"
                    % (provider, health.failures / health.attempts * 100, health.attempts)
                )
                raise SafetyStop(self.stop_reason)
            if (
                self.safety.max_model_calls is not None
                and self.model_calls >= self.safety.max_model_calls
            ):
                self.stop_reason = "model-call budget reached (%d)" % self.model_calls
                raise SafetyStop(self.stop_reason)
            if (
                self.safety.max_total_tokens is not None
                and self.total_tokens >= self.safety.max_total_tokens
            ):
                self.stop_reason = "token budget reached (%d)" % self.total_tokens
                raise SafetyStop(self.stop_reason)
            if (
                self.safety.max_cost_usd is not None
                and self.cost_usd >= self.safety.max_cost_usd
            ):
                self.stop_reason = "cost budget reached ($%.2f)" % self.cost_usd
                raise SafetyStop(self.stop_reason)
            self.model_calls += 1
            health.attempts += 1

    async def call_succeeded(self, model: ModelConfig, usage: Dict[str, Any]) -> None:
        provider = provider_name(model)
        input_tokens, output_tokens, total_tokens = _usage_tokens(usage)
        cost = usage.get("cost")
        if not isinstance(cost, (int, float)) or (
            float(cost) <= 0 and (input_tokens or output_tokens)
        ):
            price = self.safety.model_token_prices.get(model.model)
            cost = (
                (
                    input_tokens * price.input_per_million
                    + output_tokens * price.output_per_million
                )
                / 1_000_000
                if price is not None
                else 0.0
            )
        async with self._lock:
            health = self.provider_health.setdefault(provider, ProviderHealth())
            health.consecutive_failures = 0
            self.total_tokens += total_tokens
            self.cost_usd += float(cost or 0.0)

    async def seed_existing(
        self,
        source: str,
        records: Iterable[Tuple[ModelConfig, Dict[str, Any]]],
    ) -> None:
        """Include persisted attempts once so resumed runs retain their budgets."""
        async with self._lock:
            if source in self._seeded_sources:
                return
            self._seeded_sources.add(source)
            for model, record in records:
                provider = provider_name(model)
                health = self.provider_health.setdefault(provider, ProviderHealth())
                self.model_calls += 1
                health.attempts += 1
                if record.get("status") != "completed":
                    health.failures += 1
                    continue
                input_tokens, output_tokens, total_tokens = _usage_tokens(
                    record.get("usage", {})
                )
                cost = record.get("usage", {}).get("cost")
                if not isinstance(cost, (int, float)) or (
                    float(cost) <= 0 and (input_tokens or output_tokens)
                ):
                    price = self.safety.model_token_prices.get(model.model)
                    cost = (
                        (
                            input_tokens * price.input_per_million
                            + output_tokens * price.output_per_million
                        )
                        / 1_000_000
                        if price is not None
                        else 0.0
                    )
                self.total_tokens += total_tokens
                self.cost_usd += float(cost or 0.0)

    async def call_failed(self, model: ModelConfig) -> None:
        provider = provider_name(model)
        async with self._lock:
            health = self.provider_health.setdefault(provider, ProviderHealth())
            health.failures += 1
            health.consecutive_failures += 1

    def snapshot(self) -> Dict[str, Any]:
        return {
            "model_calls": self.model_calls,
            "total_tokens": self.total_tokens,
            "cost_usd": self.cost_usd,
            "stop_reason": self.stop_reason,
            "providers": {
                name: {
                    "attempts": health.attempts,
                    "failures": health.failures,
                    "consecutive_failures": health.consecutive_failures,
                    "failure_rate": (
                        health.failures / health.attempts if health.attempts else 0.0
                    ),
                }
                for name, health in sorted(self.provider_health.items())
            },
        }
