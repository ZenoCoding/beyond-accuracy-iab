"""Portable provider-side JSON contracts for debate model calls."""

from copy import deepcopy
from typing import Any, Dict, List, Optional, Tuple

from .config import ModelConfig


OUTPUT_CONTRACT_VERSION = "debate-json-v1"
DIRECT_OUTPUT_CONTRACT_VERSION = "direct-json-v1"
DIRECT_INITIAL_PROPOSAL_OUTPUT_CONTRACT_VERSION = "direct-initial-proposal-json-v2"
_ROLES = ["knight", "knave", "spy"]
_SOLUTION_PURPOSES = {
    "initial_proposal",
    "self_adjustment",
    "second_proposal",
    "final_decision",
    "consensus_tie_break",
    "tie_break",
}


def debate_output_schema(
    purpose: str,
    players: List[str],
    *,
    player: Optional[str] = None,
    other_agents: Optional[List[str]] = None,
) -> Tuple[str, Dict[str, Any]]:
    """Build the portable JSON Schema for one debate call."""
    if purpose in _SOLUTION_PURPOSES:
        return "controlmad_complete_assignment", {
            "type": "object",
            "properties": {
                "roles": {
                    "type": "object",
                    "properties": {
                        name: {"type": "string", "enum": _ROLES}
                        for name in players
                    },
                    "required": list(players),
                    "additionalProperties": False,
                },
                "explanation": {"type": "string"},
            },
            "required": ["roles", "explanation"],
            "additionalProperties": False,
        }
    if purpose == "debate_turn":
        if player is None or other_agents is None:
            raise ValueError("debate_turn output schema requires player and other_agents")
        peer_items: Dict[str, Any] = {"type": "string"}
        if other_agents:
            peer_items["enum"] = list(other_agents)
        return "controlmad_debate_turn", {
            "type": "object",
            "properties": {
                "player": {"type": "string", "enum": [player]},
                "role": {"type": "string", "enum": _ROLES},
                "agree_with": {"type": "array", "items": peer_items},
                "disagree_with": {"type": "array", "items": peer_items},
                "agree_reasoning": {"type": "string"},
                "disagree_reasoning": {"type": "string"},
            },
            "required": [
                "player",
                "role",
                "agree_with",
                "disagree_with",
                "agree_reasoning",
                "disagree_reasoning",
            ],
            "additionalProperties": False,
        }
    if purpose == "verification":
        return "controlmad_verification", {
            "type": "object",
            "properties": {
                "verdict": {
                    "type": "string",
                    "enum": ["valid", "errors_found"],
                },
                "checks": {
                    "type": "array",
                    "minItems": 1,
                    "items": {
                        "type": "object",
                        "properties": {
                            "test": {"type": "string"},
                            "result": {"type": "string", "enum": ["pass", "fail"]},
                            "error": {"type": "string"},
                        },
                        "required": ["test", "result", "error"],
                        "additionalProperties": False,
                    },
                },
                "errors": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["verdict", "checks", "errors"],
            "additionalProperties": False,
        }
    raise ValueError("unknown debate output purpose: %s" % purpose)


def model_with_debate_output_contract(
    model: ModelConfig,
    purpose: str,
    players: List[str],
    *,
    player: Optional[str] = None,
    other_agents: Optional[List[str]] = None,
) -> Tuple[ModelConfig, Dict[str, Any]]:
    """Return a deep-copied model config with a call-specific response format."""
    mode = model.structured_output_mode
    prepared = model.model_copy(deep=True) if hasattr(model, "model_copy") else model.copy(deep=True)
    response_format: Optional[Dict[str, Any]] = None
    schema_name: Optional[str] = None
    if mode == "json_object":
        response_format = {"type": "json_object"}
    elif mode == "json_schema":
        schema_name, schema = debate_output_schema(
            purpose,
            players,
            player=player,
            other_agents=other_agents,
        )
        response_format = {
            "type": "json_schema",
            "json_schema": {
                "name": schema_name,
                "strict": True,
                "schema": schema,
            },
        }
    if response_format is not None:
        prepared.params = deepcopy(prepared.params)
        prepared.params["response_format"] = response_format
    return prepared, {
        "version": OUTPUT_CONTRACT_VERSION,
        "mode": mode,
        "schema_name": schema_name,
        "response_format": response_format,
    }


def model_with_direct_output_contract(
    model: ModelConfig,
    players: List[str],
    *,
    include_explanation: bool = False,
) -> Tuple[ModelConfig, Dict[str, Any]]:
    """Return a model config with the task-specific direct-answer contract."""
    mode = model.structured_output_mode
    prepared = (
        model.model_copy(deep=True)
        if hasattr(model, "model_copy")
        else model.copy(deep=True)
    )
    response_format: Optional[Dict[str, Any]] = None
    schema_name: Optional[str] = None
    if mode == "json_object":
        response_format = {"type": "json_object"}
    elif mode == "json_schema":
        schema_name = (
            "controlmad_initial_proposal"
            if include_explanation
            else "controlmad_direct_assignment"
        )
        properties: Dict[str, Any] = {
            "roles": {
                "type": "object",
                "properties": {
                    name: {"type": "string", "enum": _ROLES}
                    for name in players
                },
                "required": list(players),
                "additionalProperties": False,
            },
        }
        required = ["roles"]
        if include_explanation:
            properties["explanation"] = {"type": "string"}
            required.append("explanation")
        schema = {
            "type": "object",
            "properties": properties,
            "required": required,
            "additionalProperties": False,
        }
        response_format = {
            "type": "json_schema",
            "json_schema": {
                "name": schema_name,
                "strict": True,
                "schema": schema,
            },
        }
    if response_format is not None:
        prepared.params = deepcopy(prepared.params)
        prepared.params["response_format"] = response_format
    return prepared, {
        "version": (
            DIRECT_INITIAL_PROPOSAL_OUTPUT_CONTRACT_VERSION
            if include_explanation
            else DIRECT_OUTPUT_CONTRACT_VERSION
        ),
        "mode": mode,
        "schema_name": schema_name,
        "response_format": response_format,
    }
