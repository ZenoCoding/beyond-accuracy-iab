"""Post-run validation for matched solo suites."""

from __future__ import annotations

from typing import Any


FORBIDDEN_TOKEN_CAP_KEYS = {
    "max_tokens",
    "max_completion_tokens",
    "max_output_tokens",
    "budget_tokens",
    "reasoning_budget",
    "reasoning_budget_tokens",
    "max_reasoning_tokens",
    "thinking_budget",
}


def find_forbidden_token_caps(value: Any, prefix: str = "params") -> list[str]:
    """Return nested per-call completion/reasoning cap paths."""
    found: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            path = f"{prefix}.{key}"
            if key in FORBIDDEN_TOKEN_CAP_KEYS:
                found.append(path)
            found.extend(find_forbidden_token_caps(item, path))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            found.extend(find_forbidden_token_caps(item, f"{prefix}[{index}]"))
    return found


def validate_matched_solo_summary(
    summary: dict[str, Any],
    *,
    expected_experiments: int,
    expected_runs: int,
    max_first_pass_invalid_rate: float,
) -> list[str]:
    errors: list[str] = []
    experiments = summary.get("experiments", {})
    if summary.get("status") != "completed":
        errors.append("suite status is not completed")
    if len(experiments) != expected_experiments:
        errors.append(
            f"expected {expected_experiments} experiments, found {len(experiments)}"
        )
    if summary.get("planned_runs") != expected_runs:
        errors.append(
            f"expected {expected_runs} planned runs, found {summary.get('planned_runs')}"
        )
    if summary.get("completed_runs") != expected_runs:
        errors.append(
            f"expected {expected_runs} completed runs, found "
            f"{summary.get('completed_runs')}"
        )

    first_pass_responses = 0
    first_pass_invalid = 0
    for experiment_id, item in experiments.items():
        experiment = item.get("summary", {})
        planned = item.get("planned_runs")
        completed = experiment.get("completed_count")
        if completed != planned:
            errors.append(
                f"{experiment_id}: completed {completed} of {planned} planned runs"
            )
        if experiment.get("failed_count", 0):
            errors.append(
                f"{experiment_id}: {experiment.get('failed_count')} failed runs"
            )

        health = experiment.get("health", {})
        if health.get("empty_response_count", 0):
            errors.append(f"{experiment_id}: empty model response")
        if health.get("nonstop_finish_count", 0):
            errors.append(f"{experiment_id}: non-stop finish reason")

        protocol = experiment.get("format_protocol") or {}
        terminal_invalid = protocol.get("terminal_invalid_count", 0)
        if terminal_invalid:
            errors.append(
                f"{experiment_id}: {terminal_invalid} terminal-invalid responses"
            )
        first_pass_responses += protocol.get("response_count", 0)
        first_pass_invalid += protocol.get("first_pass_invalid_count", 0)

    invalid_rate = (
        first_pass_invalid / first_pass_responses if first_pass_responses else 0.0
    )
    if invalid_rate > max_first_pass_invalid_rate:
        errors.append(
            "first-pass invalid rate %.2f%% exceeds %.2f%%"
            % (invalid_rate * 100, max_first_pass_invalid_rate * 100)
        )
    return errors


def validate_staged_solo_summary(
    summary: dict[str, Any],
    *,
    expected_experiments: int,
    expected_runs: int,
    max_first_pass_invalid_rate: float,
    max_format_repairs: int,
    max_provider_failures: int,
    max_cost_usd: float,
    min_strict_planned_accuracy: float | None = None,
    max_strict_planned_accuracy_exclusive: float | None = None,
) -> list[str]:
    """Apply fail-closed operational gates before advancing a staged run."""
    errors = validate_matched_solo_summary(
        summary,
        expected_experiments=expected_experiments,
        expected_runs=expected_runs,
        max_first_pass_invalid_rate=max_first_pass_invalid_rate,
    )

    repairs = 0
    for experiment_id, item in summary.get("experiments", {}).items():
        experiment = item.get("summary", {})
        planned = item.get("planned_runs")
        health = experiment.get("health")
        if not isinstance(health, dict):
            errors.append(f"{experiment_id}: health metrics are missing")
        else:
            for field in ("empty_response_count", "nonstop_finish_count"):
                if not isinstance(health.get(field), int):
                    errors.append(
                        f"{experiment_id}: health.{field} is missing"
                    )

        protocol = experiment.get("format_protocol")
        if not isinstance(protocol, dict):
            errors.append(f"{experiment_id}: format protocol metrics are missing")
            continue
        for field in (
            "response_count",
            "first_pass_invalid_count",
            "repair_attempt_count",
            "terminal_invalid_count",
        ):
            if not isinstance(protocol.get(field), int):
                errors.append(
                    f"{experiment_id}: format_protocol.{field} is missing"
                )
        if protocol.get("response_count") != planned:
            errors.append(
                f"{experiment_id}: format protocol covers "
                f"{protocol.get('response_count')} of {planned} planned responses"
            )
        repairs += int(protocol.get("repair_attempt_count", 0))
    if repairs > max_format_repairs:
        errors.append(
            f"format repair count {repairs} exceeds allowed {max_format_repairs}"
        )

    safety = summary.get("safety")
    if not isinstance(safety, dict):
        errors.append("suite safety metrics are missing")
        safety = {}
    providers = safety.get("providers")
    if not isinstance(providers, dict) or not providers:
        errors.append("provider safety metrics are missing")
        providers = {}
    provider_failures = 0
    for provider_name, provider in providers.items():
        failures = provider.get("failures") if isinstance(provider, dict) else None
        if not isinstance(failures, int):
            errors.append(
                f"provider {provider_name} failure metric is missing"
            )
            continue
        provider_failures += failures
    if provider_failures > max_provider_failures:
        errors.append(
            f"provider failure count {provider_failures} exceeds allowed "
            f"{max_provider_failures}"
        )

    cost_value = safety.get("cost_usd")
    if not isinstance(cost_value, (int, float)):
        errors.append("suite estimated cost metric is missing")
    elif float(cost_value) > max_cost_usd:
        errors.append(
            f"estimated cost ${float(cost_value):.6f} exceeds allowed "
            f"${max_cost_usd:.6f}"
        )
    if safety.get("stop_reason"):
        errors.append(f"safety circuit stopped the suite: {safety['stop_reason']}")

    if (
        min_strict_planned_accuracy is not None
        or max_strict_planned_accuracy_exclusive is not None
    ):
        for experiment_id, item in summary.get("experiments", {}).items():
            accuracy = (
                item.get("summary", {})
                .get("overall_planned", {})
                .get("semantic_strict_accuracy")
            )
            if not isinstance(accuracy, (int, float)):
                errors.append(
                    f"{experiment_id}: semantic strict planned accuracy is missing"
                )
                continue
            if (
                min_strict_planned_accuracy is not None
                and accuracy < min_strict_planned_accuracy
            ):
                errors.append(
                    f"{experiment_id}: semantic strict planned accuracy "
                    f"{accuracy:.6f} "
                    f"is below {min_strict_planned_accuracy:.6f}"
                )
            if (
                max_strict_planned_accuracy_exclusive is not None
                and accuracy >= max_strict_planned_accuracy_exclusive
            ):
                errors.append(
                    f"{experiment_id}: semantic strict planned accuracy "
                    f"{accuracy:.6f} "
                    f"must be below {max_strict_planned_accuracy_exclusive:.6f}"
                )
    return errors
