"""Parallel, resumable orchestration for solo-model experiment suites."""

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple

from .config import ResolvedSuiteConfig, load_config
from .preflight import preflight_suite
from .runner import ExperimentRunner, _shutdown_litellm
from .safety import ExecutionControl


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def suite_report_path(suite: ResolvedSuiteConfig) -> Path:
    output = Path(suite.output_dir)
    if not output.is_absolute():
        output = Path(suite.config_root) / output
    return output / suite.suite_id / "summary.json"


def _write_report(path: Path, report: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(path)


async def _run_experiment(
    config_path: str,
    progress_callback: Optional[Callable[[str, str, Dict[str, int]], None]] = None,
    execution_control: Optional[ExecutionControl] = None,
) -> Tuple[str, ExperimentRunner, Dict[str, int]]:
    config = load_config(config_path)
    runner = ExperimentRunner(config, execution_control=execution_control)
    if progress_callback is None:
        counts = await runner.run_async(shutdown_litellm=False)
    else:
        counts = await runner.run_async(
            shutdown_litellm=False,
            progress_callback=lambda value: progress_callback(
                config_path,
                config.experiment_id,
                value,
            ),
        )
    return config_path, runner, counts


def run_suite(
    suite: ResolvedSuiteConfig,
    *,
    require_credentials: bool = True,
    progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
) -> Dict[str, Any]:
    """Run experiments in parallel; rerunning safely continues incomplete work."""
    launch = preflight_suite(suite, require_credentials=require_credentials)
    if not launch["ok"]:
        raise ValueError("Suite preflight failed: %s" % "; ".join(launch["errors"]))

    report: Dict[str, Any] = {
        "schema_version": 1,
        "suite_id": suite.suite_id,
        "started_at": _now(),
        "updated_at": _now(),
        "status": "running",
        "parallelism": suite.parallelism,
        "global_concurrency": suite.global_concurrency,
        "provider_concurrency": suite.provider_concurrency,
        "planned_model_calls": launch["planned_model_calls"],
        "maximum_model_calls": launch.get("maximum_model_calls", launch["planned_model_calls"]),
        "planned_runs": sum(
            item.get("planned_runs", item["planned_model_calls"])
            for item in launch["experiments"]
        ),
        "experiments": {},
    }
    path = suite_report_path(suite)
    _write_report(path, report)

    planned_runs_by_experiment = {
        item["experiment_id"]: item.get("planned_runs", item["planned_model_calls"])
        for item in launch["experiments"]
    }
    planned_calls_by_experiment = {
        item["experiment_id"]: item["planned_model_calls"]
        for item in launch["experiments"]
    }
    progress_job_counts = {
        item["experiment_id"]: 0
        for item in launch["experiments"]
    }
    progress_call_counts = dict(progress_job_counts)

    def report_progress(
        config_path: str,
        experiment_id: str,
        counts: Dict[str, int],
    ) -> None:
        if progress_callback is None:
            return
        progress_job_counts[experiment_id] = counts.get("completed", 0)
        progress_call_counts[experiment_id] = counts.get("completed_model_calls", 0)
        progress_callback({
            "completed_jobs": sum(progress_job_counts.values()),
            "planned_jobs": report["planned_runs"],
            "completed_calls": sum(progress_call_counts.values()),
            "planned_calls": report["planned_model_calls"],
            "experiment_id": experiment_id,
            "command": ["controlmad", "run", "--config", config_path],
        })

    async def run_experiments() -> None:
        semaphore = asyncio.Semaphore(suite.parallelism)
        execution_control = ExecutionControl(
            concurrency=suite.global_concurrency,
            provider_concurrency=dict(suite.provider_concurrency),
            safety=suite.safety,
        )

        async def run_one(
            config_path: str,
        ) -> Tuple[str, ExperimentRunner, Dict[str, int]]:
            async with semaphore:
                return await _run_experiment(
                    config_path,
                    report_progress if progress_callback is not None else None,
                    execution_control,
                )

        tasks = [
            asyncio.create_task(run_one(config_path))
            for config_path in suite.experiments
        ]
        try:
            for future in asyncio.as_completed(tasks):
                config_path, runner, counts = await future
                experiment_id = runner.config.experiment_id
                experiment_summary = json.loads(
                    (runner.storage.run_dir / "summary.json").read_text(encoding="utf-8")
                )
                report["experiments"][experiment_id] = {
                    "config": config_path,
                    "planned_model_calls": planned_calls_by_experiment[experiment_id],
                    "planned_runs": planned_runs_by_experiment[experiment_id],
                    "counts": counts,
                    "summary": experiment_summary,
                }
                report["updated_at"] = _now()
                report["safety"] = execution_control.snapshot()
                _write_report(path, report)
        finally:
            for task in tasks:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            await _shutdown_litellm()
        report["safety"] = execution_control.snapshot()

    asyncio.run(run_experiments())

    incomplete = any(
        item["counts"].get("completed", 0) != item["planned_runs"]
        for item in report["experiments"].values()
    )
    report["completed_runs"] = sum(
        item["summary"]["completed_count"]
        for item in report["experiments"].values()
    )
    report["attempted_model_calls"] = sum(
        item["summary"].get("model_call_count", item["summary"]["completed_count"])
        for item in report["experiments"].values()
    )
    report["completed_model_calls"] = sum(
        item["summary"].get("completed_model_call_count", item["summary"]["completed_count"])
        for item in report["experiments"].values()
    )
    report["failed_model_calls"] = sum(
        item["summary"].get("failed_model_call_count", 0)
        for item in report["experiments"].values()
    )
    report["completion_rate"] = (
        report["completed_runs"] / report["planned_runs"]
        if report["planned_runs"]
        else 0.0
    )
    usage: Dict[str, float] = {}
    for item in report["experiments"].values():
        for key, value in item["summary"].get("usage", {}).items():
            if isinstance(value, (int, float)):
                usage[key] = usage.get(key, 0.0) + value
    report["usage"] = usage
    report["status"] = "incomplete" if incomplete else "completed"
    report["completed_at"] = _now()
    report["updated_at"] = report["completed_at"]
    _write_report(path, report)
    return report
