"""Benchmark input interfaces for generic JSONL and Knight-Knave-Spy."""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List

from controlmad_replication.benchmarks.kks.dataset import (
    dataset_sizes,
    read_jsonl,
    sample_by_difficulty,
)

from .config import BenchmarkConfig


@dataclass
class BenchmarkTask:
    id: str
    prompt: str
    answer: Any = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class Benchmark:
    def load(self) -> List[BenchmarkTask]:
        raise NotImplementedError


class JsonlBenchmark(Benchmark):
    def __init__(self, config: BenchmarkConfig, root: str) -> None:
        path = Path(config.path)
        self.path = path if path.is_absolute() else Path(root) / path
        self.config = config

    def load(self) -> List[BenchmarkTask]:
        tasks: List[BenchmarkTask] = []
        requested = set(self.config.task_ids)
        with self.path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                item = json.loads(line)
                task_id = str(item.get("id", "task-%04d" % line_number))
                if requested and task_id not in requested:
                    continue
                prompt = item.get("prompt", item.get("question", item.get("problem")))
                if prompt is None:
                    raise ValueError("Benchmark task %s has no prompt/question/problem" % task_id)
                tasks.append(BenchmarkTask(
                    id=task_id,
                    prompt=str(prompt),
                    answer=item.get("answer"),
                    metadata=dict(item.get("metadata", {})),
                ))
                if self.config.limit and len(tasks) >= self.config.limit:
                    break
        return tasks


def render_kks_prompt(question: Dict[str, Any]) -> str:
    players = question["players"]
    statements = "\n".join(
        "- %s: %s" % (statement["speaker"], statement["text"])
        for statement in question["statements"]
    )
    example = ", ".join('"%s":"knight"' % player for player in players)
    return (
        "Solve this Knight-Knave-Spy logic puzzle.\n\n"
        "Rules:\n"
        "- Every player is exactly one of: knight, knave, or spy.\n"
        "- Knights always make true statements.\n"
        "- Knaves always make false statements.\n"
        "- There is exactly one spy. The spy's statement may be true or false.\n\n"
        "Players: %s\n\n"
        "Statements:\n%s\n\n"
        "Identify every player's role. Return only valid JSON in exactly this shape:\n"
        '{"roles":{%s}}\n'
    ) % (", ".join(players), statements, example)


class KksBenchmark(Benchmark):
    def __init__(self, config: BenchmarkConfig, root: str) -> None:
        path = Path(config.path)
        self.path = path if path.is_absolute() else Path(root) / path
        self.config = config

    def load(self) -> List[BenchmarkTask]:
        requested = set(self.config.task_ids)
        tasks: List[BenchmarkTask] = []
        found_ids: set[str] = set()
        for size in dataset_sizes(self.path):
            questions = read_jsonl(self.path / "questions" / ("%d.jsonl" % size))
            if requested:
                questions = [question for question in questions if question["id"] in requested]
            elif self.config.samples_per_size is not None:
                questions = sample_by_difficulty(questions, self.config.samples_per_size)
            labels = {
                record["id"]: record["roles"]
                for record in read_jsonl(self.path / "labels" / ("%d.jsonl" % size))
            }
            for question in questions:
                task_id = question["id"]
                if task_id not in labels:
                    raise ValueError("KKS task %s has no label" % task_id)
                found_ids.add(task_id)
                tasks.append(BenchmarkTask(
                    id=task_id,
                    prompt=render_kks_prompt(question),
                    answer=labels[task_id],
                    metadata={
                        "benchmark": "kks-v1",
                        "size": size,
                        "players": list(question["players"]),
                        "difficulty_score": question["metadata"]["difficulty_score"],
                    },
                ))
                if self.config.limit and len(tasks) >= self.config.limit:
                    return tasks
        missing = requested - found_ids
        if missing:
            raise ValueError("Unknown KKS task ids: %s" % ", ".join(sorted(missing)))
        return tasks


def benchmark_from_config(config: BenchmarkConfig, root: str) -> Benchmark:
    if config.kind == "kks":
        return KksBenchmark(config, root)
    return JsonlBenchmark(config, root)
