"""Filesystem-backed event and artifact storage.

Run directories are bound to an immutable experiment identity.  This prevents
an innocent-looking resume from combining outputs produced with different
models, prompts, task selections, labels, or harness code.
"""

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Sequence

import yaml

from .config import ResolvedConfig, config_dict
from .events import Event, event_dict


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


IDENTITY_SCHEMA_VERSION = 1


def _repository_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        default=str,
    ).encode("utf-8")


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _resolved_config_identity(config: ResolvedConfig) -> Dict[str, Any]:
    """Return a portable config representation suitable for identity checks."""
    value = config_dict(config)
    # This is a machine-local resolution aid, not part of the experiment.
    value.pop("config_root", None)
    # Concurrency, timeout, and retry controls may legitimately be tuned when
    # resuming. They affect execution, but not the model/task/prompt identity.
    value.pop("run", None)
    return value


def _prompt_hashes(config: ResolvedConfig) -> Dict[str, str]:
    result: Dict[str, str] = {}
    root = Path(config.config_root)
    for name, value in config_dict(config.prompts).items():
        if value is None:
            continue
        path = Path(value)
        if not path.is_absolute():
            path = root / path
        result[name] = _sha256_file(path)
    return result


def _dataset_provenance(config: ResolvedConfig) -> Dict[str, Any]:
    path = Path(config.benchmark.path)
    if not path.is_absolute():
        path = Path(config.config_root) / path
    result: Dict[str, Any] = {"configured_path": config.benchmark.path}
    if path.is_file():
        result.update({"artifact": path.name, "sha256": _sha256_file(path)})
    elif path.is_dir() and (path / "manifest.json").is_file():
        result.update({"artifact": "manifest.json", "sha256": _sha256_file(path / "manifest.json")})
    return result


def _source_provenance() -> Dict[str, Any]:
    """Hash relevant source content and record Git metadata when available.

    The source-content digest, rather than the commit SHA, participates in the
    immutable fingerprint.  As a result, committing run artifacts does not
    make an interrupted run unresumable when the harness source is unchanged.
    """
    repository_root = _repository_root()
    source_root = repository_root / "src"
    files = sorted(
        list((source_root / "controlmad").rglob("*.py"))
        + list((source_root / "controlmad_replication").rglob("*.py"))
    )
    for filename in ("pyproject.toml", "uv.lock"):
        path = repository_root / filename
        if path.is_file():
            files.append(path)
    digest = hashlib.sha256()
    for path in sorted(files):
        relative = path.relative_to(repository_root).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")

    result: Dict[str, Any] = {"source_sha256": digest.hexdigest()}
    try:
        result["git_commit"] = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repository_root,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
        result["git_dirty"] = bool(subprocess.run(
            ["git", "status", "--porcelain", "--untracked-files=no", "--", "src", "pyproject.toml", "uv.lock"],
            cwd=repository_root,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip())
    except (OSError, subprocess.CalledProcessError):
        result.update({"git_commit": None, "git_dirty": None})
    return result


def experiment_identity(config: ResolvedConfig, tasks: Optional[Sequence[Any]] = None) -> Dict[str, Any]:
    task_records = []
    for task in tasks or []:
        task_records.append({
            "id": task.id,
            "prompt": task.prompt,
            "answer": task.answer,
            "metadata": task.metadata,
        })
    task_ids = [record["id"] for record in task_records]
    source = _source_provenance()
    fingerprint_input = {
        "schema_version": IDENTITY_SCHEMA_VERSION,
        "config": _resolved_config_identity(config),
        "prompt_hashes": _prompt_hashes(config),
        "dataset": _dataset_provenance(config),
        "task_count": len(task_records),
        "task_ids_sha256": _sha256_bytes(_json_bytes(task_ids)),
        "tasks_sha256": _sha256_bytes(_json_bytes(task_records)),
        "source_sha256": source["source_sha256"],
    }
    return {
        **fingerprint_input,
        "fingerprint": _sha256_bytes(_json_bytes(fingerprint_input)),
        "source": source,
    }


class ExperimentStorage:
    def __init__(self, run_dir: str) -> None:
        self.run_dir = Path(run_dir)
        self.tasks_dir = self.run_dir / "tasks"
        self.model_call_completed_callback = None

    def initialize(self, config: ResolvedConfig, tasks: Optional[Sequence[Any]] = None) -> None:
        self.tasks_dir.mkdir(parents=True, exist_ok=True)
        identity = experiment_identity(config, tasks)
        config_path = self.run_dir / "resolved_config.yaml"
        if config_path.exists():
            previous = self.load_resolved_config()
            previous.pop("config_root", None)
            previous.pop("run", None)
            if previous != _resolved_config_identity(config):
                raise ValueError(
                    "Run directory is bound to a different resolved configuration: %s. "
                    "Use a new experiment_id/output directory." % self.run_dir
                )
        else:
            self.write_resolved_config(config)

        if self.manifest_path.exists():
            manifest = self.load_manifest()
            previous_fingerprint = manifest.get("experiment_fingerprint")
            if previous_fingerprint and previous_fingerprint != identity["fingerprint"]:
                raise ValueError(
                    "Run directory experiment fingerprint mismatch: %s. "
                    "The model, prompts, selected tasks, dataset, or harness source changed; "
                    "use a new experiment_id/output directory." % self.run_dir
                )
            if not previous_fingerprint and manifest.get("runs"):
                raise ValueError(
                    "Legacy run directory %s contains results without an experiment fingerprint; "
                    "it remains readable, but cannot be safely resumed. Use a new experiment_id/output directory."
                    % self.run_dir
                )
            manifest["experiment_fingerprint"] = identity["fingerprint"]
            manifest["identity_schema_version"] = IDENTITY_SCHEMA_VERSION
            manifest["provenance"] = identity
            self.save_manifest(manifest)
        else:
            self.save_manifest({
                "experiment_id": config.experiment_id,
                "created_at": _now(),
                "updated_at": _now(),
                "experiment_fingerprint": identity["fingerprint"],
                "identity_schema_version": IDENTITY_SCHEMA_VERSION,
                "provenance": identity,
                "runs": {},
            })

    @property
    def manifest_path(self) -> Path:
        return self.run_dir / "manifest.json"

    def write_resolved_config(self, config: ResolvedConfig) -> None:
        self.run_dir.mkdir(parents=True, exist_ok=True)
        value = config_dict(config)
        config_root = Path(value["config_root"])
        try:
            value["config_root"] = config_root.relative_to(_repository_root()).as_posix()
        except ValueError:
            # External/temp configs cannot be made repository-relative.
            pass
        with (self.run_dir / "resolved_config.yaml").open("w", encoding="utf-8") as handle:
            yaml.safe_dump(value, handle, sort_keys=False)

    def load_resolved_config(self) -> Dict[str, Any]:
        with (self.run_dir / "resolved_config.yaml").open("r", encoding="utf-8") as handle:
            value = yaml.safe_load(handle) or {}
        config_root = Path(value.get("config_root", "."))
        if not config_root.is_absolute():
            value["config_root"] = str((_repository_root() / config_root).resolve())
        return value

    def load_manifest(self) -> Dict[str, Any]:
        if not self.manifest_path.exists():
            return {"runs": {}}
        with self.manifest_path.open("r", encoding="utf-8") as handle:
            return json.load(handle)

    def save_manifest(self, manifest: Dict[str, Any]) -> None:
        self.run_dir.mkdir(parents=True, exist_ok=True)
        manifest["updated_at"] = _now()
        temporary = self.manifest_path.with_suffix(".tmp")
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(manifest, handle, indent=2, sort_keys=True)
        temporary.replace(self.manifest_path)

    def upsert_run(self, run_id: str, **values: Any) -> Dict[str, Any]:
        manifest = self.load_manifest()
        record = manifest.setdefault("runs", {}).setdefault(run_id, {})
        record.update(values)
        self.save_manifest(manifest)
        return record

    def append_event(self, event: Event, task: bool = False) -> None:
        path = self.run_dir / "events.jsonl"
        if task and event.run_id:
            task_dir = self.tasks_dir / event.run_id
            task_dir.mkdir(parents=True, exist_ok=True)
            path = task_dir / "events.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event_dict(event), sort_keys=True) + "\n")

    def append_jsonl(self, run_id: str, filename: str, value: Dict[str, Any]) -> None:
        path = self.tasks_dir / run_id / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(value, sort_keys=True) + "\n")
        if (
            filename == "model_calls.jsonl"
            and value.get("status") == "completed"
            and self.model_call_completed_callback is not None
        ):
            self.model_call_completed_callback()

    def write_json(self, run_id: str, filename: str, value: Dict[str, Any]) -> None:
        path = self.tasks_dir / run_id / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)

    def read_run_json(self, relative_path: str) -> Dict[str, Any]:
        with (self.run_dir / relative_path).open("r", encoding="utf-8") as handle:
            return json.load(handle)

    def write_run_json(self, filename: str, value: Dict[str, Any]) -> None:
        self.run_dir.mkdir(parents=True, exist_ok=True)
        with (self.run_dir / filename).open("w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)

    def write_run_jsonl(self, filename: str, values: Iterable[Dict[str, Any]]) -> None:
        self.run_dir.mkdir(parents=True, exist_ok=True)
        with (self.run_dir / filename).open("w", encoding="utf-8") as handle:
            for value in values:
                handle.write(json.dumps(value, sort_keys=True) + "\n")

    def write_transcript(self, run_id: str, text: str) -> None:
        path = self.tasks_dir / run_id / "transcript.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")

    def status_counts(self) -> Dict[str, int]:
        counts: Dict[str, int] = {}
        for record in self.load_manifest().get("runs", {}).values():
            status = record.get("status", "pending")
            counts[status] = counts.get(status, 0) + 1
        return counts

    def model_call_counts(self) -> Dict[str, int]:
        counts: Dict[str, int] = {}
        for run_id in self.load_manifest().get("runs", {}):
            path = self.tasks_dir / run_id / "model_calls.jsonl"
            if not path.exists():
                continue
            with path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    if not line.strip():
                        continue
                    status = json.loads(line).get("status", "unknown")
                    counts[status] = counts.get(status, 0) + 1
        return counts
