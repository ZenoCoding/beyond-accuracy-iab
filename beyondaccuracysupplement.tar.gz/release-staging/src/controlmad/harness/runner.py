"""Experiment orchestration, concurrency, retry, and resume."""

import asyncio
import hashlib
import json
import re
import sys
import time
from contextlib import AsyncExitStack
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Dict, Iterable, List, Optional, Tuple, TypeVar

from .benchmark import BenchmarkTask, benchmark_from_config
from .config import ModelConfig, ResolvedConfig
from .direct import DirectExecutor
from .debate import DebateExecutor
from .events import make_event
from .evaluator import Evaluator, ProofInitialProposalEvaluator, evaluator_for_kind
from .models import ModelClient
from .safety import ExecutionControl, provider_name
from .storage import ExperimentStorage


@dataclass
class WorkItem:
    run_id: str
    task: BenchmarkTask
    repetition: int
    attempt: int = 1
    parent_run_id: Optional[str] = None


T = TypeVar("T")


def _safe_id(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value)


def base_run_id(task_id: str, repetition: int) -> str:
    return "%s__rep_%04d" % (_safe_id(task_id), repetition)


def attempt_run_id(base_id: str, attempt: int) -> str:
    return base_id if attempt == 1 else "%s__attempt_%03d" % (base_id, attempt)


def _mean(values: List[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _retry_delay(base_seconds: float, run_id: str, attempt: int) -> float:
    """Exponential backoff with stable per-attempt jitter to avoid retry waves."""
    if not base_seconds:
        return 0.0
    token = hashlib.sha256((run_id + ":" + str(attempt)).encode("utf-8")).digest()
    jitter = 0.75 + int.from_bytes(token[:2], "big") / 65535 * 0.5
    return base_seconds * (2 ** max(0, attempt - 1)) * jitter


def _retry_after_seconds(exc: Exception) -> Optional[float]:
    for source in (exc, getattr(exc, "response", None)):
        headers = getattr(source, "headers", None)
        if headers is None:
            continue
        value = headers.get("retry-after") or headers.get("Retry-After")
        try:
            return max(0.0, float(value))
        except (TypeError, ValueError):
            continue
    return None


def _is_retryable_model_error(exc: Exception) -> bool:
    status_code = getattr(exc, "status_code", None)
    if status_code is None and getattr(exc, "response", None) is not None:
        status_code = getattr(exc.response, "status_code", None)
    if status_code in {408, 409, 429, 500, 502, 503, 504}:
        return True
    name_and_message = "%s %s" % (type(exc).__name__, exc)
    retryable_terms = (
        "timeout", "timed out", "rate limit", "ratelimit", "connection",
        "temporarily unavailable", "service unavailable", "overloaded",
        "internal server error",
    )
    return any(term in name_and_message.lower() for term in retryable_terms)


async def _shutdown_litellm() -> None:
    """Drain LiteLLM background resources before asyncio.run closes the loop."""
    litellm = sys.modules.get("litellm")
    if litellm is None:
        return

    try:
        from litellm.litellm_core_utils.logging_worker import GLOBAL_LOGGING_WORKER
    except Exception:
        GLOBAL_LOGGING_WORKER = None

    if GLOBAL_LOGGING_WORKER is not None:
        try:
            await asyncio.wait_for(GLOBAL_LOGGING_WORKER.flush(), timeout=5.0)
        except Exception:
            pass
        try:
            await GLOBAL_LOGGING_WORKER.stop()
        except Exception:
            pass

    close_clients = getattr(litellm, "close_litellm_async_clients", None)
    if close_clients is not None:
        try:
            await close_clients()
        except Exception:
            pass


class ExperimentRunner:
    def __init__(
        self,
        config: ResolvedConfig,
        model_client: ModelClient = None,
        evaluator: Evaluator = None,
        run_dir: Optional[str] = None,
        execution_control: Optional[ExecutionControl] = None,
    ) -> None:
        self.config = config
        self.storage = ExperimentStorage(run_dir or self._run_dir())
        self.model_client = model_client
        self.evaluator = evaluator
        self.execution_control = execution_control

    def _run_dir(self) -> str:
        from pathlib import Path
        return str(Path(self.config.config_root) / self.config.run.output_dir / self.config.experiment_id)

    def _tasks(self) -> List[BenchmarkTask]:
        return benchmark_from_config(self.config.benchmark, self.config.config_root).load()

    def _configured_models(self) -> Dict[str, ModelConfig]:
        models: List[ModelConfig] = []
        if self.config.model is not None:
            models.append(self.config.model)
        if self.config.debate is not None:
            models.extend(agent.model for agent in self.config.debate.agents)
            models.append(self.config.debate.supervisor_model)
        return {model.model: model for model in models}

    def _stored_model_calls(self) -> List[Tuple[ModelConfig, Dict[str, Any]]]:
        models = self._configured_models()
        records: List[Tuple[ModelConfig, Dict[str, Any]]] = []
        for path in self.storage.tasks_dir.glob("*/model_calls.jsonl"):
            with path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    if not line.strip():
                        continue
                    record = json.loads(line)
                    configured = record.get("configured_model") or record.get("model")
                    model = models.get(configured)
                    if model is not None:
                        records.append((model, record))
        return records

    def _new_work(self, tasks: Iterable[BenchmarkTask], include_completed: bool = False) -> List[WorkItem]:
        manifest = self.storage.load_manifest().get("runs", {})
        latest = {
            run_id.split("__attempt_", 1)[0]: (run_id, record)
            for run_id, record in self._latest_records(manifest)
        }
        work: List[WorkItem] = []
        for task in tasks:
            for repetition in range(1, self.config.benchmark.repetitions + 1):
                base_id = base_run_id(task.id, repetition)
                latest_entry = latest.get(base_id)
                existing = latest_entry[1] if latest_entry else None
                if existing and existing.get("status") == "completed" and self.config.run.skip_completed and not include_completed:
                    continue
                if existing:
                    work.append(WorkItem(
                        base_id,
                        task,
                        repetition,
                        attempt=int(existing.get("attempt", 1)) + 1,
                        parent_run_id=latest_entry[0],
                    ))
                else:
                    work.append(WorkItem(base_id, task, repetition))
        return work

    async def _execute_item(self, item: WorkItem) -> None:
        executor = (
            DebateExecutor(
                self.config,
                self.storage,
                self.model_client,
                self.evaluator,
                run_model_call=self._run_model_call,
            )
            if self.config.treatment == "debate"
            else DirectExecutor(
                self.config,
                self.storage,
                self.model_client,
                self.evaluator,
                run_model_call=self._run_model_call,
            )
        )
        async with self._semaphore:
            async with self._execution_control.puzzle_slot():
                await self._execute_with_retries(executor, item)

    async def _wait_for_rate_slot(self) -> None:
        requests_per_minute = self.config.run.requests_per_minute
        if requests_per_minute is None:
            return
        interval = 60.0 / requests_per_minute
        async with self._rate_lock:
            now = time.monotonic()
            if self._next_request_at > now:
                await asyncio.sleep(self._next_request_at - now)
                now = time.monotonic()
            self._next_request_at = now + interval

    async def _run_model_call(
        self,
        model: ModelConfig,
        retry_key: str,
        call: Callable[[], Awaitable[T]],
        on_retry: Callable[[int, Exception, float], None],
    ) -> T:
        attempt = 1
        while True:
            caught_exc: Optional[Exception] = None
            await self._wait_for_rate_slot()
            provider = provider_name(model)
            semaphores = [
                semaphore
                for semaphore in (
                    self._execution_control.provider_semaphore(provider),
                    self._provider_semaphores.get(provider),
                )
                if semaphore is not None
            ]
            async with AsyncExitStack() as stack:
                for semaphore in semaphores:
                    await stack.enter_async_context(semaphore)
                await self._execution_control.before_call(model)
                try:
                    result = await call()
                except Exception as exc:
                    caught_exc = exc
                    await self._execution_control.call_failed(model)
                else:
                    await self._execution_control.call_succeeded(
                        model,
                        getattr(result, "usage", {}) or {},
                    )
                    return result
            if caught_exc is not None:
                if (
                    attempt > self.config.run.model_call_max_retries
                    or not _is_retryable_model_error(caught_exc)
                ):
                    raise caught_exc
                delay = _retry_after_seconds(caught_exc)
                if delay is None:
                    delay = _retry_delay(
                        self.config.run.model_call_retry_backoff_seconds,
                        retry_key,
                        attempt,
                    )
                on_retry(attempt, caught_exc, delay)
                if delay:
                    await asyncio.sleep(delay)
                attempt += 1

    def _notify_progress(self) -> None:
        if self._progress_callback is None:
            return
        counts = self.storage.status_counts()
        counts["completed_model_calls"] = self._completed_model_calls
        self._progress_callback(counts)

    def _model_call_completed(self) -> None:
        self._completed_model_calls += 1
        self._notify_progress()

    async def _execute_with_retries(self, executor: Any, item: WorkItem) -> None:
        attempt = item.attempt
        while True:
            run_id = attempt_run_id(item.run_id, attempt)
            if item.parent_run_id:
                self.storage.upsert_run(
                    item.parent_run_id,
                    status="retried",
                    failure_status="failed",
                    retried_at=time.time(),
                    next_attempt=attempt,
                )
                item.parent_run_id = None
            self.storage.upsert_run(
                run_id,
                status="pending",
                task_id=item.task.id,
                repetition=item.repetition,
                attempt=attempt,
            )
            try:
                await executor.run(run_id, item.task, item.repetition, attempt)
                return
            except Exception as exc:
                self.storage.upsert_run(run_id, status="failed", error=str(exc), failed_at=time.time())
                executor._emit("run_failed", run_id, task_id=item.task.id, error=str(exc))
                if attempt > self.config.run.max_retries:
                    return
                next_attempt = attempt + 1
                executor._emit("retry_scheduled", run_id, next_attempt=next_attempt, error=str(exc))
                delay = _retry_delay(self.config.run.retry_backoff_seconds, run_id, attempt)
                if delay:
                    await asyncio.sleep(delay)
                item.parent_run_id = run_id
                attempt = next_attempt

    def _metrics(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        evaluations = [result["evaluation"] for result in results]
        semantic_strict = _mean([
            float(item.get("semantic_strict", item.get("strict", 0.0)))
            for item in evaluations
        ])
        semantic_smooth = _mean([
            float(item.get("semantic_smooth", item.get("smooth", 0.0)))
            for item in evaluations
        ])
        return {
            "count": len(results),
            "strict_accuracy": semantic_strict,
            "smooth_accuracy": semantic_smooth,
            "semantic_strict_accuracy": semantic_strict,
            "semantic_smooth_accuracy": semantic_smooth,
            "contract_strict_accuracy": _mean([
                float(item.get("contract_strict", item.get("strict", 0.0)))
                for item in evaluations
            ]),
            "protocol_valid_rate": _mean([float(bool(item.get("protocol_valid", False))) for item in evaluations]),
        }

    def _metric_views(
        self,
        results: List[Dict[str, Any]],
        planned_count: int,
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        completed = self._metrics(results)
        planned = dict(completed)
        planned["count"] = planned_count
        planned["completed_count"] = len(results)
        planned["completion_rate"] = len(results) / planned_count if planned_count else 0.0
        for key in (
            "strict_accuracy",
            "smooth_accuracy",
            "semantic_strict_accuracy",
            "semantic_smooth_accuracy",
            "contract_strict_accuracy",
            "protocol_valid_rate",
        ):
            planned[key] = completed[key] * len(results) / planned_count if planned_count else 0.0
        return completed, planned

    def _write_run_artifacts(self, tasks: List[BenchmarkTask]) -> None:
        manifest = self.storage.load_manifest().get("runs", {})
        results: List[Dict[str, Any]] = []
        failed: List[str] = []
        for run_id, record in self._latest_records(manifest):
            if record.get("status") == "completed" and record.get("result_path"):
                results.append(self.storage.read_run_json(record["result_path"]))
            elif record.get("status") == "failed":
                failed.append(run_id)
        results.sort(key=lambda item: (item["task_id"], item.get("repetition", 1)))

        predictions = [
            {"id": result["task_id"], "roles": result.get("prediction")}
            for result in results
        ]
        self.storage.write_run_jsonl("predictions.jsonl", predictions)
        proof_records = []
        for result in results:
            proposal = result.get("proof_proposal")
            if not isinstance(proposal, dict):
                continue
            proof_records.append({
                "formalization_id": "%s-rep-%04d" % (
                    result["task_id"], result.get("repetition", 1)
                ),
                "model": result.get("configured_model"),
                "source": {
                    "task_id": result["task_id"],
                    "agent_id": result.get("configured_model", "direct-model"),
                    "stage": "initial_proposal",
                },
                "submitted_roles": proposal.get("roles", {}),
                "source_text": proposal.get("source_text", ""),
                "claims": proposal.get("nodes", []),
                "proof_checks": proposal.get("checks", []),
                "parse_errors": [],
            })
        if proof_records:
            self.storage.write_run_jsonl("proof-proposals.jsonl", proof_records)
        prediction_counts: Dict[str, int] = {}
        revision_count = 0
        unchanged_revision_count = 0
        for result in results:
            prediction_key = json.dumps(
                result.get("prediction"), sort_keys=True, separators=(",", ":")
            )
            prediction_counts[prediction_key] = prediction_counts.get(prediction_key, 0) + 1
            for round_item in result.get("rounds", []):
                before = round_item.get("solutions_before", {})
                for agent_id, adjusted in round_item.get("adjustments", {}).items():
                    revision_count += 1
                    if adjusted.get("roles") == before.get(agent_id, {}).get("roles"):
                        unchanged_revision_count += 1

        by_size: Dict[str, Any] = {}
        planned_by_size: Dict[int, int] = {}
        for task in tasks:
            size = task.metadata.get("size")
            if size is not None:
                planned_by_size[int(size)] = (
                    planned_by_size.get(int(size), 0) + self.config.benchmark.repetitions
                )
        sizes = sorted(planned_by_size)
        for size in sizes:
            size_results = [
                result for result in results if result.get("metadata", {}).get("size") == size
            ]
            size_completed, size_planned = self._metric_views(
                size_results,
                planned_by_size[size],
            )
            by_size[str(size)] = {
                **size_planned,
                "planned_count": planned_by_size[size],
                "overall": size_planned,
                "overall_completed": size_completed,
                "overall_planned": size_planned,
            }

        usage: Dict[str, float] = {}
        model_call_count = 0
        completed_model_call_count = 0
        failed_model_call_count = 0
        finish_reasons: Dict[str, int] = {}
        empty_response_count = 0
        short_response_count = 0
        response_counts: Dict[str, int] = {}
        for run_id in manifest:
            calls_path = self.storage.tasks_dir / run_id / "model_calls.jsonl"
            if not calls_path.exists():
                continue
            with calls_path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    if not line.strip():
                        continue
                    call = json.loads(line)
                    model_call_count += 1
                    if call.get("status") == "completed":
                        completed_model_call_count += 1
                        finish_reason = str(call.get("finish_reason") or "unknown")
                        finish_reasons[finish_reason] = finish_reasons.get(finish_reason, 0) + 1
                        response = str(call.get("response") or "")
                        if not response.strip():
                            empty_response_count += 1
                        if len(response.strip()) < 20:
                            short_response_count += 1
                        normalized = " ".join(response.split())
                        if normalized:
                            response_counts[normalized] = response_counts.get(normalized, 0) + 1
                        for key, value in call.get("usage", {}).items():
                            if key in {"prompt_tokens", "completion_tokens", "input_tokens", "output_tokens", "total_tokens", "cost"} and isinstance(value, (int, float)):
                                usage[key] = usage.get(key, 0) + value
                    else:
                        failed_model_call_count += 1

        planned_count = len(tasks) * self.config.benchmark.repetitions
        completed_metrics, planned_metrics = self._metric_views(results, planned_count)
        interaction_valid_turns = 0
        interaction_invalid_turns = 0
        format_first_pass_valid = 0
        format_first_pass_invalid = 0
        format_repaired = 0
        format_terminal_invalid = 0
        format_repair_attempts = 0
        for events_path in self.storage.tasks_dir.glob("*/events.jsonl"):
            with events_path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    if not line.strip():
                        continue
                    event = json.loads(line)
                    event_type = event.get("type")
                    payload = event.get("payload", {})
                    if event_type == "debate_argument_submitted":
                        interaction_valid_turns += 1
                    elif event_type == "debate_argument_rejected":
                        interaction_invalid_turns += 1
                    elif event_type == "format_response_accepted":
                        if payload.get("repaired"):
                            format_repaired += 1
                        else:
                            format_first_pass_valid += 1
                    elif event_type == "format_response_rejected":
                        if payload.get("format_repair_attempt", 0) == 0:
                            format_first_pass_invalid += 1
                        if payload.get("terminal"):
                            format_terminal_invalid += 1
                        else:
                            format_repair_attempts += 1
        interaction_turns = interaction_valid_turns + interaction_invalid_turns
        format_response_count = format_first_pass_valid + format_first_pass_invalid

        if self.config.model is not None:
            model_name = self.config.model.model
            model_params: Any = self.config.model.params
            debate_models = None
        else:
            model_name = "multi-agent-debate"
            model_params = None
            debate_models = {
                agent.id: agent.model.model
                for agent in self.config.debate.agents
            } if self.config.debate else None

        normal_finish_reasons = {"stop", "completed", "tool_calls"}
        summary = {
            "schema_version": 2,
            "experiment_id": self.config.experiment_id,
            "treatment": self.config.treatment,
            "model": model_name,
            "model_params": model_params,
            "debate_models": debate_models,
            "selected_count": planned_count,
            "completed_count": len(results),
            "completion_rate": len(results) / planned_count if planned_count else 0.0,
            "failed_count": len(failed),
            "failed_run_ids": sorted(failed),
            "overall": planned_metrics,
            "headline_denominator": "planned",
            "overall_completed": completed_metrics,
            "overall_planned": planned_metrics,
            "by_size": by_size,
            "usage": usage,
            "model_call_count": model_call_count,
            "completed_model_call_count": completed_model_call_count,
            "failed_model_call_count": failed_model_call_count,
            "safety": self._execution_control.snapshot(),
            "health": {
                "finish_reasons": finish_reasons,
                "nonstop_finish_count": sum(
                    count
                    for reason, count in finish_reasons.items()
                    if reason not in normal_finish_reasons
                ),
                "empty_response_count": empty_response_count,
                "short_response_count": short_response_count,
                "largest_identical_response_count": max(
                    response_counts.values(), default=0
                ),
                "dominant_prediction_count": max(
                    prediction_counts.values(), default=0
                ),
                "dominant_prediction_rate": (
                    max(prediction_counts.values(), default=0) / len(results)
                    if results else 0.0
                ),
                "revision_count": revision_count,
                "unchanged_revision_count": unchanged_revision_count,
                "unchanged_revision_rate": (
                    unchanged_revision_count / revision_count
                    if revision_count else 0.0
                ),
                "warnings": [
                    warning
                    for warning, active in (
                        (
                            "one or more model responses were empty",
                            empty_response_count > 0,
                        ),
                        (
                            "one or more model calls ended without a normal stop reason",
                            any(
                                reason not in normal_finish_reasons
                                for reason in finish_reasons
                            ),
                        ),
                        (
                            "an identical response appeared in at least 10 model calls",
                            max(response_counts.values(), default=0) >= 10,
                        ),
                        (
                            "one prediction accounts for at least 95% of completed puzzles",
                            len(results) >= 20
                            and max(prediction_counts.values(), default=0) / len(results)
                            >= 0.95,
                        ),
                        (
                            "at least 95% of debate revisions left the role assignment unchanged",
                            revision_count >= 20
                            and unchanged_revision_count / revision_count >= 0.95,
                        ),
                    )
                    if active
                ],
            },
            "interaction_protocol": {
                "scope": "all_attempts",
                "turn_count": interaction_turns,
                "valid_turn_count": interaction_valid_turns,
                "invalid_turn_count": interaction_invalid_turns,
                "valid_rate": (
                    interaction_valid_turns / interaction_turns
                    if interaction_turns else 1.0
                ),
            } if self.config.treatment == "debate" else None,
            "format_protocol": {
                "scope": "all_attempts",
                "response_count": format_response_count,
                "first_pass_valid_count": format_first_pass_valid,
                "first_pass_invalid_count": format_first_pass_invalid,
                "repaired_count": format_repaired,
                "terminal_invalid_count": format_terminal_invalid,
                "repair_attempt_count": format_repair_attempts,
                "first_pass_valid_rate": (
                    format_first_pass_valid / format_response_count
                    if format_response_count else 1.0
                ),
                "post_repair_valid_rate": (
                    (format_first_pass_valid + format_repaired) / format_response_count
                    if format_response_count else 1.0
                ),
            } if (
                self.config.treatment == "debate"
                or self.config.run.direct_format_repair_max_retries > 0
            ) else None,
        }
        self.storage.write_run_json("summary.json", summary)

    async def run_async(
        self,
        include_completed: bool = False,
        work_items: Optional[List[WorkItem]] = None,
        *,
        shutdown_litellm: bool = True,
        progress_callback: Optional[Any] = None,
    ) -> Dict[str, int]:
        tasks = self._tasks()
        self.storage.initialize(self.config, tasks)
        self.storage.append_event(
            make_event("experiment_started", self.config.experiment_id, task_count=len(tasks)),
            task=False,
        )
        work = work_items if work_items is not None else self._new_work(tasks, include_completed=include_completed)
        self._semaphore = asyncio.Semaphore(self.config.run.concurrency)
        self._execution_control = self.execution_control or ExecutionControl(
            concurrency=None,
            provider_concurrency={},
            safety=self.config.run.safety,
        )
        await self._execution_control.seed_existing(
            str(self.storage.run_dir.resolve()),
            self._stored_model_calls(),
        )
        self._provider_semaphores = {
            provider.lower(): asyncio.Semaphore(limit)
            for provider, limit in self.config.run.provider_concurrency.items()
        }
        self._rate_lock = asyncio.Lock()
        self._next_request_at = 0.0
        self._progress_callback = progress_callback
        self._completed_model_calls = self.storage.model_call_counts().get("completed", 0)
        self.storage.model_call_completed_callback = self._model_call_completed

        async def execute_and_report(item: WorkItem) -> None:
            await self._execute_item(item)
            self._notify_progress()

        try:
            self._notify_progress()
            await asyncio.gather(*(execute_and_report(item) for item in work))
            self._write_run_artifacts(tasks)
            return self.storage.status_counts()
        finally:
            self.storage.model_call_completed_callback = None
            if shutdown_litellm:
                await _shutdown_litellm()

    def run(
        self,
        *,
        shutdown_litellm: bool = True,
        progress_callback: Optional[Any] = None,
    ) -> Dict[str, int]:
        return asyncio.run(self.run_async(
            shutdown_litellm=shutdown_litellm,
            progress_callback=progress_callback,
        ))

    def resume(self, progress_callback: Optional[Any] = None) -> Dict[str, int]:
        manifest = self.storage.load_manifest().get("runs", {})
        tasks = self._tasks()
        latest = {
            run_id.split("__attempt_", 1)[0]: (run_id, record)
            for run_id, record in self._latest_records(manifest)
        }
        work: List[WorkItem] = []
        for task in tasks:
            for repetition in range(1, self.config.benchmark.repetitions + 1):
                base_id = base_run_id(task.id, repetition)
                latest_entry = latest.get(base_id)
                if latest_entry is None:
                    work.append(WorkItem(base_id, task, repetition))
                    continue
                run_id, record = latest_entry
                if record.get("status") == "completed":
                    continue
                work.append(WorkItem(
                    base_id,
                    task,
                    repetition,
                    attempt=int(record.get("attempt", 1)) + 1,
                    parent_run_id=run_id,
                ))
        return asyncio.run(self.run_async(
            work_items=work,
            progress_callback=progress_callback,
        ))

    def retry_failed(self, progress_callback: Optional[Any] = None) -> Dict[str, int]:
        manifest = self.storage.load_manifest().get("runs", {})
        tasks = {task.id: task for task in self._tasks()}
        work: List[WorkItem] = []
        for run_id, record in self._latest_records(manifest):
            if record.get("status") != "failed":
                continue
            task = tasks.get(record.get("task_id"))
            if not task:
                continue
            base_id = run_id.split("__attempt_", 1)[0]
            work.append(WorkItem(
                base_id,
                task,
                int(record.get("repetition", 1)),
                attempt=int(record.get("attempt", 1)) + 1,
                parent_run_id=run_id,
            ))
        return asyncio.run(self.run_async(
            work_items=work,
            progress_callback=progress_callback,
        ))

    def rescore(self) -> Dict[str, int]:
        """Re-evaluate stored raw responses without making provider calls."""
        tasks = {task.id: task for task in self._tasks()}
        manifest = self.storage.load_manifest().get("runs", {})
        rescored = 0
        changed = 0
        evaluator = self.evaluator
        if evaluator is None:
            evaluator = (
                ProofInitialProposalEvaluator()
                if self.config.run.direct_output_contract
                in {
                    "proof_initial_proposal",
                    "simple_proof_initial_proposal",
                    "json_then_proof_initial_proposal",
                }
                else evaluator_for_kind(
                    self.config.benchmark.kind,
                    strict_json="response_format" in self.config.model.params,
                )
            )
        for run_id, record in self._latest_records(manifest):
            if record.get("status") != "completed" or not record.get("result_path"):
                continue
            result = self.storage.read_run_json(record["result_path"])
            task = tasks.get(result.get("task_id"))
            if task is None or "raw_response" not in result:
                continue
            evaluation = evaluator.evaluate(task, result["raw_response"])
            prediction = evaluation.get("prediction")
            if result.get("evaluation") != evaluation or result.get("prediction") != prediction:
                changed += 1
                result["evaluation"] = evaluation
                result["prediction"] = prediction
                self.storage.write_json(run_id, "result.json", result)
            rescored += 1
        self._write_run_artifacts(list(tasks.values()))
        return {"rescored": rescored, "changed": changed}

    @staticmethod
    def _latest_records(manifest: Dict[str, Dict[str, Any]]) -> List[Tuple[str, Dict[str, Any]]]:
        latest: Dict[str, Tuple[str, Dict[str, Any]]] = {}
        for run_id, record in manifest.items():
            base_id = run_id.split("__attempt_", 1)[0]
            attempt = int(record.get("attempt", 1))
            previous = latest.get(base_id)
            if previous is None or attempt >= int(previous[1].get("attempt", 1)):
                latest[base_id] = (run_id, record)
        return list(latest.values())


def config_from_resolved_dict(data: Dict[str, Any]) -> ResolvedConfig:
    if hasattr(ResolvedConfig, "model_validate"):
        return ResolvedConfig.model_validate(data)  # type: ignore[attr-defined]
    return ResolvedConfig.parse_obj(data)
