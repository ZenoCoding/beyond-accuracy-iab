"""Plain-text initial proposal contract backed by proof-v2 traces."""

from __future__ import annotations

import re
from typing import Any, Mapping, Sequence

from controlmad.analysis.formal_logic_compact import expression_contains
from controlmad.analysis.formal_logic_proof import check_proof_trace, parse_proof_trace


_ROLES = {"knight", "knave", "spy"}
_FINAL = re.compile(r"FINAL\s*::\s*(.+)$", re.IGNORECASE)


def _player_aliases(players: Sequence[str]) -> dict[str, str]:
    aliases: dict[str, str] = {}
    for index, player in enumerate(players):
        canonical = str(player)
        letter = chr(ord("A") + index)
        aliases[canonical.casefold()] = canonical
        aliases[letter.casefold()] = canonical
        aliases[("Player " + letter).casefold()] = canonical
    return aliases


def parse_final_assignment(line: str, players: Sequence[str]) -> dict[str, str]:
    """Parse ``FINAL :: A=knight;B=knave`` into canonical player names."""
    match = _FINAL.fullmatch(line.strip())
    if not match:
        raise ValueError("first non-empty line must be FINAL :: A=role;B=role")
    aliases = _player_aliases(players)
    roles: dict[str, str] = {}
    for raw_item in match.group(1).split(";"):
        item = raw_item.strip()
        if not item or "=" not in item:
            raise ValueError("FINAL entries must use player=role separated by semicolons")
        raw_player, raw_role = item.split("=", 1)
        player = aliases.get(raw_player.strip().casefold())
        role = raw_role.strip().casefold()
        if player is None:
            raise ValueError("FINAL contains an unknown player %r" % raw_player.strip())
        if player in roles:
            raise ValueError("FINAL assigns %s more than once" % player)
        if role not in _ROLES:
            raise ValueError("FINAL role for %s must be knight, knave, or spy" % player)
        roles[player] = role
    missing = [player for player in players if player not in roles]
    if missing:
        raise ValueError("FINAL must assign every player: missing %s" % ", ".join(missing))
    return roles


def _expression_player_indexes(expression: Any) -> set[int]:
    if not isinstance(expression, Mapping):
        return set()
    indexes: set[int] = set()
    if "player" in expression:
        indexes.add(int(expression["player"]))
    for value in expression.get("players", []):
        indexes.add(int(value))
    for key in ("arg", "left", "right"):
        indexes.update(_expression_player_indexes(expression.get(key)))
    return indexes


def _proposal_source(nodes: Sequence[Mapping[str, Any]]) -> str:
    return ". ".join(
        str(node.get("source_span", "")).strip().rstrip(".")
        for node in nodes
        if str(node.get("source_span", "")).strip()
    )


def parse_initial_proof_proposal(
    content: str, players: Sequence[str]
) -> dict[str, Any]:
    """Parse and validate a FINAL assignment followed by proof-v2 lines."""
    lines = [line for line in content.splitlines() if line.strip()]
    if len(lines) < 2:
        raise ValueError("proposal requires a FINAL line and at least one proof line")
    roles = parse_final_assignment(lines[0], players)
    trace = "\n".join(lines[1:])
    nodes, parse_errors = parse_proof_trace(trace, trace)
    if parse_errors:
        raise ValueError("; ".join(parse_errors))
    if not nodes:
        raise ValueError("proposal must contain at least one proof node")

    invalid_players = sorted({
        index
        for node in nodes
        for index in _expression_player_indexes(node.get("expression"))
        if index < 0 or index >= len(players)
    })
    if invalid_players:
        names = ", ".join(chr(ord("A") + index) for index in invalid_players)
        raise ValueError("proof references players outside this puzzle: %s" % names)

    checks = check_proof_trace(nodes)
    fatal = [
        item for item in checks
        if item.get("verdict") in {"invalid_contradiction", "invalid_discharge"}
    ]
    if fatal:
        raise ValueError(
            "invalid proof structure: "
            + ", ".join("%s=%s" % (item["id"], item["verdict"]) for item in fatal)
        )

    for index, player in enumerate(players):
        expected = {"op": "role_is", "player": index, "role": roles[player]}
        matching = [
            node for node in nodes
            if node.get("scope") == "root"
            and node.get("stance") == "assert"
            and expression_contains(node.get("expression"), expected)
        ]
        if not matching:
            raise ValueError(
                "FINAL role for %s must appear in a root ASSERT proof node" % player
            )

    if not any(node.get("kind") in {"derive", "discharge"} for node in nodes):
        raise ValueError(
            "proof must show intermediate DERIVE or DISCHARGE steps; "
            "MODEL_CHECK cannot be the only reasoning"
        )

    verdicts = {str(item["id"]): str(item["verdict"]) for item in checks}
    normalized_nodes = []
    for node in nodes:
        normalized = dict(node)
        normalized["verdict"] = verdicts.get(str(node["id"]), "unknown")
        normalized_nodes.append(normalized)
    return {
        "roles": roles,
        "nodes": normalized_nodes,
        "checks": checks,
        "source_text": _proposal_source(normalized_nodes),
    }


def proof_initial_proposal_prompt(task_prompt: str, players: Sequence[str]) -> str:
    """Build the opt-in direct solver prompt for proof-formatted proposals."""
    final_example = ";".join(
        "%s=knight" % chr(ord("A") + index) for index, _ in enumerate(players)
    )
    statement_refs = "\n".join(
        "- @ctx:stmt-%s refers to Player %s's puzzle statement."
        % (chr(ord("A") + index), chr(ord("A") + index))
        for index, _ in enumerate(players)
    )
    puzzle_prompt = task_prompt.split("Identify every player's role.", 1)[0].rstrip()
    return f"""{puzzle_prompt}

Solve independently and return a plain-text proof proposal, not JSON or Markdown.

First output the complete assignment:
FINAL :: {final_example}

Then output one proof event per line:
<id> :: <kind> :: <stance> :: IN(<scope>) :: <expression> :: FROM(<ids>) :: <short reason>

Kinds: CLAIM, ASSUME, DERIVE, CONTRADICTION, DISCHARGE(<assumption-id>),
MODEL_CHECK(SAT|UNSAT|UNIQUE), or OPAQUE.
Stances: ASSERT, HYPOTHETICAL, or ABSTAIN. Every non-OPAQUE node inside an
assumption is HYPOTHETICAL; ASSERT is for root-level conclusions and discharges.
ASSUME opens a scope named by its node id. CONTRADICTION uses BOTTOM and at
least two earlier local dependencies. OPAQUE uses ABSTAIN. Empty support is FROM(-).

Strict line rules:
- Every proof line has exactly seven `` :: ``-separated fields.
- IDs are exactly n1, n2, n3, ... in order; never use e1, r1, mc-1, or bare numbers.
- Root scope is IN(root), never IN(-). An assumed scope is IN(n1), using its ASSUME id.
- MODEL_CHECK is a kind, not an id. ASSERT is a stance, not a kind.
- Dependencies use earlier n IDs or the supplied @ctx references.
- MODEL_CHECK must contain a real compact expression, never ABSTAIN.

Expressions:
ROLE(A,knight), STMT_TRUE(A), SAME_ROLE(A,B), NOT(expr),
AND(expr;expr), OR(expr;expr), XOR(expr;expr), IFF(expr;expr),
COUNT(exactly,1,spy,A,B,C,D), PARITY(even,knave,A,B), BOTTOM, or ABSTAIN.
Use the actual players in this puzzle; count expressions may list all of them.

Puzzle references:
{statement_refs}
- @ctx:rule-role-exclusivity refers to each player having exactly one role.
- @ctx:rule-exactly-one-spy refers to there being exactly one spy.
- @ctx:rule-speaker-truthfulness refers to knight/knave truth behavior.

Use FROM(...) for exact support. Every FINAL role must also appear in a root-level
ASSERT node, either alone or inside AND. Keep the last field short and readable.
Show intermediate reasoning supported by puzzle statements before the final role
claims. Do not use MODEL_CHECK as a shortcut for the whole solution. Do not put
the complete assignment into one deeply nested AND expression; emit one simple
root ASSERT ROLE(...) line per final player instead.
Your proposal is invalid unless it contains at least one DERIVE or DISCHARGE
event. MODEL_CHECK never replaces the intermediate deductions.
Return only the FINAL line and proof lines.

Minimal formatting example:
FINAL :: A=knight;B=spy
n1 :: DERIVE :: ASSERT :: IN(root) :: ROLE(A,knight) :: FROM(@ctx:stmt-A) :: A is a knight
n2 :: DERIVE :: ASSERT :: IN(root) :: ROLE(B,spy) :: FROM(@ctx:rule-exactly-one-spy,n1) :: B is the spy"""


def simple_proof_initial_proposal_prompt(
    task_prompt: str,
    players: Sequence[str],
    candidate: Mapping[str, Any] | None = None,
) -> str:
    """Build the compact root-only proof contract used by paired experiments."""
    final_example = ";".join(
        "%s=knight" % chr(ord("A") + index) for index, _ in enumerate(players)
    )
    statement_refs = ", ".join(
        "@ctx:stmt-%s" % chr(ord("A") + index)
        for index, _ in enumerate(players)
    )
    puzzle_prompt = task_prompt.split("Identify every player's role.", 1)[0].rstrip()
    candidate_block = ""
    if candidate is not None:
        candidate_block = (
            "\n\nA JSON solver proposed the following answer. Verify it against every "
            "puzzle statement. Correct any role that is wrong; do not merely copy it.\n"
            "CANDIDATE JSON\n"
            + str(candidate.get("raw_response", ""))
        )
    return f"""{puzzle_prompt}{candidate_block}

Solve the puzzle and return plain text, not JSON or Markdown. Think through the
constraints internally, then give the complete assignment followed by one short
root-level derivation for every player.

FINAL :: {final_example}
n1 :: DERIVE :: ASSERT :: IN(root) :: ROLE(A,knight) :: FROM(@ctx:stmt-A) :: short reason

Use exactly seven `` :: ``-separated fields on each proof line. Number lines n1,
n2, n3, and so on. Every line must use DERIVE, ASSERT, and IN(root). Its expression
must be one ROLE(letter,knight|knave|spy). Support may cite earlier n-lines or:
{statement_refs}, @ctx:rule-role-exclusivity, @ctx:rule-exactly-one-spy, and
@ctx:rule-speaker-truthfulness. Use FROM(-) only when no support applies.

Assign every actual player exactly once in FINAL, and include a matching proof line
for every FINAL role. Return only the FINAL line and proof lines."""
