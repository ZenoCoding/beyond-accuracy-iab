"""Typed configuration for direct and multi-agent debate experiments."""

from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

import yaml
from pydantic import BaseModel, Field, PositiveInt

try:
    from pydantic import ConfigDict
except ImportError:  # Pydantic 1.x
    ConfigDict = None


class StrictModel(BaseModel):
    if ConfigDict is not None and hasattr(BaseModel, "model_validate"):
        model_config = ConfigDict(extra="forbid")
    else:
        class Config:
            extra = "forbid"


class BenchmarkConfig(StrictModel):
    kind: Literal["jsonl", "kks"] = "jsonl"
    path: str
    limit: Optional[int] = Field(default=None, ge=1)
    task_ids: List[str] = Field(default_factory=list)
    samples_per_size: Optional[int] = Field(default=None, ge=1)
    repetitions: int = Field(default=1, ge=1)


class ModelTokenPrice(StrictModel):
    input_per_million: float = Field(ge=0)
    output_per_million: float = Field(ge=0)


class SafetyConfig(StrictModel):
    max_model_calls: Optional[int] = Field(default=None, ge=1)
    max_total_tokens: Optional[int] = Field(default=None, ge=1)
    max_cost_usd: Optional[float] = Field(default=None, gt=0)
    model_token_prices: Dict[str, ModelTokenPrice] = Field(default_factory=dict)
    provider_consecutive_failures: int = Field(default=0, ge=0)
    provider_failure_rate_min_calls: int = Field(default=100, ge=1)
    provider_max_failure_rate: Optional[float] = Field(default=None, gt=0, le=1)


class RunConfig(StrictModel):
    output_dir: str = "runs"
    concurrency: int = Field(default=1, ge=1)
    provider_concurrency: Dict[str, PositiveInt] = Field(default_factory=dict)
    timeout_seconds: float = Field(default=120.0, gt=0)
    max_retries: int = Field(default=0, ge=0)
    retry_backoff_seconds: float = Field(default=0.0, ge=0)
    model_call_max_retries: int = Field(default=0, ge=0)
    model_call_retry_backoff_seconds: float = Field(default=0.0, ge=0)
    direct_format_repair_max_retries: int = Field(default=0, ge=0, le=1)
    direct_record_terminal_invalid: bool = False
    direct_output_contract: Literal[
        "roles_only",
        "initial_proposal",
        "proof_initial_proposal",
        "simple_proof_initial_proposal",
        "json_then_proof_initial_proposal",
    ] = "roles_only"
    proof_verification_source_dir: Optional[str] = None
    requests_per_minute: Optional[float] = Field(default=None, gt=0)
    skip_completed: bool = True
    safety: SafetyConfig = Field(default_factory=SafetyConfig)


class ModelConfig(StrictModel):
    id: str
    model: str
    provider: Optional[str] = None
    structured_output_mode: Literal["none", "json_object", "json_schema"] = "none"
    format_repair_reasoning: Literal["disable", "minimal", "preserve"] = "disable"
    params: Dict[str, Any] = Field(default_factory=dict)


class PromptConfig(StrictModel):
    system: str
    direct_answer: Optional[str] = None
    initial_proposal: Optional[str] = None
    debate_turn: Optional[str] = None
    self_adjustment: Optional[str] = None
    final_decision: Optional[str] = None
    supervisor: Optional[str] = None
    verification: Optional[str] = None
    second_proposal: Optional[str] = None


class DebateAgentFileConfig(StrictModel):
    id: str
    model: str
    role: str = "debater"
    reference_accuracy: Optional[float] = Field(default=None, ge=0, le=1)
    accuracy_source: Optional[str] = None


DebateCapability = Literal["propose", "debate", "revise", "final_vote"]
DebateWorkflow = Literal["standard", "verifier_a", "verifier_b"]


class DebateRoleConfig(StrictModel):
    id: str
    description: str = ""
    capabilities: List[DebateCapability]


class DebateFileConfig(StrictModel):
    agents: List[DebateAgentFileConfig]
    roles: str
    supervisor_model: str
    passes: int = Field(default=1, ge=1)
    accuracy_visible: bool = False
    agent_order: Literal["fixed", "cyclic_task_hash"] = "fixed"
    workflow: DebateWorkflow = "standard"
    verifier_agent_id: Optional[str] = None
    format_repair_max_retries: int = Field(default=1, ge=0, le=1)
    require_structured_output: bool = False


class DebateAgentConfig(StrictModel):
    id: str
    model: ModelConfig
    role: str
    reference_accuracy: Optional[float] = Field(default=None, ge=0, le=1)
    accuracy_source: Optional[str] = None


class DebateConfig(StrictModel):
    agents: List[DebateAgentConfig]
    roles: List[DebateRoleConfig]
    supervisor_model: ModelConfig
    passes: int = Field(default=1, ge=1)
    accuracy_visible: bool = False
    agent_order: Literal["fixed", "cyclic_task_hash"] = "fixed"
    workflow: DebateWorkflow = "standard"
    verifier_agent_id: Optional[str] = None
    format_repair_max_retries: int = Field(default=1, ge=0, le=1)
    require_structured_output: bool = False


class ExperimentFileConfig(StrictModel):
    experiment_id: str
    treatment: Literal["direct", "debate"] = "direct"
    seed: Optional[int] = None
    benchmark: BenchmarkConfig
    run: RunConfig = Field(default_factory=RunConfig)
    model: Optional[str] = None
    debate: Optional[str] = None
    debate_model_params: Dict[str, Any] = Field(default_factory=dict)
    debate_model_params_by_model: Dict[str, Dict[str, Any]] = Field(
        default_factory=dict
    )
    prompts: str


class ResolvedConfig(StrictModel):
    experiment_id: str
    treatment: Literal["direct", "debate"] = "direct"
    seed: Optional[int] = None
    benchmark: BenchmarkConfig
    run: RunConfig
    model: Optional[ModelConfig] = None
    debate: Optional[DebateConfig] = None
    prompts: PromptConfig
    config_root: str


class SuiteFileConfig(StrictModel):
    suite_id: str
    experiments: List[str]
    output_dir: str = "../runs/suites"
    parallelism: int = Field(default=1, ge=1)
    global_concurrency: Optional[int] = Field(default=None, ge=1)
    provider_concurrency: Dict[str, PositiveInt] = Field(default_factory=dict)
    safety: SafetyConfig = Field(default_factory=SafetyConfig)


class ResolvedSuiteConfig(StrictModel):
    suite_id: str
    experiments: List[str]
    output_dir: str
    parallelism: int
    global_concurrency: Optional[int] = None
    provider_concurrency: Dict[str, PositiveInt] = Field(default_factory=dict)
    safety: SafetyConfig = Field(default_factory=SafetyConfig)
    config_root: str


def _model_dict(model: BaseModel) -> Dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump()  # type: ignore[attr-defined]
    return model.dict()


def _parse_model(model_cls: Any, data: Any) -> Any:
    if hasattr(model_cls, "model_validate"):
        return model_cls.model_validate(data)
    return model_cls.parse_obj(data)


def _load_yaml(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


def _resolve_path(root: Path, value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def load_config(path: str) -> ResolvedConfig:
    """Load an experiment file and its direct or debate references."""
    config_path = Path(path).expanduser().resolve()
    root = config_path.parent
    file_config = _parse_model(ExperimentFileConfig, _load_yaml(config_path))
    prompts_raw = _load_yaml(_resolve_path(root, file_config.prompts))
    prompts = _parse_model(PromptConfig, prompts_raw.get("prompts", prompts_raw))

    model = None
    debate = None
    if file_config.treatment == "direct":
        if (
            file_config.debate_model_params
            or file_config.debate_model_params_by_model
        ):
            raise ValueError(
                "debate model params are only supported for debate experiments"
            )
        if not file_config.model:
            raise ValueError("A direct experiment requires model")
        if not prompts.direct_answer:
            raise ValueError("A direct experiment requires prompts.direct_answer")
        model_raw = _load_yaml(_resolve_path(root, file_config.model))
        model = _parse_model(ModelConfig, model_raw.get("model_config", model_raw))
    else:
        if not file_config.debate:
            raise ValueError("A debate experiment requires debate")
        required_prompts = (
            "initial_proposal",
            "debate_turn",
            "self_adjustment",
            "final_decision",
            "supervisor",
        )
        debate_raw = _load_yaml(_resolve_path(root, file_config.debate))
        debate_file = _parse_model(
            DebateFileConfig,
            debate_raw.get("debate", debate_raw),
        )
        if debate_file.workflow == "verifier_a":
            required_prompts += ("verification",)
        elif debate_file.workflow == "verifier_b":
            required_prompts += ("verification", "second_proposal")
        missing_prompts = [name for name in required_prompts if not getattr(prompts, name)]
        if missing_prompts:
            raise ValueError(
                "A debate experiment is missing prompt templates: %s"
                % ", ".join(missing_prompts)
            )
        if len(debate_file.agents) < 2:
            raise ValueError("A debate requires at least two agents")
        agent_ids = [agent.id for agent in debate_file.agents]
        if len(agent_ids) != len(set(agent_ids)):
            raise ValueError("Debate agent IDs must be unique")

        roles_raw = _load_yaml(_resolve_path(root, debate_file.roles))
        roles_data = roles_raw.get("roles", roles_raw)
        roles = [_parse_model(DebateRoleConfig, item) for item in roles_data]
        role_ids = [role.id for role in roles]
        if len(role_ids) != len(set(role_ids)):
            raise ValueError("Debate role IDs must be unique")
        role_map = {role.id: role for role in roles}
        for agent in debate_file.agents:
            if agent.role not in role_map:
                raise ValueError(
                    "Debate agent %r references unknown role %r" % (agent.id, agent.role)
                )
        if debate_file.accuracy_visible:
            for agent in debate_file.agents:
                if (
                    agent.reference_accuracy is None
                    or not agent.accuracy_source
                    or not agent.accuracy_source.strip()
                ):
                    raise ValueError(
                        "accuracy_visible requires reference_accuracy and accuracy_source "
                        "for debate agent %r" % agent.id
                    )
        if debate_file.workflow != "standard":
            verifier = next(
                (
                    agent for agent in debate_file.agents
                    if agent.id == debate_file.verifier_agent_id
                ),
                None,
            )
            if verifier is None:
                raise ValueError(
                    "%s requires verifier_agent_id to name a debate agent"
                    % debate_file.workflow
                )
            if any(
                agent.reference_accuracy is None
                or not agent.accuracy_source
                or not agent.accuracy_source.strip()
                for agent in debate_file.agents
            ):
                raise ValueError(
                    "%s requires reference_accuracy and accuracy_source for every "
                    "debate agent so the strongest verifier can be validated"
                    % debate_file.workflow
                )
            strongest_accuracy = max(
                agent.reference_accuracy for agent in debate_file.agents
                if agent.reference_accuracy is not None
            )
            if verifier.reference_accuracy != strongest_accuracy:
                raise ValueError(
                    "verifier_agent_id must identify an agent with the highest "
                    "reference_accuracy in the group"
                )
        for role in roles:
            if len(role.capabilities) != len(set(role.capabilities)):
                raise ValueError("Debate role %r repeats a capability" % role.id)

        capability_counts = {
            capability: sum(
                capability in role_map[agent.role].capabilities
                for agent in debate_file.agents
            )
            for capability in ("propose", "debate", "revise", "final_vote")
        }
        if capability_counts["propose"] < 1:
            raise ValueError("A debate team requires at least one proposing agent")
        if capability_counts["debate"] < 1:
            raise ValueError("A debate team requires at least one debating agent")
        if capability_counts["revise"] < 1:
            raise ValueError("A debate team requires at least one revising agent")
        if capability_counts["final_vote"] < 2:
            raise ValueError("A debate team requires at least two final-vote agents")
        if debate_file.workflow != "standard":
            full_protocol = {"propose", "debate", "revise", "final_vote"}
            incomplete_agents = [
                agent.id for agent in debate_file.agents
                if not full_protocol.issubset(
                    set(role_map[agent.role].capabilities)
                )
            ]
            if incomplete_agents:
                raise ValueError(
                    "%s requires every agent to participate in proposals, debate, "
                    "reflection, and final voting: %s"
                    % (debate_file.workflow, ", ".join(incomplete_agents))
                )

        def load_model_reference(value: str) -> ModelConfig:
            raw = _load_yaml(_resolve_path(root, value))
            model_config = _parse_model(ModelConfig, raw.get("model_config", raw))
            model_data = _model_dict(model_config)
            model_data["params"] = {
                **model_config.params,
                **file_config.debate_model_params,
                **file_config.debate_model_params_by_model.get(
                    model_config.model, {}
                ),
            }
            return _parse_model(ModelConfig, model_data)

        debate = DebateConfig(
            agents=[
                DebateAgentConfig(
                    id=agent.id,
                    model=load_model_reference(agent.model),
                    role=agent.role,
                    reference_accuracy=agent.reference_accuracy,
                    accuracy_source=agent.accuracy_source,
                )
                for agent in debate_file.agents
            ],
            roles=roles,
            supervisor_model=load_model_reference(debate_file.supervisor_model),
            passes=debate_file.passes,
            accuracy_visible=debate_file.accuracy_visible,
            agent_order=debate_file.agent_order,
            workflow=debate_file.workflow,
            verifier_agent_id=debate_file.verifier_agent_id,
            format_repair_max_retries=debate_file.format_repair_max_retries,
            require_structured_output=debate_file.require_structured_output,
        )

    if file_config.benchmark.kind != "kks" and file_config.benchmark.samples_per_size is not None:
        raise ValueError("samples_per_size is only supported for the kks benchmark")

    return _parse_model(
        ResolvedConfig,
        {
            "experiment_id": file_config.experiment_id,
            "treatment": file_config.treatment,
            "seed": file_config.seed,
            "benchmark": _model_dict(file_config.benchmark),
            "run": _model_dict(file_config.run),
            "model": _model_dict(model) if model else None,
            "debate": _model_dict(debate) if debate else None,
            "prompts": _model_dict(prompts),
            "config_root": str(root),
        },
    )


def load_suite_config(path: str) -> ResolvedSuiteConfig:
    """Load a suite and resolve experiment paths relative to the suite file."""
    config_path = Path(path).expanduser().resolve()
    root = config_path.parent
    file_config = _parse_model(SuiteFileConfig, _load_yaml(config_path))
    if not file_config.experiments:
        raise ValueError("A suite must contain at least one experiment")
    experiments = [str(_resolve_path(root, value).resolve()) for value in file_config.experiments]
    if len(experiments) != len(set(experiments)):
        raise ValueError("A suite cannot contain the same experiment more than once")
    return _parse_model(
        ResolvedSuiteConfig,
        {
            "suite_id": file_config.suite_id,
            "experiments": experiments,
            "output_dir": file_config.output_dir,
            "parallelism": file_config.parallelism,
            "global_concurrency": file_config.global_concurrency,
            "provider_concurrency": file_config.provider_concurrency,
            "safety": _model_dict(file_config.safety),
            "config_root": str(root),
        },
    )


def config_dict(config: ResolvedConfig) -> Dict[str, Any]:
    return _model_dict(config)
