"""Paper-aligned multi-agent debate execution for KKS experiments."""

from collections import Counter
from copy import deepcopy
import json
import re
import time
import zlib
from typing import Any, Awaitable, Callable, Dict, List, Optional

from .benchmark import BenchmarkTask
from .config import DebateAgentConfig, ModelConfig, ResolvedConfig
from .events import make_event
from .evaluator import Evaluator, evaluator_for_kind
from .models import ModelClient, ModelResponse, model_client_for_config
from .prompts import PromptStore
from .storage import ExperimentStorage
from .structured_output import model_with_debate_output_contract


_ROLES = {"knight", "knave", "spy"}


def _parse_json_object(content: str) -> Dict[str, Any]:
    try:
        value = json.loads(content)
    except json.JSONDecodeError:
        matches = re.findall(
            r"```(?:json)?\s*([\s\S]*?)\s*```",
            content,
            flags=re.IGNORECASE,
        )
        candidates = []
        for match in matches:
            try:
                candidate = json.loads(match)
            except json.JSONDecodeError:
                continue
            if isinstance(candidate, dict):
                candidates.append(candidate)

        # Some models explain their answer before emitting one JSON object. If
        # there is no usable fenced object, accept one unambiguous embedded
        # object while still rejecting multiple competing valid answers.
        if not candidates:
            decoder = json.JSONDecoder()
            cursor = 0
            while True:
                start = content.find("{", cursor)
                if start < 0:
                    break
                try:
                    candidate, end = decoder.raw_decode(content[start:])
                except json.JSONDecodeError:
                    cursor = start + 1
                    continue
                if isinstance(candidate, dict):
                    candidates.append(candidate)
                cursor = start + end
        if len(candidates) == 1:
            value = candidates[0]
        else:
            # Prefer one explicit contract object over bare nested maps found
            # inside a malformed draft. Multiple explicit answers remain
            # ambiguous and are still rejected.
            explicit = [
                candidate for candidate in candidates
                if set(candidate) & {"roles", "player", "verdict"}
            ]
            if len(explicit) != 1:
                raise ValueError("response must contain exactly one valid JSON object")
            value = explicit[0]
    if not isinstance(value, dict):
        raise ValueError("response must be a JSON object")
    return value


def _parse_solution(
    content: str,
    players: List[str],
) -> Dict[str, Any]:
    value = _parse_json_object(content)
    roles = value.get("roles")
    if not isinstance(roles, dict):
        # Some providers flatten the requested {"roles": ..., "explanation": ...}
        # object. Normalize that exact, unambiguous shape locally so a
        # format-only retry does not need to reconstruct substantive content.
        allowed_outer_keys = set(players) | {"explanation"}
        if set(value).issubset(allowed_outer_keys):
            roles = {player: value[player] for player in players if player in value}
        else:
            # If the outer object is malformed, the tolerant JSON extractor may
            # recover the complete embedded role map itself.
            roles = value
    canonical_players = {player.casefold(): player for player in players}
    normalized_keys: Dict[str, str] = {}
    if isinstance(roles, dict):
        for raw_player in roles:
            key = str(raw_player).strip().casefold()
            canonical = canonical_players.get(key)
            if canonical is None or canonical in normalized_keys.values():
                break
            normalized_keys[str(raw_player)] = canonical
    if (
        not isinstance(roles, dict)
        or len(normalized_keys) != len(roles)
        or set(normalized_keys.values()) != set(players)
    ):
        raise ValueError("solution must assign every player exactly once")
    normalized = {
        normalized_keys[str(player)]: str(role).lower()
        for player, role in roles.items()
    }
    if any(role not in _ROLES for role in normalized.values()):
        raise ValueError("solution roles must be knight, knave, or spy")
    return {
        "roles": normalized,
        "explanation": str(value.get("explanation", "")),
        "raw_response": content,
    }


def _parse_debate_turn(
    content: str,
    player: str,
    other_agents: List[str],
    self_agent: str,
) -> Dict[str, Any]:
    value = _parse_json_object(content)
    if str(value.get("player", "")).strip().casefold() != player.casefold():
        raise ValueError("debate response must identify the current player")
    role = str(value.get("role", "")).lower()
    if role not in _ROLES:
        raise ValueError("debate response role must be knight, knave, or spy")
    allowed = set(other_agents)
    agree = value.get("agree_with", [])
    disagree = value.get("disagree_with", [])
    if not isinstance(agree, list) or not isinstance(disagree, list):
        raise ValueError("agree_with and disagree_with must be arrays")
    if any(not isinstance(item, str) for item in agree + disagree):
        raise ValueError("agree_with and disagree_with must contain agent IDs")
    if self_agent in agree or self_agent in disagree:
        raise ValueError("an agent cannot classify itself")
    if (set(agree) | set(disagree)) - allowed:
        raise ValueError("debate response contains unknown peer agent IDs")
    if len(agree) != len(set(agree)) or len(disagree) != len(set(disagree)):
        raise ValueError("each peer agent must be classified exactly once")
    if set(agree) & set(disagree):
        raise ValueError("an agent cannot be both agreed and disagreed with")
    if set(agree) | set(disagree) != allowed:
        raise ValueError("each peer agent must be classified exactly once")
    shared_reasoning = value.get("reasoning", "")
    agree_reasoning = str(
        value.get("agree_reasoning", value.get("agree_with_reasoning", shared_reasoning))
    ).strip()
    disagree_reasoning = str(
        value.get("disagree_reasoning", value.get("disagree_with_reasoning", shared_reasoning))
    ).strip()
    return {
        "player": player,
        "role": role,
        "agree_with": agree,
        "disagree_with": disagree,
        "agree_reasoning": agree_reasoning,
        "disagree_reasoning": disagree_reasoning,
        "raw_response": content,
    }


def _parse_verification(content: str) -> Dict[str, Any]:
    value = _parse_json_object(content)
    if set(value) - {"verdict", "checks", "errors"}:
        raise ValueError("verification must report errors without proposing a solution")
    verdict = str(value.get("verdict", "")).lower()
    if verdict not in {"valid", "errors_found"}:
        raise ValueError("verification verdict must be valid or errors_found")
    checks = value.get("checks")
    errors = value.get("errors")
    if not isinstance(checks, list) or not checks:
        raise ValueError("verification must contain at least one logical test")
    if not isinstance(errors, list) or any(not isinstance(item, str) for item in errors):
        raise ValueError("verification errors must be an array of strings")
    normalized_errors = [item.strip() for item in errors]
    if any(not item for item in normalized_errors):
        raise ValueError("verification error descriptions cannot be blank")
    normalized_checks: List[Dict[str, str]] = []
    for check in checks:
        if not isinstance(check, dict):
            raise ValueError("each verification check must be an object")
        if set(check) - {"test", "result", "error"}:
            raise ValueError("verification checks cannot contain proposed corrections")
        result = str(check.get("result", "")).lower()
        if result not in {"pass", "fail"}:
            raise ValueError("verification check result must be pass or fail")
        test = str(check.get("test", "")).strip()
        if not test:
            raise ValueError("each verification check must name the logical test")
        error = str(check.get("error", "")).strip()
        if result == "fail" and not error:
            raise ValueError("a failing verification check must describe the error")
        normalized_checks.append({"test": test, "result": result, "error": error})
    has_failure = any(check["result"] == "fail" for check in normalized_checks)
    if verdict == "valid" and (has_failure or normalized_errors):
        raise ValueError("a valid verification cannot contain failures or errors")
    if verdict == "errors_found" and (not has_failure or not normalized_errors):
        raise ValueError("errors_found requires a failing test and an error description")
    return {
        "verdict": verdict,
        "checks": normalized_checks,
        "errors": normalized_errors,
        "raw_response": content,
    }


class DebateExecutor:
    """Run initial proposals, localized debate, revision, and final voting."""

    def __init__(
        self,
        config: ResolvedConfig,
        storage: ExperimentStorage,
        model_client: ModelClient = None,
        evaluator: Evaluator = None,
        run_model_call: Optional[
            Callable[
                [
                    ModelConfig,
                    str,
                    Callable[[], Awaitable[ModelResponse]],
                    Callable[[int, Exception, float], None],
                ],
                Awaitable[ModelResponse],
            ]
        ] = None,
    ) -> None:
        if config.debate is None:
            raise ValueError("DebateExecutor requires config.debate")
        if config.benchmark.kind != "kks":
            raise ValueError("The player-by-player debate treatment requires benchmark.kind=kks")
        self.config = config
        self.debate = config.debate
        self.roles = {role.id: role for role in self.debate.roles}
        if self.debate.workflow != "standard":
            verifier = next(
                (
                    agent for agent in self.debate.agents
                    if agent.id == self.debate.verifier_agent_id
                ),
                None,
            )
            if verifier is None:
                raise ValueError(
                    "%s requires verifier_agent_id to name a debate agent"
                    % self.debate.workflow
                )
            if any(
                agent.reference_accuracy is None
                or not agent.accuracy_source
                or not agent.accuracy_source.strip()
                for agent in self.debate.agents
            ):
                raise ValueError(
                    "%s requires reference_accuracy and accuracy_source for every debate agent"
                    % self.debate.workflow
                )
            strongest_accuracy = max(
                agent.reference_accuracy for agent in self.debate.agents
                if agent.reference_accuracy is not None
            )
            if verifier.reference_accuracy != strongest_accuracy:
                raise ValueError(
                    "verifier_agent_id must identify an agent with the highest "
                    "reference_accuracy in the group"
                )
            full_protocol = {"propose", "debate", "revise", "final_vote"}
            incomplete_agents = [
                agent.id for agent in self.debate.agents
                if not full_protocol.issubset(
                    set(self.roles[agent.role].capabilities)
                )
            ]
            if incomplete_agents:
                raise ValueError(
                    "%s requires every agent to participate in the full protocol: %s"
                    % (self.debate.workflow, ", ".join(incomplete_agents))
                )
        if self.debate.accuracy_visible:
            for agent in self.debate.agents:
                if (
                    agent.reference_accuracy is None
                    or not agent.accuracy_source
                    or not agent.accuracy_source.strip()
                ):
                    raise ValueError(
                        "accuracy_visible requires reference_accuracy and accuracy_source "
                        "for debate agent %r" % agent.id
                    )
        self.storage = storage
        self.injected_model_client = model_client
        self.evaluator = evaluator or evaluator_for_kind("kks", strict_json=True)
        self.prompts = PromptStore(config.prompts, config.config_root)
        self._usage: Dict[str, float] = {}
        self._model_call_count = 0
        self._format_response_count = 0
        self._format_first_pass_valid_count = 0
        self._format_repaired_count = 0
        self._format_terminal_invalid_count = 0
        self._format_repair_attempt_count = 0
        self.run_model_call = run_model_call

    @staticmethod
    def _model_for_format_repair(model: ModelConfig) -> ModelConfig:
        """Disable deliberative compute for a format-only retry."""
        prepared = (
            model.model_copy(deep=True)
            if hasattr(model, "model_copy")
            else model.copy(deep=True)
        )
        params = deepcopy(prepared.params)
        repair_reasoning = prepared.format_repair_reasoning
        if repair_reasoning == "preserve":
            prepared.params = params
            return prepared
        extra_body = params.get("extra_body")
        reasoning = (
            extra_body.get("reasoning")
            if isinstance(extra_body, dict)
            else None
        )
        if isinstance(reasoning, dict) and repair_reasoning == "disable":
            extra_body["reasoning"] = {"enabled": False}
        thinking = params.get("thinking")
        if isinstance(thinking, dict) and repair_reasoning == "disable":
            params["thinking"] = {
                "type": "disabled",
                "budget_tokens": 0,
            }
        if "reasoning_effort" in params:
            params["reasoning_effort"] = (
                "minimal" if repair_reasoning == "minimal" else "none"
            )
        prepared.params = params
        return prepared

    def _agents_with(
        self,
        capability: str,
        task: Optional[BenchmarkTask] = None,
    ) -> List[DebateAgentConfig]:
        agents = list(self.debate.agents)
        if self.debate.agent_order == "cyclic_task_hash" and task is not None:
            offset = zlib.crc32(task.id.encode("utf-8")) % len(agents)
            agents = agents[offset:] + agents[:offset]
        return [
            agent
            for agent in agents
            if capability in self.roles[agent.role].capabilities
        ]

    def _role_context(self, agent_id: str) -> Dict[str, str]:
        agent = next((item for item in self.debate.agents if item.id == agent_id), None)
        if agent is None:
            return {
                "role": "supervisor",
                "role_description": "Resolve final vote ties using the debate evidence.",
            }
        role = self.roles[agent.role]
        return {"role": role.id, "role_description": role.description}

    @staticmethod
    def _assignment_requirements(purpose: str, player: Optional[str]) -> str:
        if purpose == "verification":
            return (
                "- Test the supplied consensus answer step by step\n"
                "- Report only whether the tests pass and any errors found\n"
                "- Do NOT propose, repair, or reveal an alternative assignment"
            )
        if purpose == "debate_turn":
            return (
                '- You MUST assign %s one of the three roles: "knight", "knave", or "spy"\n'
                '- Do NOT use "unknown" or any other value - you must make a definitive '
                "choice for %s"
            ) % (player, player)
        return (
            '- You MUST assign each player one of the three roles: "knight", "knave", or "spy"\n'
            '- Do NOT use "unknown" or any other value - you must make a definitive choice for\n'
            "each player"
        )

    @staticmethod
    def _puzzle_text(task: BenchmarkTask) -> str:
        """Remove the direct-only output contract from a KKS task prompt."""
        marker = "\nIdentify every player's role."
        return task.prompt.split(marker, 1)[0].rstrip()

    def _emit(self, event_type: str, run_id: str, **payload: Any) -> None:
        event = make_event(event_type, self.config.experiment_id, run_id, **payload)
        self.storage.append_event(event, task=True)
        self.storage.append_event(event, task=False)

    def _record_prompt(
        self,
        run_id: str,
        name: str,
        rendered: str,
        *,
        agent_id: str,
        pass_number: Optional[int] = None,
        player: Optional[str] = None,
    ) -> None:
        record = {
            "template": name,
            "agent_id": agent_id,
            "pass": pass_number,
            "player": player,
            "prompt": rendered,
        }
        self.storage.append_jsonl(run_id, "prompts.jsonl", record)
        self._emit("prompt_rendered", run_id, **{key: value for key, value in record.items() if key != "prompt"})

    async def _call(
        self,
        run_id: str,
        *,
        agent_id: str,
        model: ModelConfig,
        purpose: str,
        prompt: str,
        size: Any,
        pass_number: Optional[int] = None,
        player: Optional[str] = None,
        format_repair_attempt: int = 0,
        output_contract: Optional[Dict[str, Any]] = None,
    ) -> ModelResponse:
        started = time.monotonic()
        self._emit(
            "model_call_started",
            run_id,
            agent_id=agent_id,
            model=model.model,
            purpose=purpose,
            pass_number=pass_number,
            player=player,
            format_repair_attempt=format_repair_attempt,
            output_contract=output_contract,
        )
        client = self.injected_model_client or model_client_for_config(model)
        role_context = self._role_context(agent_id)
        system = self.prompts.render(
            "system",
            agent_id=agent_id,
            **role_context,
            task="",
            player="",
            context="",
            size=size,
            assignment_requirements=self._assignment_requirements(purpose, player),
        )
        self._record_prompt(
            run_id,
            "system",
            system,
            agent_id=agent_id,
            pass_number=pass_number,
            player=player,
        )
        try:
            async def complete() -> ModelResponse:
                return await client.complete(
                    model,
                    [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
                    self.config.run.timeout_seconds,
                )

            def record_retry(attempt: int, exc: Exception, delay: float) -> None:
                self.storage.append_jsonl(run_id, "model_calls.jsonl", {
                    "agent_id": agent_id,
                    "configured_model": model.model,
                    "purpose": purpose,
                    "pass": pass_number,
                    "player": player,
                    "format_repair_attempt": format_repair_attempt,
                    "output_contract": output_contract,
                    "status": "retryable_failure",
                    "attempt": attempt,
                    "error": str(exc),
                    "retry_delay_seconds": delay,
                })
                self._emit(
                    "model_call_retry_scheduled",
                    run_id,
                    agent_id=agent_id,
                    model=model.model,
                    purpose=purpose,
                    pass_number=pass_number,
                    player=player,
                    format_repair_attempt=format_repair_attempt,
                    output_contract=output_contract,
                    failed_attempt=attempt,
                    retry_delay_seconds=delay,
                    error=str(exc),
                )

            response = (
                await self.run_model_call(
                    model,
                    ":".join(str(value) for value in (
                        run_id, agent_id, purpose, pass_number, player,
                        format_repair_attempt,
                    )),
                    complete,
                    record_retry,
                )
                if self.run_model_call is not None
                else await complete()
            )
        except Exception as exc:
            self.storage.append_jsonl(run_id, "model_calls.jsonl", {
                "agent_id": agent_id,
                "configured_model": model.model,
                "purpose": purpose,
                "pass": pass_number,
                "player": player,
                "format_repair_attempt": format_repair_attempt,
                "output_contract": output_contract,
                "status": "failed",
                "error": str(exc),
                "latency_seconds": time.monotonic() - started,
            })
            raise
        record = {
            "agent_id": agent_id,
            "model": response.model,
            "configured_model": model.model,
            "returned_model": response.model,
            "purpose": purpose,
            "pass": pass_number,
            "player": player,
            "format_repair_attempt": format_repair_attempt,
            "output_contract": output_contract,
            "status": "completed",
            "finish_reason": response.finish_reason,
            "response_metadata": response.response_metadata,
            "usage": response.usage,
            "response": response.content,
            "latency_seconds": time.monotonic() - started,
        }
        self.storage.append_jsonl(run_id, "model_calls.jsonl", record)
        self._model_call_count += 1
        for key, value in response.usage.items():
            if isinstance(value, (int, float)) and key in {
                "prompt_tokens", "completion_tokens", "input_tokens", "output_tokens", "total_tokens", "cost"
            }:
                self._usage[key] = self._usage.get(key, 0.0) + value
        self._emit("model_call_completed", run_id, **{key: value for key, value in record.items() if key != "status"})
        return response

    async def _call_and_parse(
        self,
        run_id: str,
        *,
        agent_id: str,
        model: ModelConfig,
        purpose: str,
        prompt: str,
        size: Any,
        parser: Callable[[str], Dict[str, Any]],
        players: List[str],
        other_agents: Optional[List[str]] = None,
        pass_number: Optional[int] = None,
        player: Optional[str] = None,
    ) -> Dict[str, Any]:
        call_model, output_contract = model_with_debate_output_contract(
            model,
            purpose,
            players,
            player=player,
            other_agents=other_agents,
        )
        current_prompt = prompt
        previous_response = ""
        for repair_attempt in range(self.debate.format_repair_max_retries + 1):
            if repair_attempt == 0:
                self._format_response_count += 1
            else:
                self._format_repair_attempt_count += 1
            if repair_attempt:
                self._record_prompt(
                    run_id,
                    "format_repair",
                    current_prompt,
                    agent_id=agent_id,
                    pass_number=pass_number,
                    player=player,
                )
            attempt_model = (
                self._model_for_format_repair(call_model)
                if repair_attempt
                else call_model
            )
            response = await self._call(
                run_id,
                agent_id=agent_id,
                model=attempt_model,
                purpose=purpose,
                prompt=current_prompt,
                size=size,
                pass_number=pass_number,
                player=player,
                format_repair_attempt=repair_attempt,
                output_contract=output_contract,
            )
            try:
                parsed = parser(response.content)
            except ValueError as exc:
                terminal = repair_attempt >= self.debate.format_repair_max_retries
                self._emit(
                    "format_response_rejected",
                    run_id,
                    agent_id=agent_id,
                    purpose=purpose,
                    pass_number=pass_number,
                    player=player,
                    format_repair_attempt=repair_attempt,
                    terminal=terminal,
                    error=str(exc),
                )
                if terminal:
                    self._format_terminal_invalid_count += 1
                    raise
                previous_response = response.content
                current_prompt = (
                    prompt
                    + "\n\nFORMAT REPAIR ONLY\n"
                    + "Your previous response could not be accepted because: "
                    + str(exc)
                    + "\nPreserve the same substantive answer. Correct only the output "
                    + "format; do not reconsider the puzzle or use any external feedback. "
                    + "Return exactly one response in the originally requested JSON schema."
                    + "\n\nPREVIOUS RESPONSE\n"
                    + previous_response
                )
                continue
            self._emit(
                "format_response_accepted",
                run_id,
                agent_id=agent_id,
                purpose=purpose,
                pass_number=pass_number,
                player=player,
                format_repair_attempt=repair_attempt,
                repaired=bool(repair_attempt),
            )
            if repair_attempt:
                self._format_repaired_count += 1
            else:
                self._format_first_pass_valid_count += 1
            return parsed
        raise AssertionError("format repair loop exhausted unexpectedly")

    def _render(
        self,
        run_id: str,
        name: str,
        *,
        agent_id: str,
        task: BenchmarkTask,
        context: Any,
        player: str = "",
        pass_number: Optional[int] = None,
    ) -> str:
        rendered = self.prompts.render(
            name,
            agent_id=agent_id,
            **self._role_context(agent_id),
            task=(
                self._puzzle_text(task)
                if name in {"debate_turn", "verification"}
                else task.prompt
            ),
            size=task.metadata.get("size", len(task.metadata.get("players", []))),
            player=player,
            context=json.dumps(context, ensure_ascii=False, indent=2, sort_keys=True),
            other_agent_ids=json.dumps([
                agent.id for agent in self.debate.agents if agent.id != agent_id
            ]),
            assignment_requirements=self._assignment_requirements(name, player or None),
        )
        self._record_prompt(
            run_id,
            name,
            rendered,
            agent_id=agent_id,
            pass_number=pass_number,
            player=player or None,
        )
        return rendered

    def _visible_solutions(self, solutions: Dict[str, Dict[str, Any]], viewer: str) -> Dict[str, Any]:
        visible = deepcopy(solutions)
        for solution in visible.values():
            solution.pop("raw_response", None)
        return visible

    def _agent_profiles(self, viewer: str) -> Dict[str, Any]:
        return {
            agent.id: {
                "reference_accuracy": agent.reference_accuracy,
                "accuracy_source": agent.accuracy_source.strip(),
            }
            for agent in self.debate.agents
            if agent.id != viewer
        }

    def _accuracy_context(self, viewer: str) -> Dict[str, Any]:
        if not self.debate.accuracy_visible or viewer == "supervisor":
            return {}
        return {
            "agent_reference_accuracies": {
                "description": (
                    "Externally measured reference accuracy from the listed source; "
                    "not a label or result for this game."
                ),
                "agents": self._agent_profiles(viewer),
            }
        }

    @staticmethod
    def _visible_arguments(arguments: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        visible = deepcopy(arguments)
        for argument in visible.values():
            argument.pop("raw_response", None)
        return visible

    def _visible_rounds(self, rounds: List[Dict[str, Any]], viewer: str) -> List[Dict[str, Any]]:
        visible = deepcopy(rounds)
        for item in visible:
            item["solutions_before"] = self._visible_solutions(item["solutions_before"], viewer)
            item["solutions_after"] = self._visible_solutions(item["solutions_after"], viewer)
            item["adjustments"] = self._visible_solutions(item["adjustments"], viewer)
            for argument in item["arguments"].values():
                argument.pop("raw_response", None)
        return visible

    async def _run_debate_passes(
        self,
        run_id: str,
        task: BenchmarkTask,
        players: List[str],
        latest: Dict[str, Dict[str, Any]],
        rounds: List[Dict[str, Any]],
        pass_numbers: List[int],
        *,
        stage: str,
    ) -> Dict[str, Dict[str, Any]]:
        for pass_number in pass_numbers:
            for player in players:
                arguments: Dict[str, Dict[str, Any]] = {}
                for agent in self._agents_with("debate", task):
                    context = {
                        "workflow_stage": stage,
                        "latest_solutions": self._visible_solutions(latest, agent.id),
                        **self._accuracy_context(agent.id),
                        **(
                            {"previous_rounds": self._visible_rounds(rounds, agent.id)}
                            if rounds else {}
                        ),
                        **(
                            {"current_arguments": self._visible_arguments(arguments)}
                            if arguments else {}
                        ),
                    }
                    prompt = self._render(
                        run_id,
                        "debate_turn",
                        agent_id=agent.id,
                        task=task,
                        context=context,
                        player=player,
                        pass_number=pass_number,
                    )
                    other_agents = [item.id for item in self.debate.agents if item.id != agent.id]
                    try:
                        arguments[agent.id] = await self._call_and_parse(
                            run_id,
                            agent_id=agent.id,
                            model=agent.model,
                            purpose="debate_turn",
                            prompt=prompt,
                            size=task.metadata.get("size", len(players)),
                            players=players,
                            other_agents=other_agents,
                            pass_number=pass_number,
                            player=player,
                            parser=lambda content: _parse_debate_turn(
                                content, player, other_agents, agent.id
                            ),
                        )
                    except ValueError as exc:
                        self._emit(
                            "debate_argument_rejected",
                            run_id,
                            agent_id=agent.id,
                            player=player,
                            error=str(exc),
                        )
                        raise
                    self._emit(
                        "debate_argument_submitted",
                        run_id,
                        agent_id=agent.id,
                        pass_number=pass_number,
                        player=player,
                        stage=stage,
                        argument=arguments[agent.id],
                    )

                before_adjustment = deepcopy(latest)
                adjusted: Dict[str, Dict[str, Any]] = {}
                for agent in self._agents_with("revise", task):
                    context = {
                        "workflow_stage": stage,
                        "latest_solutions_before_adjustment": self._visible_solutions(
                            before_adjustment, agent.id
                        ),
                        **self._accuracy_context(agent.id),
                        "current_arguments": self._visible_arguments(arguments),
                        **(
                            {"previous_rounds": self._visible_rounds(rounds, agent.id)}
                            if rounds else {}
                        ),
                    }
                    prompt = self._render(
                        run_id,
                        "self_adjustment",
                        agent_id=agent.id,
                        task=task,
                        context=context,
                        player=player,
                        pass_number=pass_number,
                    )
                    adjusted[agent.id] = await self._call_and_parse(
                        run_id,
                        agent_id=agent.id,
                        model=agent.model,
                        purpose="self_adjustment",
                        prompt=prompt,
                        size=task.metadata.get("size", len(players)),
                        players=players,
                        pass_number=pass_number,
                        player=player,
                        parser=lambda content: _parse_solution(content, players),
                    )
                    self._emit(
                        "self_adjustment_submitted",
                        run_id,
                        agent_id=agent.id,
                        pass_number=pass_number,
                        player=player,
                        stage=stage,
                        solution=adjusted[agent.id],
                    )
                latest = {**before_adjustment, **adjusted}
                rounds.append({
                    "pass": pass_number,
                    "stage": stage,
                    "player": player,
                    "arguments": arguments,
                    "adjustments": deepcopy(adjusted),
                    "solutions_before": before_adjustment,
                    "solutions_after": deepcopy(latest),
                })
        return latest

    @staticmethod
    def _aggregate_solutions(
        solutions: Dict[str, Dict[str, Any]],
        players: List[str],
    ) -> tuple[Dict[str, str], Dict[str, Dict[str, int]], List[str]]:
        prediction: Dict[str, str] = {}
        votes: Dict[str, Dict[str, int]] = {}
        tied_players: List[str] = []
        for player in players:
            counts = Counter(solution["roles"][player] for solution in solutions.values())
            votes[player] = dict(sorted(counts.items()))
            role, count = counts.most_common(1)[0]
            if count > len(solutions) / 2:
                prediction[player] = role
            else:
                tied_players.append(player)
        return prediction, votes, tied_players

    async def run(
        self,
        run_id: str,
        task: BenchmarkTask,
        repetition: int,
        attempt: int = 1,
    ) -> Dict[str, Any]:
        players = list(task.metadata.get("players", []))
        if not players:
            raise ValueError("KKS debate tasks require metadata.players")
        self._usage = {}
        self._model_call_count = 0
        self._format_response_count = 0
        self._format_first_pass_valid_count = 0
        self._format_repaired_count = 0
        self._format_terminal_invalid_count = 0
        self._format_repair_attempt_count = 0
        self.storage.upsert_run(
            run_id,
            status="running",
            task_id=task.id,
            repetition=repetition,
            attempt=attempt,
            started_at=time.time(),
        )
        self._emit("run_started", run_id, task_id=task.id, repetition=repetition, attempt=attempt, treatment="debate")
        self._emit("task_loaded", run_id, task_id=task.id, players=players)

        initial: Dict[str, Dict[str, Any]] = {}
        for agent in self._agents_with("propose", task):
            prompt = self._render(run_id, "initial_proposal", agent_id=agent.id, task=task, context={})
            initial[agent.id] = await self._call_and_parse(
                run_id,
                agent_id=agent.id,
                model=agent.model,
                purpose="initial_proposal",
                prompt=prompt,
                size=task.metadata.get("size", len(players)),
                players=players,
                parser=lambda content: _parse_solution(content, players),
            )
            self._emit("initial_proposal_submitted", run_id, agent_id=agent.id, proposal=initial[agent.id])

        latest = deepcopy(initial)
        rounds: List[Dict[str, Any]] = []
        latest = await self._run_debate_passes(
            run_id,
            task,
            players,
            latest,
            rounds,
            list(range(1, self.debate.passes + 1)),
            stage=(
                "debate" if self.debate.workflow == "standard"
                else "pre_verification"
            ),
        )

        consensus = None
        consensus_votes = None
        consensus_tied_players: List[str] = []
        consensus_supervisor_decision = None
        verification_report = None
        second_proposals: Dict[str, Dict[str, Any]] = {}
        if self.debate.workflow != "standard":
            consensus, consensus_votes, consensus_tied_players = self._aggregate_solutions(
                latest, players
            )
            if consensus_tied_players:
                prompt = self._render(
                    run_id,
                    "supervisor",
                    agent_id="supervisor",
                    task=task,
                    context={
                        "purpose": "resolve the pre-verification consensus only",
                        "latest_solutions": self._visible_solutions(latest, "supervisor"),
                        "votes": consensus_votes,
                        "tied_players": consensus_tied_players,
                    },
                )
                consensus_supervisor_decision = await self._call_and_parse(
                    run_id,
                    agent_id="supervisor",
                    model=self.debate.supervisor_model,
                    purpose="consensus_tie_break",
                    prompt=prompt,
                    size=task.metadata.get("size", len(players)),
                    players=players,
                    parser=lambda content: _parse_solution(content, players),
                )
                for player in consensus_tied_players:
                    consensus[player] = consensus_supervisor_decision["roles"][player]
                self._emit(
                    "consensus_tie_break_submitted",
                    run_id,
                    tied_players=consensus_tied_players,
                    solution=consensus_supervisor_decision,
                )
            self._emit(
                "consensus_aggregated",
                run_id,
                votes=consensus_votes,
                tied_players=consensus_tied_players,
                consensus=consensus,
            )

            verifier = next(
                agent for agent in self.debate.agents
                if agent.id == self.debate.verifier_agent_id
            )
            prompt = self._render(
                run_id,
                "verification",
                agent_id=verifier.id,
                task=task,
                context={"consensus_answer": {"roles": consensus}},
            )
            verification_report = await self._call_and_parse(
                run_id,
                agent_id=verifier.id,
                model=verifier.model,
                purpose="verification",
                prompt=prompt,
                size=task.metadata.get("size", len(players)),
                players=players,
                parser=_parse_verification,
            )
            self._emit(
                "verification_submitted",
                run_id,
                verifier_agent_id=verifier.id,
                report=verification_report,
            )

            shared_verification_context = {
                "consensus_answer": {"roles": consensus},
                "verification_report": {
                    key: value for key, value in verification_report.items()
                    if key != "raw_response"
                },
            }
            if self.debate.workflow == "verifier_b":
                for agent in self._agents_with("propose", task):
                    prompt = self._render(
                        run_id,
                        "second_proposal",
                        agent_id=agent.id,
                        task=task,
                        context={
                            **shared_verification_context,
                            "first_debate_latest_solutions": self._visible_solutions(
                                latest, agent.id
                            ),
                        },
                        pass_number=self.debate.passes + 1,
                    )
                    second_proposals[agent.id] = await self._call_and_parse(
                        run_id,
                        agent_id=agent.id,
                        model=agent.model,
                        purpose="second_proposal",
                        prompt=prompt,
                        size=task.metadata.get("size", len(players)),
                        players=players,
                        pass_number=self.debate.passes + 1,
                        parser=lambda content: _parse_solution(content, players),
                    )
                    self._emit(
                        "second_proposal_submitted",
                        run_id,
                        agent_id=agent.id,
                        proposal=second_proposals[agent.id],
                    )
                latest = deepcopy(second_proposals)
                latest = await self._run_debate_passes(
                    run_id,
                    task,
                    players,
                    latest,
                    rounds,
                    [self.debate.passes + 1],
                    stage="post_verification",
                )

        final_decisions: Dict[str, Dict[str, Any]] = {}
        for agent in self._agents_with("final_vote", task):
            full_context = {
                "workflow": self.debate.workflow,
                "initial_proposals": self._visible_solutions(initial, agent.id),
                **self._accuracy_context(agent.id),
                "rounds": self._visible_rounds(rounds, agent.id),
                "latest_solutions": self._visible_solutions(latest, agent.id),
                "your_latest_solution": (
                    self._visible_solutions(
                        {agent.id: latest[agent.id]}, agent.id
                    )[agent.id]
                    if agent.id in latest else None
                ),
                **(
                    {
                        "consensus_answer": {"roles": consensus},
                        "verification_report": {
                            key: value for key, value in verification_report.items()
                            if key != "raw_response"
                        },
                    }
                    if verification_report else {}
                ),
            }
            prompt = self._render(
                run_id,
                "final_decision",
                agent_id=agent.id,
                task=task,
                context=full_context,
            )
            final_decisions[agent.id] = await self._call_and_parse(
                run_id,
                agent_id=agent.id,
                model=agent.model,
                purpose="final_decision",
                prompt=prompt,
                size=task.metadata.get("size", len(players)),
                players=players,
                parser=lambda content: _parse_solution(content, players),
            )
            self._emit("final_decision_submitted", run_id, agent_id=agent.id, solution=final_decisions[agent.id])

        prediction, votes, tied_players = self._aggregate_solutions(
            final_decisions, players
        )

        supervisor_decision = None
        if tied_players:
            full_context = {
                "initial_proposals": self._visible_solutions(initial, "supervisor"),
                **self._accuracy_context("supervisor"),
                "rounds": self._visible_rounds(rounds, "supervisor"),
                "latest_solutions": self._visible_solutions(latest, "supervisor"),
            }
            prompt = self._render(
                run_id,
                "supervisor",
                agent_id="supervisor",
                task=task,
                context={
                    **full_context,
                    "final_decisions": self._visible_solutions(final_decisions, "supervisor"),
                    "votes": votes,
                    "tied_players": tied_players,
                },
            )
            supervisor_decision = await self._call_and_parse(
                run_id,
                agent_id="supervisor",
                model=self.debate.supervisor_model,
                purpose="tie_break",
                prompt=prompt,
                size=task.metadata.get("size", len(players)),
                players=players,
                parser=lambda content: _parse_solution(content, players),
            )
            for player in tied_players:
                prediction[player] = supervisor_decision["roles"][player]
            self._emit("supervisor_tie_break_submitted", run_id, tied_players=tied_players, solution=supervisor_decision)

        aggregate_response = json.dumps({"roles": prediction}, ensure_ascii=False, sort_keys=True)
        evaluation = self.evaluator.evaluate(task, aggregate_response)
        self._emit("final_vote_aggregated", run_id, votes=votes, tied_players=tied_players, prediction=prediction)
        self._emit("evaluation_completed", run_id, evaluation=evaluation)

        debate_turns = [
            argument
            for round_data in rounds
            for argument in round_data["arguments"].values()
        ]
        result = {
            "run_id": run_id,
            "task_id": task.id,
            "repetition": repetition,
            "attempt": attempt,
            "treatment": "debate",
            "models": {agent.id: agent.model.model for agent in self.debate.agents},
            "agent_roles": {agent.id: agent.role for agent in self.debate.agents},
            "agent_order": [agent.id for agent in self._agents_with("debate", task)],
            "workflow": self.debate.workflow,
            "role_capabilities": {
                role.id: list(role.capabilities)
                for role in self.debate.roles
            },
            "supervisor_model": self.debate.supervisor_model.model,
            "initial_proposals": initial,
            "rounds": rounds,
            "consensus": consensus,
            "consensus_votes": consensus_votes,
            "consensus_tied_players": consensus_tied_players,
            "consensus_supervisor_decision": consensus_supervisor_decision,
            "verifier_agent_id": self.debate.verifier_agent_id,
            "verification_report": verification_report,
            "second_proposals": second_proposals,
            "final_decisions": final_decisions,
            "votes": votes,
            "tied_players": tied_players,
            "supervisor_decision": supervisor_decision,
            "raw_response": aggregate_response,
            "prediction": prediction,
            "evaluation": evaluation,
            "usage": self._usage,
            "model_call_count": self._model_call_count,
            "interaction_protocol": {
                "scope": "completed_attempt",
                "turn_count": len(debate_turns),
                "valid_turn_count": len(debate_turns),
                "invalid_turn_count": 0,
                "valid_rate": 1.0,
            },
            "format_protocol": {
                "scope": "completed_attempt",
                "response_count": self._format_response_count,
                "first_pass_valid_count": self._format_first_pass_valid_count,
                "first_pass_invalid_count": (
                    self._format_response_count
                    - self._format_first_pass_valid_count
                ),
                "repaired_count": self._format_repaired_count,
                "terminal_invalid_count": self._format_terminal_invalid_count,
                "repair_attempt_count": self._format_repair_attempt_count,
                "first_pass_valid_rate": (
                    self._format_first_pass_valid_count / self._format_response_count
                    if self._format_response_count else 1.0
                ),
                "post_repair_valid_rate": (
                    (
                        self._format_first_pass_valid_count
                        + self._format_repaired_count
                    ) / self._format_response_count
                    if self._format_response_count else 1.0
                ),
            },
            "metadata": task.metadata,
            "status": "completed",
        }
        self.storage.write_json(run_id, "result.json", result)
        self.storage.write_transcript(run_id, self._transcript(task, result))
        self.storage.upsert_run(
            run_id,
            status="completed",
            completed_at=time.time(),
            result_path="tasks/%s/result.json" % run_id,
        )
        self._emit("run_completed", run_id, task_id=task.id, evaluation=evaluation)
        return result

    @staticmethod
    def _transcript(task: BenchmarkTask, result: Dict[str, Any]) -> str:
        lines = ["# Debate: %s" % task.id, "", "## Initial proposals", ""]
        for agent_id, proposal in result["initial_proposals"].items():
            lines.extend(["### %s" % agent_id, proposal["raw_response"], ""])

        def append_round(item: Dict[str, Any]) -> None:
            lines.extend([
                "## Pass %d — %s — %s"
                % (item["pass"], item.get("stage", "debate"), item["player"]),
                "",
            ])
            for agent_id, argument in item["arguments"].items():
                lines.extend(["### Argument — %s" % agent_id, argument["raw_response"], ""])
            for agent_id, solution in item["adjustments"].items():
                lines.extend(["### Self-adjustment — %s" % agent_id, solution["raw_response"], ""])

        for item in result["rounds"]:
            if item.get("stage") != "post_verification":
                append_round(item)
        if result["verification_report"]:
            lines.extend([
                "## Pre-verification consensus",
                "",
                json.dumps({"roles": result["consensus"]}, ensure_ascii=False, sort_keys=True),
                "",
                "## Verifier report — %s" % result["verifier_agent_id"],
                "",
                result["verification_report"]["raw_response"],
                "",
            ])
        if result["second_proposals"]:
            lines.extend(["## Second-round proposals", ""])
            for agent_id, solution in result["second_proposals"].items():
                lines.extend(["### %s" % agent_id, solution["raw_response"], ""])
        for item in result["rounds"]:
            if item.get("stage") == "post_verification":
                append_round(item)
        lines.extend(["## Final decisions", ""])
        for agent_id, solution in result["final_decisions"].items():
            lines.extend(["### %s" % agent_id, solution["raw_response"], ""])
        if result["supervisor_decision"]:
            lines.extend(["## Supervisor tie-break", "", result["supervisor_decision"]["raw_response"], ""])
        lines.extend(["## Aggregated answer", "", result["raw_response"], ""])
        return "\n".join(lines)
