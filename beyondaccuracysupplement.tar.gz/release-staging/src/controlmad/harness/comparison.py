"""Paired comparisons for two benchmark runtimes on identical task draws."""

import json
import math
from pathlib import Path
from typing import Any, Dict, List, Tuple


PairKey = Tuple[str, int]


def _completed_results(run_dir: Path) -> Dict[PairKey, Dict[str, Any]]:
    results: Dict[PairKey, Dict[str, Any]] = {}
    for path in sorted((run_dir / "tasks").glob("*/result.json")):
        with path.open("r", encoding="utf-8") as handle:
            result = json.load(handle)
        if result.get("status") != "completed":
            continue
        key = (str(result["task_id"]), int(result.get("repetition", 1)))
        previous = results.get(key)
        if previous is None or int(result.get("attempt", 1)) > int(previous.get("attempt", 1)):
            results[key] = result
    return results


def _exact_mcnemar_p(left_only: int, right_only: int) -> float:
    discordant = left_only + right_only
    if discordant == 0:
        return 1.0
    tail = sum(math.comb(discordant, k) for k in range(min(left_only, right_only) + 1))
    return min(1.0, 2.0 * tail / (2 ** discordant))


def _semantic_correct(result: Dict[str, Any]) -> bool:
    evaluation = result["evaluation"]
    return bool(evaluation.get("semantic_strict", evaluation.get("strict", 0.0)))


def compare_runtime_results(left_dir: Path, right_dir: Path) -> Dict[str, Any]:
    left = _completed_results(left_dir)
    right = _completed_results(right_dir)
    if not left or not right:
        raise ValueError("both run directories must contain completed task results")
    if set(left) != set(right):
        left_missing = sorted(set(right) - set(left))
        right_missing = sorted(set(left) - set(right))
        raise ValueError(
            "run directories are not a complete pair; missing from left=%s missing from right=%s"
            % (left_missing, right_missing)
        )

    keys: List[PairKey] = sorted(left)
    left_correct = sum(_semantic_correct(left[key]) for key in keys)
    right_correct = sum(_semantic_correct(right[key]) for key in keys)
    left_only = sum(
        _semantic_correct(left[key]) and not _semantic_correct(right[key]) for key in keys
    )
    right_only = sum(
        _semantic_correct(right[key]) and not _semantic_correct(left[key]) for key in keys
    )
    p_value = _exact_mcnemar_p(left_only, right_only)
    count = len(keys)
    return {
        "paired_count": count,
        "left": {
            "run_dir": str(left_dir.resolve()),
            "correct": left_correct,
            "accuracy": left_correct / count,
        },
        "right": {
            "run_dir": str(right_dir.resolve()),
            "correct": right_correct,
            "accuracy": right_correct / count,
        },
        "right_minus_left_accuracy": (right_correct - left_correct) / count,
        "discordant_pairs": {
            "left_correct_right_wrong": left_only,
            "left_wrong_right_correct": right_only,
            "total": left_only + right_only,
        },
        "test": {
            "name": "exact_mcnemar_two_sided",
            "p_value": p_value,
            "alpha": 0.05,
            "significant": p_value < 0.05,
            "primary_metric": "semantic_strict_accuracy",
        },
    }
