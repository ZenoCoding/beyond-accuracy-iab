"""Model client interfaces for API and Codex CLI benchmark calls."""

import asyncio
import json
import os
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import ModelConfig


@dataclass
class ModelResponse:
    content: str
    model: str
    usage: Dict[str, Any] = field(default_factory=dict)
    finish_reason: Optional[str] = None
    response_metadata: Dict[str, Any] = field(default_factory=dict)
    raw: Any = None


class ModelClient:
    async def complete(self, model: ModelConfig, messages: List[Dict[str, str]], timeout: float) -> ModelResponse:
        raise NotImplementedError


class LiteLLMModelClient(ModelClient):
    async def complete(self, model: ModelConfig, messages: List[Dict[str, str]], timeout: float) -> ModelResponse:
        try:
            from dotenv import load_dotenv
            load_dotenv()
        except ImportError:
            pass
        try:
            import litellm
        except ImportError as exc:
            raise RuntimeError("LiteLLM is required for live model calls; install project dependencies") from exc

        started = time.monotonic()
        params = dict(model.params)
        try:
            response = await asyncio.wait_for(
                litellm.acompletion(
                    model=model.model,
                    messages=messages,
                    timeout=timeout,
                    **params,
                ),
                timeout=timeout,
            )
        except asyncio.TimeoutError as exc:
            raise TimeoutError(
                "LiteLLM call exceeded %.1f seconds" % timeout
            ) from exc
        choice = response["choices"][0] if isinstance(response, dict) else response.choices[0]
        message = choice["message"] if isinstance(choice, dict) else choice.message
        content = message["content"] if isinstance(message, dict) else message.content
        finish_reason = choice.get("finish_reason") if isinstance(choice, dict) else getattr(choice, "finish_reason", None)
        usage = response.get("usage", {}) if isinstance(response, dict) else getattr(response, "usage", {})
        if usage and not isinstance(usage, dict):
            if hasattr(usage, "model_dump"):
                usage = usage.model_dump()
            else:
                usage = dict(usage)
        usage = dict(usage or {})
        hidden = getattr(response, "_hidden_params", {}) or {}
        cost = response.get("cost") if isinstance(response, dict) else hidden.get("response_cost")
        if cost is not None:
            usage["cost"] = cost
        usage["latency_seconds"] = time.monotonic() - started
        returned_model = response.get("model") if isinstance(response, dict) else getattr(response, "model", None)
        response_metadata: Dict[str, Any] = {}
        for key in ("id", "created", "system_fingerprint", "service_tier"):
            value = response.get(key) if isinstance(response, dict) else getattr(response, key, None)
            if value is not None:
                response_metadata[key] = value
        provider = hidden.get("custom_llm_provider")
        if provider is not None:
            response_metadata["provider"] = provider
        reasoning_content = (
            message.get("reasoning_content")
            if isinstance(message, dict)
            else getattr(message, "reasoning_content", None)
        )
        if reasoning_content is not None:
            response_metadata["reasoning_content_present"] = bool(
                str(reasoning_content).strip()
            )
            response_metadata["reasoning_content_chars"] = len(
                str(reasoning_content)
            )
        return ModelResponse(
            content=str(content or ""),
            model=str(returned_model or model.model),
            usage=usage,
            finish_reason=str(finish_reason) if finish_reason is not None else None,
            response_metadata=response_metadata,
            raw=response,
        )


class CodexCLIModelClient(ModelClient):
    """Run a matched model treatment through non-interactive Codex CLI."""

    async def complete(self, model: ModelConfig, messages: List[Dict[str, str]], timeout: float) -> ModelResponse:
        executable = os.environ.get("CONTROLMAD_CODEX_EXECUTABLE") or shutil.which("codex")
        if not executable:
            raise RuntimeError("Codex CLI is required for provider=codex_cli but was not found on PATH")

        params = dict(model.params)
        reasoning_effort = params.pop("reasoning_effort", params.pop("model_reasoning_effort", None))
        output_schema = params.pop("output_schema", None)
        if params:
            raise ValueError(
                "Unsupported Codex CLI model params: %s" % ", ".join(sorted(params))
            )
        base_instructions = "\n\n".join(
            str(message.get("content", ""))
            for message in messages
            if message.get("role") in {"system", "developer"}
        )
        prompt_messages = [
            message for message in messages
            if message.get("role") not in {"system", "developer"}
        ]
        if len(prompt_messages) == 1 and prompt_messages[0].get("role") == "user":
            prompt = str(prompt_messages[0].get("content", ""))
        else:
            prompt = "\n\n".join(
                "%s:\n%s" % (
                    message.get("role", "user").capitalize(),
                    message.get("content", ""),
                )
                for message in prompt_messages
            )
        started = time.monotonic()
        with tempfile.TemporaryDirectory(prefix="controlmad-codex-") as temp_dir:
            command = [
                executable,
                "exec",
                "--ephemeral",
                "--ignore-user-config",
                "--ignore-rules",
                "--skip-git-repo-check",
                "--sandbox",
                "read-only",
                "--model",
                model.model,
            ]
            if reasoning_effort:
                command.extend(["-c", 'model_reasoning_effort="%s"' % reasoning_effort])
            if base_instructions:
                instructions_path = Path(temp_dir) / "model-instructions.txt"
                instructions_path.write_text(base_instructions, encoding="utf-8")
                command.extend([
                    "-c",
                    "model_instructions_file=%s" % json.dumps(str(instructions_path)),
                ])
            if output_schema:
                schema_path = Path(temp_dir) / "output-schema.json"
                schema_path.write_text(json.dumps(output_schema, sort_keys=True), encoding="utf-8")
                command.extend(["--output-schema", str(schema_path)])
            command.extend(["--json", "-"])

            stdout_path = Path(temp_dir) / "events.jsonl"
            stderr_path = Path(temp_dir) / "stderr.txt"
            with stdout_path.open("wb") as stdout_handle, stderr_path.open("wb") as stderr_handle:
                try:
                    completed_process = await asyncio.to_thread(
                        subprocess.run,
                        command,
                        cwd=temp_dir,
                        input=prompt.encode("utf-8"),
                        stdout=stdout_handle,
                        stderr=stderr_handle,
                        timeout=timeout,
                        check=False,
                    )
                except subprocess.TimeoutExpired:
                    raise TimeoutError("Codex CLI call exceeded %.1f seconds" % timeout)
            stdout_text = stdout_path.read_text(encoding="utf-8", errors="replace")
            stderr_text = stderr_path.read_text(encoding="utf-8", errors="replace")

        if completed_process.returncode != 0:
            diagnostics = [
                value for value in (stderr_text.strip(), stdout_text.strip()) if value
            ]
            detail = "\n".join(diagnostics) or "no diagnostic output"
            raise RuntimeError(
                "Codex CLI exited with code %s: %s"
                % (completed_process.returncode, detail)
            )

        events: List[Dict[str, Any]] = []
        for line in stdout_text.splitlines():
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError as exc:
                raise RuntimeError("Codex CLI emitted invalid JSONL: %s" % line) from exc
            if isinstance(event, dict):
                events.append(event)

        messages_out = [
            event.get("item", {}).get("text")
            for event in events
            if event.get("type") == "item.completed"
            and event.get("item", {}).get("type") == "agent_message"
            and event.get("item", {}).get("text")
        ]
        if not messages_out:
            raise RuntimeError("Codex CLI completed without a final agent message")

        usage: Dict[str, Any] = {}
        for event in events:
            if event.get("type") == "turn.completed" and isinstance(event.get("usage"), dict):
                usage = dict(event["usage"])
        usage["latency_seconds"] = time.monotonic() - started
        thread_id = next(
            (event.get("thread_id") for event in events if event.get("type") == "thread.started"),
            None,
        )
        metadata: Dict[str, Any] = {
            "provider": "codex_cli",
            "runtime": "codex_exec",
            "sandbox": "read-only",
            "ephemeral": True,
            "ignore_user_config": True,
            "ignore_rules": True,
            "base_instructions": "benchmark_override" if base_instructions else "codex_default",
        }
        if reasoning_effort:
            metadata["reasoning_effort"] = reasoning_effort
        if thread_id:
            metadata["thread_id"] = thread_id
        return ModelResponse(
            content=str(messages_out[-1]),
            model=model.model,
            usage=usage,
            finish_reason="completed",
            response_metadata=metadata,
            raw=events,
        )


def model_client_for_config(model: ModelConfig) -> ModelClient:
    if (model.provider or "").lower() == "codex_cli":
        return CodexCLIModelClient()
    return LiteLLMModelClient()
