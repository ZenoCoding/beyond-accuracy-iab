"""Prompt template loading and rendering."""

from pathlib import Path
from typing import Any

from .config import PromptConfig


class PromptStore:
    def __init__(self, config: PromptConfig, root: str) -> None:
        self.root = Path(root)
        self.templates = {
            name: self._read(value)
            for name, value in self._items(config).items()
            if value is not None
        }

    @staticmethod
    def _items(config: PromptConfig):
        if hasattr(config, "model_dump"):
            return config.model_dump()
        return config.dict()

    def _read(self, value: str) -> str:
        path = Path(value)
        if not path.is_absolute():
            path = self.root / path
        return path.read_text(encoding="utf-8")

    def render(self, name: str, **values: Any) -> str:
        try:
            return self.templates[name].format(**values)
        except KeyError as exc:
            raise ValueError("Prompt %r requires missing variable %s" % (name, exc.args[0]))
