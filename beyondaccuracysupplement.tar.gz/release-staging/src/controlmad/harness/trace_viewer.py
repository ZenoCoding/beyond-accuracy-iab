"""Generate a small, self-contained HTML reader for one task trace."""

from __future__ import annotations

from html import escape
import json
from pathlib import Path
import tempfile
from typing import Any, Dict, List, Optional, Tuple

import yaml


_PURPOSE_LABELS = {
    "initial_proposal": "Initial proposal",
    "debate_turn": "Debate",
    "self_adjustment": "Revision",
    "final_decision": "Final decision",
    "tie_break": "Tie-break",
    "consensus_tie_break": "Consensus tie-break",
    "verification": "Verifier check",
    "second_proposal": "Second-round proposal",
    "direct": "Answer",
    "direct_answer": "Answer",
}

_PURPOSE_PHASES = {
    "initial_proposal": "proposal",
    "debate_turn": "debate",
    "self_adjustment": "revision",
    "final_decision": "decision",
    "tie_break": "decision",
    "consensus_tie_break": "consensus",
    "verification": "verification",
    "second_proposal": "proposal",
    "direct": "answer",
    "direct_answer": "answer",
}


def _read_json(path: Path) -> Dict[str, Any]:
    if not path.is_file():
        return {}
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    return value if isinstance(value, dict) else {}


def _read_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.is_file():
        return []
    records = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError("Invalid JSON on line %d of %s" % (line_number, path)) from exc
            if isinstance(value, dict):
                records.append(value)
    return records


def _read_yaml(path: Path) -> Dict[str, Any]:
    if not path.is_file():
        return {}
    with path.open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle)
    return value if isinstance(value, dict) else {}


def _model_identity(model: Any, role: Optional[str]) -> Dict[str, Any]:
    model = model if isinstance(model, dict) else {}
    params = model.get("params") if isinstance(model.get("params"), dict) else {}
    return {
        "model": model.get("model"),
        "role": role,
        "reasoning_effort": params.get("reasoning_effort"),
    }


def _configured_agents(config: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """Return saved identities keyed by the IDs used in model-call records."""
    identities: Dict[str, Dict[str, Any]] = {}
    debate = config.get("debate")
    if isinstance(debate, dict):
        for agent in debate.get("agents", []):
            if not isinstance(agent, dict) or not agent.get("id"):
                continue
            identities[str(agent["id"])] = _model_identity(agent.get("model"), agent.get("role"))
        supervisor = debate.get("supervisor_model")
        if isinstance(supervisor, dict):
            identities["supervisor"] = _model_identity(supervisor, "supervisor")
    model = config.get("model")
    if isinstance(model, dict):
        identity = _model_identity(model, "solo")
        for key in (model.get("id"), model.get("model")):
            if key:
                identities[str(key)] = identity
    return identities


def _available_tasks(run_dir: Path) -> List[str]:
    manifest = _read_json(run_dir / "manifest.json")
    tasks = list(manifest.get("runs", {}))
    if not tasks and (run_dir / "tasks").is_dir():
        tasks = [path.name for path in (run_dir / "tasks").iterdir() if path.is_dir()]
    return sorted(tasks)


def resolve_task(run_dir: Path, task: Optional[str] = None) -> str:
    """Resolve a task id without allowing paths outside the run directory."""
    tasks = _available_tasks(run_dir)
    if task is not None:
        if task not in tasks:
            raise ValueError("Unknown task %r. Available tasks: %s" % (task, ", ".join(tasks[:12]) or "none"))
        return task
    if len(tasks) == 1:
        return tasks[0]
    if not tasks:
        raise ValueError("No task traces were found in %s" % run_dir)
    raise ValueError(
        "This run has %d task traces; choose one with --task. First tasks: %s"
        % (len(tasks), ", ".join(tasks[:12]))
    )


def _parsed_content(record: Dict[str, Any]) -> Any:
    content = record.get("response")
    if not isinstance(content, str):
        return content
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return content


def load_trace(run_dir: Path, task: Optional[str] = None) -> Dict[str, Any]:
    """Load the compact view model for a task attempt."""
    run_dir = Path(run_dir)
    task_id = resolve_task(run_dir, task)
    task_dir = run_dir / "tasks" / task_id
    result = _read_json(task_dir / "result.json")
    configured_agents = _configured_agents(_read_yaml(run_dir / "resolved_config.yaml"))
    manifest_record = _read_json(run_dir / "manifest.json").get("runs", {}).get(task_id, {})
    calls = _read_jsonl(task_dir / "model_calls.jsonl")
    prompts = _read_jsonl(task_dir / "prompts.jsonl")
    task_prompt = next(
        (
            record.get("prompt")
            for record in prompts
            if record.get("template") in {"initial_proposal", "direct_answer"}
            and isinstance(record.get("prompt"), str)
        ),
        None,
    )
    messages = []
    for index, record in enumerate(calls, 1):
        purpose = str(record.get("purpose") or "message")
        agent = str(record.get("agent_id") or record.get("configured_model") or "agent")
        messages.append({
            "index": index,
            "agent": agent,
            "model": record.get("returned_model") or record.get("model") or record.get("configured_model"),
            "purpose": purpose,
            "phase": _PURPOSE_PHASES.get(purpose, purpose.replace("_", "-")),
            "label": _PURPOSE_LABELS.get(purpose, purpose.replace("_", " ").title()),
            "pass": record.get("pass"),
            "player": record.get("player"),
            "status": record.get("status", "completed"),
            "content": _parsed_content(record),
            "latency_seconds": record.get("latency_seconds"),
            "usage": record.get("usage") or {},
            "finish_reason": record.get("finish_reason"),
            "error": record.get("error"),
        })
    if len(messages) == 1 and messages[0]["content"] is None and result.get("raw_response") is not None:
        fallback = result["raw_response"]
        if isinstance(fallback, str):
            try:
                fallback = json.loads(fallback)
            except json.JSONDecodeError:
                pass
        messages[0]["content"] = fallback
    agents = []
    seen = set()
    roles = result.get("agent_roles", {})
    models = result.get("models", {})
    for message in messages:
        agent = message["agent"]
        identity = configured_agents.get(agent, {})
        message["model"] = identity.get("model") or models.get(agent) or message["model"]
        message["role"] = identity.get("role") or roles.get(agent)
        message["reasoning_effort"] = identity.get("reasoning_effort")
        if agent not in seen:
            seen.add(agent)
            agents.append({
                "id": agent,
                "role": message["role"],
                "model": message["model"],
                "reasoning_effort": message["reasoning_effort"],
            })
    recorded_status = manifest_record.get("status") or "incomplete"
    status = result.get("status") or ("incomplete" if recorded_status == "completed" else recorded_status)
    return {
        "experiment": _read_json(run_dir / "manifest.json").get("experiment_id") or run_dir.name,
        "task": task_id,
        "status": status,
        "treatment": result.get("treatment") or ("direct" if messages and messages[0]["purpose"] == "direct" else "unknown"),
        "evaluation": result.get("evaluation") or {},
        "prediction": result.get("prediction") or {},
        "votes": result.get("votes") or {},
        "tied_players": result.get("tied_players") or [],
        "task_prompt": task_prompt,
        "agents": agents,
        "messages": messages,
    }


def _attributes(**values: Any) -> str:
    return " ".join('%s="%s"' % (key.replace("_", "-"), escape(str(value), quote=True)) for key, value in values.items())


def _role_grid(roles: Dict[str, Any]) -> str:
    if not roles:
        return ""
    items = []
    for player, role in roles.items():
        normalized_role = str(role).lower()
        role_class = " role-%s" % normalized_role if normalized_role in {"knight", "knave", "spy"} else ""
        items.append(
            '<div class="assignment%s"><span>%s</span><strong>%s</strong></div>'
            % (role_class, escape(str(player)), escape(str(role)))
        )
    return '<div class="assignments">%s</div>' % "".join(items)


def _reasoning(content: Dict[str, Any]) -> str:
    parts = []
    for key in ("explanation", "agree_reasoning", "disagree_reasoning"):
        value = content.get(key)
        if value:
            parts.append('<p class="reasoning">%s</p>' % escape(str(value)))
    agree = content.get("agree_with")
    disagree = content.get("disagree_with")
    if agree:
        parts.append('<p class="stance agree">Agrees with %s</p>' % escape(", ".join(map(str, agree))))
    if disagree:
        parts.append('<p class="stance disagree">Challenges %s</p>' % escape(", ".join(map(str, disagree))))
    verdict = content.get("verdict")
    if verdict:
        parts.append('<p class="reasoning"><strong>Verdict:</strong> %s</p>' % escape(str(verdict)))
    checks = content.get("checks")
    if isinstance(checks, list):
        for check in checks:
            if not isinstance(check, dict):
                continue
            text = "%s: %s" % (check.get("result", "check"), check.get("test", ""))
            if check.get("error"):
                text += " — %s" % check["error"]
            parts.append('<p class="stance">%s</p>' % escape(text))
    errors = content.get("errors")
    if isinstance(errors, list) and errors:
        parts.append(
            '<p class="stance disagree">Errors: %s</p>'
            % escape("; ".join(map(str, errors)))
        )
    return "".join(parts)


def _identity_text(identity: Dict[str, Any]) -> str:
    parts = []
    if identity.get("model"):
        parts.append(str(identity["model"]))
    effort = identity.get("reasoning_effort")
    reasoning = "%s reasoning" % effort if effort is not None else "reasoning not set"
    if identity.get("role"):
        parts.append("%s (%s)" % (identity["role"], reasoning))
    else:
        parts.append("(%s)" % reasoning)
    return " · ".join(parts)


def _message_html(message: Dict[str, Any], color_index: int) -> str:
    content = message["content"]
    if isinstance(content, dict):
        body = _role_grid(content.get("roles", {})) + _reasoning(content)
        raw = json.dumps(content, indent=2, ensure_ascii=False, sort_keys=True)
    else:
        body = '<p class="reasoning">%s</p>' % escape(str(content or message.get("error") or "No response recorded."))
        raw = str(content or message.get("error") or "")
    context = []
    if message.get("pass") is not None:
        context.append("Pass %s" % message["pass"])
    if message.get("player"):
        context.append(str(message["player"]))
    meta = []
    if message.get("latency_seconds") is not None:
        meta.append("%.1fs" % float(message["latency_seconds"]))
    usage = message.get("usage", {})
    tokens = usage.get("total_tokens") or usage.get("input_tokens") or usage.get("prompt_tokens")
    if tokens:
        meta.append("%s tokens" % tokens)
    if message.get("status") != "completed":
        meta.append(str(message["status"]))
    details = ""
    if raw or meta:
        details = '<details><summary>Raw response%s</summary><pre>%s</pre></details>' % (
            " · " + " · ".join(meta) if meta else "",
            escape(raw),
        )
    return (
        '<article class="message agent-color-%d" %s tabindex="0">'
        '<header><div><div><span class="agent">%s</span><span class="purpose">%s</span></div>'
        '<div class="identity">%s</div></div>'
        '<span class="context">%s</span></header>%s%s</article>'
    ) % (
        color_index % 6,
        _attributes(data_agent=message["agent"], data_phase=message["phase"]),
        escape(message["agent"]),
        escape(message["label"]),
        escape(_identity_text(message)),
        escape(" · ".join(context)),
        body,
        details,
    )


def _summary_html(trace: Dict[str, Any]) -> str:
    evaluation = trace["evaluation"]
    correct = evaluation.get("semantic_strict")
    if correct is None:
        correct = evaluation.get("strict")
    outcome = ""
    if correct is not None:
        outcome = '<span class="outcome %s">%s</span>' % (
            "correct" if float(correct) == 1 else "incorrect",
            "Correct" if float(correct) == 1 else "Incorrect",
        )
    prediction = _role_grid(trace["prediction"])
    task_prompt = ""
    if trace.get("task_prompt"):
        task_prompt = '<details class="task-prompt"><summary>Task and instructions</summary><pre>%s</pre></details>' % escape(
            str(trace["task_prompt"])
        )
    return '<section class="summary"><div>%s<span class="status">%s</span></div>%s%s</section>' % (
        outcome,
        escape(str(trace["status"]).title()),
        prediction,
        task_prompt,
    )


def render_trace_html(trace: Dict[str, Any]) -> str:
    """Render a self-contained, offline trace reader."""
    agent_colors = {agent["id"]: index for index, agent in enumerate(trace["agents"])}
    messages = "".join(_message_html(message, agent_colors.get(message["agent"], 0)) for message in trace["messages"])
    agent_buttons = "".join(
        '<button class="filter" %s><i class="agent-color-%d"></i><span>%s</span><small>%s</small></button>'
        % (
            _attributes(data_agent=agent["id"]),
            index % 6,
            escape(agent["id"]),
            escape(_identity_text(agent)),
        )
        for index, agent in enumerate(trace["agents"])
    )
    phases = []
    for message in trace["messages"]:
        pair = (message["phase"], message["label"])
        if pair not in phases:
            phases.append(pair)
    phase_buttons = "".join(
        '<button class="phase" %s>%s</button>' % (_attributes(data_phase=phase), escape(label))
        for phase, label in phases
    )
    empty = '<div class="empty">No model messages have been recorded for this attempt yet.</div>' if not messages else ""
    title = "%s · %s" % (trace["experiment"], trace["task"])
    return """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>%(title)s</title>
<style>
:root{--paper:#f7f6f2;--ink:#20211f;--muted:#72736e;--line:#deddd7;--card:#fff;--accent:#2c5148}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;line-height:1.5}
.shell{width:min(760px,calc(100%% - 32px));margin:0 auto;padding:56px 0 96px}h1{font-family:ui-serif,Georgia,serif;font-size:clamp(28px,5vw,42px);line-height:1.08;letter-spacing:-.025em;margin:8px 0}.eyebrow,.context,.purpose,.status,.identity{color:var(--muted);font-size:12px;letter-spacing:.04em}.eyebrow{text-transform:uppercase}.lede{color:var(--muted);margin:0 0 24px}.summary{border-block:1px solid var(--line);padding:16px 0;margin:28px 0}.summary>div:first-child{display:flex;gap:10px;align-items:center}.outcome,.status{border:1px solid var(--line);border-radius:99px;padding:3px 9px}.outcome.correct{background:#e7f1eb;color:#245b3c;border-color:#c9dfd0}.outcome.incorrect{background:#f6e8e5;color:#873e32;border-color:#e8cbc5}
.controls{position:sticky;top:0;z-index:2;background:color-mix(in srgb,var(--paper) 93%%,transparent);backdrop-filter:blur(12px);padding:12px 0;border-bottom:1px solid var(--line)}.control-row{display:flex;gap:7px;overflow:auto;scrollbar-width:none;margin-top:7px}.control-row:first-child{margin-top:0}.filter,.phase{white-space:nowrap;border:1px solid var(--line);background:var(--card);border-radius:99px;padding:6px 10px;color:var(--ink);cursor:pointer;font:inherit;font-size:13px}.filter.active,.phase.active{background:var(--ink);color:#fff;border-color:var(--ink)}.filter i{display:inline-block;width:7px;height:7px;border-radius:50%%;margin-right:6px}.filter small{display:block;margin-left:13px;color:var(--muted);font-size:10px}.filter.active small{color:#c9cbc5}
.stream{margin-top:24px}.message{--agent:#526d82;background:var(--card);border:1px solid var(--line);border-left:3px solid var(--agent);border-radius:8px;padding:16px 18px;margin:10px 0;box-shadow:0 1px 0 rgba(0,0,0,.025)}.message:focus{outline:2px solid color-mix(in srgb,var(--agent) 55%%,transparent);outline-offset:2px}.message[hidden]{display:none}.message header{display:flex;justify-content:space-between;gap:16px;margin-bottom:12px}.agent{font-weight:700;margin-right:9px}.purpose{letter-spacing:0}.identity{letter-spacing:0;margin-top:2px}.reasoning{margin:10px 0;white-space:pre-wrap}.stance{font-size:13px;margin:6px 0;color:var(--muted)}.stance.agree::before{content:"+ ";color:#2e7650}.stance.disagree::before{content:"− ";color:#a44b3d}
.assignments{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:6px;margin:10px 0}.assignment{display:flex;justify-content:space-between;gap:10px;background:#f4f3ef;border:1px solid transparent;border-radius:5px;padding:6px 8px;font-size:13px}.assignment span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--muted)}.assignment strong{font-weight:650;text-transform:capitalize}.assignment.role-knight{background:#e9f0f7;border-color:#ceddec}.assignment.role-knight strong{color:#315f88}.assignment.role-knave{background:#f7ebe8;border-color:#ead1ca}.assignment.role-knave strong{color:#8b473b}.assignment.role-spy{background:#f6f0df;border-color:#e7d9ad}.assignment.role-spy strong{color:#7c621c}details{border-top:1px solid #ebeae5;margin-top:14px;padding-top:10px}summary{cursor:pointer;color:var(--muted);font-size:12px}pre{white-space:pre-wrap;word-break:break-word;font:12px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace;background:#f4f3ef;border-radius:5px;padding:12px;max-height:360px;overflow:auto}.empty{color:var(--muted);padding:32px 0;text-align:center}
.agent-color-0{--agent:#477568;background-color:#477568}.message.agent-color-0{background-color:var(--card)}.agent-color-1{--agent:#866b46;background-color:#866b46}.message.agent-color-1{background-color:var(--card)}.agent-color-2{--agent:#646f9c;background-color:#646f9c}.message.agent-color-2{background-color:var(--card)}.agent-color-3{--agent:#9a5f69;background-color:#9a5f69}.message.agent-color-3{background-color:var(--card)}.agent-color-4{--agent:#53778a;background-color:#53778a}.message.agent-color-4{background-color:var(--card)}.agent-color-5{--agent:#78658d;background-color:#78658d}.message.agent-color-5{background-color:var(--card)}
@media(max-width:560px){.shell{width:min(100%% - 22px,760px);padding-top:28px}.message{padding:14px}.message header{display:block}.context{display:block;margin-top:3px}.assignments{grid-template-columns:1fr 1fr}}
@media(prefers-color-scheme:dark){:root{--paper:#171816;--ink:#edeee9;--muted:#a5a69f;--line:#383a35;--card:#20221f;--accent:#91b9aa}.assignment,pre{background:#292b27}.assignment.role-knight{background:#202d38;border-color:#344b5e}.assignment.role-knight strong{color:#9ec3e1}.assignment.role-knave{background:#382625;border-color:#5b3935}.assignment.role-knave strong{color:#e6aaa0}.assignment.role-spy{background:#342f20;border-color:#554b2b}.assignment.role-spy strong{color:#dec77e}.outcome.correct{background:#1f3829;color:#a9d5b7;border-color:#345b41}.outcome.incorrect{background:#3d2926;color:#e2aaa1;border-color:#63423c}}
</style></head><body><main class="shell">
<div class="eyebrow">%(experiment)s · %(treatment)s trace</div><h1>%(task)s</h1><p class="lede">%(count)d messages from %(agents)d agents</p>
%(summary)s
<nav class="controls" aria-label="Trace filters"><div class="control-row"><button class="filter active" data-agent="all">All agents</button>%(agent_buttons)s</div><div class="control-row"><button class="phase active" data-phase="all">All phases</button>%(phase_buttons)s</div></nav>
<section class="stream" aria-live="polite">%(messages)s%(empty)s</section>
</main><script>
const state={agent:'all',phase:'all'};
function apply(){document.querySelectorAll('.message').forEach(m=>m.hidden=!((state.agent==='all'||m.dataset.agent===state.agent)&&(state.phase==='all'||m.dataset.phase===state.phase)));}
document.querySelectorAll('.filter').forEach(b=>b.addEventListener('click',()=>{state.agent=b.dataset.agent;document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x===b));apply();}));
document.querySelectorAll('.phase').forEach(b=>b.addEventListener('click',()=>{state.phase=b.dataset.phase;document.querySelectorAll('.phase').forEach(x=>x.classList.toggle('active',x===b));apply();}));
document.addEventListener('keydown',e=>{if(!['j','k'].includes(e.key)||e.metaKey||e.ctrlKey)return;const visible=[...document.querySelectorAll('.message:not([hidden])')],i=visible.indexOf(document.activeElement),next=e.key==='j'?Math.min(i+1,visible.length-1):Math.max(i-1,0);if(visible[next])visible[next].focus();});
</script></body></html>""" % {
        "title": escape(title), "experiment": escape(str(trace["experiment"])),
        "treatment": escape(str(trace["treatment"])), "task": escape(str(trace["task"])),
        "count": len(trace["messages"]), "agents": len(trace["agents"]),
        "summary": _summary_html(trace), "agent_buttons": agent_buttons,
        "phase_buttons": phase_buttons, "messages": messages, "empty": empty,
    }


def write_trace_html(run_dir: Path, task: Optional[str] = None, output: Optional[Path] = None) -> Tuple[Path, str]:
    """Write a trace reader and return its path and resolved task id."""
    trace = load_trace(Path(run_dir), task)
    if output is None:
        output = Path(tempfile.gettempdir()) / "controlmad-traces" / Path(run_dir).name / (trace["task"] + ".html")
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_trace_html(trace), encoding="utf-8")
    return output.resolve(), trace["task"]
