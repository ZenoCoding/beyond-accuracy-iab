"""Read-only launch checks for benchmark experiments and suites."""

import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, Iterable, List

from .benchmark import BenchmarkTask, benchmark_from_config
from .config import ModelConfig, ResolvedConfig, ResolvedSuiteConfig, load_config
from .prompts import PromptStore
from .storage import ExperimentStorage, experiment_identity


_PROVIDER_CREDENTIALS = {
    "anthropic": ("ANTHROPIC_API_KEY",),
    "dashscope": ("DASHSCOPE_API_KEY", "QWEN_API_KEY"),
    "deepinfra": ("DEEPINFRA_API_KEY",),
    "gemini": ("GEMINI_API_KEY", "GOOGLE_API_KEY"),
    "google": ("GEMINI_API_KEY", "GOOGLE_API_KEY"),
    "openai": ("OPENAI_API_KEY",),
    "openrouter": ("OPENROUTER_API_KEY",),
}


def _stable_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _provider_name(model: ModelConfig) -> str:
    if model.provider:
        return model.provider.lower()
    return model.model.split("/", 1)[0].lower()


def _credential_status(model: ModelConfig) -> Dict[str, Any]:
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass
    provider = _provider_name(model)
    if provider == "codex_cli":
        executable = shutil.which("codex")
        present: List[str] = []
        if os.getenv("CODEX_API_KEY"):
            present.append("CODEX_API_KEY")
        if executable:
            try:
                status = subprocess.run(
                    [executable, "login", "status"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False,
                )
                if status.returncode == 0:
                    present.append("codex_authenticated_session")
            except (OSError, subprocess.SubprocessError):
                pass
        return {
            "provider": provider,
            "expected_any_of": ["CODEX_API_KEY", "codex_authenticated_session"],
            "present": present,
            "executable": executable,
            "ok": bool(executable and present),
        }
    expected = _PROVIDER_CREDENTIALS.get(provider, ())
    present = [name for name in expected if os.getenv(name)]
    return {
        "provider": provider,
        "expected_any_of": list(expected),
        "present": present,
        "ok": not expected or bool(present),
    }


def _task_payload(tasks: Iterable[BenchmarkTask]) -> List[Dict[str, Any]]:
    return [
        {
            "id": task.id,
            "prompt": task.prompt,
            "answer": task.answer,
            "metadata": task.metadata,
        }
        for task in tasks
    ]


def _run_dir(config: ResolvedConfig) -> Path:
    return Path(config.config_root) / config.run.output_dir / config.experiment_id


def preflight_experiment(
    config: ResolvedConfig,
    *,
    require_credentials: bool = False,
    check_output: bool = True,
) -> Dict[str, Any]:
    """Load all launch inputs and return an actionable, machine-readable report."""
    errors: List[str] = []
    warnings: List[str] = []
    tasks: List[BenchmarkTask] = []

    try:
        tasks = benchmark_from_config(config.benchmark, config.config_root).load()
    except Exception as exc:
        errors.append("benchmark: %s" % exc)

    ids = [task.id for task in tasks]
    if not tasks and not errors:
        errors.append("benchmark selected zero tasks")
    if len(ids) != len(set(ids)):
        errors.append("benchmark selected duplicate task IDs")

    try:
        prompts = PromptStore(config.prompts, config.config_root)
        if tasks:
            sample = tasks[0]
            values = {
                "task": sample.prompt,
                "task_id": sample.id,
                "size": sample.metadata.get("size", ""),
                "agent_id": "preflight-agent",
                "role": "debater",
                "role_description": "Participate in every debate phase.",
                "player": sample.metadata.get("players", [""])[0],
                "context": "{}",
                "other_agent_ids": '["preflight-peer-1", "preflight-peer-2"]',
                "assignment_requirements": (
                    '- You MUST assign each player one of the three roles: '
                    '"knight", "knave", or "spy"'
                ),
            }
            prompts.render("system", **values)
            if config.treatment == "direct":
                prompts.render("direct_answer", **values)
            else:
                for name in (
                    "initial_proposal",
                    "debate_turn",
                    "self_adjustment",
                    "final_decision",
                    "supervisor",
                ):
                    prompts.render(name, **values)
                if config.debate.workflow == "verifier_a":
                    prompts.render("verification", **values)
                elif config.debate.workflow == "verifier_b":
                    for name in ("verification", "second_proposal"):
                        prompts.render(name, **values)
    except Exception as exc:
        errors.append("prompts: %s" % exc)

    models = (
        [config.model]
        if config.model is not None
        else [agent.model for agent in config.debate.agents] + [config.debate.supervisor_model]
        if config.debate is not None
        else []
    )
    credentials_by_provider: Dict[str, Dict[str, Any]] = {}
    for model in models:
        if (
            model.structured_output_mode != "none"
            and "response_format" in model.params
        ):
            errors.append(
                "model %s declares structured_output_mode=%s and a static "
                "params.response_format; remove the static response format"
                % (model.id, model.structured_output_mode)
            )
        if (
            config.treatment == "debate"
            and config.debate is not None
            and config.debate.require_structured_output
            and model.structured_output_mode == "none"
        ):
            errors.append(
                "constrained JSON experiment model %s must declare a provider "
                "structured output mode" % model.id
            )
        status = _credential_status(model)
        credentials_by_provider.setdefault(status["provider"], status)
    credentials = list(credentials_by_provider.values())
    missing_credentials = [status for status in credentials if not status["ok"]]
    for status in missing_credentials:
        if len(credentials) == 1:
            message = "credentials: set one of %s" % ", ".join(status["expected_any_of"])
            warning = "no provider credential found; set one of %s before a live run" % ", ".join(
                status["expected_any_of"]
            )
        else:
            message = "credentials for %s: set one of %s" % (
                status["provider"],
                ", ".join(status["expected_any_of"]),
            )
            warning = message
        if require_credentials:
            errors.append(message)
        else:
            warnings.append(warning)

    run_dir = _run_dir(config).resolve()
    resolved_path = run_dir / "resolved_config.yaml"
    if check_output and run_dir.exists() and not resolved_path.exists():
        errors.append("output directory exists without resolved_config.yaml: %s" % run_dir)
    elif check_output and run_dir.exists():
        storage = ExperimentStorage(str(run_dir))
        manifest = storage.load_manifest()
        previous_fingerprint = manifest.get("experiment_fingerprint")
        if not previous_fingerprint:
            errors.append(
                "output directory is a legacy run without an immutable fingerprint: %s" % run_dir
            )
        elif tasks:
            current_fingerprint = experiment_identity(config, tasks)["fingerprint"]
            if previous_fingerprint != current_fingerprint:
                errors.append(
                    "output directory fingerprint does not match current launch inputs: %s" % run_dir
                )

    if config.treatment == "debate" and config.debate is not None:
        roles = {role.id: role for role in config.debate.roles}
        capability_counts = {
            capability: sum(
                capability in roles[agent.role].capabilities
                for agent in config.debate.agents
            )
            for capability in ("propose", "debate", "revise", "final_vote")
        }
        def calls_for_task(task: BenchmarkTask) -> int:
            player_count = len(task.metadata.get("players", []))
            calls = (
                capability_counts["propose"]
                + capability_counts["final_vote"]
                + config.debate.passes
                * player_count
                * (capability_counts["debate"] + capability_counts["revise"])
            )
            if config.debate.workflow == "verifier_a":
                calls += 1
            elif config.debate.workflow == "verifier_b":
                calls += (
                    1
                    + capability_counts["propose"]
                    + player_count
                    * (capability_counts["debate"] + capability_counts["revise"])
                )
            return calls

        planned_calls = sum(calls_for_task(task) for task in tasks) * config.benchmark.repetitions
        possible_tie_breaks = 2 if config.debate.workflow != "standard" else 1
        maximum_calls = (
            planned_calls
            + possible_tie_breaks * len(tasks) * config.benchmark.repetitions
        ) * (
            config.debate.format_repair_max_retries + 1
        ) * (config.run.max_retries + 1) * (config.run.model_call_max_retries + 1)
    else:
        planned_calls = len(tasks) * config.benchmark.repetitions
        maximum_calls = (
            planned_calls
            * (config.run.direct_format_repair_max_retries + 1)
            * (config.run.max_retries + 1)
            * (config.run.model_call_max_retries + 1)
        )
    model_ids = [model.id for model in models]
    model_names = [model.model for model in models]
    return {
        "ok": not errors,
        "experiment_id": config.experiment_id,
        "treatment": config.treatment,
        "model_id": model_ids[0] if len(model_ids) == 1 else None,
        "model": model_names[0] if len(model_names) == 1 else None,
        "model_ids": model_ids,
        "models": model_names,
        "structured_output_modes": {
            model.id: model.structured_output_mode for model in models
        },
        "run_dir": str(run_dir),
        "run_dir_exists": run_dir.exists(),
        "selected_tasks": len(tasks),
        "repetitions": config.benchmark.repetitions,
        "planned_runs": len(tasks) * config.benchmark.repetitions,
        "planned_model_calls": planned_calls,
        "maximum_model_calls": maximum_calls,
        "task_payload_sha256": _stable_hash(_task_payload(tasks)) if tasks else None,
        "credentials": credentials[0] if len(credentials) == 1 else credentials,
        "errors": errors,
        "warnings": warnings,
    }


def preflight_suite(
    suite: ResolvedSuiteConfig,
    *,
    require_credentials: bool = False,
) -> Dict[str, Any]:
    """Preflight every experiment and reject cross-experiment collisions."""
    experiments: List[Dict[str, Any]] = []
    load_errors: List[str] = []
    for path in suite.experiments:
        try:
            experiments.append(
                preflight_experiment(load_config(path), require_credentials=require_credentials)
            )
        except Exception as exc:
            load_errors.append("%s: %s" % (path, exc))

    ids = [item["experiment_id"] for item in experiments]
    run_dirs = [item["run_dir"] for item in experiments]
    collisions: List[str] = []
    if len(ids) != len(set(ids)):
        collisions.append("duplicate experiment IDs")
    if len(run_dirs) != len(set(run_dirs)):
        collisions.append("multiple experiments resolve to the same run directory")

    errors = load_errors + collisions
    if any(not item["ok"] for item in experiments):
        errors.append("one or more experiment preflights failed")
    planned_model_calls = sum(item["planned_model_calls"] for item in experiments)
    if (
        suite.safety.max_model_calls is not None
        and suite.safety.max_model_calls < planned_model_calls
    ):
        errors.append(
            "suite max_model_calls (%d) is below the normal-path plan (%d)"
            % (suite.safety.max_model_calls, planned_model_calls)
        )
    if suite.safety.max_cost_usd is not None:
        configured_models = {
            model
            for item in experiments
            for model in item.get("models", [])
        }
        missing_prices = sorted(
            configured_models - set(suite.safety.model_token_prices)
        )
        if missing_prices:
            errors.append(
                "cost budget requires token prices for: %s"
                % ", ".join(missing_prices)
            )
    return {
        "ok": not errors,
        "suite_id": suite.suite_id,
        "experiment_count": len(experiments),
        "selected_tasks": sum(item["selected_tasks"] for item in experiments),
        "planned_model_calls": planned_model_calls,
        "maximum_model_calls": sum(item["maximum_model_calls"] for item in experiments),
        "experiments": experiments,
        "errors": errors,
    }
