"""Single-model, single-call benchmark execution."""

from copy import deepcopy
import json
from pathlib import Path
import time
from typing import Any, Awaitable, Callable, Dict, List, Optional

from .benchmark import BenchmarkTask
from .config import ModelConfig, ResolvedConfig
from .events import make_event
from .evaluator import Evaluator, ProofInitialProposalEvaluator, evaluator_for_kind
from .models import ModelClient, ModelResponse, model_client_for_config
from .prompts import PromptStore
from .storage import ExperimentStorage
from .structured_output import model_with_direct_output_contract


_PROOF_CONTRACTS = {
    "proof_initial_proposal",
    "simple_proof_initial_proposal",
    "json_then_proof_initial_proposal",
}


class DirectExecutor:
    def __init__(
        self,
        config: ResolvedConfig,
        storage: ExperimentStorage,
        model_client: ModelClient = None,
        evaluator: Evaluator = None,
        run_model_call: Optional[
            Callable[
                [
                    ModelConfig,
                    str,
                    Callable[[], Awaitable[ModelResponse]],
                    Callable[[int, Exception, float], None],
                ],
                Awaitable[ModelResponse],
            ]
        ] = None,
    ) -> None:
        self.config = config
        self.storage = storage
        if config.model is None:
            raise ValueError("DirectExecutor requires config.model")
        self.model_client = model_client or model_client_for_config(config.model)
        if evaluator is not None:
            self.evaluator = evaluator
        elif config.run.direct_output_contract in _PROOF_CONTRACTS:
            self.evaluator = ProofInitialProposalEvaluator()
        else:
            self.evaluator = evaluator_for_kind(
                config.benchmark.kind,
                strict_json=(
                    "response_format" in config.model.params
                    or config.model.structured_output_mode != "none"
                ),
                require_explanation=(
                    config.run.direct_output_contract == "initial_proposal"
                ),
                max_explanation_words=(
                    99
                    if config.run.direct_output_contract == "initial_proposal"
                    else None
                ),
            )
        self.prompts = PromptStore(config.prompts, config.config_root)
        self.run_model_call = run_model_call

    def _emit(self, event_type: str, run_id: str, **payload: Any) -> None:
        event = make_event(event_type, self.config.experiment_id, run_id, **payload)
        self.storage.append_event(event, task=True)
        self.storage.append_event(event, task=False)

    def _record_prompt(self, run_id: str, name: str, rendered: str) -> None:
        self.storage.append_jsonl(run_id, "prompts.jsonl", {
            "template": name,
            "prompt": rendered,
        })
        self._emit("prompt_rendered", run_id, template=name)

    @staticmethod
    def _model_for_format_repair(model: ModelConfig) -> ModelConfig:
        """Make a malformed-output retry mechanical and tightly bounded."""
        prepared = (
            model.model_copy(deep=True)
            if hasattr(model, "model_copy")
            else model.copy(deep=True)
        )
        params = deepcopy(prepared.params)
        repair_reasoning = prepared.format_repair_reasoning
        if repair_reasoning == "preserve":
            prepared.params = params
            return prepared
        extra_body = params.get("extra_body")
        reasoning = (
            extra_body.get("reasoning")
            if isinstance(extra_body, dict)
            else None
        )
        if isinstance(reasoning, dict) and repair_reasoning == "disable":
            extra_body["reasoning"] = {"enabled": False}
        thinking = params.get("thinking")
        if isinstance(thinking, dict) and repair_reasoning == "disable":
            params["thinking"] = {
                "type": "disabled",
                "budget_tokens": 0,
            }
        if "reasoning_effort" in params:
            params["reasoning_effort"] = (
                "minimal" if repair_reasoning == "minimal" else "none"
            )
        if (
            isinstance(reasoning, dict)
            or isinstance(thinking, dict)
            or "reasoning_effort" in params
        ):
            max_tokens = params.get("max_tokens")
            if isinstance(max_tokens, int):
                params["max_tokens"] = min(max_tokens, 2048)
        prepared.params = params
        return prepared

    @staticmethod
    def _clip_initial_proposal_explanation(
        response: str,
        max_words: int = 99,
    ) -> Optional[str]:
        """Enforce the debate word cap without granting another inference call."""
        try:
            parsed = json.loads(response)
        except (json.JSONDecodeError, TypeError):
            return None
        if not isinstance(parsed, dict) or "roles" not in parsed:
            return None
        explanation = parsed.get("explanation")
        if not isinstance(explanation, str):
            return None
        words = explanation.split()
        if len(words) <= max_words:
            return None
        parsed["explanation"] = " ".join(words[:max_words])
        return json.dumps(parsed, ensure_ascii=False, separators=(",", ":"))

    def _model_for_task(
        self,
        task: BenchmarkTask,
    ) -> tuple[ModelConfig, Dict[str, Any]]:
        """Resolve the output contract against this task's exact player set."""
        params = deepcopy(self.config.model.params)
        if self.config.run.direct_output_contract in _PROOF_CONTRACTS:
            params.pop("response_format", None)
            plain_model = ModelConfig(
                id=self.config.model.id,
                model=self.config.model.model,
                provider=self.config.model.provider,
                structured_output_mode="none",
                format_repair_reasoning=self.config.model.format_repair_reasoning,
                params=params,
            )
            return plain_model, {
                "version": "direct-proof-initial-v1",
                "mode": "plain_text",
                "schema_name": None,
                "response_format": None,
            }
        response_format = params.get("response_format", {})
        json_schema = response_format.get("json_schema", {})
        schema = json_schema.get("schema", {})
        roles = schema.get("properties", {}).get("roles")
        if (
            self.config.benchmark.kind == "kks"
            and response_format.get("type") == "json_schema"
            and isinstance(roles, dict)
        ):
            players = list(task.metadata.get("players", []))
            roles["properties"] = {
                player: {
                    "type": "string",
                    "enum": ["knight", "knave", "spy"],
                }
                for player in players
            }
            roles["required"] = players
            roles["additionalProperties"] = False
        legacy_model = ModelConfig(
            id=self.config.model.id,
            model=self.config.model.model,
            provider=self.config.model.provider,
            structured_output_mode=self.config.model.structured_output_mode,
            params=params,
        )
        if self.config.benchmark.kind != "kks":
            return legacy_model, {
                "version": None,
                "mode": legacy_model.structured_output_mode,
                "schema_name": None,
                "response_format": params.get("response_format"),
            }
        return model_with_direct_output_contract(
            legacy_model,
            list(task.metadata.get("players", [])),
            include_explanation=(
                self.config.run.direct_output_contract == "initial_proposal"
            ),
        )

    async def _call(
        self,
        run_id: str,
        messages: List[Dict[str, str]],
        model: ModelConfig,
        *,
        format_repair_attempt: int = 0,
        output_contract: Optional[Dict[str, Any]] = None,
    ) -> ModelResponse:
        started = time.monotonic()
        self._emit(
            "model_call_started",
            run_id,
            model=self.config.model.model,
            purpose="direct",
            format_repair_attempt=format_repair_attempt,
            output_contract=output_contract,
        )
        try:
            async def complete() -> ModelResponse:
                return await self.model_client.complete(
                    model,
                    messages,
                    self.config.run.timeout_seconds,
                )

            def record_retry(attempt: int, exc: Exception, delay: float) -> None:
                self.storage.append_jsonl(run_id, "model_calls.jsonl", {
                    "model": self.config.model.model,
                    "configured_model": self.config.model.model,
                    "purpose": "direct",
                    "format_repair_attempt": format_repair_attempt,
                    "output_contract": output_contract,
                    "status": "retryable_failure",
                    "attempt": attempt,
                    "error": str(exc),
                    "retry_delay_seconds": delay,
                })
                self._emit(
                    "model_call_retry_scheduled",
                    run_id,
                    model=self.config.model.model,
                    purpose="direct",
                    format_repair_attempt=format_repair_attempt,
                    output_contract=output_contract,
                    failed_attempt=attempt,
                    retry_delay_seconds=delay,
                    error=str(exc),
                )

            response = (
                await self.run_model_call(
                    model,
                    "%s:direct" % run_id,
                    complete,
                    record_retry,
                )
                if self.run_model_call is not None
                else await complete()
            )
        except Exception as exc:
            self.storage.append_jsonl(run_id, "model_calls.jsonl", {
                "model": self.config.model.model,
                "configured_model": self.config.model.model,
                "purpose": "direct",
                "format_repair_attempt": format_repair_attempt,
                "output_contract": output_contract,
                "status": "failed",
                "error": str(exc),
                "latency_seconds": time.monotonic() - started,
            })
            raise
        self.storage.append_jsonl(run_id, "model_calls.jsonl", {
            "model": response.model,
            "configured_model": self.config.model.model,
            "returned_model": response.model,
            "purpose": "direct",
            "format_repair_attempt": format_repair_attempt,
            "output_contract": output_contract,
            "status": "completed",
            "finish_reason": response.finish_reason,
            "response_metadata": response.response_metadata,
            "usage": response.usage,
            "response": response.content,
            "model_call_count": 1,
            "latency_seconds": time.monotonic() - started,
        })
        self._emit(
            "model_call_completed",
            run_id,
            model=response.model,
            configured_model=self.config.model.model,
            returned_model=response.model,
            format_repair_attempt=format_repair_attempt,
            output_contract=output_contract,
            finish_reason=response.finish_reason,
            response_metadata=response.response_metadata,
            usage=response.usage,
        )
        return response

    async def run(self, run_id: str, task: BenchmarkTask, repetition: int, attempt: int = 1) -> Dict[str, Any]:
        self.storage.upsert_run(
            run_id,
            status="running",
            task_id=task.id,
            repetition=repetition,
            attempt=attempt,
            started_at=time.time(),
        )
        self._emit("run_started", run_id, task_id=task.id, repetition=repetition, attempt=attempt)
        self._emit("task_loaded", run_id, task_id=task.id)

        values = {
            "task": task.prompt,
            "task_id": task.id,
            "size": task.metadata.get("size", ""),
        }
        system = self.prompts.render("system", **values)
        user = self.prompts.render("direct_answer", **values)
        verification_candidate = None
        if self.config.run.direct_output_contract in _PROOF_CONTRACTS:
            from .proof_proposal import (
                proof_initial_proposal_prompt,
                simple_proof_initial_proposal_prompt,
            )

            players = list(task.metadata.get("players", []))
            if self.config.run.direct_output_contract == "proof_initial_proposal":
                user = proof_initial_proposal_prompt(task.prompt, players)
            else:
                if (
                    self.config.run.direct_output_contract
                    == "json_then_proof_initial_proposal"
                ):
                    source = self.config.run.proof_verification_source_dir
                    if not source:
                        raise ValueError(
                            "json_then_proof_initial_proposal requires "
                            "run.proof_verification_source_dir"
                        )
                    source_dir = Path(source)
                    if not source_dir.is_absolute():
                        source_dir = Path(self.config.config_root) / source_dir
                    candidate_path = source_dir / "tasks" / run_id / "result.json"
                    if not candidate_path.exists():
                        raise ValueError(
                            "missing JSON proposal for verification: %s"
                            % candidate_path
                        )
                    verification_candidate = json.loads(
                        candidate_path.read_text(encoding="utf-8")
                    )
                    if verification_candidate.get("task_id") != task.id:
                        raise ValueError(
                            "verification candidate task does not match %s" % task.id
                        )
                user = simple_proof_initial_proposal_prompt(
                    task.prompt,
                    players,
                    candidate=verification_candidate,
                )
        self._record_prompt(run_id, "system", system)
        self._record_prompt(run_id, "direct_answer", user)
        model, output_contract = self._model_for_task(task)
        response = None
        evaluation = None
        enforce_output_contract = (
            self.config.run.direct_output_contract in _PROOF_CONTRACTS
            or self.config.model.structured_output_mode != "none"
            or self.config.run.direct_format_repair_max_retries > 0
        )
        for repair_attempt in range(
            self.config.run.direct_format_repair_max_retries + 1
        ):
            current_user = user
            if repair_attempt:
                protocol_errors = evaluation.get("protocol_errors", [])
                parser_feedback = (
                    "; ".join(str(error) for error in protocol_errors)
                    or "response violated the required output contract"
                )
                requested_format = (
                    "plain-text FINAL and proof-line contract"
                    if self.config.run.direct_output_contract in _PROOF_CONTRACTS
                    else "JSON schema"
                )
                repair_request = (
                    "FORMAT REPAIR ONLY\n"
                    + "Your previous response could not be accepted because it "
                    + "violated the required output contract. Preserve the same "
                    + "substantive answer. Correct only the output format; do not "
                    + "reconsider the puzzle or use external feedback. Return exactly "
                    + "one response in the originally requested "
                    + requested_format
                    + "."
                    + "\n\nFORMAT ERRORS\n"
                    + parser_feedback
                    + "\n\nPREVIOUS RESPONSE\n"
                    + response.content
                )
                current_user = (
                    user + "\n\n" + repair_request
                    if self.config.run.direct_output_contract in _PROOF_CONTRACTS
                    else repair_request
                )
                self._record_prompt(
                    run_id,
                    "format_repair",
                    current_user,
                )
            response = await self._call(
                run_id,
                [
                    {"role": "system", "content": system},
                    {"role": "user", "content": current_user},
                ],
                (
                    self._model_for_format_repair(model)
                    if repair_attempt
                    else model
                ),
                format_repair_attempt=repair_attempt,
                output_contract=output_contract,
            )
            evaluation = self.evaluator.evaluate(task, response.content)
            if (
                self.config.run.direct_output_contract == "initial_proposal"
                and evaluation.get("protocol_errors")
                == ["response explanation must contain at most 99 words"]
            ):
                clipped = self._clip_initial_proposal_explanation(
                    response.content
                )
                if clipped is not None:
                    response.content = clipped
                    evaluation = self.evaluator.evaluate(task, response.content)
                    self._emit(
                        "explanation_clipped",
                        run_id,
                        purpose="direct",
                        format_repair_attempt=repair_attempt,
                        max_words=99,
                    )
            if not enforce_output_contract:
                break
            if evaluation.get("protocol_valid"):
                self._emit(
                    "format_response_accepted",
                    run_id,
                    purpose="direct",
                    format_repair_attempt=repair_attempt,
                    repaired=bool(repair_attempt),
                )
                break
            terminal = (
                repair_attempt
                >= self.config.run.direct_format_repair_max_retries
                or not response.content.strip()
            )
            self._emit(
                "format_response_rejected",
                run_id,
                purpose="direct",
                format_repair_attempt=repair_attempt,
                terminal=terminal,
                error="; ".join(
                    str(error)
                    for error in evaluation.get("protocol_errors", [])
                )
                or "response violated the direct-answer output contract",
            )
            if terminal:
                if self.config.run.direct_record_terminal_invalid:
                    break
                raise ValueError(
                    "direct response violated the required output contract"
                )
        assert response is not None and evaluation is not None
        self._emit("answer_submitted", run_id, answer=response.content)
        self._emit("evaluation_completed", run_id, evaluation=evaluation)

        result = {
            "run_id": run_id,
            "task_id": task.id,
            "repetition": repetition,
            "attempt": attempt,
            "model": response.model,
            "configured_model": self.config.model.model,
            "finish_reason": response.finish_reason,
            "response_metadata": response.response_metadata,
            "raw_response": response.content,
            "prediction": evaluation.get("prediction"),
            "evaluation": evaluation,
            **(
                {"proof_proposal": evaluation.get("proposal")}
                if self.config.run.direct_output_contract in _PROOF_CONTRACTS
                else {}
            ),
            **(
                {
                    "verification_source": {
                        "experiment_id": verification_candidate.get("run_id"),
                        "raw_response": verification_candidate.get("raw_response"),
                        "prediction": verification_candidate.get("prediction"),
                    }
                }
                if verification_candidate is not None
                else {}
            ),
            "usage": response.usage,
            "metadata": task.metadata,
            "status": "completed",
        }
        self.storage.write_json(run_id, "result.json", result)
        self.storage.write_transcript(
            run_id,
            "# Direct evaluation: %s\n\n## Response\n%s\n" % (task.id, response.content),
        )
        self.storage.upsert_run(
            run_id,
            status="completed",
            completed_at=time.time(),
            result_path="tasks/%s/result.json" % run_id,
        )
        self._emit("run_completed", run_id, task_id=task.id, evaluation=evaluation)
        return result
