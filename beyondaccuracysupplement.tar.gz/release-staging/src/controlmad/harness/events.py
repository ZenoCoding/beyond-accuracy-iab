"""Event records emitted by the harness."""

from datetime import datetime, timezone
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class Event(BaseModel):
    type: str
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    experiment_id: Optional[str] = None
    run_id: Optional[str] = None
    payload: Dict[str, Any] = Field(default_factory=dict)


def make_event(event_type: str, experiment_id: Optional[str] = None, run_id: Optional[str] = None, **payload: Any) -> Event:
    return Event(type=event_type, experiment_id=experiment_id, run_id=run_id, payload=payload)


def event_dict(event: Event) -> Dict[str, Any]:
    if hasattr(event, "model_dump"):
        return event.model_dump()  # type: ignore[attr-defined]
    return event.dict()
