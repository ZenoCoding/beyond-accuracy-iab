"""Command-line interface for the ControlMAD harness."""

import json
from pathlib import Path
import shlex
from typing import Optional
import webbrowser

import typer

from .analysis import run_analysis
from .analysis.formal_logic_compact import run_compact_evaluation
from .analysis.formal_logic_compact_fields import (
    run_compact_fields,
    run_compact_initials,
)
from .analysis.formal_logic_field_gold import evaluate_field_gold_files
from .analysis.formal_logic_benchmark_report import analyze_compact_benchmark
from .analysis.formal_logic_minimal_report import analyze_minimal_reasoning
from .analysis.formal_logic_minimal import (
    evaluate_minimal_gold_file,
    rescore_minimal_file,
    run_minimal_claims,
    run_minimal_end_to_end_rerun,
    run_minimal_initials,
    run_minimal_manifest,
    run_minimal_relation_rerun,
    score_minimal_file,
    validate_minimal_development_gold,
)
from .analysis.formal_logic_checker import run_minimal_checker
from .analysis.formal_logic import run_formalizations
from .analysis.formal_logic_report import analyze_formalizations
from .analysis.formal_logic_viewer import write_formalization_html
from .analysis.formal_logic_proof import (
    check_proof_trace as check_proof_trace_nodes,
    parse_proof_trace,
    run_proof_canary,
)
from .analysis.judge import run_judge
from .harness.config import load_config, load_suite_config
from .harness.comparison import compare_runtime_results
from .harness.preflight import preflight_experiment, preflight_suite
from .harness.runner import ExperimentRunner, config_from_resolved_dict
from .harness.storage import ExperimentStorage
from .harness.suite import run_suite
from .harness.trace_viewer import write_trace_html

app = typer.Typer(add_completion=False, no_args_is_help=True)


def _print_counts(counts):
    typer.echo(json.dumps(counts, sort_keys=True))


def _print_progress(progress) -> None:
    command = shlex.join(progress["command"])
    planned_calls = progress["planned_calls"]
    completion_percentage = (
        100.0 * progress["completed_calls"] / planned_calls
        if planned_calls
        else 100.0
    )
    typer.echo(
        "jobs %d/%d | calls %d/%d (%.1f%%) | %s: %s"
        % (
            progress["completed_jobs"],
            progress["planned_jobs"],
            progress["completed_calls"],
            planned_calls,
            completion_percentage,
            progress["experiment_id"],
            command,
        )
    )


def _progress_printer(command, launch, experiment_id):
    def print_progress(counts) -> None:
        _print_progress({
            "completed_jobs": counts.get("completed", 0),
            "planned_jobs": launch["planned_runs"],
            "completed_calls": counts.get("completed_model_calls", 0),
            "planned_calls": launch["planned_model_calls"],
            "experiment_id": experiment_id,
            "command": command,
        })

    return print_progress


def _require_launch_ready(resolved):
    report = preflight_experiment(resolved, require_credentials=True)
    if not report["ok"]:
        raise ValueError("Preflight failed: %s" % "; ".join(report["errors"]))
    return report


@app.command()
def validate(config: Path = typer.Option(..., "--config", exists=True, readable=True)):
    """Validate an experiment, benchmark tasks, and prompt templates."""
    try:
        resolved = load_config(str(config))
        report = preflight_experiment(
            resolved,
            require_credentials=False,
            check_output=False,
        )
        if not report["ok"]:
            raise ValueError("; ".join(report["errors"]))
    except Exception as exc:
        typer.echo("Invalid configuration: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command()
def preflight(
    config: Path = typer.Option(..., "--config", exists=True, readable=True),
    require_credentials: bool = typer.Option(
        False,
        "--require-credentials/--allow-missing-credentials",
    ),
):
    """Report exact launch inputs and optionally require provider credentials."""
    try:
        report = preflight_experiment(
            load_config(str(config)),
            require_credentials=require_credentials,
        )
    except Exception as exc:
        typer.echo("Preflight failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))
    if not report["ok"]:
        raise typer.Exit(code=1)


@app.command("suite-preflight")
def suite_preflight(
    config: Path = typer.Option(..., "--config", exists=True, readable=True),
    require_credentials: bool = typer.Option(
        False,
        "--require-credentials/--allow-missing-credentials",
    ),
):
    """Validate every solo experiment and detect suite-level collisions."""
    try:
        report = preflight_suite(
            load_suite_config(str(config)),
            require_credentials=require_credentials,
        )
    except Exception as exc:
        typer.echo("Suite preflight failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))
    if not report["ok"]:
        raise typer.Exit(code=1)


@app.command("suite-run")
def suite_run(config: Path = typer.Option(..., "--config", exists=True, readable=True)):
    """Preflight and run a solo suite; rerun this command to resume safely."""
    try:
        typer.echo("Running: %s" % shlex.join(["controlmad", "suite-run", "--config", str(config)]))
        report = run_suite(
            load_suite_config(str(config)),
            require_credentials=True,
            progress_callback=_print_progress,
        )
    except Exception as exc:
        typer.echo("Suite run failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))
    if report["status"] != "completed":
        raise typer.Exit(code=1)


@app.command()
def run(config: Path = typer.Option(..., "--config", exists=True, readable=True)):
    """Execute configured benchmark tasks."""
    try:
        resolved = load_config(str(config))
        launch = _require_launch_ready(resolved)
        command = ["controlmad", "run", "--config", str(config)]
        typer.echo("Running: %s" % shlex.join(command))
        counts = ExperimentRunner(resolved).run(
            progress_callback=_progress_printer(command, launch, resolved.experiment_id)
        )
    except Exception as exc:
        typer.echo("Run failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    _print_counts(counts)


@app.command()
def status(run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False)):
    """Show manifest-derived run counts."""
    _print_counts(ExperimentStorage(str(run_dir)).status_counts())


@app.command("compare-runtimes")
def compare_runtimes(
    left_run_dir: Path = typer.Option(..., "--left-run-dir", exists=True, file_okay=False),
    right_run_dir: Path = typer.Option(..., "--right-run-dir", exists=True, file_okay=False),
):
    """Run an exact paired McNemar test over semantic strict correctness."""
    try:
        report = compare_runtime_results(left_run_dir, right_run_dir)
    except Exception as exc:
        typer.echo("Runtime comparison failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command()
def analyze(config: Path = typer.Option(..., "--config", exists=True, readable=True)):
    """Generate paper-aligned statistical reports from stored debate runs."""
    try:
        report = run_analysis(config)
    except Exception as exc:
        typer.echo("Analysis failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps({
        "analysis_id": report["analysis_id"],
        "output_dir": report["output_dir"],
        "row_counts": report["row_counts"],
        "warnings": report["warnings"],
    }, indent=2, sort_keys=True))


@app.command("judge-debates")
def judge_debates(config: Path = typer.Option(..., "--config", exists=True, readable=True)):
    """Score cached debate arguments with a blinded, configurable judge model."""
    try:
        report = run_judge(config)
    except Exception as exc:
        typer.echo("Debate judging failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("formalize-reasoning")
def formalize_reasoning(
    run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False),
    task_id: str = typer.Option(..., "--task-id"),
    model_config: Path = typer.Option(..., "--model-config", exists=True, readable=True),
    output: Path = typer.Option(..., "--output", dir_okay=False),
    timeout_seconds: float = typer.Option(600.0, "--timeout-seconds", min=1.0),
    concurrency: int = typer.Option(1, "--concurrency", min=1),
):
    """Translate and mechanically check saved KKS reasoning."""
    try:
        report = run_formalizations(
            run_dir.resolve(),
            task_id,
            model_config.resolve(),
            output.resolve(),
            timeout_seconds=timeout_seconds,
            concurrency=concurrency,
        )
    except Exception as exc:
        typer.echo("Reasoning formalization failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("evaluate-compact-translator")
def evaluate_compact_translator_command(
    gold: Path = typer.Option(..., "--gold", exists=True, readable=True, dir_okay=False),
    model_config: Path = typer.Option(..., "--model-config", exists=True, readable=True),
    output: Path = typer.Option(..., "--output", dir_okay=False),
    batch_size: int = typer.Option(10, "--batch-size", min=1),
    concurrency: int = typer.Option(5, "--concurrency", min=1),
    timeout_seconds: float = typer.Option(300.0, "--timeout-seconds", min=1.0),
):
    """Evaluate compact non-JSON claim translation against reference claims."""
    try:
        report = run_compact_evaluation(
            gold.resolve(), model_config.resolve(), output.resolve(),
            batch_size=batch_size,
            concurrency=concurrency,
            timeout_seconds=timeout_seconds,
        )
    except Exception as exc:
        typer.echo("Compact translation evaluation failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps({
        key: report[key]
        for key in (
            "model", "reasoning_effort", "format", "case_count", "passed_count",
            "failed_count", "conclusion_fidelity", "batch_count", "wall_time_seconds",
            "contained_claim_count", "contained_claim_rate", "parse_error_count", "usage",
        )
    }, indent=2, sort_keys=True))


@app.command("translate-compact-fields")
def translate_compact_fields_command(
    run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False),
    task_id: str = typer.Option(..., "--task-id"),
    model_config: Path = typer.Option(..., "--model-config", exists=True, readable=True),
    output: Path = typer.Option(..., "--output", dir_okay=False),
    concurrency: int = typer.Option(5, "--concurrency", min=1),
    timeout_seconds: float = typer.Option(300.0, "--timeout-seconds", min=1.0),
):
    """Translate complete KKS fields into attribution-aware compact claims."""
    try:
        report = run_compact_fields(
            run_dir.resolve(), task_id, model_config.resolve(), output.resolve(),
            concurrency=concurrency, timeout_seconds=timeout_seconds,
        )
    except Exception as exc:
        typer.echo("Compact field translation failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("translate-minimal-claims")
def translate_minimal_claims_command(
    run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False),
    task_id: str = typer.Option(..., "--task-id"),
    model_config: Path = typer.Option(
        ..., "--model-config", exists=True, readable=True, dir_okay=False
    ),
    output: Path = typer.Option(..., "--output", dir_okay=False),
    concurrency: int = typer.Option(5, "--concurrency", min=1),
    timeout_seconds: float = typer.Option(
        300.0, "--timeout-seconds", min=1.0
    ),
):
    """Translate KKS reasoning into claims, flat cases, and local relations."""
    try:
        report = run_minimal_claims(
            run_dir.resolve(),
            task_id,
            model_config.resolve(),
            output.resolve(),
            concurrency=concurrency,
            timeout_seconds=timeout_seconds,
        )
    except Exception as exc:
        typer.echo("Minimal claim translation failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("score-minimal-claims")
def score_minimal_claims_command(
    input_path: Path = typer.Option(
        ..., "--input", exists=True, readable=True, dir_okay=False
    ),
    dataset: Path = typer.Option(
        ..., "--dataset", exists=True, readable=True, file_okay=False
    ),
    output: Optional[Path] = typer.Option(None, "--output", dir_okay=False),
):
    """Score atomic claims, cases, and local reasoning relations."""
    try:
        report = score_minimal_file(input_path.resolve(), dataset.resolve())
        if output is not None:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(
                json.dumps(report, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
    except Exception as exc:
        typer.echo("Minimal claim scoring failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(
        json.dumps(
            {key: value for key, value in report.items() if key != "rows"},
            indent=2,
            sort_keys=True,
        )
    )


@app.command("translate-minimal-initials")
def translate_minimal_initials_command(
    run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False),
    manifest: Path = typer.Option(
        ..., "--manifest", exists=True, readable=True, dir_okay=False
    ),
    model_config: Path = typer.Option(
        ..., "--model-config", exists=True, readable=True, dir_okay=False
    ),
    output: Path = typer.Option(..., "--output", dir_okay=False),
    concurrency: int = typer.Option(5, "--concurrency", min=1),
    timeout_seconds: float = typer.Option(
        300.0, "--timeout-seconds", min=1.0
    ),
):
    """Translate exactly the frozen manifest's initial explanations."""
    try:
        report = run_minimal_initials(
            run_dir.resolve(),
            manifest.resolve(),
            model_config.resolve(),
            output.resolve(),
            concurrency=concurrency,
            timeout_seconds=timeout_seconds,
        )
    except Exception as exc:
        typer.echo("Minimal initial translation failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("rescore-minimal-claims")
def rescore_minimal_claims_command(
    input_path: Path = typer.Option(
        ..., "--input", exists=True, readable=True, dir_okay=False
    ),
    output: Optional[Path] = typer.Option(None, "--output", dir_okay=False),
):
    """Reparse saved minimal-translator responses without model calls."""
    try:
        report = rescore_minimal_file(
            input_path.resolve(), output.resolve() if output else None
        )
    except Exception as exc:
        typer.echo("Minimal claim rescoring failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("translate-minimal-manifest")
def translate_minimal_manifest_command(
    run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False),
    manifest: Path = typer.Option(
        ..., "--manifest", exists=True, readable=True, dir_okay=False
    ),
    model_config: Path = typer.Option(
        ..., "--model-config", exists=True, readable=True, dir_okay=False
    ),
    repair_model_config: Optional[Path] = typer.Option(
        None, "--repair-model-config", exists=True, readable=True, dir_okay=False
    ),
    relation_model_config: Optional[Path] = typer.Option(
        None, "--relation-model-config", exists=True, readable=True, dir_okay=False,
        help="Optional second-pass model that may extract relations only.",
    ),
    output: Path = typer.Option(..., "--output", dir_okay=False),
    concurrency: int = typer.Option(5, "--concurrency", min=1),
    resume: bool = typer.Option(
        False, "--resume", help="Reuse validated records already checkpointed to output."
    ),
    checkpoint_every: int = typer.Option(
        10, "--checkpoint-every", min=1,
        help="Atomically save after this many newly completed fields."
    ),
    max_retries: int = typer.Option(2, "--max-retries", min=0),
    retry_backoff_seconds: float = typer.Option(
        1.0, "--retry-backoff-seconds", min=0.0
    ),
    timeout_seconds: float = typer.Option(300.0, "--timeout-seconds", min=1.0),
):
    """Translate exact mixed-stage reasoning fields selected by a manifest."""
    try:
        report = run_minimal_manifest(
            run_dir.resolve(),
            manifest.resolve(),
            model_config.resolve(),
            output.resolve(),
            concurrency=concurrency,
            resume=resume,
            checkpoint_every=checkpoint_every,
            max_retries=max_retries,
            retry_backoff_seconds=retry_backoff_seconds,
            timeout_seconds=timeout_seconds,
            repair_model_config=(
                repair_model_config.resolve() if repair_model_config else None
            ),
            relation_model_config=(
                relation_model_config.resolve() if relation_model_config else None
            ),
        )
    except Exception as exc:
        typer.echo("Minimal manifest translation failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("rerun-minimal-relations")
def rerun_minimal_relations_command(
    input_path: Path = typer.Option(
        ..., "--input", exists=True, readable=True, dir_okay=False
    ),
    relation_model_config: Path = typer.Option(
        ..., "--relation-model-config", exists=True, readable=True, dir_okay=False
    ),
    output: Path = typer.Option(..., "--output", dir_okay=False),
    repair_model_config: Optional[Path] = typer.Option(
        None, "--repair-model-config", exists=True, readable=True, dir_okay=False
    ),
    concurrency: int = typer.Option(5, "--concurrency", min=1),
    timeout_seconds: float = typer.Option(300.0, "--timeout-seconds", min=1.0),
    relation_prompt_profile: str = typer.Option(
        "v1", "--relation-prompt-profile", help="v1 or explicit"
    ),
):
    """Replace only relations in existing minimal-translation JSONL records."""
    try:
        report = run_minimal_relation_rerun(
            input_path.resolve(),
            relation_model_config.resolve(),
            output.resolve(),
            concurrency=concurrency,
            timeout_seconds=timeout_seconds,
            repair_model_config=(
                repair_model_config.resolve() if repair_model_config else None
            ),
            relation_prompt_profile=relation_prompt_profile,
        )
    except Exception as exc:
        typer.echo("Minimal relation rerun failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("rerun-minimal-end-to-end")
def rerun_minimal_end_to_end_command(
    input_path: Path = typer.Option(
        ..., "--input", exists=True, readable=True, dir_okay=False
    ),
    dataset: Path = typer.Option(
        ..., "--dataset", exists=True, readable=True, file_okay=False
    ),
    claim_model_config: Path = typer.Option(
        ..., "--claim-model-config", exists=True, readable=True, dir_okay=False
    ),
    relation_model_config: Path = typer.Option(
        ..., "--relation-model-config", exists=True, readable=True, dir_okay=False
    ),
    output: Path = typer.Option(..., "--output", dir_okay=False),
    repair_model_config: Optional[Path] = typer.Option(
        None, "--repair-model-config", exists=True, readable=True, dir_okay=False
    ),
    concurrency: int = typer.Option(5, "--concurrency", min=1),
    timeout_seconds: float = typer.Option(300.0, "--timeout-seconds", min=1.0),
):
    """Regenerate claims/cases, then relations, from saved source fields only."""
    try:
        report = run_minimal_end_to_end_rerun(
            input_path.resolve(),
            dataset.resolve(),
            claim_model_config.resolve(),
            relation_model_config.resolve(),
            output.resolve(),
            concurrency=concurrency,
            timeout_seconds=timeout_seconds,
            repair_model_config=(
                repair_model_config.resolve() if repair_model_config else None
            ),
        )
    except Exception as exc:
        typer.echo("Minimal end-to-end rerun failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("check-minimal-translations")
def check_minimal_translations_command(
    input_path: Path = typer.Option(
        ..., "--input", exists=True, readable=True, dir_okay=False
    ),
    model_config: Path = typer.Option(
        ..., "--model-config", exists=True, readable=True, dir_okay=False
    ),
    output: Path = typer.Option(..., "--output", dir_okay=False),
    architecture: str = typer.Option(
        "full_field",
        "--architecture",
        help="full_field, suspect_routed, abstain_resolution, span_first, or context_routed",
    ),
    dataset: Optional[Path] = typer.Option(
        None, "--dataset", exists=True, readable=True, file_okay=False
    ),
    concurrency: int = typer.Option(5, "--concurrency", min=1),
    timeout_seconds: float = typer.Option(300.0, "--timeout-seconds", min=1.0),
):
    """Run a conservative claim-level check-my-work pass over saved translations."""
    try:
        report = run_minimal_checker(
            input_path.resolve(),
            model_config.resolve(),
            output.resolve(),
            architecture=architecture,
            dataset_path=dataset.resolve() if dataset else None,
            concurrency=concurrency,
            timeout_seconds=timeout_seconds,
        )
    except Exception as exc:
        typer.echo("Minimal translation checker failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("evaluate-minimal-translator")
def evaluate_minimal_translator_command(
    input_path: Path = typer.Option(
        ..., "--input", exists=True, readable=True, dir_okay=False
    ),
    gold: list[Path] = typer.Option(
        ..., "--gold", exists=True, readable=True, dir_okay=False
    ),
    dataset: Optional[Path] = typer.Option(
        None, "--dataset", exists=True, readable=True, file_okay=False
    ),
    output: Optional[Path] = typer.Option(None, "--output", dir_okay=False),
):
    """Audit claims and any optional v2 case/relation gold."""
    try:
        report = evaluate_minimal_gold_file(
            input_path.resolve(),
            [path.resolve() for path in gold],
            dataset.resolve() if dataset else None,
        )
        if output is not None:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(
                json.dumps(report, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
    except Exception as exc:
        typer.echo("Minimal translator evaluation failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report["primary_metrics"], indent=2, sort_keys=True))


@app.command("validate-minimal-gold")
def validate_minimal_gold_command(
    run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False),
    manifest: Path = typer.Option(
        ..., "--manifest", exists=True, readable=True, dir_okay=False
    ),
    gold: Path = typer.Option(
        ..., "--gold", exists=True, readable=True, dir_okay=False
    ),
):
    """Validate exhaustive v2 gold against exact completed-run sources."""
    try:
        report = validate_minimal_development_gold(
            run_dir.resolve(), manifest.resolve(), gold.resolve()
        )
    except Exception as exc:
        typer.echo("Minimal gold validation failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("evaluate-field-translator")
def evaluate_field_translator_command(
    input_path: Path = typer.Option(
        ..., "--input", exists=True, readable=True, dir_okay=False
    ),
    gold: Path = typer.Option(
        ..., "--gold", exists=True, readable=True, dir_okay=False
    ),
    output: Optional[Path] = typer.Option(None, "--output", dir_okay=False),
):
    """Evaluate compact translations against whole-field expert gold."""
    try:
        report = evaluate_field_gold_files(input_path.resolve(), gold.resolve())
        if output is not None:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(
                json.dumps(report, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
    except Exception as exc:
        typer.echo("Field translation evaluation failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps({
        key: value
        for key, value in report.items()
        if key != "rows"
    }, indent=2, sort_keys=True))


@app.command("translate-compact-initials")
def translate_compact_initials_command(
    run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False),
    manifest: Path = typer.Option(
        ..., "--manifest", exists=True, readable=True, dir_okay=False
    ),
    model_config: Path = typer.Option(
        ..., "--model-config", exists=True, readable=True
    ),
    output: Path = typer.Option(..., "--output", dir_okay=False),
    concurrency: int = typer.Option(5, "--concurrency", min=1),
    prompt_version: str = typer.Option("v3", "--prompt-version"),
    timeout_seconds: float = typer.Option(
        300.0, "--timeout-seconds", min=1.0
    ),
):
    """Translate only frozen initial explanations into compact claims."""
    try:
        report = run_compact_initials(
            run_dir.resolve(),
            manifest.resolve(),
            model_config.resolve(),
            output.resolve(),
            concurrency=concurrency,
            prompt_version=prompt_version,
            timeout_seconds=timeout_seconds,
        )
    except Exception as exc:
        typer.echo("Compact initial translation failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("analyze-formalizations")
def analyze_formal_logic(
    input_path: Path = typer.Option(..., "--input", exists=True, readable=True, dir_okay=False),
    output_dir: Path = typer.Option(..., "--output-dir", file_okay=False),
    expected_fields: Optional[int] = typer.Option(None, "--expected-fields", min=1),
    run_dir: Optional[Path] = typer.Option(None, "--run-dir", exists=True, file_okay=False),
):
    """Summarize formalized reasoning by step, field, agent, and stage."""
    try:
        report = analyze_formalizations(
            input_path.resolve(),
            output_dir.resolve(),
            expected_fields=expected_fields,
            run_dir=run_dir.resolve() if run_dir else None,
        )
    except Exception as exc:
        typer.echo("Formalization analysis failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("analyze-compact-benchmark")
def analyze_compact_benchmark_command(
    config: Path = typer.Option(
        ..., "--config", exists=True, readable=True, dir_okay=False
    ),
    output_dir: Path = typer.Option(..., "--output-dir", file_okay=False),
):
    """Compare compact formalizations against a field-level gold benchmark."""
    try:
        report = analyze_compact_benchmark(config.resolve(), output_dir.resolve())
    except Exception as exc:
        typer.echo("Compact benchmark analysis failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command("analyze-minimal-reasoning")
def analyze_minimal_reasoning_command(
    config: Path = typer.Option(
        ..., "--config", exists=True, readable=True, dir_okay=False
    ),
    output_dir: Path = typer.Option(..., "--output-dir", file_okay=False),
):
    """Analyze minimal claims by field, agent/round, debate, and outcome."""
    try:
        report = analyze_minimal_reasoning(
            config.resolve(), output_dir.resolve()
        )
    except Exception as exc:
        typer.echo("Minimal reasoning analysis failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


def _runner_for_dir(run_dir: Path) -> ExperimentRunner:
    storage = ExperimentStorage(str(run_dir))
    resolved = config_from_resolved_dict(storage.load_resolved_config())
    return ExperimentRunner(resolved, run_dir=str(run_dir))


@app.command()
def resume(
    run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False),
    concurrency: Optional[int] = typer.Option(None, "--concurrency", min=1),
):
    """Continue incomplete or failed work from a run directory."""
    try:
        runner = _runner_for_dir(run_dir)
        if concurrency is not None:
            runner.config.run.concurrency = concurrency
        launch = _require_launch_ready(runner.config)
        command = ["controlmad", "resume", "--run-dir", str(run_dir)]
        if concurrency is not None:
            command.extend(["--concurrency", str(concurrency)])
        typer.echo("Running: %s" % shlex.join(command))
        _print_counts(runner.resume(
            progress_callback=_progress_printer(
                command,
                launch,
                runner.config.experiment_id,
            )
        ))
    except Exception as exc:
        typer.echo("Resume failed: %s" % exc, err=True)
        raise typer.Exit(code=1)


@app.command("retry-failed")
def retry_failed(run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False)):
    """Create new attempts for failed runs."""
    try:
        runner = _runner_for_dir(run_dir)
        launch = _require_launch_ready(runner.config)
        command = ["controlmad", "retry-failed", "--run-dir", str(run_dir)]
        typer.echo("Running: %s" % shlex.join(command))
        _print_counts(runner.retry_failed(
            progress_callback=_progress_printer(
                command,
                launch,
                runner.config.experiment_id,
            )
        ))
    except Exception as exc:
        typer.echo("Retry failed: %s" % exc, err=True)
        raise typer.Exit(code=1)


@app.command("trace")
def trace(
    run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False),
    task: Optional[str] = typer.Option(None, "--task", help="Task attempt id; optional when the run has one task."),
    output: Optional[Path] = typer.Option(None, "--output", dir_okay=False, help="HTML destination; defaults to a temporary directory."),
    open_browser: bool = typer.Option(False, "--open/--no-open", help="Open the generated reader in the default browser."),
):
    """Build a lightweight, offline reader for one agent trace."""
    try:
        path, resolved_task = write_trace_html(run_dir, task, output)
    except Exception as exc:
        typer.echo("Trace generation failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps({"task": resolved_task, "trace": str(path)}, indent=2))
    if open_browser:
        webbrowser.open(path.as_uri())


@app.command("logic-trace")
def logic_trace(
    input_path: Path = typer.Option(
        ..., "--input", exists=True, readable=True, dir_okay=False,
        help="Compact formalizations or proof-v2 canary JSONL file.",
    ),
    task: Optional[str] = typer.Option(None, "--task", help="Source task id."),
    agent: Optional[str] = typer.Option(None, "--agent", help="Source agent id."),
    formalization_id: Optional[str] = typer.Option(None, "--id", help="Exact formalization id."),
    output: Optional[Path] = typer.Option(
        None, "--output", dir_okay=False,
        help="HTML destination; defaults to a temporary directory.",
    ),
    open_browser: bool = typer.Option(
        False, "--open/--no-open", help="Open the generated reader in the default browser."
    ),
):
    """Inspect one compact or proof-v2 translation and its dependencies."""
    try:
        path, record = write_formalization_html(
            input_path,
            task=task,
            agent=agent,
            formalization_id=formalization_id,
            output=output,
        )
    except Exception as exc:
        typer.echo("Logic trace generation failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    source = record.get("source") or {}
    typer.echo(json.dumps({
        "task": source.get("task_id"),
        "agent": source.get("agent_id"),
        "logic_trace": str(path),
    }, indent=2))
    if open_browser:
        webbrowser.open(path.as_uri())


@app.command("check-proof-trace")
def check_proof_trace_command(
    trace_path: Path = typer.Option(
        ..., "--trace", exists=True, readable=True, dir_okay=False,
        help="Proof-v2 line trace.",
    ),
    source_path: Path = typer.Option(
        ..., "--source", exists=True, readable=True, dir_okay=False,
        help="Exact source reasoning text used by the trace.",
    ),
    output: Optional[Path] = typer.Option(
        None, "--output", dir_okay=False,
        help="Optional JSON report destination.",
    ),
):
    """Parse and structurally check a proof-v2 trace without model calls."""
    source_text = source_path.read_text(encoding="utf-8").strip()
    nodes, errors = parse_proof_trace(
        trace_path.read_text(encoding="utf-8"), source_text
    )
    report = {
        "format_version": "kks-proof-v2-draft",
        "trace": str(trace_path.resolve()),
        "source": str(source_path.resolve()),
        "node_count": len(nodes),
        "errors": errors,
        "checks": check_proof_trace_nodes(nodes),
        "nodes": nodes,
    }
    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
    typer.echo(json.dumps(report, indent=2, sort_keys=True))
    if errors:
        raise typer.Exit(code=1)


@app.command("translate-proof-canary")
def translate_proof_canary_command(
    cases: Path = typer.Option(..., "--cases", exists=True, readable=True, dir_okay=False),
    dataset: Path = typer.Option(..., "--dataset", exists=True, readable=True, file_okay=False),
    model_config: Path = typer.Option(..., "--model-config", exists=True, readable=True, dir_okay=False),
    output: Path = typer.Option(..., "--output", dir_okay=False),
    concurrency: int = typer.Option(4, "--concurrency", min=1),
    timeout_seconds: float = typer.Option(300.0, "--timeout-seconds", min=1.0),
):
    """Run a proof-v2 translator canary; report reliability, not accuracy."""
    try:
        report = run_proof_canary(
            cases.resolve(),
            dataset.resolve(),
            model_config.resolve(),
            output.resolve(),
            concurrency=concurrency,
            timeout_seconds=timeout_seconds,
        )
    except Exception as exc:
        typer.echo("Proof canary failed: %s" % exc, err=True)
        raise typer.Exit(code=1)
    typer.echo(json.dumps(report, indent=2, sort_keys=True))


@app.command()
def rescore(run_dir: Path = typer.Option(..., "--run-dir", exists=True, file_okay=False)):
    """Re-evaluate stored raw responses and rebuild aggregate artifacts."""
    try:
        _print_counts(_runner_for_dir(run_dir).rescore())
    except Exception as exc:
        typer.echo("Rescore failed: %s" % exc, err=True)
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()
