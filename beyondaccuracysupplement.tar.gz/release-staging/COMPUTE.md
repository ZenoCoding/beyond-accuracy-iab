# Compute and execution record

The 40 fresh eight-player debates were executed by GitHub Actions job
`33927257810` on the Ubuntu 24.04 runner image `20260831.293.1`. The run step
spanned 2026-09-04 22:53:39 UTC to 2026-09-05 00:05:56 UTC (about 72 minutes).
GitHub's documented standard private-repository runner class is x64, 2 vCPUs,
and 8 GB RAM; this is the documented class rather than a measurement embedded
in the archived job.

The homogeneous run took about 54 minutes and recorded 1,095 model calls,
13,484,643 tokens, and $0.75157741. The heterogeneous run took about 72 minutes
and recorded 1,112 model calls, 11,692,537 tokens, and $2.76391498. Together,
the fresh extension recorded 2,207 model calls, 25,177,180 tokens, and
$3.51549239. The two conditions ran concurrently. Exact model assignments,
reasoning settings, sampling temperature, retry policy, task IDs, timestamps,
usage, and cost are retained in each run's `manifest.json`,
`resolved_config.yaml`, and `summary.json`.

The original strong-condition generation was also run in GitHub Actions. The
initial generation job was `30280903029`, workflow
`debate-recalibrated-v2-full.yml`, starting 2026-07-27 15:37:52 UTC on Ubuntu
24.04.4 runner image `20260720.247.2`. Job `30314582310` is the final recovery
and import checkpoint retained in the run directory, rather than the initial
generation environment.

Provider-side accelerators and memory are not exposed by the hosted APIs and
are not estimated. Analysis and bootstrap reproduction are CPU-only and make no
network or model calls.

The two fresh size-8 translation files contain 2,281 translated fields. Every
field has a relation pass, and 402 first-pass format repairs were attempted.
Their recorded per-record usage sums to 67,431,164 input tokens, including
46,434,560 cached input tokens, 3,865,321 output tokens, and 2,753,083 reasoning
output tokens. Summed per-call latency is 89,845 seconds; because calls overlap,
this is not wall-clock time. The record timestamps span 2026-09-05 02:42:34 to
04:52:00 UTC. The artifacts do not contain a complete resource or cost account
for the relation pass and later model-assisted semantic review, so those costs
cannot be reconstructed from this release.
