"""Recompute the existing feature AUC analysis for size 6 only.

Run: .venv/bin/python scripts/remake_size6_auc.py
"""
import pandas as pd

from analyze_reasoning_features import ROOT, OUT, SIZE6, FEATURES, WINDOW, COMMITMENTS, SCORED, KEY, auc_table


def main():
    destination = OUT / "size6-only"
    frame = pd.read_csv(OUT / "debate-features.csv")
    frame = frame.loc[frame.dataset.eq("size6")].reset_index(drop=True)
    assert len(frame) == 80 and frame["size"].eq(6).all()
    assert not frame.duplicated(KEY).any()
    assert frame.groupby("condition_id").size().eq(20).all()
    assert frame.operational_final_correct.sum() == 38
    puzzle_sets = frame.groupby("condition_id").task_id.apply(set).tolist()
    assert all(puzzles == puzzle_sets[0] for puzzles in puzzle_sets)

    claims = pd.read_csv(SIZE6 / "claims.csv", low_memory=False)
    claims = claims[claims.commitment.isin(COMMITMENTS) & claims.information_type.isin(SCORED)].copy()
    claims["expr"] = claims.effective_expression.fillna(claims.expression)
    assert claims.expr.notna().all()
    assert claims.groupby(KEY + ["expr"]).target_truth.nunique().le(1).all()
    first = claims.sort_values("stage_order").drop_duplicates(KEY + ["expr"])
    masks = {
        "initial_correct_propositions": first.stage_order.eq(0) & first.target_truth.eq(1),
        "post_initial_distinct": first.stage_order.gt(0),
        "post_initial_distinct_before_final": first.stage_order.gt(0) & first.stage.ne("final_decision"),
    }
    for feature, mask in masks.items():
        counts = first[mask].groupby(KEY).size().rename(feature)
        frame = frame.merge(counts, on=KEY, how="left", validate="one_to_one")
        frame[feature] = frame[feature].fillna(0).astype(int)
    assert (frame.initial_correct_propositions >= frame.initial_true).all()
    assert (frame.post_initial_distinct >= frame.post_initial_distinct_before_final).all()
    initial_counts = first[first.stage_order.eq(0)].groupby(KEY).size()
    assert (frame.set_index(KEY).initial_distinct.sort_index() == initial_counts.sort_index()).all()
    prior_counts = pd.read_csv(ROOT / "reports/analysis/claim-introductions-vs-outcomes-2026-09-04/debate-data.csv")
    checked = frame.merge(prior_counts[KEY + ["late_claims"]], on=KEY, validate="one_to_one")
    assert len(checked) == 80 and (abs(checked.post_initial_distinct - checked.late_claims) < 1e-9).all()
    additions = {
        "initial_correct_propositions": "Distinct correct propositions introduced initially (including true redundant propositions)",
        "post_initial_distinct": "Distinct propositions first introduced after initial proposals (including final decisions)",
        "post_initial_distinct_before_final": "Distinct propositions first introduced after initial proposals, before final decisions",
    }
    WINDOW.update(initial_correct_propositions="initial", post_initial_distinct="whole-debate",
                  post_initial_distinct_before_final="mid-debate")
    table = auc_table(frame, {**FEATURES, **additions})
    indexed = table.set_index("feature")
    assert abs(indexed.loc["false_resistance", "auc_within_condition"]
               + indexed.loc["uptake_false", "auc_within_condition"] - 1) < 1e-12
    destination.mkdir(parents=True, exist_ok=True)
    frame.to_csv(destination / "debate-features.csv", index=False)
    table.to_csv(destination / "feature-auc.csv", index=False)

    selected = {
        "any_initial_correct": "At least one correct initial solution",
        "initial_net_bits": "Net initial information (true minus misleading bits)",
        "initial_precision": "Initial claim precision",
        "false_resistance": "False-claim resistance",
        "selectivity": "True uptake minus false uptake",
        "initial_true_bits": "Truth-aligned initial bits",
        "uptake_true": "True-claim adaptation",
        "initial_distinct": "Distinct initial propositions",
        **additions,
    }
    lines = [
        "# Feature AUCs: six-character puzzles only", "",
        "80 debates: strong/weak × heterogeneous/homogeneous, 20 shared puzzles per condition. "
        "Strong corresponds to the source data's medium label. Each team has three debaters. "
        "38 final answers were correct and 42 incorrect (strong: 35/40; weak: 3/40).", "",
        "Reproduce: `.venv/bin/python scripts/remake_size6_auc.py`", "",
        "Source: `../debate-features.csv`, filtered to dataset=size6. "
        "Feature definitions and estimation reuse `scripts/analyze_reasoning_features.py`. "
        "The original 120-debate outputs are preserved.", "",
        "| Feature | Eligible debates | Pooled AUC (95% CI) | Within-condition AUC (95% CI) |",
        "|---|---:|---:|---:|",
    ]
    for feature in table.feature:
        if feature not in selected:
            continue
        label = selected[feature]
        row = indexed.loc[feature]
        pooled = f"{row.auc_pooled:.3f} [{row.pooled_ci_low:.3f}, {row.pooled_ci_high:.3f}]"
        within = f"{row.auc_within_condition:.3f} [{row.within_ci_low:.3f}, {row.within_ci_high:.3f}]"
        lines.append(f"| {label} | {int(row.n)} | {pooled} | {within} |")
    lines += ["",
        "Added proposition counts use the size-6 strength-comparison `claims.csv`: scored "
        "assert/endorse/reject commitments, deduplicated by exact effective expression within each "
        "debate. Logical equivalence beyond expression equality is not inferred. Correct initial "
        "propositions have target_truth=1 and first appear at stage_order=0, including true redundant "
        "propositions; the older initial_true feature counts only truth_aligned propositions. "
        "Later counts include both true and false propositions whose first appearance is after "
        "the initial proposals. The main later count includes final decisions and is descriptive; "
        "the before-final variant excludes propositions first appearing in final_decision. "
        "Counts measure volume and can depend on debate length.", "",
        "AUC is the probability that a correct debate has a higher feature value than an "
        "incorrect debate, with ties weighted 0.5. Within-condition AUC pools correct–incorrect "
        "pairs only within the same condition; it is not an unweighted mean of condition AUCs. "
        "Missing feature values are excluded separately for each feature.", "",
        "Intervals preserve the original method: 2,000 percentile bootstrap samples, "
        "resampling debates separately within each condition, seed 20260905. This does not "
        "jointly resample shared puzzles across conditions. Few successes in weak conditions "
        "and few failures in strong conditions limit precision. Features have different eligible "
        "samples; AUC differences are not formal tests of equal performance or independent importance.", "",
        "Uptake uses the original all-proposition definition, including role-assignment claims. "
        "Resistance means non-adoption, not necessarily explicit rejection. Net initial bits "
        "measure supply, not information-weighted uptake. The full CSV additionally includes "
        "whole-debate features that include the final decision; these are not antecedent predictors. "
        "AUCs below 0.5 for error features indicate association in the expected negative direction.", "",
    ]
    (destination / "README.md").write_text("\n".join(lines))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
