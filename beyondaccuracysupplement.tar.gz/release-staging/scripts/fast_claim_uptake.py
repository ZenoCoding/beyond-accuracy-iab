"""Reproduce Table 2 and audit claim uptake without new model calls.

Run: .venv/bin/python scripts/fast_claim_uptake.py
The puzzle, not the claim-recipient pair, is the bootstrap sampling unit.
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from analyze_conflicting_uptake import initial_positions, conflicts
from controlmad.analysis.formal_logic_minimal import _load_dataset_context
from controlmad.analysis.formal_logic_compact import parse_compact_expression
from controlmad_replication.benchmarks.kks.logic import assignments, evaluate_expr

SOURCE = ROOT / 'reports/analysis/minimal-reasoning-size6-strength-comparison-2026-09-04'
OUT = ROOT / 'reports/analysis/fast-claim-uptake-2026-09-06'
KEY = ['condition_id', 'task_id', 'repetition']
PAIR = KEY + ['expression', 'recipient']
SEED, DRAWS = 20260906, 10000


def own_mask(c):
    # Rejection never asserts its quoted proposition. Self-inclusive reports
    # count only in the separately labeled commitment sensitivity analysis.
    return c.commitment.isin(['assert', 'endorse']) & c.information_type.isin(['truth_aligned', 'misleading', 'redundant', 'contradictory'])


def peers(row):
    return {a.strip().removeprefix('agent:') for a in row.attribution.split(',') if a.strip().startswith('agent:')} - {row.agent_id}


def correct_literal_polarity(raw, texts, statements):
    """Conservative full-span mismatch audit; never infer unstated truth values."""
    q, targets = _load_dataset_context(ROOT/'data/kks/v1')
    pattern = re.compile(r"^(?:Player )?([A-F])(?:['’]s (?:statement|claim))?\s+(?:(?:is|must be|was)\s+)?(true|false)[.!]?$", re.I)
    corrected, ledger = raw.copy(), []
    for i, row in raw.iterrows():
        match = pattern.fullmatch(row.source_span.strip())
        if not match or not re.fullmatch(r'(?:NOT\()?STMT_TRUE\([A-F]\)\)?', row.expression):
            continue
        expr = f'STMT_TRUE({match[1].upper()})'
        if match[2].lower() == 'false':
            expr = f'NOT({expr})'
        if expr == row.expression:
            continue
        ast = parse_compact_expression(expr)
        gold = bool(evaluate_expr(ast, tuple(targets[row.task_id]), statements[row.task_id]))
        worlds = list(assignments(len(q[row.task_id]['players'])))
        n = sum(evaluate_expr(ast, w, statements[row.task_id]) for w in worlds)
        kind = 'contradictory' if n == 0 else 'redundant' if n == len(worlds) else 'truth_aligned' if gold else 'misleading'
        corrected.loc[i, ['expression','effective_expression','expr']] = expr
        corrected.loc[i, 'target_truth'] = gold
        corrected.loc[i, 'information_type'] = kind
        ledger.append(dict(claim_uid=row.claim_uid, old_expression=row.expression, new_expression=expr,
                           source_span=row.source_span, full_field_text=texts[row.field_uid],
                           reason='Literal polarity contradicts translated expression; full source field reviewed by assistant.'))
    return corrected, pd.DataFrame(ledger)


def build_pairs(raw, positions, statements, canonical=False, self_reports=False):
    q, targets = _load_dataset_context(ROOT / 'data/kks/v1')

    @lru_cache(None)
    def signature(task, expr):
        ast = parse_compact_expression(expr)
        worlds = assignments(len(q[task]['players']))
        return bytes(int(evaluate_expr(ast, w, statements[task])) for w in worlds).hex()

    mask = own_mask(raw)
    if self_reports:
        mask |= raw.committed.eq(1) & raw.information_type.isin(['truth_aligned', 'misleading', 'redundant', 'contradictory'])
    c = raw[mask & ~raw.expr.str.contains('ROLE(', regex=False)].copy()
    c['match'] = [signature(t, e) for t, e in zip(c.task_id, c.expr)] if canonical else c.expr
    rows, edges = [], []
    for key, group in c.groupby(KEY):
        cond, task, rep = key
        rg = raw[(raw.condition_id == cond) & (raw.task_id == task) & (raw.repetition == rep)]
        agents = set(rg.loc[rg.stage_order.eq(0), 'agent_id'])
        assert len(agents) == 3
        for match, prop in group.groupby('match'):
            initial = prop[prop.stage_order.eq(0)]
            if initial.empty or initial.information_type.iloc[0] not in ['truth_aligned', 'misleading']:
                continue
            expr = initial.expr.iloc[0]
            gold = bool(evaluate_expr(parse_compact_expression(expr), tuple(targets[task]), statements[task]))
            assert gold == bool(initial.target_truth.iloc[0])
            introducers = set(initial.agent_id)
            later = prop[prop.stage_order.gt(0) & prop.stage_order.lt(10010)]
            for recipient in sorted(agents - introducers):
                hits = later[later.agent_id.eq(recipient)]
                base = dict(zip(KEY, key), expression=expr, recipient=recipient,
                            tier='medium' if 'medium' in cond else 'weak',
                            composition='heterogeneous' if cond.endswith('-het') else 'homogeneous',
                            truth=gold, adopted=int(not hits.empty),
                            conflicting=conflicts(expr, positions[(*key, recipient)], statements[task]),
                            argument=int(hits.stage.eq('debate_argument').any()),
                            early=int((hits.round_index < rg.round_index.max()).any()),
                            direct_attributed=0, linked_attributed=0,
                            introducers=','.join(sorted(introducers)),
                            initial_claim_uids='|'.join(initial.claim_uid),
                            uptake_claim_uids='|'.join(hits.claim_uid))
                if not canonical:
                    refs = rg[rg.agent_id.eq(recipient) & rg.expression.eq(expr) & rg.stage_order.gt(0) & rg.stage_order.lt(10010) & rg.attribution.str.contains('agent:')]
                    for ref in refs.itertuples():
                        cited = peers(ref) & introducers
                        if not cited:
                            continue
                        direct = ref.commitment == 'endorse'
                        same_field = hits[hits.field_uid.eq(ref.field_uid)]
                        linked = direct or not same_field.empty
                        base['direct_attributed'] |= int(direct)
                        base['linked_attributed'] |= int(linked)
                        edges.append(dict(zip(KEY, key), expression=expr, recipient=recipient,
                                          tier=base['tier'], truth=gold, claim_uid=ref.claim_uid,
                                          field_uid=ref.field_uid, stage_order=ref.stage_order,
                                          cited_introducers=','.join(sorted(cited)), commitment=ref.commitment,
                                          direct=direct, linked=linked, source_span=ref.source_span,
                                          own_spans=' | '.join(same_field.source_span),
                                          origin_spans=' | '.join(initial[initial.agent_id.isin(cited)].source_span)))
                rows.append(base)
    p = pd.DataFrame(rows)
    assert not p.duplicated(PAIR).any()
    assert (p.direct_attributed <= p.linked_attributed).all()
    assert (p.linked_attributed <= p.adopted).all()
    return p, pd.DataFrame(edges)


def summarize(p, tasks, scope, outcome='adopted', shared=False):
    """Joint cluster draws preserve all four conditions and both truth cells."""
    picks = np.random.default_rng(SEED).integers(0, len(tasks), (DRAWS, len(tasks)))
    rows, contrasts = [], []
    for comp in ['pooled', 'heterogeneous', 'homogeneous']:
        subset = p if comp == 'pooled' else p[p.composition.eq(comp)]
        if shared:
            sk = ['task_id', 'expression', 'composition']
            available = subset.groupby(sk).tier.nunique()
            keys = available[available.eq(2)].reset_index()[sk]
            subset = subset.merge(keys, on=sk, validate='many_to_one')
        estimates, draws = {}, {}
        for tier in ['medium', 'weak']:
            g = subset[subset.tier.eq(tier)]
            rates, bootrates = {}, {}
            rec = dict(scope=scope, composition=comp, tier=tier, pairs=len(g),
                       puzzles=g.task_id.nunique(), debates=len(g[KEY].drop_duplicates()))
            for truth, label in [(True, 'true'), (False, 'false')]:
                x = g[g.truth.eq(truth)]
                if shared:
                    # Equal weight to each shared puzzle/composition/proposition;
                    # average recipient uptake within that stratum first.
                    units = x.groupby(['task_id', 'composition', 'expression'])[outcome].mean().reset_index()
                else:
                    units = x
                counts = units.groupby('task_id')[outcome].agg(['sum', 'count']).reindex(tasks, fill_value=0)
                den = counts['count'].to_numpy()[picks].sum(axis=1)
                num = counts['sum'].to_numpy()[picks].sum(axis=1)
                bootrates[label] = np.divide(num, den, out=np.full(DRAWS, np.nan), where=den > 0)
                rates[label] = units[outcome].mean()
                rec.update({f'{label}_n': len(x), f'{label}_hits': int(x[outcome].sum()),
                            f'{label}_puzzles': x.task_id.nunique(), f'{label}_units': len(units),
                            f'uptake_{label}': rates[label]})
            estimates[tier] = dict(uptake_true=rates['true'], uptake_false=rates['false'],
                                   resistance=1-rates['false'], gap=rates['true']-rates['false'])
            draws[tier] = dict(uptake_true=bootrates['true'], uptake_false=bootrates['false'],
                               resistance=1-bootrates['false'], gap=bootrates['true']-bootrates['false'])
            for name, value in estimates[tier].items():
                finite = draws[tier][name][np.isfinite(draws[tier][name])]
                rec[name] = value
                rec[name+'_lo'], rec[name+'_hi'] = np.quantile(finite, [.025, .975]) if len(finite) else (np.nan, np.nan)
                rec[name+'_draws'] = len(finite)
            rows.append(rec)
        for metric in estimates['medium']:
            delta = draws['medium'][metric] - draws['weak'][metric]
            finite = delta[np.isfinite(delta)]
            lo, hi = np.quantile(finite, [.025, .975]) if len(finite) else (np.nan, np.nan)
            contrasts.append(dict(scope=scope, composition=comp, metric=metric,
                                  difference=estimates['medium'][metric]-estimates['weak'][metric],
                                  ci_low=lo, ci_high=hi, defined_draws=len(finite)))
    return rows, contrasts


def consistent_auc(pairs, tasks):
    """Use the same non-role recipient-pair measure in Table 2 and Table 3."""
    frame = pd.read_csv(ROOT/'reports/analysis/expanded-nonrole-auc-2026-09-06/debate-features.csv')
    frame = frame[frame.dataset.eq('size6')].copy()
    rates = pairs.groupby(KEY+['truth']).adopted.mean().unstack('truth')
    for col, truth in [('uptake_true', True), ('uptake_false', False)]:
        frame = frame.drop(columns=col).merge(rates[truth].rename(col), on=KEY, how='left', validate='one_to_one')
    frame['false_resistance'] = 1-frame.uptake_false
    frame['selectivity'] = frame.uptake_true-frame.uptake_false
    frame.to_csv(OUT/'corrected-debate-features.csv', index=False)
    features = ['initial_net_bits','any_initial_correct','initial_precision','initial_true_bits',
                'selectivity','false_resistance','uptake_true','initial_distinct']
    picks = np.random.default_rng(SEED).integers(0,len(tasks),(DRAWS,len(tasks)))
    weights = np.array([np.bincount(p,minlength=len(tasks)) for p in picks])
    index = {task:i for i,task in enumerate(tasks)}
    rows = []
    for feature in features:
        valid = frame[frame[feature].notna()]
        row = dict(feature=feature, n=len(valid))
        for scope in ['pooled','within']:
            numerator = np.zeros((len(tasks),len(tasks)))
            denominator = numerator.copy()
            groups = [valid] if scope == 'pooled' else [g for _,g in valid.groupby('condition_id')]
            for g in groups:
                for _,a in g[g.operational_final_correct.eq(1)].iterrows():
                    for _,b in g[g.operational_final_correct.eq(0)].iterrows():
                        i,j = index[a.task_id], index[b.task_id]
                        numerator[i,j] += float(a[feature]>b[feature])+0.5*float(a[feature]==b[feature])
                        denominator[i,j] += 1
            num = np.einsum('bi,ij,bj->b',weights,numerator,weights)
            den = np.einsum('bi,ij,bj->b',weights,denominator,weights)
            draws = num[den>0]/den[den>0]
            row[scope] = numerator.sum()/denominator.sum() if denominator.sum() else np.nan
            row[scope+'_lo'],row[scope+'_hi'] = np.quantile(draws,[.025,.975]) if len(draws) else (np.nan,np.nan)
            row[scope+'_pairs'] = int(denominator.sum())
            row[scope+'_draws'] = len(draws)
        rows.append(row)
    pd.DataFrame(rows).to_csv(OUT/'consistent-auc.csv', index=False)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    raw = pd.read_csv(SOURCE/'claims.csv', low_memory=False)
    for col in ['expression', 'effective_expression', 'attribution', 'source_span']:
        raw[col] = raw[col].fillna('')
    raw['expr'] = raw.effective_expression.where(raw.effective_expression.ne(''), raw.expression)
    debates = pd.read_csv(SOURCE/'debates.csv')
    tasks = sorted(debates.task_id.unique())
    assert len(tasks) == 20 and len(debates) == 80
    assert debates.groupby('condition_id').task_id.apply(set).apply(lambda s: s == set(tasks)).all()
    positions, statements = initial_positions()
    pairs, edges = build_pairs(raw, positions, statements)
    original = pd.read_csv(ROOT/'reports/analysis/expanded-nonrole-auc-2026-09-06/exposure-pairs.csv')
    original = original[original.dataset.eq('size6')]
    cols = PAIR + ['adopted']
    pd.testing.assert_frame_equal(pairs[cols].sort_values(PAIR).reset_index(drop=True), original[cols].sort_values(PAIR).reset_index(drop=True), check_dtype=False)
    pairs.to_csv(OUT/'pairs.csv', index=False)
    edges.to_csv(OUT/'attribution-audit.csv', index=False)
    texts = {}
    cfg = ROOT/'configs/analysis/minimal-reasoning-size6-strength-comparison.yaml'
    for source in yaml.safe_load(cfg.read_text())['sources']:
        for line in (cfg.parent/source['translation_file']).resolve().read_text().splitlines():
            record = json.loads(line)
            src = record['source']
            uid = ':'.join([source['id'], src['task_id'], str(src['repetition']), record['formalization_id']])
            texts[uid] = record['source_text']
    edges['full_field_text'] = edges.field_uid.map(texts)
    assert edges.full_field_text.notna().all()
    edges.to_csv(OUT/'attribution-audit.csv', index=False)
    indexed = raw.set_index('claim_uid')
    sample = pairs[pairs.adopted.eq(1)].groupby(['condition_id', 'truth'], group_keys=False).sample(n=2, random_state=SEED)
    audit = []
    for row in sample.itertuples():
        origin = indexed.loc[row.initial_claim_uids.split('|')[0]]
        uptake = indexed.loc[row.uptake_claim_uids.split('|')[0]]
        audit.append(dict(condition_id=row.condition_id, task_id=row.task_id, recipient=row.recipient,
                          expression=row.expression, truth=row.truth, origin_uid=origin.name, uptake_uid=uptake.name,
                          origin_text=texts[origin.field_uid], uptake_text=texts[uptake.field_uid]))
    (OUT/'uptake-audit-sample.json').write_text(json.dumps(audit, indent=2)+'\n')
    rows, contrasts = [], []
    for scope, data, outcome, shared in [
        ('primary', pairs, 'adopted', False),
        ('initial_conflict', pairs[pairs.conflicting.eq(True)], 'adopted', False),
        ('argument_only', pairs, 'argument', False),
        ('before_last_round', pairs, 'early', False),
        ('explicit_endorsement', pairs, 'direct_attributed', False),
        ('reference_and_same_field_commitment', pairs, 'linked_attributed', False),
        ('shared_claims', pairs, 'adopted', True),
    ]:
        r, c = summarize(data, tasks, scope, outcome, shared)
        rows += r; contrasts += c
    for scope, kwargs in [('semantic_equivalence', dict(canonical=True)), ('self_inclusive_reports', dict(self_reports=True))]:
        data, _ = build_pairs(raw, positions, statements, **kwargs)
        data.to_csv(OUT/(scope+'-pairs.csv'), index=False)
        r, c = summarize(data, tasks, scope)
        rows += r; contrasts += c
        if scope == 'self_inclusive_reports':
            r, c = summarize(data, tasks, 'self_inclusive_attributed', 'linked_attributed')
            rows += r; contrasts += c
    corrected, ledger = correct_literal_polarity(raw, texts, statements)
    ledger.to_csv(OUT/'polarity-corrections.csv', index=False)
    clean, _ = build_pairs(corrected, positions, statements)
    clean.to_csv(OUT/'corrected-pairs.csv', index=False)
    consistent_auc(clean, tasks)
    # Repeat all central checks after applying the disclosed corrections.
    for scope, data, outcome, shared in [
        ('corrected_primary', clean, 'adopted', False),
        ('corrected_initial_conflict', clean[clean.conflicting.eq(True)], 'adopted', False),
        ('corrected_argument_only', clean, 'argument', False),
        ('corrected_before_last_round', clean, 'early', False),
        ('corrected_shared_claims', clean, 'adopted', True),
    ]:
        r, c = summarize(data, tasks, scope, outcome, shared)
        rows += r; contrasts += c
    summary = pd.DataFrame(rows); contrast = pd.DataFrame(contrasts)
    summary.to_csv(OUT/'summary.csv', index=False)
    contrast.to_csv(OUT/'contrasts.csv', index=False)
    # Leave-one-puzzle-out analysis diagnoses dependence on individual clusters.
    leave = []
    for task in tasks:
        sub = pairs[pairs.task_id.ne(task)]
        r = sub.groupby(['tier', 'truth']).adopted.mean()
        leave.append(dict(omitted=task, gap_difference=(r['medium', True]-r['medium', False])-(r['weak', True]-r['weak', False])))
    pd.DataFrame(leave).to_csv(OUT/'leave-one-puzzle-out.csv', index=False)
    manifest = dict(seed=SEED, draws=DRAWS, clusters=tasks, conditions=sorted(debates.condition_id.unique()),
                    primary_pairs=len(pairs), baseline_reproduced=True,
                    input_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [SOURCE/'claims.csv', SOURCE/'debates.csv', Path(__file__)]})
    (OUT/'provenance.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(summary[summary.scope.eq('primary')][['composition','tier','true_hits','true_n','false_hits','false_n','gap','gap_lo','gap_hi']].to_string(index=False))
    print(contrast[contrast.composition.eq('pooled') & contrast.metric.eq('gap')].to_string(index=False))


if __name__ == '__main__':
    main()
