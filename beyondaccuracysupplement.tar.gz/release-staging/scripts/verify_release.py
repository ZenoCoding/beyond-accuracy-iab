"""Verify integrity and corrected 120-debate coverage without model calls."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLEAN = ROOT / "reports/analysis/fast-translation-cleanup-v1-2026-09-06"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


manifest = json.loads((ROOT / "MANIFEST.json").read_text())
assert manifest["cohort"] == "80 original size-6 + 40 fresh size-8"
for item in manifest["files"]:
    path = ROOT / item["path"]
    assert path.is_file(), f"missing: {item['path']}"
    assert path.stat().st_size == item["bytes"], f"size mismatch: {item['path']}"
    assert sha256(path) == item["sha256"], f"hash mismatch: {item['path']}"

run_dirs = [
    ROOT / "runs/kks-debate-weak-het-full-120-temp07-gpt5t1-or-pinned-v1",
    ROOT / "runs/kks-debate-weak-hom-full-120-temp07-gpt5t1-v1",
    ROOT / "runs/imported/debate-recalibrated-v2-final-30314582310/checkpoint/kks-debate-v2-medium-het-full-120",
    ROOT / "runs/imported/debate-recalibrated-v2-final-30314582310/checkpoint/kks-debate-v2-medium-hom-full-120",
    ROOT / "runs/imported/size8-gpt-oss-control-r1-20260904-33927257810/kks-debate-v2-medium-het-size8-fresh-r1-20260904",
    ROOT / "runs/imported/size8-gpt-oss-control-r1-20260904-33927257810/kks-debate-v2-gpt-oss-hom-size8-control-r1-20260904",
]
for run in run_dirs:
    assert run.is_dir(), f"missing raw run: {run.relative_to(ROOT)}"
    results = list((run / "tasks").glob("*/result.json"))
    assert len(results) == 20, (run.relative_to(ROOT), len(results))
    for required in ["manifest.json", "resolved_config.yaml", "events.jsonl", "predictions.jsonl", "summary.json"]:
        assert (run / required).is_file(), f"missing {required} in {run.relative_to(ROOT)}"

with (CLEAN / "corrected/debate-features.csv").open(newline="") as handle:
    rows = list(csv.DictReader(handle))
assert len(rows) == 120
assert sum(int(float(row["operational_final_correct"])) for row in rows) == 73
fresh = [row for row in rows if row["dataset"] == "size8"]
assert len(fresh) == 40
by_condition = {}
for row in fresh:
    by_condition.setdefault(row["condition_id"], []).append(row)
assert {key: (len(value), sum(int(float(row["operational_final_correct"])) for row in value))
        for key, value in by_condition.items()} == {"het": (20, 15), "hom": (20, 20)}

for name in ["debate-features.csv", "paper-auc.csv", "exposure-pairs.csv"]:
    assert sha256(CLEAN / "corrected" / name) == sha256(ROOT / "paper-analysis" / name), name

overlay_manifest = json.loads((CLEAN / "overlay-manifest.json").read_text())
assert sum(item["total_fields"] for item in overlay_manifest) == 5826
assert sum(item["modified_fields"] for item in overlay_manifest) == 24
assert sum(item["unchanged_fields_byte_preserved"] for item in overlay_manifest) == 5802
for item in overlay_manifest:
    assert sha256(CLEAN / item["overlay_path"]) == item["overlay_sha256"]

print(json.dumps({
    "manifest_files_verified": len(manifest["files"]),
    "raw_debates_verified": 120,
    "corrected_debates": len(rows),
    "correct_outcomes": 73,
    "fresh_size8": {"heterogeneous": "15/20", "homogeneous": "20/20"},
    "overlay_fields": 5826,
    "modified_fields": 24,
    "paper_inputs_match_corrected_outputs": True,
}, indent=2))
