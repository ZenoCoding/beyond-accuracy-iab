"""Supply and selection mechanisms behind debate outcomes.

Decomposes each debate into (i) the pool of distinct formal propositions its
agents put on the table and (ii) how selectively peers take those propositions
up mid-debate. Claim filtering matches the existing introduction analyses
(scripts/plot_weak_claim_introductions.py): scored unconditional commitments
only, deduplicated by effective expression within a debate.

Reproduce:
    .venv/bin/python scripts/analyze_supply_and_selection.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "reports/analysis/supply-and-selection-2026-09-05"
SOURCES = {
    "size6": ROOT / "reports/analysis/minimal-reasoning-size6-strength-comparison-2026-09-04",
    "size8": ROOT / "reports/analysis/fresh-size8-heterogeneity-2026-09-05/base",
}
COMMITMENTS = ["assert", "endorse", "reject"]
SCORED = ["truth_aligned", "misleading", "redundant", "contradictory"]
FINAL_ORDER = 10010
KEY = ["condition_id", "task_id", "repetition"]
SEED = 20260905


def per_debate(source: Path) -> pd.DataFrame:
    claims = pd.read_csv(source / "claims.csv", low_memory=False)
    debates = pd.read_csv(source / "debates.csv", low_memory=False)
    claims = claims[claims.commitment.isin(COMMITMENTS) & claims.information_type.isin(SCORED)].copy()
    claims["expr"] = claims.effective_expression.fillna(claims.expression)

    records = []
    for key, group in claims.groupby(KEY):
        pool = {"truth_aligned": 0, "misleading": 0, "redundant": 0, "contradictory": 0}
        uptake = {"truth_aligned": [0, 0], "misleading": [0, 0]}
        for _, prop in group.groupby("expr"):
            kind = prop.information_type.iloc[0]
            pool[kind] += 1
            if kind not in uptake:
                continue
            # Selection is measured only on propositions available from the
            # initial proposals and only on re-expression strictly before the
            # final decision, so it cannot restate the outcome it predicts.
            if prop.stage_order.min() != 0:
                continue
            introducers = set(prop.loc[prop.stage_order == 0, "agent_id"])
            peers = set(prop.loc[(prop.stage_order > 0) & (prop.stage_order < FINAL_ORDER), "agent_id"])
            uptake[kind][1] += 1
            uptake[kind][0] += bool(peers - introducers)

        record = dict(zip(KEY, key))
        record["n_true"] = pool["truth_aligned"]
        record["n_false"] = pool["misleading"]
        record["n_distinct"] = sum(pool.values())
        signed = pool["truth_aligned"] + pool["misleading"]
        record["pool_precision"] = pool["truth_aligned"] / signed if signed else np.nan
        for kind, label in (("truth_aligned", "true"), ("misleading", "false")):
            hits, eligible = uptake[kind]
            record[f"uptake_{label}"] = hits / eligible if eligible else np.nan
            record[f"eligible_{label}"] = eligible
        record["selectivity"] = record["uptake_true"] - record["uptake_false"]
        records.append(record)

    frame = pd.DataFrame(records)
    return frame.merge(
        debates[KEY + ["condition_label", "operational_final_correct", "behavior_stratum", "any_initial_correct"]],
        on=KEY, how="left")


def bootstrap(a: pd.Series, b: pd.Series, draws: int = 10000) -> tuple[float, float]:
    a, b = a.dropna().to_numpy(), b.dropna().to_numpy()
    if not len(a) or not len(b):
        return (np.nan, np.nan)
    rng = np.random.default_rng(SEED)
    diffs = (rng.choice(a, (draws, len(a))).mean(axis=1) - rng.choice(b, (draws, len(b))).mean(axis=1))
    return tuple(np.percentile(diffs, [2.5, 97.5]))


METRICS = ["n_distinct", "n_true", "n_false", "pool_precision", "uptake_true", "uptake_false", "selectivity"]


def contrasts(frame: pd.DataFrame, label: str, left: pd.Series, right: pd.Series, names: tuple[str, str]):
    rows = []
    for metric in METRICS:
        lo, hi = bootstrap(frame.loc[left, metric], frame.loc[right, metric])
        rows.append({
            "contrast": label, "metric": metric,
            names[0]: frame.loc[left, metric].mean(), names[1]: frame.loc[right, metric].mean(),
            "difference": frame.loc[left, metric].mean() - frame.loc[right, metric].mean(),
            "ci_low": lo, "ci_high": hi,
            "n_left": int(left.sum()), "n_right": int(right.sum()),
        })
    return rows


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    frames, contrast_rows, group_rows = {}, [], []

    for name, source in SOURCES.items():
        frame = per_debate(source)
        frames[name] = frame
        frame.to_csv(OUT / f"{name}-per-debate.csv", index=False)

        correct = frame.operational_final_correct == 1
        for label, mask in [("all", frame.index == frame.index)] + \
                [(f"outcome={int(v)}", correct if v else ~correct) for v in (1, 0)] + \
                [(f"stratum={s}", frame.behavior_stratum == s) for s in sorted(frame.behavior_stratum.dropna().unique())] + \
                [(f"condition={c}", frame.condition_label == c) for c in sorted(frame.condition_label.dropna().unique())]:
            row = {"dataset": name, "group": label, "n": int(mask.sum()),
                   "accuracy": frame.loc[mask, "operational_final_correct"].mean()}
            row.update({m: frame.loc[mask, m].mean() for m in METRICS})
            group_rows.append(row)

        rows = contrasts(frame, f"{name}: correct - incorrect", correct, ~correct, ("correct", "incorrect"))
        rows += contrasts(frame, f"{name}: correction - persistent_failure",
                          frame.behavior_stratum == "correction",
                          frame.behavior_stratum == "persistent_failure", ("correct", "incorrect"))
        contrast_rows += rows

    # Within-tier checks on the size-6 sample, holding member competence fixed.
    size6 = frames["size6"]
    for tier in ("Medium", "Weak"):
        tier_frame = size6[size6.condition_label.str.startswith(tier)].reset_index(drop=True)
        correct = tier_frame.operational_final_correct == 1
        contrast_rows += contrasts(tier_frame, f"size6 {tier.lower()}: correct - incorrect",
                                   correct, ~correct, ("correct", "incorrect"))

    pd.DataFrame(group_rows).to_csv(OUT / "group-means.csv", index=False)
    pd.DataFrame(contrast_rows).to_csv(OUT / "contrasts.csv", index=False)

    # Joint supply x selection table on the pooled size-6 sample.
    eligible = size6.dropna(subset=["selectivity"]).copy()
    supply_cut, selection_cut = size6.n_true.median(), eligible.selectivity.median()
    eligible["supply"] = np.where(eligible.n_true >= supply_cut, "high", "low")
    eligible["selection"] = np.where(eligible.selectivity >= selection_cut, "high", "low")
    joint = (eligible.groupby(["supply", "selection"])
             .agg(n=("operational_final_correct", "size"), accuracy=("operational_final_correct", "mean"))
             .reset_index())
    joint["supply_cut"], joint["selection_cut"] = supply_cut, selection_cut
    joint.to_csv(OUT / "supply-by-selection.csv", index=False)

    print(pd.DataFrame(group_rows).to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print()
    print(pd.DataFrame(contrast_rows).to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print()
    print(joint.to_string(index=False, float_format=lambda v: f"{v:.3f}"))


if __name__ == "__main__":
    main()
