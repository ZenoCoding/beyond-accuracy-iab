"""Selection measured only where the peer claim contradicted the recipient.

The supply-and-selection decomposition counts uptake of any proposition an
agent introduced in its initial proposal. That denominator includes
propositions the recipient already agreed with, so a debate whose agents are
simply correct can score high selectivity without ever evaluating a peer.

This restriction keeps only (proposition, recipient) pairs where the
proposition is FALSE under the recipient's own initial role assignment, i.e.
the recipient held an incompatible position when exposed. Uptake then means a
recipient abandoned a commitment in favour of the peer's claim.

Reproduce:
    .venv/bin/python scripts/analyze_conflicting_uptake.py
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))
from controlmad.analysis.core import completed_results
from controlmad.analysis.formal_logic_minimal import _load_dataset_context
from controlmad.analysis.formal_logic_compact import parse_compact_expression
from controlmad_replication.benchmarks.kks.logic import evaluate_expr

SOURCE = REPO / "reports/analysis/minimal-reasoning-size6-strength-comparison-2026-09-04"
CONFIG = REPO / "configs/analysis/minimal-reasoning-size6-strength-comparison.yaml"
OUT = REPO / "reports/analysis/conflicting-uptake-2026-09-05"
COMMITMENTS = ["assert", "endorse", "reject"]
SCORED = ["truth_aligned", "misleading", "redundant", "contradictory"]
FINAL_ORDER = 10010
KEY = ["condition_id", "task_id", "repetition"]
SEED = 20260905


def initial_positions() -> dict:
    """Each agent's initial role assignment, as an index-ordered tuple."""
    questions, _ = _load_dataset_context(REPO / "data/kks/v1")
    spec = yaml.safe_load(CONFIG.read_text())
    positions, statements = {}, {}
    for source in spec["sources"]:
        run = (CONFIG.parent / source["run_dir"]).resolve()
        for (task, rep), result in completed_results(run).items():
            players = questions[task]["players"]
            statements[task] = [item["ast"] for item in questions[task]["statements"]]
            for agent, solution in result["initial_proposals"].items():
                roles = solution["roles"]
                positions[(source["id"], task, rep, agent)] = tuple(roles.get(p) for p in players)
    return positions, statements


def conflicts(expr_text: str, assignment, statements) -> bool | None:
    """True when the proposition is false under the recipient's own answer."""
    parsed = parse_compact_expression(expr_text)
    if parsed is None or any(role is None for role in assignment):
        return None
    try:
        return not evaluate_expr(parsed, assignment, statements)
    except Exception:
        return None


def per_debate(positions, statements) -> pd.DataFrame:
    claims = pd.read_csv(SOURCE / "claims.csv", low_memory=False)
    debates = pd.read_csv(SOURCE / "debates.csv", low_memory=False)
    claims = claims[claims.commitment.isin(COMMITMENTS) & claims.information_type.isin(SCORED)].copy()
    claims["expr"] = claims.effective_expression.fillna(claims.expression)

    records, pairs = [], []
    for key, group in claims.groupby(KEY):
        condition, task, rep = key
        agents = sorted(group.agent_id.dropna().unique())
        counts = {("truth_aligned", "all"): [0, 0], ("misleading", "all"): [0, 0],
                  ("truth_aligned", "conflict"): [0, 0], ("misleading", "conflict"): [0, 0]}
        for expr, prop in group.groupby("expr"):
            kind = prop.information_type.iloc[0]
            if kind not in ("truth_aligned", "misleading") or prop.stage_order.min() != 0:
                continue
            introducers = set(prop.loc[prop.stage_order == 0, "agent_id"])
            window = prop[(prop.stage_order > 0) & (prop.stage_order < FINAL_ORDER)]
            takers = set(window.agent_id) - introducers
            for agent in agents:
                if agent in introducers:
                    continue
                position = positions.get((condition, task, rep, agent))
                if position is None:
                    continue
                took = int(agent in takers)
                counts[(kind, "all")][1] += 1
                counts[(kind, "all")][0] += took
                conflict = conflicts(expr, position, statements[task])
                if conflict:
                    counts[(kind, "conflict")][1] += 1
                    counts[(kind, "conflict")][0] += took
                pairs.append(dict(condition_id=condition, task_id=task, repetition=rep, recipient=agent,
                                  expression=expr, information_type=kind, conflicting=conflict, adopted=took))

        record = dict(zip(KEY, key))
        for scope in ("all", "conflict"):
            for kind, label in (("truth_aligned", "true"), ("misleading", "false")):
                hits, eligible = counts[(kind, scope)]
                suffix = "" if scope == "all" else "_conflict"
                record[f"uptake_{label}{suffix}"] = hits / eligible if eligible else np.nan
                record[f"eligible_{label}{suffix}"] = eligible
            record[f"selectivity{'' if scope == 'all' else '_conflict'}"] = (
                record[f"uptake_true{'' if scope == 'all' else '_conflict'}"]
                - record[f"uptake_false{'' if scope == 'all' else '_conflict'}"])
        records.append(record)

    frame = pd.DataFrame(records).merge(
        debates[KEY + ["condition_label", "operational_final_correct", "behavior_stratum"]], on=KEY, how="left")
    return frame, pd.DataFrame(pairs)


def bootstrap(a, b, draws=10000):
    a, b = a.dropna().to_numpy(), b.dropna().to_numpy()
    if not len(a) or not len(b):
        return np.nan, np.nan
    rng = np.random.default_rng(SEED)
    diffs = rng.choice(a, (draws, len(a))).mean(axis=1) - rng.choice(b, (draws, len(b))).mean(axis=1)
    return tuple(np.percentile(diffs, [2.5, 97.5]))


METRICS = ["uptake_true", "uptake_false", "selectivity",
           "uptake_true_conflict", "uptake_false_conflict", "selectivity_conflict",
           "eligible_true_conflict", "eligible_false_conflict"]


def contrasts(frame, label, left, right):
    rows = []
    for metric in METRICS:
        lo, hi = bootstrap(frame.loc[left, metric], frame.loc[right, metric])
        rows.append(dict(contrast=label, metric=metric,
                         correct=frame.loc[left, metric].mean(), incorrect=frame.loc[right, metric].mean(),
                         difference=frame.loc[left, metric].mean() - frame.loc[right, metric].mean(),
                         ci_low=lo, ci_high=hi,
                         n_left=int(frame.loc[left, metric].notna().sum()),
                         n_right=int(frame.loc[right, metric].notna().sum())))
    return rows


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    positions, statements = initial_positions()
    frame, pairs = per_debate(positions, statements)
    frame.to_csv(OUT / "per-debate.csv", index=False)
    pairs.to_csv(OUT / "exposure-pairs.csv", index=False)

    correct = frame.operational_final_correct == 1
    rows = contrasts(frame, "size6: correct - incorrect", correct, ~correct)
    for tier in ("Medium", "Weak"):
        sub = frame[frame.condition_label.str.startswith(tier)].reset_index(drop=True)
        rows += contrasts(sub, f"size6 {tier.lower()}: correct - incorrect",
                          sub.operational_final_correct == 1, sub.operational_final_correct != 1)
    contrast_frame = pd.DataFrame(rows)
    contrast_frame.to_csv(OUT / "contrasts.csv", index=False)

    groups = []
    for label, mask in [("all", frame.index == frame.index), ("outcome=1", correct), ("outcome=0", ~correct)]:
        row = dict(group=label, n=int(mask.sum()))
        row.update({m: frame.loc[mask, m].mean() for m in METRICS})
        groups.append(row)
    group_frame = pd.DataFrame(groups)
    group_frame.to_csv(OUT / "group-means.csv", index=False)

    print(pairs.groupby(["information_type", "conflicting"]).agg(n=("adopted", "size"), adopted=("adopted", "mean")).to_string())
    print()
    print(group_frame.to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print()
    print(contrast_frame.to_string(index=False, float_format=lambda v: f"{v:.3f}"))





def pooled_interaction() -> None:
    """Does contradicting the recipient suppress adoption more for false claims?

    Bootstrapped over debates, so the resample unit is the debate, not the pair.
    """
    pairs = pd.read_csv(OUT / "exposure-pairs.csv")
    pairs = pairs.dropna(subset=["conflicting"])
    pairs["debate"] = pairs.condition_id + "|" + pairs.task_id

    def cell(frame, kind, conflicting):
        sub = frame[(frame.information_type == kind) & (frame.conflicting == conflicting)]
        return sub.adopted.mean() if len(sub) else np.nan

    def stats(frame):
        return dict(
            true_compatible=cell(frame, "truth_aligned", False), true_conflicting=cell(frame, "truth_aligned", True),
            false_compatible=cell(frame, "misleading", False), false_conflicting=cell(frame, "misleading", True))

    def derived(s):
        return dict(**s,
                    conflict_effect_true=s["true_conflicting"] - s["true_compatible"],
                    conflict_effect_false=s["false_conflicting"] - s["false_compatible"],
                    truth_gap_conflicting=s["true_conflicting"] - s["false_conflicting"],
                    interaction=(s["false_conflicting"] - s["false_compatible"])
                    - (s["true_conflicting"] - s["true_compatible"]))

    point = derived(stats(pairs))
    debates = list(pairs.groupby("debate"))
    rng = np.random.default_rng(SEED)
    draws = []
    for _ in range(10000):
        pick = rng.integers(0, len(debates), len(debates))
        draws.append(derived(stats(pd.concat([debates[i][1] for i in pick], ignore_index=True))))
    boot = pd.DataFrame(draws)
    rows = [dict(metric=k, estimate=point[k],
                 ci_low=np.nanpercentile(boot[k], 2.5), ci_high=np.nanpercentile(boot[k], 97.5))
            for k in point]
    frame = pd.DataFrame(rows)
    frame.to_csv(OUT / "pooled-interaction.csv", index=False)
    print()
    print(f"pairs={len(pairs)}  debates={len(debates)}")
    print(frame.to_string(index=False, float_format=lambda v: f"{v:.3f}"))


if __name__ == "__main__":
    main()
    pooled_interaction()
