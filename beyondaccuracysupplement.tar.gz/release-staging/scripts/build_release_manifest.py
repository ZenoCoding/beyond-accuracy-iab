"""Build a deterministic SHA-256 inventory for the release tree."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
files = []
for path in sorted(candidate for candidate in ROOT.rglob("*") if candidate.is_file()):
    rel = path.relative_to(ROOT).as_posix()
    if rel == "MANIFEST.json" or "/__pycache__/" in f"/{rel}/" or rel.startswith(".venv/"):
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    files.append({"path": rel, "bytes": path.stat().st_size, "sha256": digest})

manifest = {
    "schema_version": 2,
    "cohort": "80 original size-6 + 40 fresh size-8",
    "conditions": ["weak-het", "weak-hom", "strong-het", "strong-hom", "size8-het", "size8-hom"],
    "file_count": len(files),
    "total_bytes": sum(item["bytes"] for item in files),
    "files": files,
}
(ROOT / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({key: manifest[key] for key in ["file_count", "total_bytes"]}, indent=2))
