# Broad Luna reasoning and influence

This package analyzes 80 size-6 debates, 3545 fields, 35000 claims, and 13119 relations from the parse-clean v3 Broad Luna corpus.

## Main findings

- The strongest positive transition association is net information bits (+0.092); the strongest negative is prior accuracy (-0.103).
- Weak heterogeneity introduces +5.8 distinct claims and +0.2 net information bits per matched puzzle relative to weak homogeneity.
- Medium heterogeneity introduces +4.7 distinct claims and +2.5 net information bits per matched puzzle relative to medium homogeneity.
- There are 13 explicit reject events; abandonment is much more common and is reported only as a proxy.
- Among 2874 scorable peer citations, 91.8% are faithful to the peer's captured claims or latest declared position.
- Under the thin background, 25.0% of checkable captured support relations are locally valid; this is not relation-recall-adjusted.

## Outputs

- `report.html`: self-contained paper-ready report.
- Nine figures in PNG and SVG.
- CSV inputs for claim movement, origins, diversity, agent contribution, citations, truth/validity, and both coefficient plots.
- `model-specifications.json`: targets, grouped validation, regularization, and bootstrap details.

## Definitions

- Helpful information: truth-aligned information bits.
- Harmful information: misleading information bits that exclude the verified solution.
- Net information: helpful minus harmful bits.
- A distinct claim is one unique normalized committed expression per debate;
  later exact repetitions do not add another claim.
- Claim information is `log2(all role worlds / supporting role worlds)` under
  the exactly-one-spy structural constraint.
- Adoption: a different agent restates an exact normalized expression at a strictly later stage.
- Abandonment: a claim in the agent's previous solution turn is absent from its next solution turn; this is not direct rejection.
- Truth describes a claim at the verified solution. Validity describes whether a captured local relation supports its conclusion.

## Statistical reading

The transition ridge uses 1680 agent revisions and puzzle-grouped cross-validation (R²=0.431). The final logistic ridge uses 80 debates with only 42 failures, so it is secondary and uncertainty should dominate interpretation.

The weak and medium heterogeneous-versus-homogeneous comparisons are paired over the same 20 puzzles within each tier.

## Limitations

- Exact-expression restatement cannot distinguish influence from independent convergence.
- Agents argue in parallel, preventing clean individual causal attribution.
- Relation metrics cover extracted relations only; missing relations are not evidence of unsupported reasoning.
- Parse-clean translations can still contain semantic errors.
