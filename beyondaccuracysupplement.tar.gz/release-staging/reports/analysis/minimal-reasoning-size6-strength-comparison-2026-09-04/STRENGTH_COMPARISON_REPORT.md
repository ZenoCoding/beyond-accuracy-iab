# Model strength, heterogeneity, and debate reasoning

## Executive finding

Across the matched size-6 sample, model strength changes the *quality and handling* of claims much more than it changes claim volume. Both weak and medium heterogeneous teams introduce more distinct claims than their homogeneous controls. Only the medium teams, however, produce positive net information and reliably prefer truth-aligned peer claims over misleading ones. Weak debate largely circulates and repeats claims without improving role accuracy.

The strongest supported interpretation is that diversity creates candidate ideas at both capability levels, while sufficient model strength is needed to make those ideas truth-directed and useful. These are descriptive fixed-roster comparisons, not a model-family-independent causal estimate of strength.

## Scope

The analysis covers 80 condition-puzzles: 20 shared six-player puzzles in each of four conditions. The parse-clean corpus contains 3,545 fields, 35,000 claims, and 13,119 relations. Puzzle-level paired bootstrap intervals use 10,000 resamples.

## Condition summary

| Condition | Exact | Initial partial | Final partial | Distinct claims | Truth-aligned rate | Misleading rate | Net bits | Value/claim | Selection gap | False-premise reliance | Local validity | Repetition |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Weak homogeneous | 5.0% | 45.8% | 47.5% | 24.2 | 43.3% | 44.3% | -8.05 | -0.310 | -0.012 | 28.9% | 21.9% | 21.0× |
| Weak heterogeneous | 10.0% | 43.9% | 43.3% | 30.1 | 45.1% | 46.2% | -7.86 | -0.231 | -0.006 | 29.9% | 24.6% | 14.5× |
| Medium homogeneous | 85.0% | 65.6% | 90.8% | 29.8 | 76.5% | 12.6% | +5.88 | +0.266 | +0.333 | 8.8% | 36.5% | 15.4× |
| Medium heterogeneous | 90.0% | 66.7% | 95.0% | 34.5 | 81.1% | 8.8% | +8.34 | +0.273 | +0.386 | 6.6% | 34.6% | 12.8× |

## Paired contrasts

Values are mean paired differences with puzzle-bootstrap 95% intervals. Heterogeneity means heterogeneous minus homogeneous; strength means medium minus weak.

| Measure | Weak heterogeneity | Medium heterogeneity | Homogeneous strength | Heterogeneous strength | Difference in heterogeneity effects |
|---|---:|---:|---:|---:|---:|
| Exact accuracy | +0.05 [+0.00, +0.15] | +0.05 [-0.10, +0.20] | +0.80 [+0.60, +0.95] | +0.80 [+0.60, +0.95] | +0.00 [-0.20, +0.20] |
| Final partial accuracy | -0.04 [-0.16, +0.07] | +0.04 [-0.04, +0.13] | +0.43 [+0.33, +0.53] | +0.52 [+0.39, +0.63] | +0.08 [-0.04, +0.20] |
| Distinct claims | +5.80 [+2.50, +9.30] | +4.70 [+0.90, +8.55] | +5.55 [-0.00, +10.85] | +4.45 [+0.65, +8.70] | -1.10 [-6.20, +4.40] |
| Net information bits | +0.19 [-4.16, +4.66] | +2.46 [-2.03, +7.26] | +13.93 [+7.75, +20.49] | +16.20 [+10.95, +21.70] | +2.27 [-4.43, +8.80] |
| Truth-vs-false adoption gap | +0.01 [-0.17, +0.19] | +0.04 [-0.11, +0.18] | +0.36 [+0.15, +0.56] | +0.40 [+0.23, +0.57] | +0.08 [-0.13, +0.31] |
| False-premise reliance | +0.01 [-0.09, +0.10] | -0.02 [-0.06, +0.01] | -0.20 [-0.27, -0.13] | -0.23 [-0.32, -0.15] | -0.03 [-0.12, +0.06] |
| Local relation validity | +0.03 [-0.04, +0.10] | -0.02 [-0.12, +0.07] | +0.15 [+0.09, +0.20] | +0.10 [+0.04, +0.15] | -0.05 [-0.14, +0.03] |
| Claim repetition | -6.53 [-9.15, -4.05] | -2.57 [-4.79, -0.48] | -5.64 [-9.22, -1.76] | -1.68 [-3.24, -0.11] | +3.96 [+0.16, +7.55] |

## What changes with model strength

1. **Information direction reverses.** Weak teams average -8.05 to -7.86 net bits per puzzle; medium teams average +5.88 to +8.34. Medium-minus-weak gains are +13.93 bits in homogeneous teams and +16.20 in heterogeneous teams.
2. **Claim selection becomes truth-directed.** The truth-minus-misleading adoption gap is -0.006 for weak heterogeneous debate and +0.386 for medium heterogeneous debate. Weak heterogeneous agents adopt misleading claims slightly more often than truth-aligned claims; medium agents show the opposite pattern.
3. **False-premise reliance falls sharply.** It is 28.9%–29.9% for weak teams versus 6.6%–8.8% for medium teams.
4. **Debate produces correction only at medium strength.** Mean role-accuracy change per revision is approximately -0.001 to +0.002 in weak teams, versus +0.036 to +0.040 in medium teams.
5. **The general transition model agrees.** Across all 1,680 revisions, net information has the largest positive standardized coefficient (+0.092); adopting true claims is positive (+0.033), adopting false claims is negative (-0.030), and abandoning false claims is positive (+0.025). Grouped cross-validated R² is 0.431.

## What heterogeneity changes

Heterogeneity increases distinct claims at both tiers: +5.8 for weak teams and +4.7 for medium teams. It also reduces repetition. But its net-information increment is only +0.19 bits for weak teams, compared with +2.46 bits for medium teams. Thus weak heterogeneity creates novelty without demonstrating a comparable increase in useful information.

Exact accuracy rises by only one puzzle within each tier (weak: 1/20 to 2/20; medium: 17/20 to 18/20). The formal-logic measurements therefore support a mechanism claim about information quality and selection more strongly than an accuracy claim about heterogeneity.

## Measurement controls

| Condition | Fields | Claims | Translation coverage | Opaque rate | Premise coverage | Relation checkability | Citation fidelity |
|---|---:|---:|---:|---:|---:|---:|---:|
| Weak homogeneous | 873 | 9,502 | 92.8% | 7.2% | 22.5% | 50.6% | 84.9% |
| Weak heterogeneous | 909 | 8,461 | 94.2% | 5.8% | 29.8% | 67.6% | 93.6% |
| Medium homogeneous | 883 | 8,548 | 94.9% | 5.1% | 32.1% | 68.5% | 94.0% |
| Medium heterogeneous | 880 | 8,489 | 93.1% | 6.9% | 31.8% | 73.7% | 96.2% |

## Conclusions and limits

The evidence supports three descriptive conclusions:

- Stronger teams do not merely say more; they produce a substantially higher proportion of truth-aligned claims and positive net information.
- Stronger teams are better at selecting peer information: true claims spread preferentially, while weak heterogeneous agents show no such preference.
- Heterogeneity increases unique claim production and reduces repetition at both strengths, but diversity becomes useful only when agents have enough capability to evaluate and integrate it.

These results do not isolate causal model strength. The weak and medium rosters use different model families and settings, translations are parse-clean rather than exhaustively gold-adjudicated, and relation results are conditional on captured relations. Exact-expression restatement is an adoption proxy, not proof of social influence. Because all comparisons use only 20 puzzles, uncertainty intervals and puzzle-level variation should remain visible in any paper claim.

## Reproducibility

Supporting tables are in `influence/condition-strength-summary.csv`, `influence/strength-comparison-by-puzzle.csv`, `influence/paired-strength-contrasts.csv`, and `influence/measurement-controls.csv`. The complete influence package also contains model coefficients, claim origins, agent contributions, citation fidelity, figures, and a self-contained HTML report.
