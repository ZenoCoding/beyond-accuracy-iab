# Feature AUCs: six-character puzzles only

80 debates: strong/weak × heterogeneous/homogeneous, 20 shared puzzles per condition. Strong corresponds to the source data's medium label. Each team has three debaters. 38 final answers were correct and 42 incorrect (strong: 35/40; weak: 3/40).

Reproduce: `.venv/bin/python scripts/remake_size6_auc.py`

Source: `../debate-features.csv`, filtered to dataset=size6. Feature definitions and estimation reuse `scripts/analyze_reasoning_features.py`. The original 120-debate outputs are preserved.

| Feature | Eligible debates | Pooled AUC (95% CI) | Within-condition AUC (95% CI) |
|---|---:|---:|---:|
| Net initial information (true minus misleading bits) | 80 | 0.836 [0.741, 0.916] | 0.930 [0.803, 1.000] |
| At least one correct initial solution | 80 | 0.882 [0.812, 0.949] | 0.919 [0.839, 0.976] |
| Initial claim precision | 80 | 0.811 [0.713, 0.903] | 0.884 [0.741, 0.985] |
| Truth-aligned initial bits | 80 | 0.739 [0.621, 0.853] | 0.873 [0.735, 0.981] |
| True uptake minus false uptake | 71 | 0.876 [0.783, 0.955] | 0.862 [0.692, 1.000] |
| False-claim resistance | 71 | 0.794 [0.673, 0.910] | 0.816 [0.645, 0.958] |
| Distinct correct propositions introduced initially (including true redundant propositions) | 80 | 0.656 [0.530, 0.782] | 0.806 [0.646, 0.936] |
| True-claim adaptation | 80 | 0.740 [0.618, 0.844] | 0.722 [0.507, 0.904] |
| Distinct initial propositions | 80 | 0.426 [0.304, 0.558] | 0.489 [0.246, 0.711] |
| Distinct propositions first introduced after initial proposals, before final decisions | 80 | 0.635 [0.526, 0.740] | 0.173 [0.036, 0.331] |
| Distinct propositions first introduced after initial proposals (including final decisions) | 80 | 0.638 [0.529, 0.743] | 0.169 [0.034, 0.324] |

Added proposition counts use the size-6 strength-comparison `claims.csv`: scored assert/endorse/reject commitments, deduplicated by exact effective expression within each debate. Logical equivalence beyond expression equality is not inferred. Correct initial propositions have target_truth=1 and first appear at stage_order=0, including true redundant propositions; the older initial_true feature counts only truth_aligned propositions. Later counts include both true and false propositions whose first appearance is after the initial proposals. The main later count includes final decisions and is descriptive; the before-final variant excludes propositions first appearing in final_decision. Counts measure volume and can depend on debate length.

AUC is the probability that a correct debate has a higher feature value than an incorrect debate, with ties weighted 0.5. Within-condition AUC pools correct–incorrect pairs only within the same condition; it is not an unweighted mean of condition AUCs. Missing feature values are excluded separately for each feature.

Intervals preserve the original method: 2,000 percentile bootstrap samples, resampling debates separately within each condition, seed 20260905. This does not jointly resample shared puzzles across conditions. Few successes in weak conditions and few failures in strong conditions limit precision. Features have different eligible samples; AUC differences are not formal tests of equal performance or independent importance.

Uptake uses the original all-proposition definition, including role-assignment claims. Resistance means non-adoption, not necessarily explicit rejection. Net initial bits measure supply, not information-weighted uptake. The full CSV additionally includes whole-debate features that include the final decision; these are not antecedent predictors. AUCs below 0.5 for error features indicate association in the expected negative direction.
