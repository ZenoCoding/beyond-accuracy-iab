# Initial proposition supply, overlap, and exclusive contributions

Reproduce: `.venv/bin/python scripts/analyze_initial_proposition_overlap.py`

This follow-up examines all 120 debate runs and 360 initial explanation fields used in the parent report. It makes no new model calls. Counts describe extracted initial commitments, not all reasoning, final assignments, or whole-debate speech.

## Definitions and denominator audit

Use the parent report's filter: stage order 0, commitment assert/endorse/reject, and information type truth_aligned/misleading/redundant/contradictory. Deduplicate effective-expression strings within each agent before comparing agents.

- **Agent supply:** distinct eligible expressions in an agent's initial explanation.
- **Total agent contributions (S):** sum of the three agent counts. An expression in three agents contributes three.
- **Team distinct supply (U):** union of the three sets; that expression contributes one.
- **Duplicate contributions (D):** S − U. An expression in three agents contributes two duplicates.
- **Exclusive:** an expression supplied by exactly one agent. Exclusive true/false counts use reference-solution truth labels. Exclusive does not imply logically novel, peer-used, or causally helpful.
- **Pairwise Jaccard:** intersection divided by union for an agent pair, averaged over defined pairs within each debate. Empty–nonempty pairs score zero; empty–empty pairs are undefined. A sensitivity measure excludes pairs with either set empty.

All 360 initial fields exist and have zero recorded parse errors. Zero eligible supply is retained as zero; this does not mean the explanation contains no reasoning. In size8 hom, puzzle `kks-v1-n08-048` has zero eligible commitments across all three agents despite having translated explanation fields. The parent feature extractor omits this debate from initial-supply means. Consequently, this follow-up's all-20-run size8 hom mean is 15.65, versus 16.47 over the parent's 19 nonempty runs. No parent numerical tables were overwritten. Precision and Jaccard remain undefined when their denominators are zero.

## 1. Why similar team counts can conceal different patterns

All entries below are means over 20 debates per condition. The identity U = S − D holds in every debate and in these means.

| Condition | Props per agent | Agent contributions S | Duplicates D | Team union U |
|---|---|---|---|---|
| size6 weak hom | 8.57 | 25.70 | 7.10 | 18.60 |
| size6 weak het | 7.20 | 21.60 | 4.35 | 17.25 |
| size6 medium hom | 7.63 | 22.90 | 7.50 | 15.40 |
| size6 medium het | 7.50 | 22.50 | 6.85 | 15.65 |
| size8 hom | 6.95 | 20.85 | 5.20 | 15.65 |
| size8 het | 8.02 | 24.05 | 5.70 | 18.35 |

- **Weak size6:** heterogeneous minus homogeneous supply is −4.10 agent contributions and −2.75 duplicate contributions, yielding −1.35 team propositions. Fewer repeats partially offset lower individual supply; lower overlap need not produce a larger union.
- **Medium size6:** agent contributions differ by −0.40 and duplicates by −0.65, yielding +0.25 team propositions. Both components are descriptively similar.
- **Size8:** agent contributions differ by +3.20 and duplicates by +0.50, yielding +2.70 team propositions when zero extracted supply is included. Excluding the zero-supply paired puzzle yields +1.58, matching the parent's paired point estimate.

These are accounting decompositions, not causal explanations for why the models generated those claims.

Paired heterogeneous-minus-homogeneous union differences, 10,000 puzzle-pair percentile-bootstrap draws:

| Comparison | Difference [95% CI] | Paired puzzles |
|---|---|---|
| size6 weak | -1.35 [-5.20, +2.35] | 20 |
| size6 medium | +0.25 [-3.45, +3.60] | 20 |
| size8 | +2.70 [-2.45, +7.75] | 20 |

All intervals span zero. There is no demonstrated equivalence and no clear increase in union size.

## 2. How much do the agents overlap?

| Condition | Mean pairwise Jaccard | Props in ≥2 agents | Props in all 3 |
|---|---|---|---|
| size6 weak hom | 0.20 | 5.35 | 1.75 |
| size6 weak het | 0.09 | 3.60 | 0.75 |
| size6 medium hom | 0.22 | 5.30 | 2.20 |
| size6 medium het | 0.19 | 4.85 | 2.00 |
| size8 hom | 0.11 | 4.45 | 0.75 |
| size8 het | 0.12 | 4.85 | 0.85 |

Paired Jaccard differences:

| Comparison | Difference [95% CI] | Paired puzzles |
|---|---|---|
| size6 weak | -0.10 [-0.20, -0.01] | 20 |
| size6 medium | -0.03 [-0.09, +0.03] | 20 |
| size8 | +0.01 [-0.07, +0.10] | 19 |

Weak heterogeneous teams show lower measured overlap in the primary calculation. However, they also average 0.85 zero-supply agents per debate versus 0.30 for weak homogeneous teams. When requiring both agents in each pair to have nonempty supply, the weak contrast's interval spans zero:

| Comparison | Nonempty-pair Jaccard difference [95% CI] | Paired puzzles |
|---|---|---|
| size6 weak | -0.09 [-0.21, +0.03] | 15 |
| size6 medium | -0.03 [-0.09, +0.04] | 14 |
| size8 | +0.01 [-0.08, +0.11] | 11 |

This sensitivity changes eligible agent pairs and debates; it is not an adjustment that isolates model diversity. Neither medium size6 nor size8 provides clear evidence of changed overlap.

## 3. Does exclusive content add truths or errors?

These are team sums of expressions supplied by exactly one agent, averaged across 20 debates.

| Condition | Exclusive true | Exclusive false | Shared true | Shared false |
|---|---|---|---|---|
| size6 weak hom | 6.25 | 5.65 | 1.70 | 2.50 |
| size6 weak het | 6.25 | 5.95 | 1.65 | 1.60 |
| size6 medium hom | 5.55 | 4.10 | 4.00 | 0.60 |
| size6 medium het | 5.80 | 4.45 | 3.75 | 0.40 |
| size8 hom | 6.60 | 3.75 | 3.15 | 0.50 |
| size8 het | 6.40 | 6.10 | 3.30 | 0.80 |

Paired differences in exclusive true supply:

| Comparison | Difference [95% CI] | Paired puzzles |
|---|---|---|
| size6 weak | +0.00 [-1.90, +2.05] | 20 |
| size6 medium | +0.25 [-1.20, +1.55] | 20 |
| size8 | -0.20 [-2.95, +2.50] | 20 |

Paired differences in exclusive false supply:

| Comparison | Difference [95% CI] | Paired puzzles |
|---|---|---|
| size6 weak | +0.30 [-1.80, +2.45] | 20 |
| size6 medium | +0.35 [-1.50, +2.25] | 20 |
| size8 | +2.35 [+0.30, +4.60] | 20 |

No comparison clearly increases exclusive true supply. At size8, the full-sample excess in exclusive content is mostly false: +2.35 false versus −0.20 true propositions. But excluding the zero-supply paired puzzle reduces the false excess and its interval spans zero:

| Comparison | Exclusive false difference, positive supply in both teams [95% CI] | Paired puzzles |
|---|---|---|
| size6 weak | +0.30 [-1.90, +2.50] | 20 |
| size6 medium | +0.35 [-1.55, +2.20] | 20 |
| size8 | +1.79 [-0.16, +3.74] | 19 |

Thus the size8 false-content pattern is suggestive and sensitive to inclusion of one puzzle, not a robust general conclusion about heterogeneous teams.

## 4. Which agents contribute it?

Every row averages 20 initial proposals, including zero eligible supply. True and false counts need not sum to total supply because redundant and contradictory expressions also enter the total.

| Condition | Slot | Model | Distinct | True | False | Exclusive true | Exclusive false |
|---|---|---|---|---|---|---|---|
| size6 medium het | agent-1 | Gemini 3.5 Flash-Lite | 9.85 | 5.65 | 3.15 | 2.55 | 2.80 |
| size6 medium het | agent-2 | Mercury 2 | 5.95 | 4.05 | 1.25 | 1.30 | 1.00 |
| size6 medium het | agent-3 | GPT-OSS-20B | 6.70 | 5.25 | 0.85 | 1.95 | 0.65 |
| size6 medium hom | agent-1 | Mercury 2 | 5.90 | 3.95 | 1.30 | 1.25 | 0.85 |
| size6 medium hom | agent-2 | Mercury 2 | 8.80 | 5.75 | 2.30 | 2.50 | 1.95 |
| size6 medium hom | agent-3 | Mercury 2 | 8.20 | 5.50 | 1.80 | 1.80 | 1.30 |
| size6 weak het | agent-1 | GPT-4.1 mini | 7.65 | 2.95 | 3.70 | 1.95 | 2.50 |
| size6 weak het | agent-2 | Gemini 3.1 Flash-Lite | 5.05 | 2.80 | 1.70 | 1.50 | 0.70 |
| size6 weak het | agent-3 | Llama 4 Maverick | 8.90 | 4.20 | 4.05 | 2.80 | 2.75 |
| size6 weak hom | agent-1 | GPT-4.1 mini | 8.45 | 2.95 | 4.05 | 1.65 | 1.75 |
| size6 weak hom | agent-2 | GPT-4.1 mini | 6.80 | 2.75 | 2.80 | 1.30 | 1.45 |
| size6 weak hom | agent-3 | GPT-4.1 mini | 10.45 | 4.60 | 4.45 | 3.30 | 2.45 |
| size8 het | agent-1 | Gemini 3.5 Flash-Lite | 9.95 | 5.05 | 3.70 | 2.10 | 2.90 |
| size8 het | agent-2 | Mercury 2 | 7.45 | 4.15 | 2.50 | 1.80 | 2.10 |
| size8 het | agent-3 | GPT-OSS-20B | 6.65 | 4.35 | 1.55 | 2.50 | 1.10 |
| size8 hom | agent-1 | GPT-OSS-20B | 6.55 | 4.15 | 1.80 | 2.10 | 1.50 |
| size8 hom | agent-2 | GPT-OSS-20B | 7.80 | 4.80 | 1.95 | 2.75 | 1.65 |
| size8 hom | agent-3 | GPT-OSS-20B | 6.50 | 4.55 | 1.00 | 1.75 | 0.60 |

In size8 heterogeneous teams, Gemini contributes 2.90 exclusive false propositions per debate, Mercury 2.10, and GPT-OSS 1.10; exclusive true contributions are 2.10, 1.80, and 2.50 respectively. These describe this sample, not intrinsic model abilities or causal influence. Homogeneous copies also differ in their generated content.

## What FAST can say

> Decomposing initial proposition supply into per-agent contributions and cross-agent repetition revealed different patterns across roster comparisons. In weak size-6 teams, lower individual supply was partly offset by lower repetition in the heterogeneous roster. We found no clear increase in team-level distinct propositions or exclusive true propositions across the three comparisons.

The size8 exclusive-false excess can be described as exploratory alongside its exclusion sensitivity. Do not claim heterogeneity generally causes harmful novelty or that equal counts imply equal information.

## Limits and checks

- All comparisons use 20 paired puzzles, one run per condition. Bootstrap draws resample whole puzzle pairs for each contrast; agent observations are not treated as independent experiments.
- Intervals are exploratory, unadjusted for multiple comparisons; exclusion sensitivities use smaller samples. They do not account for translation error or establish equivalence.
- Exact expressions can differ while being logically equivalent or mutually implied. These counts measure expression overlap, not semantic independence. No semantic-equivalence audit was performed.
- Scoring excludes attributed, conditional, unscored, and opaque content; different expression styles can affect extracted supply. Parse-clean status does not ensure semantic fidelity.
- Each roster comparison changes model composition. Differences are not isolated effects of heterogeneity.
- Validated all 120 team counts against the existing feature table, treating its one omitted initial-supply row as zero. Checked three initial agent fields per debate, consistent truth labels for repeated expressions, and both set-count identities.

Files: `per-agent.csv`, `per-debate.csv`, `agent-summary.csv`, `condition-summary.csv`, and `paired-contrasts.csv`. The script regenerates the numerical CSVs; this README interprets their results.
