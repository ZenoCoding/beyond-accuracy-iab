# Peer citations and subsequent answer updates

Reproduce: `.venv/bin/python scripts/analyze_attributed_updates.py`

## Question and operational definition

Does the truth-sensitive update pattern remain when the recipient explicitly references a peer's proposition before revising its answer?

This analysis covers the same 120 debates, uses initial and intermediate submitted role assignments, and excludes final decisions. It measures **citation-linked answer updates**, not proven causal uptake or necessarily an explicit acknowledgment of influence.

For the primary measure, require all of the following:

1. A translated `debate_argument` claim explicitly attributes a proposition to a different agent (`agent:` target).
2. The attributed proposition is true under that peer's most recent submitted assignment before the argument. This checks compatibility with the peer's position; it does not prove the peer stated the proposition in prose.
3. The proposition is false under the recipient's most recent submitted assignment before the argument.
4. Test whether it becomes true under the recipient's next submitted self-adjustment.

Truth/falsehood for the summary columns is evaluated separately against the reference solution. Repeated mentions and multiple cited peers are deduplicated to one recipient–expression–revision observation. The same expression can enter again at a later revision if it is again incompatible beforehand. Proposition rows within a debate are dependent observations.

The stricter sensitivity additionally requires that the cited peer previously expressed the identical effective-expression string as a scored commitment. It checks any prior turn, not only the latest one; concurrent claims are not counted as prior. All primary citations precede the recipient's next answer, avoiding citations extracted from that answer's own explanation.

## Main result: peer-position-supported citations

| Group | True cited claims: updates / eligible | False cited claims: updates / eligible | True − false [95% CI] |
|---|---:|---:|---:|
| weak | 13/42 (31.0%) | 14/68 (20.6%) | 10.4 pp [-12.3, 34.7] |
| medium | 41/52 (78.8%) | 9/57 (15.8%) | 63.1 pp [46.6, 82.7] |
| size8 | 32/56 (57.1%) | 11/82 (13.4%) | 43.7 pp [22.5, 70.4] |

The medium-minus-weak difference in true–false update rates is **52.7 percentage points [25.6, 79.9]**. Weak updates have an uncertain true–false difference; the data do not establish equality. Size8 pools its two rosters and is not a third capability tier.

Intervals use 10,000 bootstrap draws of puzzle IDs, retaining every within-puzzle event and jointly resampling shared puzzles across conditions and size6 tiers. These are exploratory percentile intervals, without translation-error propagation or multiplicity correction.

## Sensitivity: peer previously stated the exact proposition

| Group | True cited claims: updates / eligible | False cited claims: updates / eligible | True − false [95% CI] |
|---|---:|---:|---:|
| weak | 10/30 (33.3%) | 12/49 (24.5%) | 8.8 pp [-18.2, 41.0] |
| medium | 33/38 (86.8%) | 7/38 (18.4%) | 68.4 pp [55.2, 84.2] |
| size8 | 20/32 (62.5%) | 9/46 (19.6%) | 42.9 pp [22.3, 71.9] |

With this stricter requirement, the medium-minus-weak gap remains **59.6 pp [27.3, 87.8]**. This is stronger evidence of a temporal link to identifiable peer content than unrestricted expression matching, but still not a counterfactual influence test.

## Sensitivity: all explicit peer references

Without checking that the cited proposition matches the peer's previous assignment:

| Group | True cited claims: updates / eligible | False cited claims: updates / eligible | True − false [95% CI] |
|---|---:|---:|---:|
| weak | 13/74 (17.6%) | 14/130 (10.8%) | 6.8 pp [-5.2, 22.5] |
| medium | 41/53 (77.4%) | 9/74 (12.2%) | 65.2 pp [49.0, 84.4] |
| size8 | 33/60 (55.0%) | 13/103 (12.6%) | 42.4 pp [22.1, 69.7] |

Position filtering particularly changes the weak denominator. Unsupported attribution could reflect misreporting, a peer's prose disagreeing with its submitted assignment, or translation error; it cannot all be labeled dishonest or erroneous attribution without source auditing.

## Explicit endorsement is a much smaller category

Most attributed claims are labeled `report`, not `endorse` by the translator. Across nonself citation edges in argument fields:

| Group | Report edges | Endorse edges | Reject edges |
|---|---:|---:|---:|
| weak | 1720 | 15 | 5 |
| medium | 1057 | 8 | 8 |
| size8 | 2624 | 106 | 9 |


These are citation edges, not independent claims: a claim naming two peers contributes two edges. Requiring an `endorse` label AND incompatibility with the recipient's previous answer leaves **four eligible proposition–revision observations**: zero weak, one medium (true, adopted), and three size8 (one true, adopted; two false, one adopted). Endorsement filtering here does not additionally require peer-position fidelity; it is already too sparse to support a tier comparison.

Translation labels are themselves imperfect indicators of endorsement. For example, a span saying a peer “correctly identifies” a role can be labeled `report`. Consequently, four is the count under this extraction rule, not a verified count of every acknowledgment in the raw debates.

A concrete caution: in weak heterogeneous `kks-v1-n06-001`, agent-1's argument reports “Agent-2 incorrectly assigns Player B as knight.” B being knight is actually true under the reference solution, and agent-1's next assignment switches to support it. This qualifies as citation-linked updating despite the preceding criticism. It does not explicitly credit the peer for the correction.

## Do the linked revisions improve the answer?

To avoid counting one revision several times because it updates several propositions, aggregate the primary measure to unique agent revisions. Improvement is the change in the fraction of correctly assigned player roles, not team final accuracy.

| Group | Revisions with ≥1 linked update | Improved | Worsened | Same accuracy | Mean role-accuracy change |
|---|---:|---:|---:|---:|---:|
| medium | 40 | 31 | 6 | 3 | +39.2 pp |
| size8 | 42 | 30 | 10 | 2 | +25.0 pp |
| weak | 24 | 12 | 8 | 4 | +6.2 pp |


A revision can adopt a true proposition while making other errors, or adopt a false proposition while correcting other roles. The event-level breakdown is retained in `update-summary.csv`. These improvement rates are descriptive and selected on observed updating: they are not estimates of the effect of peer citations. In particular, most propositions are closely linked to the answer, so truth-aligned updating and answer improvement are mechanically related. `revision-summary.csv` also retains revisions without linked updates; the groups are not matched or causally comparable.

## Claim suitable for FAST

> In size-6 debates, medium-model agents were more likely to revise toward true than false explicitly cited peer propositions that conflicted with their previous assignment. The true–false update-rate gap exceeded that of weak-model agents by 52.7 percentage points (puzzle-cluster bootstrap 95% CI [25.6, 79.9]); the difference persisted when requiring a prior matching statement from the cited peer.

Use “citation-linked updates,” not “peer-caused corrections” or “agents explicitly credited peers for changing their minds.” This audit supports a truth-conditioned temporal association. It does not control claim difficulty, puzzle difficulty, prior error burden, selective citation, other peer arguments, self-reasoning, or model composition. Exact expression matching misses semantic equivalents; semantic fidelity is not fully audited.

## Artifacts and checks

- `citation-edges.csv`: original translated spans, cited peer, proposition, prior/next truth values, peer-position and prior-statement checks.
- `proposition-transitions.csv`: deduplicated observations for all four inclusion rules.
- `update-summary.csv`: incompatible-citation denominators, resulting updates, and linked outcome counts.
- `update-discrimination.csv`: true–false differences and puzzle-cluster bootstrap intervals.
- `revision-outcomes.csv`, `revision-summary.csv`: unique intermediate revisions, including those without linked updates.

The script checks complete submitted role assignments, unique revision keys, and consistency of adoption/outcome counts. There are 2,400 intermediate agent revisions: 720 weak size6, 720 medium size6, and 960 size8. Final-decision stages are excluded. No new generation or intervention was performed.
