# Reasoning features and final accuracy

Reproduce: `.venv/bin/python scripts/analyze_reasoning_features.py`

## Agents by condition

Each team has three debaters. Columns identify agent slots, not speaking order.

| Condition | Agent 1 | Agent 2 | Agent 3 |
|---|---|---|---|
| size6 weak hom | GPT-4.1 mini | GPT-4.1 mini | GPT-4.1 mini |
| size6 weak het | GPT-4.1 mini | Gemini 3.1 Flash-Lite | Llama 4 Maverick |
| size6 medium hom | Mercury 2 (low) | Mercury 2 (low) | Mercury 2 (low) |
| size6 medium het | Gemini 3.5 Flash-Lite (medium) | Mercury 2 (low) | GPT-OSS-20B (medium) |
| size8 hom | GPT-OSS-20B (medium) | GPT-OSS-20B (medium) | GPT-OSS-20B (medium) |
| size8 het | Gemini 3.5 Flash-Lite (medium) | Mercury 2 (low) | GPT-OSS-20B (medium) |

Parentheses give configured reasoning effort. GPT-4.1 mini uses the
`2025-04-14` snapshot. All six conditions configure GPT-5 nano
(`2025-08-07`, medium reasoning) as supervisor, separate from the three debaters.
Rosters were checked against the source runs' `resolved_config.yaml` files.

## Sample

120 debates with formal-logic translations: the four paired size-6 conditions
(weak/medium × heterogeneous/homogeneous, 20 puzzles each) from
`minimal-reasoning-size6-strength-comparison-2026-09-04`, plus the 40 fresh
size-8 debates (het/hom, 20 paired puzzles) from
`fresh-size8-heterogeneity-2026-09-05`. Acceptance rates use the 1,976
exposure pairs in `conflicting-uptake-2026-09-05`, which cover size 6 only.

Initial-supply features are computed from scored unconditional commitments in
the initial proposals, deduplicated by effective expression within a debate, so
a proposition three agents state independently counts once.

## 1. Supply and quality by condition

| Condition | Acc. | Distinct props | Precision | True bits | Misleading bits | Net bits | False resistance |
|---|---:|---:|---:|---:|---:|---:|---:|
| size6 weak hom | 0.05 | 18.6 | 0.518 | 8.27 | 13.19 | −4.91 | 0.414 |
| size6 weak het | 0.10 | 17.3 | 0.511 | 7.50 | 11.62 | −4.12 | 0.514 |
| size6 medium hom | 0.85 | 15.4 | 0.674 | 9.79 | 6.80 | +2.99 | 0.716 |
| size6 medium het | 0.90 | 15.7 | 0.678 | 10.02 | 7.95 | +2.07 | 0.741 |
| size8 hom | 1.00 | 16.5 | 0.676 | 12.06 | 6.99 | +5.07 | 0.605 |
| size8 het | 0.75 | 18.4 | 0.589 | 10.82 | 10.05 | +0.76 | 0.632 |

**Diversity and quality move in opposite directions.** Weak teams put *more*
distinct propositions on the table than medium teams (18.0 vs 15.5 on the same
20 puzzles) at roughly half precision (0.51 vs 0.68), and their pooled initial
content points *away* from the solution on net (−4.5 bits vs +2.5 bits). Volume
of formal content is not a proxy for informativeness.

### Follow-up: individual supply and overlap

The [initial-proposition overlap analysis](initial-overlap/README.md) separates
per-agent supply, cross-agent repetition, and exclusive true/false content.
Weak heterogeneous teams supply fewer propositions across agents but also
repeat fewer, partly offsetting the difference in their team union. Medium
size-6 teams are similar on both components. At size 8, additional exclusive
content is mostly false, but that contrast is sensitive to one zero-supply
puzzle. No comparison clearly increases exclusive true propositions.

The follow-up includes zero extracted supply when initial fields are present;
its size-8 homogeneous mean therefore uses 20 runs rather than the 19 in the
table above. It reports both inclusion choices and paired confidence intervals.

## 2. Resistance to false peer claims, by tier

Adoption of an exposed peer proposition, size 6, CIs bootstrapped over debates.
"Contradicting" keeps only pairs where the proposition is false under the
recipient's own initial assignment, so uptake means abandoning a commitment.

| Tier | Scope | True claims | False claims | Discrimination |
|---|---|---:|---:|---:|
| Weak | all exposures | 0.498 [0.431, 0.567] | 0.474 [0.399, 0.551] | **+0.024 [−0.080, 0.129]** |
| Medium | all exposures | 0.692 [0.626, 0.759] | 0.208 [0.128, 0.291] | **+0.484 [0.375, 0.585]** |
| Weak | contradicting only | 0.423 [0.341, 0.510] | 0.393 [0.319, 0.474] | +0.031 [−0.107, 0.160] |
| Medium | contradicting only | 0.843 [0.760, 0.916] | 0.158 [0.093, 0.240] | **+0.685 [0.569, 0.787]** |

Medium minus weak discrimination: **+0.460 [0.308, 0.615]** over all exposures,
**+0.654 [0.475, 0.823]** restricted to claims that contradict the recipient.

This is the sharpest tier difference in the analysis, and it is about
*rejection*, not supply. The gap between the tiers on true claims is modest
(0.692 vs 0.498); the gap on false claims is the striking one — medium teams
refuse 79% of false peer propositions and 84% of the ones that contradict their
own position, while weak teams refuse 53% and 61%, barely more often than they
refuse true content. Weak uptake is essentially insensitive to truth. The two
tiers see comparable amounts of content; they differ in what they turn down.

The `discrimination` column is reported because it is the quantity that is
immune to conditioning on the outcome, but note that the two halves are not
equally load-bearing at the debate level: Section 6b shows that only the
false-claim half separates correct from incorrect debates within a condition.

### Follow-up: explicitly cited peer claims and subsequent updates

The [citation-linked update audit](attributed-updates/README.md) requires a peer
reference in an argument before the next answer revision. Among cited claims
supported by the peer's previous assignment but incompatible with the
recipient's previous assignment, medium size-6 recipients revise to support
41/52 true claims and 9/57 false claims; weak recipients do so for 13/42 and
14/68. The medium-minus-weak true–false update-rate gap is +52.7 percentage
points [25.6, 79.9], using a bootstrap that jointly resamples shared puzzles.
The pattern persists when the peer must also have previously stated the exact
proposition. These are citation-linked changes, not proven causal uptake;
explicit endorsement labels are too sparse for a tier comparison.

## 3. Which features are associated with accuracy

AUC = P(feature is higher in a correct debate than in an incorrect one), ties
at 0.5. `auc_pooled` uses all 120 debates; `auc_within_condition` counts
concordant pairs only inside a condition and then pools them, so a feature that
merely tracks model capability cannot score well on it. Full table with CIs in
`feature-auc.csv`.

| Feature | Window | AUC within condition |
|---|---|---:|
| At least one exactly correct initial solution | initial | 0.90 [0.84, 0.95] |
| Net initial bits (truth-aligned − misleading) | initial | **0.86 [0.73, 0.95]** |
| Initial precision | initial | **0.85 [0.73, 0.94]** |
| **False-claim resistance (share of false peer props refused)** | mid-debate | **0.84 [0.72, 0.94]** |
| Selectivity (uptake true − uptake false) | mid-debate | 0.82 [0.65, 0.95] |
| Truth-aligned initial bits | initial | 0.80 [0.66, 0.91] |
| Distinct true propositions | initial | 0.78 [0.64, 0.90] |
| Uptake of true peer propositions | mid-debate | 0.62 [0.43, 0.82] |
| **Distinct propositions supplied (raw diversity)** | initial | **0.55 [0.36, 0.73]** |
| Misleading initial bits | initial | 0.26 [0.13, 0.42] |
| Distinct false propositions | initial | 0.24 [0.10, 0.41] |
| Uptake of false peer propositions | mid-debate | 0.16 [0.06, 0.28] |

Raw diversity is the null result: **the number of distinct propositions a team
supplies is uninformative about whether it will be right** (0.55, CI spanning
0.5; pooled AUC 0.47). Everything that predicts accuracy is a signed quantity —
the truth-weighted composition of the supply, or the rate at which false peer
content is refused.

False-claim resistance is preferred over selectivity as the selection measure
throughout. It has the tighter interval (0.84 [0.72, 0.94] vs 0.82 [0.65, 0.95])
and, per Section 6b, it is the half of selectivity that carries the signal:
uptake of *true* peer content does not separate correct from incorrect debates
within a condition in any specification (0.62 [0.43, 0.82]).

Whole-debate reasoning features (`sound_reasoning_rate` 0.79,
`stated_relation_validity` 0.46, `unsupported_error_rate` 0.02) are reported in
the CSV but should not be read as antecedents: they are measured over stages
that include the final decision, so a debate that ends correctly scores better
on them mechanically.

## 4. Are more information bits actually helpful?

Median split on net initial bits and on false-claim resistance, over the 104
debates where resistance is defined:

| Supply (net bits) | Resistance to false claims | n | Accuracy |
|---|---|---:|---:|
| high | high | 33 | 0.88 |
| high | low | 19 | 0.47 |
| low | high | 19 | 0.63 |
| low | low | 33 | 0.21 |

The answer is conditional. Bits help when the team refuses the false half of
what it hears: moving from low to high supply is worth +0.25 among resistant
teams and +0.26 among unresistant ones, but **high supply with low resistance
(0.47) does worse than low supply with high resistance (0.63)**. More
information is not self-evidently good; it pays off only in a team that rejects
the misleading part of it, and a team that absorbs indiscriminately is better
off with less on the table. That is why the raw-diversity AUC is 0.55 while the
net-bits AUC is 0.86.

The same table split on selectivity instead of resistance gives 0.87 / 0.55 /
0.68 / 0.15 (`supply-by-selection.csv` carries both). The pattern is the same;
resistance is reported because Section 6b shows the true-uptake half of
selectivity contributes no debate-level signal.

These are median splits on observational data, not an intervention. Supply and
resistance are both downstream of model capability and are correlated with each
other, so the cells are not matched samples.

## 5. Does heterogeneity generate more information?

Heterogeneous minus homogeneous on the same puzzle, within tier
(`heterogeneity-contrasts.csv`):

| Comparison | Net bits | Misleading bits | Distinct props | Accuracy |
|---|---:|---:|---:|---:|
| size6 weak | +0.79 [−2.48, 4.75] | −1.57 [−5.77, 2.35] | −1.35 [−5.05, 2.50] | +0.05 [0.00, 0.15] |
| size6 medium | −0.92 [−4.70, 3.01] | +1.15 [−1.95, 4.36] | +0.25 [−3.45, 3.50] | +0.05 [−0.10, 0.25] |
| size8 | **−4.31 [−8.82, −0.24]** | +2.89 [−0.52, 6.40] | +1.58 [−3.58, 6.42] | **−0.25 [−0.45, −0.05]** |

**This sample does not support "heterogeneity generates more information
bits."** At size 6 every contrast straddles zero in both tiers. At size 8 the
heterogeneous teams supply 4.3 *fewer* net bits than the homogeneous GPT-OSS
teams, with the deficit coming from misleading content (+2.9 misleading bits,
CI straddling zero) rather than from less true content, and they are less
accurate (15/20 vs 20/20). Adding weaker models widened the pool without
improving its composition.

If the paper needs a heterogeneity-versus-homogeneity information claim, it has
to be written in the direction the data goes, or restricted to the older
recalibrated size-8 comparison — which used a Mercury homogeneous control, not
this one, and is superseded for this contrast per
`size8-complementarity-audit-2026-09-04`.

## 6. Is uptake just the final answer restated?

Partly, and the two directions answer differently: **resistance to false
content survives every restriction; receptiveness to true content does not
survive even the baseline** once the tier confound is removed. This asymmetry
is why the report is written around false-claim resistance rather than around
a symmetric selectivity measure.

The construction risk is symmetric and large. Role atoms — pieces of an
assignment rather than constraints on one — make up 63.9% of the distinct true
propositions available from initial proposals at size 6 (77.1% at size 8) and
68.5% of the false ones (73.1% at size 8). Re-expressing one in the explanation
attached to a revised answer is close to submitting that answer.

Three restrictions cut the three mechanical paths, separately and together
(`check_uptake_not_answer_restatement.py`, results in
`uptake-restriction-checks.csv`):

- **`argument_only`** — adoption must occur in a `debate_argument` field
  (`agree_reasoning` / `disagree_reasoning`). No assignment is submitted with
  those fields, so re-expression there cannot be a readback of the speaker's
  own answer.
- **`non_role`** — the proposition contains no ROLE atom. What remains is
  statement-truth, counts, parity, and connectives.
- **`early`** — adoption must occur strictly before the last debate round, so
  it cannot be the final answer under an earlier stage label.
- **`strict`** — all three at once.

Two statistics per cell. The **pooled gap** is the raw correct-minus-incorrect
difference in uptake; it is confounded with tier, because weak conditions are
almost all incorrect and medium almost all correct. The **within-condition gap**
averages gaps computed inside a condition, matching what the stratified AUC
does. Read the within-condition column.

### 6a. Uptake of false claims — survives, attenuated

| Restriction | correct | incorrect | Pooled gap | Within-condition gap [95% CI] | AUC [95% CI] |
|---|---:|---:|---:|---:|---:|
| baseline | 0.275 | 0.557 | −0.282 | **−0.355 [−0.500, −0.208]** | 0.158 [0.057, 0.284] |
| argument_only | 0.088 | 0.284 | −0.196 | **−0.236 [−0.371, −0.113]** | 0.158 [0.020, 0.321] |
| non_role | 0.277 | 0.627 | −0.350 | **−0.531 [−0.754, −0.282]** | 0.117 [0.000, 0.297] |
| early | 0.272 | 0.555 | −0.283 | **−0.352 [−0.501, −0.205]** | 0.151 [0.051, 0.272] |
| **strict** | **0.058** | **0.227** | **−0.168** | **−0.252 [−0.546, −0.032]** | **0.315 [0.134, 0.470]** |

- **`early` changes nothing** (AUC 0.151 vs 0.158). Adoption of false content is
  not concentrated next to the final answer, so "the same event under an
  earlier stage label" is not the mechanism.
- **`non_role` strengthens it** (within-condition gap −0.531). Propositions that
  are not pieces of an assignment separate correct from incorrect debates
  better than role atoms do, so the signal is not specific to answer-shaped
  content.
- **`strict` attenuates but does not remove it.** AUC moves 0.158 → 0.315,
  about half the distance to the 0.5 null, CI still excluding it, on 79 debates
  and 560 eligible propositions. Part of the baseline association *is*
  restatement; a weaker one remains after removing it.

### 6b. Uptake of true claims — does not survive, and never did

| Restriction | correct | incorrect | Pooled gap [95% CI] | Within-condition gap [95% CI] | AUC [95% CI] |
|---|---:|---:|---:|---:|---:|
| baseline | 0.755 | 0.512 | +0.243 [0.149, 0.339] | +0.119 [−0.028, 0.264] | 0.624 [0.426, 0.815] |
| argument_only | 0.558 | 0.326 | +0.232 [0.147, 0.321] | +0.078 [−0.071, 0.235] | 0.592 [0.398, 0.779] |
| non_role | 0.828 | 0.605 | +0.223 [0.100, 0.349] | +0.041 [−0.110, 0.192] | 0.556 [0.373, 0.740] |
| early | 0.751 | 0.504 | +0.247 [0.154, 0.344] | +0.132 [−0.014, 0.282] | 0.629 [0.431, 0.821] |
| strict | 0.431 | 0.296 | +0.135 [0.019, 0.256] | +0.163 [−0.069, 0.384] | 0.647 [0.422, 0.840] |

**Every within-condition gap CI contains zero and every AUC CI contains 0.5, in
all five specifications including the baseline.** The large pooled gap is the
tier difference: medium teams both adopt more true content and are more
accurate, and within a condition the correct and incorrect debates are not
distinguishable by how much true content they take up.

This is not a restatement artifact — the restrictions barely move the estimate
— it is an absence of effect that the pooled numbers were hiding. `non_role`
does attenuate it toward zero (+0.041), which is the one hint that the pooled
association leans on answer-shaped content, but the baseline was already null.

### 6c. Why the report measures resistance rather than selectivity

Selectivity (uptake_true − uptake_false) also survives every restriction:
within-condition gap +0.434 [0.241, 0.640] at baseline, +0.498 [0.164, 0.797]
under `non_role`, +0.530 [0.196, 0.973] under `strict`; AUC 0.816, 0.897, 0.828.
But given 6b, **that power is carried entirely by the false half**, and the
composite is the weaker estimator for it: false-claim resistance reaches AUC
0.842 [0.716, 0.943] against selectivity's 0.816 [0.651, 0.947] on the same
debates.

So the report states the finding as **resistance to false peer content**, and
avoids "selective", "discriminating", or "selects well", which imply a
symmetric ability the data does not show. Concretely:

- Supported: debates that refuse more of the false content they are exposed to
  end correct more often, within condition, after the restatement paths are cut.
- Not supported: debates that take up more of the true content they are exposed
  to end correct more often. Within condition this is null in all five
  specifications.

Selectivity is retained in `feature-auc.csv` and `supply-by-selection.csv` so
the composite can be checked, but it is not the headline quantity.

Section 2's tier comparison is unaffected by all of this: it compares uptake of
true against false content **within** a tier without conditioning on the
outcome, so it cannot be produced by splitting on success.

Two caveats. `strict` is thin: 79 debates with a defined false-uptake rate and
73 with a defined selectivity, so its CIs are doing real work. And `non_role`
removes the *syntactic* readback path, not every logical link to the answer —
`STMT_TRUE(B)` is determined by the assignment even though it never appears in
one.

## Limitations

- Twenty puzzles per condition, one repetition each; no repetitions to separate
  sampling variance from condition effects.
- Within-condition AUCs rest on few discordant pairs (weak conditions have 3
  correct debates in 40; size-8 hom has no incorrect debates and contributes no
  pairs). The CIs reflect this; the point estimates should not be quoted
  without them.
- All features are observational and mutually correlated. No feature here is
  shown to *cause* the outcome; `any_initial_correct` in particular is close to
  a restatement of the outcome for easy puzzles.
- Uptake is re-expression by a non-introducer before the final decision. It
  shows the recipient's expressed commitment changed, not that the peer caused
  it.
- Translation error (`formal-logic-translation-issues.md`) is not propagated
  into any interval reported here.

## Files

- `debate-features.csv` — one row per debate, all features
- `feature-auc.csv` — Section 3 with pooled and within-condition CIs
- `acceptance-by-tier.csv`, `acceptance-contrasts.csv` — Section 2
- `supply-by-condition.csv` — Section 1
- `supply-by-selection.csv` — Section 4, split on resistance and on selectivity
- `heterogeneity-contrasts.csv` — Section 5
- `uptake-restriction-checks.csv`, `uptake-restriction-per-debate.csv`,
  `uptake-proposition-shape.csv` — Section 6
