# Claim-uptake revision: verified findings and integration notes

Reproduce: `.venv/bin/python scripts/fast_claim_uptake.py`

## Replacement Section 3.2

To examine differences in expressed uptake, we measured true-claim adaptation and false-claim resistance. Eligible units are distinct informative claim-recipient pairs: a claim asserted or endorsed in an initial proposal and another agent who did not initially assert or endorse the same formal expression. We exclude expressions containing explicit role-assignment atoms, as well as redundant and contradictory claims. Adaptation is the fraction of eligible true pairs subsequently asserted or endorsed by the recipient before the final decision; resistance is one minus the corresponding false-claim uptake rate. Reports without endorsement and rejections do not count as uptake. Truth is evaluated against the verified solution; resistance denotes non-adoption, not explicit rejection.

Across 80 debates on 20 shared six-character puzzles, strong teams showed greater true-claim adaptation (81.5% versus 56.3%) and false-claim resistance (85.6% versus 51.6%) than weak teams (Table 2). The true-minus-false uptake gaps were 67.1 and 7.8 percentage points, respectively; their difference was 59.3 points (95% puzzle-cluster bootstrap CI [42.8, 76.2]). The contrast remained positive within each composition and when restricting eligibility to claims incompatible with recipients' initial assignments. Counts incorporate four disclosed literal-polarity corrections; the original uncorrected contrast was 58.1 points [40.9, 75.9].

This result associates team competence with truth-sensitive expressed uptake among the fixed rosters studied. The non-role restriction removes explicit role-assignment atoms but does not remove all logical links to role assignments. Claim sets differ across teams; a shared-claim sensitivity check preserves the direction of the contrast. Subsequent expression can reflect peer influence, independent derivation, or previously unstated agreement. Our attribution audit did not supply a sufficiently reliable, populated comparison to distinguish these explanations. Neither selective peer influence nor a causal effect on debate improvement is established.

| Team | True uptake | False resistance | Uptake gap (95% CI) |
| --- | --- | --- | --- |
| Weak | 56.3% (130/231) | 51.6% (99/192) | 7.8 [-6.6, 21.8] |
| Strong | 81.5% (159/195) | 85.6% (77/90) | 67.1 [56.8, 78.4] |

## Statistical methods

Rates pool eligible pairs within tier; repeated occurrences count once per pair. The primary matching rule is exact equality of effective formal expressions, not unrestricted semantic equivalence. There are 20 independent puzzle clusters, four conditions per puzzle, and one run per condition-puzzle. The bootstrap samples 20 puzzle IDs with replacement jointly across all conditions, retaining every claim, recipient, and truth category inside each sampled cluster. We use 10,000 percentile draws (seed 20260906). Zero denominators remain undefined; the tables record defined bootstrap draws. These are exploratory intervals conditional on fixed rosters and translated claims, not model-population or translation-uncertainty intervals. The primary inferential contrast is the between-tier difference in the true-minus-false uptake gap; robustness checks are descriptive, without claims of multiplicity-adjusted significance.

| Composition / tier | True uptake | False resistance | Gap (95% CI) |
| --- | --- | --- | --- |
| Heterogeneous / strong | 80/98 | 50/54 | 74.2 [62.7, 85.1] |
| Heterogeneous / weak | 64/112 | 49/89 | 12.2 [-5.3, 29.6] |
| Homogeneous / strong | 79/97 | 27/36 | 56.4 [36.0, 80.5] |
| Homogeneous / weak | 66/119 | 50/103 | 4.0 [-16.1, 23.0] |

## Robustness

Gap differences are strong minus weak, in percentage points.

| Restriction | Difference (95% CI) | Defined draws |
| --- | --- | --- |
| Semantic matching (original corpus) | 62.9 [43.3, 82.7] | 10000 |
| Include self-reports (original corpus) | 58.7 [41.4, 76.3] | 10000 |
| Corrected primary | 59.3 [42.8, 76.2] | 10000 |
| Initially incompatible claims | 68.7 [56.2, 81.7] | 10000 |
| Uptake in argument fields only | 23.2 [7.7, 40.1] | 10000 |
| Uptake before last round | 58.1 [41.1, 75.7] | 10000 |
| Shared claims, equal stratum weights | 79.4 [40.4, 108.9] | 9999 |

## Attribution audit

Among the 708 original eligible pairs, no uptake event was tagged as an explicit ENDORSE of an initial introducer. A broader proxy required a reference to an initial introducer plus a separate commitment to the same proposition in the same reasoning field: it identified three weak-team pairs (two true, one false) and zero strong-team pairs. The audit contains all 78 matching reference occurrences, including non-endorsements. Including self-inclusive reports as commitments yields 5 true and 0 false attributed pairs for strong teams, versus 23 true and 26 false for weak teams; the between-tier gap contrast is 6.1 points [-3.0, 15.7]. These broader occurrences often say that agents agree; they do not establish that the speaker changed because of a peer. A source-text spot-check also found explicit peer credit missing from the attribution tags. Consequently, annotation sparsity and incomplete attribution capture preclude a reliable influence comparison. Zero observed events do not establish a zero population rate; a degenerate bootstrap interval is uninformative.

An assistant reviewed full origin and first-uptake fields for 16 reproducibly sampled adopted pairs, two per condition and truth category. Fourteen were supported, one had an inverted truth-value translation, and one had an ambiguous conditional origin. A corpus-wide conservative full-span polarity screen then found four clear mismatches; all four full source fields were reviewed and corrected in a separate analysis overlay. This changes strong false uptake from 14/90 to 13/90 and leaves the other pooled counts unchanged. Original translation artifacts remain intact. This targeted assistant review is not an independent human validation study and does not estimate coverage or the error rate among non-adoptions. The ambiguous pair remains disclosed rather than silently relabeled.

## Consistent Section 3.3 / Table 3

Table 3 must use the same non-role claim-recipient definition as Table 2. The supplied PDF instead uses the earlier all-proposition, any-peer uptake estimator for its uptake AUCs. Recomputing with consistent definitions and the polarity corrections gives within-condition AUCs of 0.813 for selectivity (52 eligible debates), 0.756 for resistance (53), and 0.676 for adaptation (69). Their puzzle-cluster intervals include 0.5, so these data do not establish within-condition outcome discrimination for these measures. Net initial information remains 0.930 and any correct initial solution remains 0.919; their numerical ordering is not a tested performance difference or evidence of incremental predictive value. All AUCs are descriptive outcome discrimination, not held-out prediction. The differing eligible samples also limit comparisons.

| Measure | n | Pooled AUC | Within-condition (95% CI) |
| --- | --- | --- | --- |
| Net initial information | 80 | 0.836 | 0.930 [0.798, 1.000] |
| Any correct initial solution | 80 | 0.882 | 0.919 [0.816, 0.989] |
| Initial claim precision | 80 | 0.811 | 0.884 [0.748, 0.980] |
| Truth-aligned initial bits | 80 | 0.739 | 0.873 [0.690, 0.987] |
| True uptake minus false uptake | 52 | 0.897 | 0.813 [0.451, 1.000] |
| False-claim resistance | 53 | 0.827 | 0.756 [0.375, 1.000] |
| True-claim adaptation | 69 | 0.749 | 0.676 [0.473, 0.875] |
| Distinct initial propositions | 80 | 0.426 | 0.489 [0.215, 0.712] |

## Integration and remaining limitations

Use strong/weak as defined in the supplied paper, retaining Appendix A's disclosure that strong maps to the original medium-tier runs. Strength was assigned from prior solo qualification, not these debate outcomes; qualifications used the same benchmark task pool, so this is not held-out model selection. The attached PDF is the current Beyond Accuracy paper; the local paper/fast2026/main.tex is a different manuscript. These files are replacement sections, not a silently modified or submission-ready full paper. Integration requires the current LaTeX source. Also resolve the PDF's conclusion TODO, anonymous repository-link TODO, and checklist placeholders. Section 3.1 should not claim that rejected propositions were scored through their negations: the current scorer treats rejection as an uncommitted attitude. Its treatment of self-inclusive reports must also be stated consistently. Corpus-wide quality statistics and reasoning relations have not been regenerated from the four-claim overlay; either retain them explicitly as original-corpus results or regenerate them before claiming a uniformly corrected corpus.

## Suggested conclusion

Claim-level formalization separates information quantity, truth, and expressed uptake in multi-agent debate. In this controlled corpus, higher-competence teams show a larger true-versus-false uptake gap across both compositions, while initial information quality is associated with final correctness. Attribution coverage and the small number of independent puzzles limit conclusions about peer influence and outcome mechanisms. The framework therefore offers observable diagnostics for debate, rather than a causal explanation of why debate improves answers.

Shared-claim checks retain only puzzle/composition/expression strata present in both tiers, average recipients within each stratum, and give each shared stratum equal weight. Only 9,999/10,000 gap draws are defined. Semantic matching compares truth signatures over all 192 exactly-one-spy role worlds per puzzle, never only the single verified solution. These restrictions do not randomize claim supply.

Artifacts include original and corrected pair ledgers, all attribution candidates with source context, the 16 reviewed examples, four polarity corrections, bootstrap results, per-debate AUC inputs, and input hashes.
