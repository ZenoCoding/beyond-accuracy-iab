# Selection measured only where the peer claim contradicted the recipient

Reproduce: `.venv/bin/python scripts/analyze_conflicting_uptake.py`

## Why

`supply-and-selection-2026-09-05` counts uptake of any proposition an agent put
in its initial proposal. That denominator includes propositions the recipient
already agreed with, so a debate whose agents are simply correct can score high
selectivity without ever evaluating a peer. This restriction keeps only
(proposition, recipient) pairs where the proposition is **false under the
recipient's own initial role assignment** — the recipient held an incompatible
position when exposed, so uptake means abandoning a commitment.

Truth of the proposition (`information_type`) and conflict with the recipient
are evaluated independently: truth against the gold world, conflict by
`evaluate_expr` against the recipient's own initial answer. Sample: the four
size-6 conditions, 80 debates, 1,976 exposure pairs.

Denominator change from the earlier analysis: the unit is the
(proposition, recipient) pair rather than the proposition, so uptake rates
differ slightly from `supply-and-selection-2026-09-05`.

## Result 1 — content-sensitive resistance (does not condition on outcome)

Adoption rate, pooled; CIs bootstrapped over debates (n=80).

| Proposition | Compatible with recipient | Contradicts recipient |
|---|---|---|
| True | 0.593 (n=663) | 0.599 (n=426) |
| False | 0.572 (n=243) | **0.289 (n=644)** |

- Effect of contradicting the recipient, true claims: +0.006 [-0.075, 0.084]
- Effect of contradicting the recipient, false claims: **-0.283 [-0.372, -0.196]**
- Interaction: **-0.289 [-0.401, -0.177]**
- Truth gap among contradicting claims: **+0.310 [0.187, 0.428]**

Contradiction alone does not make agents resist a claim; contradiction plus
falsehood does. This does not condition on the outcome, so it cannot be an
artifact of splitting on success.

## Result 2 — the outcome split survives the restriction

| Metric | Correct | Incorrect | Diff [95% CI] |
|---|---|---|---|
| Uptake of contradicting true claims | 0.895 | 0.390 | +0.505 [0.407, 0.601] |
| Uptake of contradicting false claims | 0.144 | 0.460 | -0.316 [-0.442, -0.188] |
| Selectivity (conflicting only) | +0.725 | -0.058 | **+0.783 [0.601, 0.949]** |
| Selectivity (unrestricted) | +0.582 | -0.063 | +0.645 [0.497, 0.796] |

Failed debates adopt contradicting *false* claims more often than contradicting
*true* ones. Restricting to conflicts widens the gap rather than removing it.

Within the medium tier (24 correct / 5 incorrect debates with both
denominators): selectivity_conflict +0.508 [0.166, 0.792].

## Limitations

- **Residual entanglement.** Adopting a contradicting true claim is close to
  "fixing a role", so its association with success is partly mechanical. The
  false-claim half is the informative one. The eligible denominator also
  differs by outcome (4.4 vs 6.1 contradicting true claims per debate,
  diff -1.7 [-3.2, -0.2]): correct debates start with fewer wrong positions.
- **The weak-tier row in `contrasts.csv` is not interpretable.** Only 1 of the
  3 correct weak debates has both denominators non-empty, so its bootstrap CI
  is over n=1. Medium is the only within-tier check with data.
- Uptake is re-expression by a non-introducer before the final decision. It
  shows the recipient's expressed commitment changed, not that the peer caused
  it; the recipient may have recomputed independently.
- Translation reliability (`formal-logic-translation-issues.md`) is not
  reflected in these intervals.

## Files

- `per-debate.csv` — restricted and unrestricted uptake per debate
- `exposure-pairs.csv` — one row per (proposition, recipient) pair
- `pooled-interaction.csv` — Result 1 with debate-clustered CIs
- `contrasts.csv`, `group-means.csv` — Result 2
