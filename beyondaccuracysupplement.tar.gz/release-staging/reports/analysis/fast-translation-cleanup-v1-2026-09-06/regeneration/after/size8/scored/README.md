# Minimal-translator reasoning analysis

## Interpretation

This report measures the truth and information content of explicit commitments,
the local validity of explicitly stated reasoning relations, and descriptive
consistency of flat hypothetical cases. It does not reconstruct whole proofs.

## Metric rules

- ASSERT and ENDORSE are scored directly; REJECT is scored through negation.
- Information uses all role assignments with exactly one spy as its baseline.
- Each commitment is measured twice. Unconditional information uses that whole
  baseline; conditional information uses only the worlds its stated premises
  still allow, following IG = log2(|W(P)| / |W(P + c)|).
- Premises come from stated INFER relations, and from the undischarged members
  of the contradiction a REDUCTIO cites. Both universes are identical, so the
  two measures coincide for a claim with no extracted premises.
- `false_premise_scoped` marks a claim whose premises had already excluded the
  verified solution: it is a distinct category from `misleading`, which marks a
  claim that eliminates a still-reachable solution.
- A relation counts as valid when its verdict is `entailed`, `valid_contradiction`,
  or `valid_reductio`. `contingent` means the conclusion does not follow from the
  premises the speaker cited, which is weaker than calling it a fallacy: an
  unstated premise reads the same way. `inconsistent_premises` is never counted
  valid, because explosion is disabled.
- `support_cell` crosses conclusion truth with local validity over INFER relations
  whose conclusion is a committed, scored claim. Case-scoped conclusions are
  hypothetical and carry no unconditional truth value, and uncheckable relations
  are held out rather than folded into "not entailed"; both are counted separately
  in `support-soundness.csv`.

## Background assumptions

Local validity is relative to the worlds left open before a step is taken, so the
background policy is a reported choice rather than a fixed fact.

- `thin` applies the knight/knave truth rule only to players whose statement-truth
  atom appears in the cited claims.
- `referenced_roles` also applies it to players named individually. This is the
  default second policy: it is a real widening, and it leaves the world set
  non-degenerate for almost every relation.
- `referenced_all` additionally fixes every player listed by a `COUNT` or `PARITY`
  atom. Because those atoms usually range over the whole roster, the world set
  then collapses to the puzzle's unique solution and `entailed` degenerates into
  "true at the solution". It remains selectable for audit only.
- A policy fixing every player is deliberately not offered, for the same reason.

`relation-background-sensitivity.csv` reports the verdict transition matrix
between the two configured policies, and every relation row carries
`local_world_count` and `background_degenerate` so a collapsed comparison is
visible per row rather than averaged away. REDUCTIO verdicts are checked
structurally and do not move with the policy.

## Relation capture

Relation extraction is the translator's weakest dimension, so every rate above is
a rate *among captured relations*, not a census of the speaker's reasoning.
Measured recall and precision per condition are recorded in `summary.json` under
`relation_capture`, taken from the configured gold evaluation rather than
restated here, and are absent where no gold evaluation is configured.
- Reports, assumptions, hypotheticals, opaque claims, and parse failures are not
  unconditional commitments and do not enter claim-accuracy denominators.
- Incomplete cases remain in coverage tables but do not enter disposition accuracy.
- Raw information totals are verbosity-sensitive; comparisons use normalized
  rates and mean bits per eligible claim.

## Research boundary

These outputs remain descriptive until a frozen multi-puzzle expert audit
validates expression fidelity, commitments, case IDs, and case dispositions.

`stated_premise_status = none_extracted` does not mean the speaker gave no
reason. The translator emits a relation only where the source explicitly
connects two already translated claims, so an omitted relation and a genuinely
unsupported assertion are indistinguishable here. Premise coverage over
committed claims is reported beside every conditional figure for that reason,
and unsupported-leap rates cannot be read off these tables.

Local dependency validity is measured, conditionally on capture and relative to a
stated background policy. It is evidence about single steps, not about how errors
travel: relations are local to one reasoning field, and error propagation across
agents and rounds, recovery, peer adoption, and causal influence are not
measured.

## Inventory

- Conditions: 2
- Debates: 7
- Fields: 398
- Claims: 3737
- Cases: 64
- Relations: 1295
- Checked relations: 1093
- Locally valid relations: 344
- Relations whose verdict moves with the background policy: 107
- Committed claims with stated premises: 795 / 2541
