"""Record primary integration of independently reviewed, exact source edits.

Review decisions are human-readable inputs, not a heuristic repair algorithm.
This pass accepts only the listed clear proposals. Ambiguous h1/h6 and U10
initial commitments remain unchanged. No matching/scoring policy is altered.
"""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
inventory=json.loads((P/'input-inventory.json').read_text())
records={};source_meta={}
for s in inventory['sources']:
    for line in (P/'frozen'/s['translation_file']).read_text().splitlines():
        r=json.loads(line);k=(s['condition_id'],r['formalization_id'])
        assert k not in records;records[k]=r;source_meta[k]=s
ledger=[];dependencies=[];pending=[]

def add(condition,fid,collection,rid,before,after,rationale,review_file,review_id,reviewer):
    record=records[(condition,fid)];s=source_meta[(condition,fid)]
    if before==after:
        dependencies.append(dict(condition_id=condition,formalization_id=fid,collection=collection,record_id=rid,decision='retain unchanged; rerun scoring',rationale=rationale,review_file=review_file,review_id=review_id))
        return
    entry=dict(change_id=f'TC{len(ledger)+1:03}',status='accepted',dataset=s['dataset'],condition_id=condition,task_id=record['source']['task_id'],repetition=int(record['source'].get('repetition',1)),formalization_id=fid,manifest_id=record['source']['manifest_id'],collection=collection,record_id=rid,before=before,after=after,
               source_span=(after or before)['source_span'],source_text_sha256=hashlib.sha256(record['source_text'].encode()).hexdigest(),translation_file=s['translation_file'],translation_sha256=hashlib.sha256((P/'frozen'/s['translation_file']).read_bytes()).hexdigest(),rationale=rationale,
               independent_reviewer=dict(model='gpt-5.6-sol',task=reviewer,decision_id=review_id,review_file=review_file,review_file_sha256=hashlib.sha256((P/review_file).read_bytes()).hexdigest()),
               primary_review=dict(reviewer='primary assistant',decision='accepted after source-prose and canonical-semantics review',scope='translation correction only'),human_adjudication=None)
    assert entry['source_span'] in record['source_text']
    if before is not None:assert next(x for x in record[collection] if x['id']==rid)==before
    else:assert not any(x['id']==rid for x in record[collection])
    ledger.append(entry)

initial_path='reviews/initial/review.json'
initial=json.loads((P/initial_path).read_text())
condition_by_fid={x['locator']['formalization_id']:'broad-luna-low-'+x['locator']['condition'] for x in initial['claim_actions']}
for category,collection,idkey in [('claim_actions','claims','claim_id'),('relation_actions','relations','relation_id')]:
    for x in initial[category]:
        loc=x['locator'];add(condition_by_fid[loc['formalization_id']],loc['formalization_id'],collection,loc[idkey],x['before'],x['after'],x['rationale'],initial_path,x['action_id'],'initial_corrections')
pending.extend(initial['retained_ambiguities'])

uptake_path='reviews/uptake/claim-operations.jsonl'
for x in map(json.loads,(P/uptake_path).read_text().splitlines()):
    add(x['condition_id'],x['formalization_id'],'claims',x['id'],x['before_claim'],x['after_claim'],x['rationale'],uptake_path,x['proposal_id'],'uptake_corrections')
dependencies.append(dict(review_file='reviews/uptake/dependency-handling.json',decision='retain all existing cases/relations; removed claim IDs have no dependent endpoints'))
pending.append(dict(audit_id='U10',decision='unchanged',reason='Whether initial hypothetical count c13 is already a commitment equivalent to F true remains unresolved. Later polarity correction is independent.'))

recurring_path='reviews/recurring/review-decisions.json'
recurring=json.loads((P/recurring_path).read_text())
second_path='reviews/uptake/recurring-polarity-second-check.json'
second={(r['formalization_id'],r['claim_id']):r for r in json.loads((P/second_path).read_text())['reviews']}
for x in recurring['decisions']:
    if x['decision']=='valid_unchanged':continue
    assert x['decision']=='clear_correction'
    fid=x['field_uid'].rsplit(':',1)[1]
    for op in x['claim_operations']:
        after=op['after'];rationale=x['rationale']
        verification=second.get((fid,op['id']))
        if verification:
            assert verification['ambiguity'] is None
            assert after['expression']==verification['proposed_ast']
            if verification['recommended_action']=='drop_candidate_keep_existing_negative':
                keep=next(c for c in records[(x['condition_id'],fid)]['claims'] if c['id']==verification['existing_correct_claim_id'])
                assert {k:v for k,v in keep.items() if k!='id'}=={k:v for k,v in after.items() if k!='id'}
                after=None
                rationale+=' A second independent reviewer found that the identical corrected negative occurrence already exists as '+keep['id']+'. Primary review confirms matching expression, span, commitment and scope; remove the bad positive instead of introducing a duplicate.'
        add(x['condition_id'],fid,'claims',op['id'],op['before'],after,rationale,recurring_path,x['field_uid']+':'+op['id'],'recurring_patterns')
        if verification:
            ledger[-1]['second_independent_review']=dict(model='gpt-5.6-sol',task='uptake_corrections',review_file=second_path,review_file_sha256=hashlib.sha256((P/second_path).read_bytes()).hexdigest(),decision=verification['recommended_action'])
    dependencies.append(dict(condition_id=x['condition_id'],formalization_id=fid,decision=x['dependency_disposition'],relations=x['dependent_relations'],cases=x['dependent_cases'],review_file=recurring_path))

assert len({(r['condition_id'],r['formalization_id'],r['collection'],r['record_id']) for r in ledger})==len(ledger)
(P/'correction-ledger.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in ledger))
(P/'dependency-ledger.json').write_text(json.dumps(dependencies,ensure_ascii=False,indent=2)+'\n')
(P/'pending-ambiguities.json').write_text(json.dumps(dict(policy='Retain earlier user-authorized unresolved hypothetical labels. On asking again the user requested explanation; primary assistant explained and continued with clear errors only.',cases=pending,prior_packet='../fast-measurement-audit-2026-09-06/uptake-human-review.md',matching_and_role_filter='unchanged; semantic-equivalence methodology issues are not repaired here'),ensure_ascii=False,indent=2)+'\n')
print('Accepted operations',len(ledger),'claims',sum(x['collection']=='claims' for x in ledger),'relations',sum(x['collection']=='relations' for x in ledger),'fields',len({(x['condition_id'],x['formalization_id']) for x in ledger}),'debates',len({(x['dataset'],x['condition_id'],x['task_id']) for x in ledger}))
