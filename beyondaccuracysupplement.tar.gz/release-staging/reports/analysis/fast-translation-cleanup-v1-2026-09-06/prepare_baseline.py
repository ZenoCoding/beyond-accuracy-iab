"""Freeze exact updated 120-debate inputs and reproduce the author's table."""
from pathlib import Path
import hashlib, json, shutil, subprocess, sys
import pandas as pd
import yaml
P=Path(__file__).resolve().parent
ROOT=P.parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import remake_expanded_nonrole_auc as expanded

def main():
    paths=set()
    sources=[]
    for dataset,config in [('size6','configs/analysis/minimal-reasoning-size6-strength-comparison.yaml'),('size8','configs/analysis/fresh-size8-heterogeneity.yaml')]:
        paths.add(config)
        cfg=yaml.safe_load((ROOT/config).read_text())
        for s in cfg['sources']:
            original=(ROOT/config).parent/s['translation_file']
            relative=original.resolve().relative_to(ROOT)
            paths.add(str(relative))
            sources.append(dict(dataset=dataset,condition_id=s['id'],condition_label=s['condition_label'],translation_file=str(relative),run_dir=str(((ROOT/config).parent/s['run_dir']).resolve()),relation_backgrounds=cfg.get('relation_backgrounds',['thin','referenced_roles'])))
    for base in [expanded.SIZE6,expanded.SIZE8]:
        for name in ['claims.csv','debates.csv','summary.json']: paths.add(str((base/name).relative_to(ROOT)))
    for name in ['debate-features.csv','exposure-pairs.csv','feature-auc.csv','paper-auc.csv','README.md','condition-counts.csv']:
        paths.add('reports/analysis/expanded-nonrole-auc-2026-09-06/'+name)
    paths.add('reports/analysis/reasoning-features-2026-09-05/debate-features.csv')
    paths.add('reports/analysis/conflicting-uptake-2026-09-05/exposure-pairs.csv')
    for name in ['scripts/remake_expanded_nonrole_auc.py','scripts/analyze_reasoning_features.py','src/controlmad/analysis/formal_logic_minimal.py','src/controlmad/analysis/formal_logic_minimal_report.py','src/controlmad/analysis/formal_logic_compact.py','src/controlmad_replication/benchmarks/kks/logic.py']:
        paths.add(name)
    for size in [6,8]:
        for kind in ['questions','labels']:paths.add(f'data/kks/v1/{kind}/{size}.jsonl')
    inventory=[]
    for rel in sorted(paths):
        f=ROOT/rel;target=P/'frozen'/rel;target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert target.read_bytes()==f.read_bytes()
        else:shutil.copyfile(f,target)
        inventory.append(dict(repository_path=rel,frozen_path=str(target.relative_to(P)),sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
    meta=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),sources=sources,files=inventory,cohort='80 original size-6 + 40 fresh size-8; no historical size-8',bootstrap=dict(draws=2000,seed=20260905,unit='debates independently within each condition'))
    (P/'input-inventory.json').write_text(json.dumps(meta,indent=2)+'\n')
    original_dest=expanded.DEST
    expanded.DEST=P/'baseline'
    expanded.main()
    comparisons=[]
    for name in ['debate-features.csv','exposure-pairs.csv','feature-auc.csv','paper-auc.csv','condition-counts.csv']:
        actual=pd.read_csv(expanded.DEST/name);expected=pd.read_csv(original_dest/name)
        pd.testing.assert_frame_equal(actual,expected,check_dtype=False,rtol=1e-12,atol=1e-12)
        comparisons.append(dict(artifact=name,rows=len(actual),matches_saved=True))
    (P/'baseline-verification.json').write_text(json.dumps(comparisons,indent=2)+'\n')
    print('ALL SAVED BASELINE TABLES REPRODUCED')

if __name__=='__main__':main()
