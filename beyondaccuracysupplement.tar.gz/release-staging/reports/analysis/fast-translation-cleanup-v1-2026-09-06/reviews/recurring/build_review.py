#!/usr/bin/env python3
"""Materialize the bounded manual decisions and exact proposed claim edits."""

from __future__ import annotations

import copy
import json
from pathlib import Path


OUT = Path(__file__).resolve().parent

# One selected group span is a faithful decomposable assertion rather than the
# generic solution-validation language targeted by this review.
VALID_UNCHANGED = {
    "het:kks-v1-n08-127:1:e01fd09bd2afecdfcb60330c18fe4d7395fe9c7891d5d4f0c38ff33861377c18": (
        "The literal span says all other statements are false, relative to H's XOR. "
        "Decomposing that group assertion into individual NOT(STMT_TRUE(X)) claims is faithful. "
        "The later role claims conflict with parts of it, but internal reasoning inconsistency is "
        "not a translation-polarity error."
    )
}


def statement_players(expr: dict | None) -> set[int]:
    if not isinstance(expr, dict):
        return set()
    players = set()
    if expr.get("op") == "statement_true":
        players.add(int(expr["player"]))
    for value in expr.values():
        if isinstance(value, dict):
            players.update(statement_players(value))
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    players.update(statement_players(item))
    return players


def canonical_statements(record: dict, claims: list[dict]) -> list[dict]:
    wanted = set()
    for claim in claims:
        wanted.update(statement_players(claim.get("expression")))
    statements = record["canonical_question"]["statements"]
    return [
        {
            "player": statements[index]["speaker"],
            "text": statements[index]["text"],
            "ast": statements[index]["ast"],
        }
        for index in sorted(wanted)
    ]


def dependent_relations(record: dict, affected_ids: set[str]) -> list[dict]:
    return [
        relation
        for relation in record["all_relations"]
        if relation.get("to") in affected_ids
        or relation.get("assume") in affected_ids
        or any(claim_id in affected_ids for claim_id in relation.get("from", []))
    ]


def main() -> None:
    review_input = json.loads((OUT / "manual-review-input.json").read_text())
    decisions = []
    for record in review_input:
        uid = record["field_uid"]
        candidate_ids = {claim["id"] for claim in record["candidate_claims"]}
        full_candidates = [claim for claim in record["all_claims"] if claim["id"] in candidate_ids]
        if uid in VALID_UNCHANGED:
            decisions.append(
                {
                    "field_uid": uid,
                    "dataset": record["dataset"],
                    "condition_id": record["condition_id"],
                    "task_id": record["task_id"],
                    "manifest_id": record["manifest_id"],
                    "translation_file": record["translation_file"],
                    "translation_line": record["translation_line"],
                    "stage": record["stage"],
                    "agent_id": record["agent_id"],
                    "field": record["field"],
                    "families": record["families"],
                    "decision": "valid_unchanged",
                    "source_text": record["source_text"],
                    "candidate_claim_ids": [claim["id"] for claim in full_candidates],
                    "canonical_statements": canonical_statements(record, full_candidates),
                    "rationale": VALID_UNCHANGED[uid],
                    "claim_operations": [],
                    "dependent_relations": dependent_relations(record, candidate_ids),
                    "dependent_cases": record["dependent_cases"],
                    "dependency_disposition": "No edit; relations and cases remain unchanged.",
                }
            )
            continue

        false_claims = [
            claim
            for claim in full_candidates
            if any(
                candidate["id"] == claim["id"]
                and "false_to_positive_stmt_true" in candidate["families"]
                for candidate in record["candidate_claims"]
            )
        ]
        if false_claims:
            operations = []
            for before in false_claims:
                after = copy.deepcopy(before)
                after["expression"] = {"arg": copy.deepcopy(before["expression"]), "op": "not"}
                operations.append(
                    {
                        "action": "replace_claim",
                        "id": before["id"],
                        "before": before,
                        "after": after,
                    }
                )
            affected_ids = {claim["id"] for claim in false_claims}
            relations = dependent_relations(record, affected_ids)
            decisions.append(
                {
                    "field_uid": uid,
                    "dataset": record["dataset"],
                    "condition_id": record["condition_id"],
                    "task_id": record["task_id"],
                    "manifest_id": record["manifest_id"],
                    "translation_file": record["translation_file"],
                    "translation_line": record["translation_line"],
                    "stage": record["stage"],
                    "agent_id": record["agent_id"],
                    "field": record["field"],
                    "families": record["families"],
                    "decision": "clear_correction",
                    "source_text": record["source_text"],
                    "candidate_claim_ids": [claim["id"] for claim in false_claims],
                    "canonical_statements": canonical_statements(record, false_claims),
                    "rationale": (
                        "The complete prose directly assigns outer falsity to the named player's "
                        "canonical statement. The current claim asserts positive STMT_TRUE for that "
                        "same player. This is a polarity inversion, independent of whether the "
                        "source reasoning or submitted role assignment is correct."
                    ),
                    "claim_operations": operations,
                    "dependent_relations": relations,
                    "dependent_cases": record["dependent_cases"],
                    "dependency_disposition": (
                        "Preserve the listed relation records and re-score them with the corrected "
                        "claim polarity; no selected false-polarity claim belongs to a case."
                        if relations
                        else "No dependent relation or case records."
                    ),
                }
            )
            continue

        # Generic closure: keep one opaque trace for the literal sentence, and
        # delete duplicate formal claims generated from that same span.
        assert "generic_closure_expansion" in record["families"]
        first = full_candidates[0]
        opaque = copy.deepcopy(first)
        opaque["commitment"] = "opaque"
        opaque["expression"] = None
        operations = [
            {
                "action": "replace_claim",
                "id": first["id"],
                "before": first,
                "after": opaque,
            }
        ]
        for before in full_candidates[1:]:
            operations.append(
                {
                    "action": "delete_duplicate_claim",
                    "id": before["id"],
                    "before": before,
                    "after": None,
                }
            )
        affected_ids = {claim["id"] for claim in full_candidates}
        relations = dependent_relations(record, affected_ids)
        decisions.append(
            {
                "field_uid": uid,
                "dataset": record["dataset"],
                "condition_id": record["condition_id"],
                "task_id": record["task_id"],
                "manifest_id": record["manifest_id"],
                "translation_file": record["translation_file"],
                "translation_line": record["translation_line"],
                "stage": record["stage"],
                "agent_id": record["agent_id"],
                "field": record["field"],
                "families": record["families"],
                "decision": "clear_correction",
                "source_text": record["source_text"],
                "candidate_claim_ids": [claim["id"] for claim in full_candidates],
                "canonical_statements": canonical_statements(record, full_candidates),
                "rationale": (
                    "In this complete field, the closure sentence says the proposed assignment "
                    "satisfies the puzzle's truth/lie constraints. That does not assert that every "
                    "canonical player statement is true: the same prose explicitly makes one or "
                    "more statements false or assigns knaves. It also does not literally restate a "
                    "full role vector. Preserve one opaque claim for the sentence and remove the "
                    "duplicate formal expansions from the same span."
                ),
                "claim_operations": operations,
                "dependent_relations": relations,
                "dependent_cases": record["dependent_cases"],
                "dependency_disposition": (
                    "Preserve the relation record as a qualitative edge; its retained target/premise "
                    "is opaque and must re-score as uncheckable. No removed duplicate claim is "
                    "referenced, and no selected closure claim belongs to a case."
                    if relations
                    else "No dependent relation or case records."
                ),
            }
        )

    assert len(decisions) == 20
    assert sum(item["decision"] == "clear_correction" for item in decisions) == 19
    assert sum(item["decision"] == "valid_unchanged" for item in decisions) == 1
    payload = {
        "scope": {
            "manual_fields_reviewed": 20,
            "clear_corrections": 19,
            "valid_unchanged": 1,
            "unresolved": 0,
            "review_basis": (
                "Complete source_text, literal source_span, the exact canonical question AST/text, "
                "and local claim/relation/case records. Submitted roles and final answer correctness "
                "were not used to infer unstated propositions."
            ),
            "inner_negation_boundary": (
                "The false-polarity family requires direct outer falsity of the same named player "
                "as positive STMT_TRUE(X). Spans such as 'cannot be false', 'two false propositions "
                "make his statement true', or a false quoted operand inside XOR/equivalence are "
                "outside the rule and remain unchanged unless separately reviewed."
            ),
        },
        "decisions": decisions,
    }
    (OUT / "review-decisions.json").write_text(json.dumps(payload, indent=2) + "\n")

    lines = [
        "# Recurring translation-pattern review",
        "",
        "Bounded review of two concrete failure families in the exact translation sources used by "
        "`scripts/remake_expanded_nonrole_auc.py`. No source translation was edited here.",
        "",
        "The enumerator joined all 5,826 translated fields to the scored claims CSVs and found 66 "
        "candidate fields before excluding prior core work: size-6 had 12 generic-closure and 6 "
        "false-to-positive candidates; size-8 had 45 and 3. U05, U10, and U14 hit these rules and "
        "were excluded. F06 had no qualifying scored candidate; F07's full-role conjunction is "
        "hypothetical and therefore failed the scored-commitment filter. This leaves 63 candidate "
        "fields. At claim level, the pre-exclusion inventory contains 47 size-6 generic, 6 size-6 "
        "false-to-positive, 211 size-8 generic, and 3 size-8 false-to-positive occurrences. "
        "`candidate-inventory.json` records every occurrence and source hash.",
        "",
        "The manual cap is exactly 20 fields. Selection took every remaining direct false-to-positive "
        "field, then the lexicographically first six generic-closure field UIDs from each size. The "
        "final list is sorted by full field UID. Outcome was not a selection input. Complete prose, "
        "canonical question semantics, and dependent relations/cases are retained in "
        "`review-decisions.json` and `manual-review-input.json`.",
        "",
        "Result: 19 clear corrections and one valid unchanged decomposition. There were no unresolved "
        "cases in the selected 20. Direct outer falsity changes `STMT_TRUE(X)` to "
        "`NOT(STMT_TRUE(X))`. Generic solution-validation prose keeps its first claim ID as "
        "`OPAQUE/ABSTAIN` and deletes duplicate formal expansions from the same span. The valid "
        "size-8 field literally says that all other statements are false; its individual negative "
        "statement claims remain unchanged even though later role reasoning conflicts with them.",
        "",
        "False-looking inner constructions are outside the direct rule: `cannot be false`, false "
        "operands that make an XOR/equivalence true, and quoted false subclaims do not establish "
        "outer falsity of the named player's canonical statement. They remain unchanged unless a "
        "separate review resolves their scope.",
        "",
        "| Dataset | Field UID suffix | Family | Decision | Claim operations | Dependent relations |",
        "|---|---|---|---|---:|---:|",
    ]
    for item in decisions:
        lines.append(
            "| {dataset} | `{suffix}` | {families} | {decision} | {operations} | {relations} |".format(
                dataset=item["dataset"],
                suffix=item["field_uid"].split(":")[-1][:12],
                families=", ".join(item["families"]),
                decision=item["decision"],
                operations=len(item["claim_operations"]),
                relations=len(item["dependent_relations"]),
            )
        )
    lines.extend(
        [
            "",
            "`review-decisions.json` is the authoritative field-level packet. Each correction contains "
            "the complete source prose, exact full claim objects before and after, canonical statement "
            "text/AST for every `STMT_TRUE` target, and the inspected dependent relation/case records.",
            "",
        ]
    )
    (OUT / "README.md").write_text("\n".join(lines))


if __name__ == "__main__":
    main()
