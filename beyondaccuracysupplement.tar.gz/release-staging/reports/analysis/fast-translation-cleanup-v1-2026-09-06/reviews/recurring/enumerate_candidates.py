#!/usr/bin/env python3
"""Deterministically enumerate the two bounded recurring-error families."""

from __future__ import annotations

import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[5]
OUT = Path(__file__).resolve().parent

SOURCES = [
    {
        "dataset": "size6",
        "condition_id": "broad-luna-low-weak-het",
        "translation": ROOT / "reports/analysis/formal-logic-minimal-v2/broad-size6-weak-luna-v0.1/weak-het-luna-low-two-stage-sol-parse-repair-v3.jsonl",
        "claims": ROOT / "reports/analysis/minimal-reasoning-size6-strength-comparison-2026-09-04/claims.csv",
    },
    {
        "dataset": "size6",
        "condition_id": "broad-luna-low-weak-hom",
        "translation": ROOT / "reports/analysis/formal-logic-minimal-v2/broad-size6-weak-luna-v0.1/weak-hom-luna-low-two-stage-sol-parse-repair-v3.jsonl",
        "claims": ROOT / "reports/analysis/minimal-reasoning-size6-strength-comparison-2026-09-04/claims.csv",
    },
    {
        "dataset": "size6",
        "condition_id": "broad-luna-low-medium-het",
        "translation": ROOT / "reports/analysis/formal-logic-minimal-v2/broad-size6-luna-v0.1/medium-het-luna-low-two-stage-sol-parse-repair-v3.jsonl",
        "claims": ROOT / "reports/analysis/minimal-reasoning-size6-strength-comparison-2026-09-04/claims.csv",
    },
    {
        "dataset": "size6",
        "condition_id": "broad-luna-low-medium-hom",
        "translation": ROOT / "reports/analysis/formal-logic-minimal-v2/broad-size6-luna-v0.1/medium-hom-luna-low-two-stage-sol-parse-repair-v3.jsonl",
        "claims": ROOT / "reports/analysis/minimal-reasoning-size6-strength-comparison-2026-09-04/claims.csv",
    },
    {
        "dataset": "size8",
        "condition_id": "hom",
        "translation": ROOT / "reports/analysis/formal-logic-minimal-v2/fresh-size8-gpt-oss-control-luna-v0.1/fresh-gpt-oss-hom-control-r1-analysis-ready-v4.jsonl",
        "claims": ROOT / "reports/analysis/fresh-size8-heterogeneity-2026-09-05/base/claims.csv",
    },
    {
        "dataset": "size8",
        "condition_id": "het",
        "translation": ROOT / "reports/analysis/formal-logic-minimal-v2/fresh-size8-gpt-oss-control-luna-v0.1/fresh-medium-het-gemini-mercury-gptoss-r1-analysis-ready-v4.jsonl",
        "claims": ROOT / "reports/analysis/fresh-size8-heterogeneity-2026-09-05/base/claims.csv",
    },
]

SCORED_COMMITMENTS = {"assert", "endorse", "reject"}
SCORED_INFORMATION = {"truth_aligned", "misleading", "redundant", "contradictory"}

# These five fields were already surfaced by the earlier U05/U10/U14/F06/F07
# packet and were explicitly assigned elsewhere for this cleanup.
EXCLUDED_CORE_FIELDS = {
    "broad-luna-low-medium-het:kks-v1-n06-001:1:fc005d8332058395244123e5ccdafaf6cb8b3686dccf16fd57c3b0210fb66b11": "U05",
    "broad-luna-low-medium-hom:kks-v1-n06-189:1:51bc8f2ab94526157e8588279fc492442c2f201b9fb7b2e3bde6170c7e4cb7cd": "U10",
    "broad-luna-low-medium-hom:kks-v1-n06-174:1:52e78fb1baf9b6a5fe7a23b10cac42f32d469d9a32864eb60cc8c982c18a33a2": "U14",
    "broad-luna-low-weak-het:kks-v1-n06-174:1:5667206fe9debe89912f8435022693c8c5b147e4994a5f3441917da1e4f63834": "F06",
    "broad-luna-low-weak-hom:kks-v1-n06-001:1:6ceb479cc9e434472083944fab892c3304f9986ae2e19befde7ce0ccb4c3a454": "F07",
}

# Closure language is deliberately narrow. Universal-entailment spans such as
# "All consistent assignments ... make D's claim true" name the conclusion and
# are not candidates. These patterns identify generic solution-validation prose.
GENERIC_CLOSURE = re.compile(
    r"(?ix)^(?:"
    r"all\s+(?:eight\s+)?statements\b|"
    r"all\s+other\s+statements\b|"
    r"all\s+roles\b|"
    r"this\s+assignment\s+satisf(?:y|ies)\s+all\s+statements\b|"
    r"satisf(?:y|ies|ied)\s+(?:all|every)\s+statements\b|"
    r"which\s+satisf(?:y|ies)\s+all\s+statements\b"
    r")"
)


def field_uid(condition_id: str, record: dict) -> str:
    source = record["source"]
    return ":".join(
        [condition_id, source["task_id"], str(source["repetition"]), record["formalization_id"]]
    )


def expr_text_from_row(row: dict) -> str:
    return row["effective_expression"] or row["expression"]


def positive_statement_player(expr: dict | None) -> str | None:
    if not expr or expr.get("op") != "statement_true":
        return None
    return chr(ord("A") + int(expr["player"]))


def span_says_same_player_false(span: str, player: str) -> bool:
    """Match direct outer falsity, excluding negated falsity and quoted operands."""
    p = re.escape(player)
    direct = [
        rf"(?i)^\s*(?:player\s+)?{p}(?:'s|’s)?(?:\s+(?:statement|claim|equivalence|disjunction|xor|condition))?\s+(?:is\s+|always\s+)?false\b",
        rf"(?i)^\s*(?:player\s+)?{p}\s+(?:lies?|is\s+lying)\b",
        rf"(?i)^\s*(?:player\s+)?{p}(?:'s|’s)?\s+[^.;]{{0,45}}\s+is\s+false\b",
    ]
    if any(re.search(pattern, span) for pattern in direct):
        return not re.search(r"(?i)\b(?:cannot|can't|not)\b.{0,18}\bfalse\b", span)

    # Coordinated subject, e.g. "A, E, and G make false statements".
    coordinated = re.search(r"(?i)^\s*((?:[A-H](?:\s*,\s*|\s+and\s+))+[A-H])\s+make\s+false\s+statements\b", span)
    if coordinated:
        named = set(re.findall(r"\b[A-H]\b", coordinated.group(1).upper()))
        return player in named
    return False


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    csv_cache: dict[Path, dict[tuple[str, str], dict]] = {}
    question_cache: dict[int, dict[str, dict]] = {}
    for size in (6, 8):
        questions = {}
        with (ROOT / f"data/kks/v1/questions/{size}.jsonl").open() as handle:
            for line in handle:
                question = json.loads(line)
                questions[question["id"]] = question
        question_cache[size] = questions

    candidates: dict[str, dict] = {}
    record_count = 0
    source_descriptors = []
    record_index = {}
    for spec in SOURCES:
        if spec["claims"] not in csv_cache:
            rows = {}
            with spec["claims"].open(newline="") as handle:
                for row in csv.DictReader(handle):
                    rows[(row["field_uid"], row["local_claim_id"])] = row
            csv_cache[spec["claims"]] = rows
        scored_rows = csv_cache[spec["claims"]]
        source_descriptors.append(
            {
                "dataset": spec["dataset"],
                "condition_id": spec["condition_id"],
                "translation_file": str(spec["translation"].relative_to(ROOT)),
                "translation_sha256": sha256(spec["translation"]),
                "claims_csv": str(spec["claims"].relative_to(ROOT)),
                "claims_csv_sha256": sha256(spec["claims"]),
            }
        )
        with spec["translation"].open() as handle:
            for line_number, line in enumerate(handle, 1):
                record_count += 1
                record = json.loads(line)
                uid = field_uid(spec["condition_id"], record)
                record_index[uid] = (spec, line_number, record)
                for claim in record["claims"]:
                    row = scored_rows.get((uid, claim["id"]))
                    if row is None:
                        continue
                    if row["commitment"] not in SCORED_COMMITMENTS:
                        continue
                    if row["information_type"] not in SCORED_INFORMATION:
                        continue
                    families = []
                    span = claim.get("source_span") or ""
                    expression = claim.get("expression")
                    expression_text = expr_text_from_row(row)
                    if GENERIC_CLOSURE.search(span) and (
                        "STMT_TRUE(" in expression_text or "ROLE(" in expression_text
                    ):
                        families.append("generic_closure_expansion")
                    player = positive_statement_player(expression)
                    if player and span_says_same_player_false(span, player):
                        families.append("false_to_positive_stmt_true")
                    if not families:
                        continue
                    item = candidates.setdefault(
                        uid,
                        {
                            "dataset": spec["dataset"],
                            "condition_id": spec["condition_id"],
                            "task_id": record["source"]["task_id"],
                            "repetition": record["source"]["repetition"],
                            "field_uid": uid,
                            "manifest_id": record["source"]["manifest_id"],
                            "translation_file": str(spec["translation"].relative_to(ROOT)),
                            "translation_line": line_number,
                            "stage": record["source"]["stage"],
                            "agent_id": record["source"]["agent_id"],
                            "field": record["source"]["field"],
                            "families": set(),
                            "candidate_claims": [],
                            "excluded_prior_core": EXCLUDED_CORE_FIELDS.get(uid),
                        },
                    )
                    item["families"].update(families)
                    item["candidate_claims"].append(
                        {
                            "id": claim["id"],
                            "claim_uid": row["claim_uid"],
                            "families": families,
                            "commitment": claim["commitment"],
                            "case_id": claim.get("case_id"),
                            "attributions": claim.get("attributions", []),
                            "expression": expression,
                            "effective_expression": expression_text,
                            "source_span": span,
                            "information_type": row["information_type"],
                            "target_truth": row["target_truth"],
                        }
                    )

    for item in candidates.values():
        item["families"] = sorted(item["families"])
        item["candidate_claims"].sort(key=lambda x: x["id"])

    eligible = [item for item in candidates.values() if not item["excluded_prior_core"]]
    false_fields = sorted(
        [item for item in eligible if "false_to_positive_stmt_true" in item["families"]],
        key=lambda x: x["field_uid"],
    )
    selected_uids = {item["field_uid"] for item in false_fields}
    remaining = 20 - len(selected_uids)
    closure_by_dataset = {
        dataset: sorted(
            [
                item
                for item in eligible
                if item["dataset"] == dataset
                and "generic_closure_expansion" in item["families"]
                and item["field_uid"] not in selected_uids
            ],
            key=lambda x: x["field_uid"],
        )
        for dataset in ("size6", "size8")
    }
    quotas = {"size6": remaining // 2, "size8": remaining - remaining // 2}
    for dataset in ("size6", "size8"):
        selected_uids.update(item["field_uid"] for item in closure_by_dataset[dataset][: quotas[dataset]])
    # Deterministic fallback if one size has fewer closure candidates than its quota.
    if len(selected_uids) < 20:
        fallback = sorted(
            [item for item in eligible if item["field_uid"] not in selected_uids],
            key=lambda x: x["field_uid"],
        )
        selected_uids.update(item["field_uid"] for item in fallback[: 20 - len(selected_uids)])

    inventory_items = []
    review_input = []
    for uid, item in sorted(candidates.items()):
        item["selected_for_manual_review"] = uid in selected_uids
        inventory_items.append(item)
        if uid not in selected_uids:
            continue
        spec, line_number, record = record_index[uid]
        candidate_ids = {claim["id"] for claim in item["candidate_claims"]}
        dependent_relations = [
            relation
            for relation in record["relations"]
            if relation.get("to") in candidate_ids
            or relation.get("assume") in candidate_ids
            or any(claim_id in candidate_ids for claim_id in relation.get("from", []))
        ]
        dependent_cases = [
            case
            for case in record["cases"]
            if any(
                claim.get("case_id") == case["id"] and claim["id"] in candidate_ids
                for claim in record["claims"]
            )
        ]
        question = question_cache[6 if item["dataset"] == "size6" else 8][item["task_id"]]
        review_input.append(
            {
                **item,
                "source_text": record["source_text"],
                "submitted_roles": record.get("submitted_roles"),
                "canonical_question": question,
                "all_claims": record["claims"],
                "dependent_relations": dependent_relations,
                "dependent_cases": dependent_cases,
                "all_cases": record["cases"],
                "all_relations": record["relations"],
            }
        )

    family_field_counts = Counter(
        (item["dataset"], family) for item in candidates.values() for family in item["families"]
    )
    selected_family_counts = Counter(
        (item["dataset"], family)
        for item in candidates.values()
        if item["field_uid"] in selected_uids
        for family in item["families"]
    )
    family_claim_counts = Counter(
        (item["dataset"], family)
        for item in candidates.values()
        for claim in item["candidate_claims"]
        for family in claim["families"]
    )
    eligible_family_claim_counts = Counter(
        (item["dataset"], family)
        for item in eligible
        for claim in item["candidate_claims"]
        for family in claim["families"]
    )
    selected_family_claim_counts = Counter(
        (item["dataset"], family)
        for item in candidates.values()
        if item["field_uid"] in selected_uids
        for claim in item["candidate_claims"]
        for family in claim["families"]
    )
    payload = {
        "scope": {
            "records_scanned": record_count,
            "debates": 120,
            "sources": source_descriptors,
            "filters": {
                "commitments": sorted(SCORED_COMMITMENTS),
                "information_types": sorted(SCORED_INFORMATION),
                "generic_closure_regex": GENERIC_CLOSURE.pattern,
                "false_rule": "positive statement_true(X) whose literal span directly says the same X statement/claim is false or X lies; cannot/not false excluded; coordinated explicit subjects included",
            },
            "selection": "Review every eligible false-to-positive field, then fill the 20-field cap equally from size-6 and size-8 generic-closure fields, taking lexicographically smallest full field_uid within each size; final presentation sorted by full field_uid. Outcome was not used.",
            "excluded_prior_core_fields": EXCLUDED_CORE_FIELDS,
        },
        "counts": {
            "candidate_fields_total_including_prior_core": len(candidates),
            "candidate_fields_excluding_prior_core": len(eligible),
            "selected_fields": len(selected_uids),
            "candidate_fields_by_dataset_family": {
                f"{dataset}:{family}": count
                for (dataset, family), count in sorted(family_field_counts.items())
            },
            "selected_fields_by_dataset_family": {
                f"{dataset}:{family}": count
                for (dataset, family), count in sorted(selected_family_counts.items())
            },
            "candidate_claims_by_dataset_family_including_prior_core": {
                f"{dataset}:{family}": count
                for (dataset, family), count in sorted(family_claim_counts.items())
            },
            "candidate_claims_by_dataset_family_excluding_prior_core": {
                f"{dataset}:{family}": count
                for (dataset, family), count in sorted(eligible_family_claim_counts.items())
            },
            "selected_claims_by_dataset_family": {
                f"{dataset}:{family}": count
                for (dataset, family), count in sorted(selected_family_claim_counts.items())
            },
        },
        "candidates": inventory_items,
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "candidate-inventory.json").write_text(json.dumps(payload, indent=2) + "\n")
    (OUT / "manual-review-input.json").write_text(json.dumps(review_input, indent=2) + "\n")
    print(json.dumps(payload["counts"], indent=2))
    print("selected")
    for item in review_input:
        print(item["dataset"], item["field_uid"], ",".join(item["families"]))


if __name__ == "__main__":
    main()
