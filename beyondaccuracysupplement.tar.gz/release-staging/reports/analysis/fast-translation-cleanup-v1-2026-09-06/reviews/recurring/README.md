# Recurring translation-pattern review

Bounded review of two concrete failure families in the exact translation sources used by `scripts/remake_expanded_nonrole_auc.py`. No source translation was edited here.

The enumerator joined all 5,826 translated fields to the scored claims CSVs and found 66 candidate fields before excluding prior core work: size-6 had 12 generic-closure and 6 false-to-positive candidates; size-8 had 45 and 3. U05, U10, and U14 hit these rules and were excluded. F06 had no qualifying scored candidate; F07's full-role conjunction is hypothetical and therefore failed the scored-commitment filter. This leaves 63 candidate fields. At claim level, the pre-exclusion inventory contains 47 size-6 generic, 6 size-6 false-to-positive, 211 size-8 generic, and 3 size-8 false-to-positive occurrences. `candidate-inventory.json` records every occurrence and source hash.

The manual cap is exactly 20 fields. Selection took every remaining direct false-to-positive field, then the lexicographically first six generic-closure field UIDs from each size. The final list is sorted by full field UID. Outcome was not a selection input. Complete prose, canonical question semantics, and dependent relations/cases are retained in `review-decisions.json` and `manual-review-input.json`.

Result: 19 clear corrections and one valid unchanged decomposition. There were no unresolved cases in the selected 20. Direct outer falsity changes `STMT_TRUE(X)` to `NOT(STMT_TRUE(X))`. Generic solution-validation prose keeps its first claim ID as `OPAQUE/ABSTAIN` and deletes duplicate formal expansions from the same span. The valid size-8 field literally says that all other statements are false; its individual negative statement claims remain unchanged even though later role reasoning conflicts with them.

False-looking inner constructions are outside the direct rule: `cannot be false`, false operands that make an XOR/equivalence true, and quoted false subclaims do not establish outer falsity of the named player's canonical statement. They remain unchanged unless a separate review resolves their scope.

| Dataset | Field UID suffix | Family | Decision | Claim operations | Dependent relations |
|---|---|---|---|---:|---:|
| size6 | `75697b9c91a2` | generic_closure_expansion | clear_correction | 6 | 0 |
| size6 | `8ec2621f2abd` | generic_closure_expansion | clear_correction | 6 | 0 |
| size6 | `33e424e20130` | false_to_positive_stmt_true | clear_correction | 1 | 1 |
| size6 | `118917e76937` | generic_closure_expansion | clear_correction | 1 | 0 |
| size6 | `7b51300d2a38` | generic_closure_expansion | clear_correction | 6 | 0 |
| size6 | `ce768a522043` | false_to_positive_stmt_true | clear_correction | 1 | 1 |
| size6 | `4f880aae9eeb` | generic_closure_expansion | clear_correction | 1 | 1 |
| size6 | `13bbf78d38d1` | false_to_positive_stmt_true | clear_correction | 1 | 2 |
| size6 | `dd41b3ab206e` | generic_closure_expansion | clear_correction | 1 | 1 |
| size6 | `240d2a2e94b9` | false_to_positive_stmt_true | clear_correction | 1 | 1 |
| size6 | `5979c029b08e` | false_to_positive_stmt_true | clear_correction | 1 | 0 |
| size8 | `aeb170c5caa7` | generic_closure_expansion | clear_correction | 8 | 0 |
| size8 | `488879e36ea6` | false_to_positive_stmt_true | clear_correction | 1 | 1 |
| size8 | `e01fd09bd2af` | generic_closure_expansion | valid_unchanged | 0 | 13 |
| size8 | `445234cf6d0f` | generic_closure_expansion | clear_correction | 8 | 1 |
| size8 | `192088714f36` | generic_closure_expansion | clear_correction | 8 | 0 |
| size8 | `84c463a45eba` | generic_closure_expansion | clear_correction | 1 | 0 |
| size8 | `feaae313b68c` | generic_closure_expansion | clear_correction | 1 | 0 |
| size8 | `5b24ba5ec2fb` | false_to_positive_stmt_true | clear_correction | 1 | 1 |
| size8 | `f36a34fbe0fb` | false_to_positive_stmt_true | clear_correction | 1 | 0 |

`review-decisions.json` is the authoritative field-level packet. Each correction contains the complete source prose, exact full claim objects before and after, canonical statement text/AST for every `STMT_TRUE` target, and the inspected dependent relation/case records.
