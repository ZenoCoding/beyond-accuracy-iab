# Targeted uptake translation review

This directory contains an independent source-level review of the three specified error-bearing fields. It does not modify raw translations, scorer inputs, or methodology.

The review confirms two error patterns:

- U05 and U14 expand one global assignment-consistency phrase into six per-player `STMT_TRUE` claims. Keep one opaque occurrence under an existing ID and drop the five duplicate expansions in each field. Do not replace the expansions with truth values inferred from roles or the canonical solution.
- U10 c8 reverses the explicit span `F false`. Replace it with `NOT(STMT_TRUE(F))` under the same claim ID.

`claim-operations.jsonl` gives 13 exact operations with full before/after claim objects: three ID-preserving replacements and ten drops. No additions are proposed. `field-reviews.json` records a target-pattern verdict for every claim in the three fields and the frozen canonical solution used as a semantic check. `dependency-handling.json` shows that no relation or case must be dropped.

U10 retains a separate commitment-scope ambiguity. Its recipient initially states a proposition equivalent to F's statement inside unresolved hypothetical case h1. Correcting the later polarity error does not decide whether the proposition was already present initially.
