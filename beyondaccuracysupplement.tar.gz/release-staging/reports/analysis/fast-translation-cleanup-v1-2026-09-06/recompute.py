"""Apply reviewed source-record edits and rerun the unchanged 120-debate metric.

No aggregate label patching. The official translation report regenerates every
field in affected debates, including cases/relations, before claims and debate
metrics are merged back into the unchanged cohort. The author's build() and
main() perform feature/pair/AUC calculations with redirected input/output paths.
Only build()'s assertion against the obsolete pre-correction pair snapshot is
removed, by AST; no estimator or selection expressions are changed.
"""
from pathlib import Path
import ast, copy, hashlib, json, sys
import pandas as pd
import yaml
P=Path(__file__).resolve().parent
ROOT=P.parents[2]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'scripts'))
from controlmad.analysis.formal_logic_minimal_report import analyze_minimal_reasoning
from controlmad.analysis.core import completed_results
from controlmad.analysis.formal_logic import extract_reasoning_sources
import analyze_reasoning_features as features
import remake_expanded_nonrole_auc as expanded
KEY=['condition_id','task_id','repetition']

def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')

def stable_hash(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def frame_equal(a,b,keys):
    assert set(a.columns)==set(b.columns),(set(a.columns)-set(b.columns),set(b.columns)-set(a.columns))
    pd.testing.assert_frame_equal(a.sort_values(keys).reset_index(drop=True)[b.columns],b.sort_values(keys).reset_index(drop=True),check_dtype=False,rtol=1e-10,atol=1e-10)

def base_path(dataset):
    return Path('reports/analysis/minimal-reasoning-size6-strength-comparison-2026-09-04') if dataset=='size6' else Path('reports/analysis/fresh-size8-heterogeneity-2026-09-05/base')

def selected(df,debates):
    return pd.Series([(str(r.condition_id),str(r.task_id),int(r.repetition)) in debates for r in df.itertuples()],index=df.index)

def apply_overlay(inventory,ledger):
    by_source={};affected=set();applied=[];checks=[]
    for c in ledger:
        assert c['status']=='accepted'
        by_source.setdefault((c['dataset'],c['condition_id']),[]).append(c)
        affected.add((c['dataset'],c['condition_id'],c['task_id'],int(c['repetition'])))
    subsets={'before':{},'after':{}}
    for s in inventory['sources']:
        rawpath=P/'frozen'/s['translation_file'];lines=rawpath.read_text().splitlines(keepends=True)
        records=[json.loads(l) for l in lines]
        original={r['formalization_id']:r for r in records}
        changed=copy.deepcopy(original);changes=by_source.get((s['dataset'],s['condition_id']),[])
        for c in changes:
            record=changed[c['formalization_id']]
            assert record['source']['task_id']==c['task_id']
            assert hashlib.sha256(record['source_text'].encode()).hexdigest()==c['source_text_sha256']
            collection=c['collection'];rid=c['record_id'];items=record[collection]
            matches=[i for i,x in enumerate(items) if x['id']==rid]
            if c['before'] is None:
                assert not matches and c['after'] is not None
                items.append(c['after'])
            else:
                assert len(matches)==1 and items[matches[0]]==c['before'],c['change_id']
                if c['after'] is None: items.pop(matches[0])
                else:items[matches[0]]=c['after']
            applied.append(c['change_id'])
        touched={c['formalization_id'] for c in changes}
        unchanged=0
        out=[]
        for line,r in zip(lines,records):
            fid=r['formalization_id'];after=changed[fid]
            if fid not in touched:
                assert after==r;out.append(line);unchanged+=1
            else:
                assert after['source']==r['source'] and after['source_text']==r['source_text']
                for coll in ['claims','cases','relations']:
                    ids=[x['id'] for x in after[coll]];assert len(ids)==len(set(ids))
                claim_ids={x['id'] for x in after['claims']}
                relation_ids={x['id'] for x in after['relations']}
                case_ids={x['id'] for x in after['cases']}
                for claim in after['claims']:
                    assert claim.get('case_id') is None or claim['case_id'] in case_ids
                for relation in after['relations']:
                    refs=list(relation.get('from',[]))
                    if relation.get('to'):refs.append(relation['to'])
                    if relation.get('assume'):refs.append(relation['assume'])
                    assert set(refs)<=claim_ids,(fid,relation['id'])
                    assert not relation.get('via') or relation['via'] in relation_ids
                out.append(json.dumps(after,ensure_ascii=False)+'\n')
            key=(s['dataset'],s['condition_id'],r['source']['task_id'],int(r['source'].get('repetition',1)))
            if key in affected:
                sourcekey=(s['dataset'],s['condition_id'])
                subsets['before'].setdefault(sourcekey,[]).append(r)
                subsets['after'].setdefault(sourcekey,[]).append(after)
        destination=P/'overlay/translations'/Path(s['translation_file']).name
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_text(''.join(out))
        checks.append(dict(dataset=s['dataset'],condition_id=s['condition_id'],original_sha256=hashlib.sha256(rawpath.read_bytes()).hexdigest(),overlay_path=str(destination.relative_to(P)),overlay_sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),total_fields=len(records),modified_fields=len(touched),unchanged_fields_byte_preserved=unchanged))
    assert sorted(applied)==sorted(c['change_id'] for c in ledger)
    write_json(P/'overlay-manifest.json',checks)
    return subsets,affected

def regenerate(subsets,inventory,phase):
    for dataset in ['size6','size8']:
        cfg=dict(schema_version=1,analysis_id=f'fast-cleanup-v1-{phase}-{dataset}',dataset=str(ROOT/'data/kks/v1'),relation_backgrounds=['thin','referenced_roles'],sources=[])
        for s in inventory['sources']:
            key=(dataset,s['condition_id'])
            if s['dataset']!=dataset or key not in subsets[phase]:continue
            path=P/'regeneration'/phase/dataset/(s['condition_id']+'.jsonl');path.parent.mkdir(parents=True,exist_ok=True)
            path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in subsets[phase][key]))
            run=ROOT/Path(s['run_dir'])
            if not run.exists():
                # The release includes the complete raw runs, but the bounded
                # correction replay needs only the affected frozen results.
                run=P/'frozen/debate-results'/dataset/s['condition_id']
            assert run.exists(),run
            # Freeze the exact original results used for outcome and prose checks.
            # Reuse them for both before/after scoring so outcome evidence is fixed.
            frozen_run=P/'frozen/debate-results'/dataset/s['condition_id']
            if phase=='before':
                results=completed_results(run)
                wanted={(r['source']['task_id'],int(r['source'].get('repetition',1))) for r in subsets[phase][key]}
                verification=[]
                for task,rep in sorted(wanted):
                    result=results[(task,rep)]
                    target=frozen_run/'tasks'/f'{task}__rep_{rep:04}'/'result.json'
                    original_result=run/'tasks'/result['run_id']/'result.json'
                    if original_result.exists() and json.loads(original_result.read_text())==result:
                        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original_result.read_bytes())
                    else:write_json(target,result)
                    source_rows=extract_reasoning_sources(result)
                    field_count=0
                    for r in subsets[phase][key]:
                        if (r['source']['task_id'],int(r['source'].get('repetition',1)))!=(task,rep):continue
                        matches=[x for x in source_rows if all(r['source'].get(k)==v for k,v in x.location.items())]
                        assert len(matches)==1 and matches[0].text==r['source_text'],r['formalization_id']
                        field_count+=1
                    verification.append(dict(task_id=task,repetition=rep,reviewed_field_prose_matches_original=True,fields=field_count,result_path=str(target.relative_to(P)),sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
                write_json(frozen_run/'source-verification.json',verification)
            cfg['sources'].append(dict(id=s['condition_id'],condition_label=s['condition_label'],translation_file=str(path),run_dir=str(frozen_run)))
        if not cfg['sources']:continue
        config=P/'regeneration'/phase/dataset/'config.yaml'
        config.write_text(yaml.safe_dump(cfg,sort_keys=False))
        print('Regenerating',phase,dataset,flush=True)
        analyze_minimal_reasoning(config,config.parent/'scored')

def merge_regenerated(affected,ledger):
    checks=[]
    for dataset in ['size6','size8']:
        debates={x[1:] for x in affected if x[0]==dataset}
        base=P/'frozen'/base_path(dataset)
        for name,keys in [('claims.csv',['claim_uid']),('debates.csv',KEY)]:
            original=pd.read_csv(base/name,low_memory=False)
            if debates:
                before=pd.read_csv(P/'regeneration/before'/dataset/'scored'/name,low_memory=False)
                after=pd.read_csv(P/'regeneration/after'/dataset/'scored'/name,low_memory=False)
                frame_equal(before,original[selected(original,debates)],keys)
                merged=pd.concat([original[~selected(original,debates)],after],ignore_index=True)
                frame_equal(merged[~selected(merged,debates)],original[~selected(original,debates)],keys)
                if name=='claims.csv':
                    changed_fields={':'.join([c['condition_id'],c['task_id'],str(c['repetition']),c['formalization_id']]) for c in ledger if c['dataset']==dataset}
                    frame_equal(merged[~merged.field_uid.isin(changed_fields)],original[~original.field_uid.isin(changed_fields)],keys)
            else:merged=original.copy()
            assert not merged.duplicated(keys).any()
            target=P/'corrected-inputs'/dataset/name;target.parent.mkdir(parents=True,exist_ok=True)
            merged.to_csv(target,index=False)
            checks.append(dict(dataset=dataset,artifact=name,original_rows=len(original),corrected_rows=len(merged),original_affected_records_reproduce_saved=True,unaffected_debates_identical=True))
    write_json(P/'regeneration-verification.json',checks)

def rerun_expanded():
    frame=pd.read_csv(P/'frozen/reports/analysis/reasoning-features-2026-09-05/debate-features.csv')
    original_frame=frame.copy()
    # Rebuild the saved base outcome/whole-debate features and initial supply
    # using the same report serializer and original initial_features function.
    for dataset in ['size6','size8']:
        source=P/'corrected-inputs'/dataset
        base=pd.read_csv(source/'debates.csv')
        initial=features.initial_features(source)
        rebuilt=base.merge(initial,on=KEY,how='left')
        mask=frame.dataset.eq(dataset)
        order=frame.loc[mask,KEY].merge(rebuilt,on=KEY,how='left',validate='one_to_one')
        for col in rebuilt.columns:
            if col in frame.columns and col not in KEY:frame.loc[mask,col]=order[col].to_numpy()
    invariant=['dataset']+KEY+['stratum','size','operational_final_correct','any_initial_correct','initial_correct_agent_count']
    frame_equal(frame[invariant],original_frame[invariant],['dataset']+KEY)
    redirected=P/'corrected-inputs/feature-source';redirected.mkdir(parents=True,exist_ok=True)
    frame.to_csv(redirected/'debate-features.csv',index=False)
    expanded.OUT=redirected;expanded.SIZE6=P/'corrected-inputs/size6';expanded.SIZE8=P/'corrected-inputs/size8';expanded.DEST=P/'corrected'
    module=ast.parse((P/'frozen/scripts/remake_expanded_nonrole_auc.py').read_text())
    fn=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='build')
    removed=[]
    kept=[]
    for node in fn.body:
        if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and ast.unparse(node.value.func)=='pd.testing.assert_frame_equal':
            removed.append(ast.unparse(node));continue
        kept.append(node)
    assert len(removed)==1
    fn.body=kept
    exec(compile(ast.Module(body=[fn],type_ignores=[]),'unchanged-build-minus-historical-snapshot-assertion','exec'),expanded.__dict__)
    write_json(P/'scorer-adapter.json',dict(removed_assertion=removed[0],reason='The historical snapshot equality is a baseline verification, not a scoring rule. Corrected pairs are expected to differ.',numerical_definitions_changed=False))
    expanded.main()
    report_path=P/'corrected/README.md'
    report=report_path.read_text()
    report=report.replace('`.venv/bin/python scripts/remake_expanded_nonrole_auc.py`', '`PYTHONPATH=src python reports/analysis/fast-translation-cleanup-v1-2026-09-06/recompute.py` (with the dependencies listed in ../README.md)')
    report=report.replace('The size-6 exposure pairs exactly reproduce the existing non-role subset underlying Table 2.', 'The uncorrected baseline reproduced the saved exposure pairs exactly. This output uses the reviewed translation overlay; changed pairs are recorded in ../affected-pairs.csv.')
    report=report.replace('Changes from the old table reflect both the expanded sample and corrected uptake definition.', 'For this before/after comparison the expanded cohort, uptake definition and bootstrap estimator are held fixed; changes come from the translation overlay.')
    report_path.write_text('Translation correction overlay v1. See ../README.md for the bounded review scope, before/after comparison and remaining ambiguities.\n\n'+report)
    before=pd.read_csv(P/'baseline/paper-auc.csv');after=pd.read_csv(P/'corrected/paper-auc.csv')
    comparison=before.merge(after,on='feature',suffixes=('_before','_after'),validate='one_to_one')
    comparison['within_auc_delta']=comparison.auc_within_condition_after-comparison.auc_within_condition_before
    comparison.to_csv(P/'before-after-paper-auc.csv',index=False)
    oldpairs=pd.read_csv(P/'baseline/exposure-pairs.csv');newpairs=pd.read_csv(P/'corrected/exposure-pairs.csv')
    identity=['dataset']+KEY+['expression','recipient','information_type']
    pairs=oldpairs.merge(newpairs,on=identity,how='outer',suffixes=('_before','_after'),indicator=True)
    pairs=pairs[pairs._merge.ne('both')|pairs.adopted_before.ne(pairs.adopted_after)]
    pairs.to_csv(P/'affected-pairs.csv',index=False)
    oldfeatures=pd.read_csv(P/'baseline/debate-features.csv');newfeatures=pd.read_csv(P/'corrected/debate-features.csv')
    rows=[]
    joined=oldfeatures.merge(newfeatures,on=['dataset']+KEY,suffixes=('_before','_after'),validate='one_to_one')
    for r in joined.to_dict('records'):
        for feat in expanded.LABELS:
            a,b=r[feat+'_before'],r[feat+'_after']
            if (pd.isna(a) and pd.isna(b)) or a==b:continue
            rows.append({k:r[k] for k in ['dataset']+KEY}|dict(feature=feat,before=a,after=b))
    pd.DataFrame(rows).to_csv(P/'affected-debate-features.csv',index=False)
    print('ALL CORRECTED TABLE ROWS WRITTEN',flush=True)

def main():
    inventory=json.loads((P/'input-inventory.json').read_text())
    for entry in inventory['files']:
        assert hashlib.sha256((P/entry['frozen_path']).read_bytes()).hexdigest()==entry['sha256']
    ledger=[json.loads(line) for line in (P/'correction-ledger.jsonl').read_text().splitlines()]
    subsets,affected=apply_overlay(inventory,ledger)
    regenerate(subsets,inventory,'before')
    regenerate(subsets,inventory,'after')
    merge_regenerated(affected,ledger)
    rerun_expanded()

if __name__=='__main__':main()
