from __future__ import annotations

import hashlib
import itertools
import json
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

ROLES = ("knight", "knave", "spy")
Expr = dict[str, Any]
Assignment = tuple[str, ...]


def assignments(player_count: int) -> Iterable[Assignment]:
    """Enumerate assignments satisfying the disclosed exactly-one-spy hint."""
    for spy in range(player_count):
        for non_spies in itertools.product(("knight", "knave"), repeat=player_count - 1):
            values = iter(non_spies)
            yield tuple("spy" if i == spy else next(values) for i in range(player_count))


def referenced_players(expr: Expr) -> set[int]:
    op = expr["op"]
    if op == "role_is":
        return {expr["player"]}
    if op == "same_role":
        return set(expr["players"])
    if op in {"count_role", "parity"}:
        return set(expr["players"])
    if op == "statement_true":
        return {expr["player"]}
    if op == "not":
        return referenced_players(expr["arg"])
    if op in {"and", "or", "xor", "iff", "implies"}:
        return referenced_players(expr["left"]) | referenced_players(expr["right"])
    raise ValueError(f"unknown expression operator: {op}")


def statement_dependencies(expr: Expr) -> set[int]:
    op = expr["op"]
    if op == "statement_true":
        return {expr["player"]}
    if op == "not":
        return statement_dependencies(expr["arg"])
    if op in {"and", "or", "xor", "iff", "implies"}:
        return statement_dependencies(expr["left"]) | statement_dependencies(expr["right"])
    return set()


def validate_statements(statements: Sequence[Expr]) -> None:
    n = len(statements)
    graph: list[set[int]] = []
    for speaker, expr in enumerate(statements):
        refs = referenced_players(expr)
        if any(ref < 0 or ref >= n for ref in refs):
            raise ValueError("statement references a player outside the puzzle")
        deps = statement_dependencies(expr)
        if speaker in deps:
            raise ValueError("self-referential statements are not allowed")
        graph.append(deps)

    state = [0] * n

    def visit(node: int) -> None:
        if state[node] == 1:
            raise ValueError("cyclic statement-truth dependency")
        if state[node] == 2:
            return
        state[node] = 1
        for dep in graph[node]:
            visit(dep)
        state[node] = 2

    for node in range(n):
        visit(node)


def evaluate_expr(
    expr: Expr,
    assignment: Assignment,
    statements: Sequence[Expr] | None = None,
    memo: dict[int, bool] | None = None,
) -> bool:
    op = expr["op"]
    if op == "role_is":
        return assignment[expr["player"]] == expr["role"]
    if op == "same_role":
        a, b = expr["players"]
        return assignment[a] == assignment[b]
    if op in {"count_role", "parity"}:
        count = sum(assignment[p] == expr["role"] for p in expr["players"])
        if op == "parity":
            return count % 2 == (0 if expr["parity"] == "even" else 1)
        comparison = expr["comparison"]
        target = expr["count"]
        return {
            "exactly": count == target,
            "at_least": count >= target,
            "at_most": count <= target,
        }[comparison]
    if op == "statement_true":
        if statements is None:
            raise ValueError("statement_true requires puzzle context")
        memo = memo if memo is not None else {}
        player = expr["player"]
        if player not in memo:
            memo[player] = evaluate_expr(statements[player], assignment, statements, memo)
        return memo[player]
    if op == "not":
        return not evaluate_expr(expr["arg"], assignment, statements, memo)
    if op in {"and", "or", "xor", "iff", "implies"}:
        left = evaluate_expr(expr["left"], assignment, statements, memo)
        right = evaluate_expr(expr["right"], assignment, statements, memo)
        if op == "and":
            return left and right
        if op == "or":
            return left or right
        if op == "xor":
            return left != right
        if op == "iff":
            return left == right
        return not left or right
    raise ValueError(f"unknown expression operator: {op}")


def statement_values(statements: Sequence[Expr], assignment: Assignment) -> tuple[bool, ...]:
    memo: dict[int, bool] = {}
    for i, statement in enumerate(statements):
        if i not in memo:
            memo[i] = evaluate_expr(statement, assignment, statements, memo)
    return tuple(memo[i] for i in range(len(statements)))


def evaluate_puzzle(statements: Sequence[Expr], assignment: Assignment) -> bool:
    if assignment.count("spy") != 1:
        return False
    values = statement_values(statements, assignment)
    return all(
        role == "spy" or (role == "knight") == value
        for role, value in zip(assignment, values, strict=True)
    )


def solve(statements: Sequence[Expr], limit: int | None = None) -> list[Assignment]:
    validate_statements(statements)
    solutions: list[Assignment] = []
    for assignment in assignments(len(statements)):
        if evaluate_puzzle(statements, assignment):
            solutions.append(assignment)
            if limit is not None and len(solutions) >= limit:
                break
    return solutions


def normalize(expr: Expr) -> Expr:
    op = expr["op"]
    if op == "not":
        arg = normalize(expr["arg"])
        if arg["op"] == "not":
            return normalize(arg["arg"])
        return {"op": "not", "arg": arg}
    if op == "implies":
        return {
            "op": op,
            "left": normalize(expr["left"]),
            "right": normalize(expr["right"]),
        }
    if op in {"and", "or", "xor", "iff"}:
        left, right = normalize(expr["left"]), normalize(expr["right"])
        if canonical_json(left) > canonical_json(right):
            left, right = right, left
        if left == right:
            if op in {"and", "or", "iff"}:
                return left if op != "iff" else {"op": "count_role", "players": [], "role": "spy", "comparison": "exactly", "count": 0}
            return {"op": "count_role", "players": [], "role": "spy", "comparison": "exactly", "count": 1}
        return {"op": op, "left": left, "right": right}
    result = dict(expr)
    if "players" in result:
        result["players"] = sorted(result["players"])
    return result


def remap(expr: Expr, mapping: Mapping[int, int]) -> Expr:
    op = expr["op"]
    if op in {"role_is", "statement_true"}:
        result = dict(expr)
        result["player"] = mapping[expr["player"]]
        return result
    if op in {"same_role", "count_role", "parity"}:
        result = dict(expr)
        result["players"] = [mapping[p] for p in expr["players"]]
        return normalize(result)
    if op == "not":
        return normalize({"op": "not", "arg": remap(expr["arg"], mapping)})
    return normalize({"op": op, "left": remap(expr["left"], mapping), "right": remap(expr["right"], mapping)})


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def canonical_hash(statements: Sequence[Expr], target: Assignment) -> str:
    """Canonicalize exactly under role-preserving player renamings."""
    groups = [[i for i, role in enumerate(target) if role == wanted] for wanted in ROLES]
    best: str | None = None
    for parts in itertools.product(*(itertools.permutations(group) for group in groups)):
        old_order = tuple(itertools.chain.from_iterable(parts))
        mapping = {old: new for new, old in enumerate(old_order)}
        mapped = [None] * len(statements)
        for old_speaker, statement in enumerate(statements):
            mapped[mapping[old_speaker]] = remap(statement, mapping)
        signature = canonical_json(mapped)
        if best is None or signature < best:
            best = signature
    assert best is not None
    return hashlib.sha256(best.encode()).hexdigest()


def render(expr: Expr, labels: Sequence[str]) -> str:
    """Render an expression with unambiguous hierarchical Boolean clauses."""
    return _render(expr, labels, ())


def _render(expr: Expr, labels: Sequence[str], path: tuple[int, ...]) -> str:
    op = expr["op"]
    if op == "role_is":
        return f'{labels[expr["player"]]} is a {expr["role"]}'
    if op == "same_role":
        a, b = expr["players"]
        return f"{labels[a]} and {labels[b]} have the same role"
    if op == "statement_true":
        return f'{labels[expr["player"]]}\'s statement is true'
    if op == "count_role":
        people = _join([labels[p] for p in expr["players"]]) or "no players"
        comparison = expr["comparison"].replace("_", " ")
        return f"{comparison} {expr['count']} of {people} are {_plural(expr['role'])}"
    if op == "parity":
        people = _join([labels[p] for p in expr["players"]])
        return f"the number of {_plural(expr['role'])} among {people} is {expr['parity']}"
    if op == "not":
        return f"it is not the case that ({_render(expr['arg'], labels, path)})"
    connectors = {
        "and": "both of the following are true",
        "or": "at least one of the following is true",
        "xor": "exactly one of the following is true",
        "iff": "the following have the same truth value",
        "implies": "if the first is true, the second is true",
    }
    left_path = (*path, 1)
    right_path = (*path, 2)
    left = _render(expr["left"], labels, left_path)
    right = _render(expr["right"], labels, right_path)
    return (
        f"{connectors[op]}: ({_render_path(left_path)}) {left}; "
        f"({_render_path(right_path)}) {right}"
    )


def _render_path(path: tuple[int, ...]) -> str:
    return ".".join(str(part) for part in path)


def _join(values: Sequence[str]) -> str:
    if len(values) <= 1:
        return "".join(values)
    if len(values) == 2:
        return f"{values[0]} and {values[1]}"
    return f"{', '.join(values[:-1])}, and {values[-1]}"


def _plural(role: str) -> str:
    return "spies" if role == "spy" else f"{role}s"


def ast_depth(expr: Expr) -> int:
    if expr["op"] == "not":
        return 1 + ast_depth(expr["arg"])
    if expr["op"] in {"and", "or", "xor", "iff", "implies"}:
        return 1 + max(ast_depth(expr["left"]), ast_depth(expr["right"]))
    return 1


def ast_nodes(expr: Expr) -> int:
    if expr["op"] == "not":
        return 1 + ast_nodes(expr["arg"])
    if expr["op"] in {"and", "or", "xor", "iff", "implies"}:
        return 1 + ast_nodes(expr["left"]) + ast_nodes(expr["right"])
    return 1
