"""Aggregate reports for the flat minimal-claim KKS translator.

This module intentionally reports proposition truth, information, and flat-case
consistency. It never reconstructs proof edges or labels inference validity.
"""

from __future__ import annotations

import html
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import yaml
from PIL import Image, ImageDraw, ImageFont

from controlmad_replication.benchmarks.kks.scoring import score_prediction

from .core import aggregate, completed_results, write_csv
from .formal_logic_compact import format_compact_expression
from .formal_logic_minimal import (
    RELATION_BACKGROUNDS,
    _load_dataset_context,
    score_minimal_translation,
)


SCHEMA_VERSION = 1
INFORMATION_TYPES = (
    "truth_aligned", "misleading", "redundant", "contradictory"
)
CONDITIONAL_INFORMATION_TYPES = (
    *INFORMATION_TYPES, "false_premise_scoped", "inconsistent_premises"
)
VALID_RELATION_VERDICTS = frozenset(
    {"entailed", "valid_contradiction", "valid_reductio"}
)
PREMISE_STATUSES = (
    "stated", "none_extracted", "unresolved_reference", "mixed_case_scope"
)
SUPPORT_CELLS = (
    "sound_reasoning",
    "unsupported_correctness",
    "valid_inference_from_false_premise",
    "unsupported_error",
)
DEFAULT_RELATION_BACKGROUNDS = ("thin", "referenced_roles")
CONFIG_KEYS = frozenset(
    {"schema_version", "analysis_id", "dataset", "sources", "relation_backgrounds"}
)
SOURCE_KEYS = frozenset(
    {"id", "condition_label", "translation_file", "run_dir", "relation_gold_eval"}
)
COLORS = {
    "truth_aligned": "#3B8060",
    "misleading": "#B94C43",
    "redundant": "#8A8F98",
    "contradictory": "#6F3C8A",
    "accuracy": "#326B9A",
    "coverage": "#D18B36",
}


def _resolve(base: Path, value: str | Path) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def _safe_rate(numerator: float, denominator: int) -> float | None:
    return numerator / denominator if denominator else None


def _mean(values: Iterable[float | int | None]) -> float | None:
    kept = [float(value) for value in values if value is not None]
    return sum(kept) / len(kept) if kept else None


def _stage_order(source: Mapping[str, Any]) -> int:
    stage = str(source.get("stage", ""))
    round_index = int(source.get("round_index", 0) or 0)
    if stage == "initial_proposal":
        return 0
    if stage == "debate_argument":
        return 100 + 10 * round_index
    if stage == "self_adjustment":
        return 101 + 10 * round_index
    if stage == "second_proposal":
        return 10_000
    if stage == "final_decision":
        return 10_010
    if stage in {"consensus_supervisor", "supervisor"}:
        return 10_020
    return 9_000 + round_index


def _source_columns(source: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "stage": source.get("stage"),
        "stage_order": _stage_order(source),
        "round_index": source.get("round_index"),
        "agent_id": source.get("agent_id"),
        "field": source.get("field"),
        "player": source.get("player"),
    }


def _strict(
    players: Sequence[str], answer: Mapping[str, str], prediction: Mapping[str, str]
) -> int:
    return int(score_prediction(list(players), dict(answer), dict(prediction))["semantic_strict"])


def _outcome_row(
    condition_id: str,
    condition_label: str,
    task_id: str,
    repetition: int,
    result: Mapping[str, Any],
    question: Mapping[str, Any],
    target: Sequence[str],
) -> dict[str, Any]:
    players = list(question["players"])
    answer = dict(zip(players, target, strict=True))
    initial = result.get("initial_proposals") or {}
    finals = result.get("final_decisions") or {}
    initial_correct = [
        _strict(players, answer, solution.get("roles") or {})
        for solution in initial.values()
    ]
    final_prediction, final_ties, _ = aggregate(dict(finals), players)
    final_majority_correct = _strict(players, answer, final_prediction)
    operational = dict(result.get("prediction") or {})
    operational_correct = _strict(players, answer, operational)
    final_assignments = [
        tuple((solution.get("roles") or {}).get(player) for player in players)
        for solution in finals.values()
    ]
    final_unanimous = bool(
        final_assignments
        and all(None not in item for item in final_assignments)
        and len(set(final_assignments)) == 1
    )
    any_initial_correct = any(initial_correct)
    if operational_correct:
        stratum = "stable_success" if any_initial_correct else "correction"
    else:
        stratum = "lost_truth" if any_initial_correct else "persistent_failure"
    return {
        "condition_id": condition_id,
        "condition_label": condition_label,
        "task_id": task_id,
        "repetition": repetition,
        "size": len(players),
        "initial_agent_count": len(initial_correct),
        "initial_correct_agent_count": sum(initial_correct),
        "any_initial_correct": int(any_initial_correct),
        "all_initial_correct": int(bool(initial_correct) and all(initial_correct)),
        "operational_final_correct": operational_correct,
        "final_majority_correct": final_majority_correct,
        "final_majority_tie_count": len(final_ties),
        "final_unanimous": int(final_unanimous),
        "behavior_stratum": stratum,
        "incorrect_convergence": int(final_unanimous and not operational_correct),
    }


def _aggregate_metric_rows(
    rows: Sequence[Mapping[str, Any]], keys: Sequence[str]
) -> list[dict[str, Any]]:
    grouped: dict[tuple[Any, ...], list[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[tuple(row.get(key) for key in keys)].append(row)
    output = []
    for group, values in sorted(grouped.items(), key=lambda item: str(item[0])):
        committed = [row for row in values if row.get("committed")]
        scored = [row for row in committed if row.get("target_truth") is not None]
        translated = [row for row in values if row.get("expression")]
        item = {key: value for key, value in zip(keys, group, strict=True)}
        item.update({
            "claim_count": len(values),
            "translated_claim_count": len(translated),
            "committed_claim_count": len(committed),
            "scored_committed_claim_count": len(scored),
            "true_committed_claim_count": sum(
                row.get("target_truth") is True for row in scored
            ),
            "committed_claim_accuracy": _safe_rate(
                sum(row.get("target_truth") is True for row in scored), len(scored)
            ),
            "translation_coverage": _safe_rate(len(translated), len(values)),
            "semantic_coverage": _safe_rate(len(scored), len(committed)),
            "truth_aligned_information_bits": sum(
                float(row.get("information_bits") or 0)
                for row in scored if row.get("information_type") == "truth_aligned"
            ),
            "misleading_information_bits": sum(
                float(row.get("information_bits") or 0)
                for row in scored if row.get("information_type") == "misleading"
            ),
            "mean_information_bits": _mean(
                row.get("information_bits") for row in scored
            ),
        })
        for category in INFORMATION_TYPES:
            count = sum(row.get("information_type") == category for row in scored)
            item[category + "_claim_count"] = count
            item[category + "_claim_rate"] = _safe_rate(count, len(scored))
        premise_backed = [
            row for row in committed
            if row.get("stated_premise_status") == "stated"
        ]
        item["stated_premise_claim_count"] = len(premise_backed)
        item["committed_claim_premise_coverage"] = _safe_rate(
            len(premise_backed), len(committed)
        )
        item["false_premise_scoped_claim_count"] = sum(
            row.get("conditional_information_type") == "false_premise_scoped"
            for row in premise_backed
        )
        for category in CONDITIONAL_INFORMATION_TYPES:
            count = sum(
                row.get("conditional_information_type") == category
                for row in premise_backed
            )
            item["conditional_" + category + "_claim_count"] = count
            item["conditional_" + category + "_claim_rate"] = _safe_rate(
                count, len(premise_backed)
            )
        output.append(item)
    return output


def _validate_config(config: Mapping[str, Any]) -> None:
    """Reject unknown settings so a typo fails instead of silently doing nothing."""
    unknown = set(config) - CONFIG_KEYS
    if unknown:
        raise ValueError("unknown analysis settings: %s" % ", ".join(sorted(unknown)))
    for index, source in enumerate(config.get("sources") or []):
        extra = set(source) - SOURCE_KEYS
        if extra:
            raise ValueError(
                "unknown source settings in source %d: %s"
                % (index, ", ".join(sorted(extra)))
            )


def _relation_backgrounds(config: Mapping[str, Any]) -> tuple[str, ...]:
    """Resolve the background policies to check, primary first."""
    requested = config.get("relation_backgrounds")
    if requested is None:
        return DEFAULT_RELATION_BACKGROUNDS
    names = tuple(str(value) for value in requested)
    if not 1 <= len(names) <= 2:
        raise ValueError("relation_backgrounds takes one or two policies")
    for name in names:
        if name not in RELATION_BACKGROUNDS:
            raise ValueError("unknown relation background: %r" % name)
    if len(set(names)) != len(names):
        raise ValueError("relation_backgrounds must be distinct")
    return names


def _support_cell(
    relation_row: Mapping[str, Any],
    raw_relation: Mapping[str, Any],
    scored_claims: Mapping[str, Mapping[str, Any]],
) -> str | None:
    """Cross conclusion truth with local support validity for one INFER step.

    Returns None where the cross is undefined rather than guessing. A case-scoped
    conclusion is hypothetical and has no unconditional truth value, and an
    uncheckable relation must never be absorbed into "not entailed".
    """
    if relation_row.get("kind") != "infer":
        return None
    if relation_row.get("verdict") == "uncheckable":
        return None
    conclusion_id = raw_relation.get("to")
    if conclusion_id is None:
        return None
    conclusion = scored_claims.get(str(conclusion_id))
    if conclusion is None or not conclusion.get("committed"):
        return None
    if conclusion.get("target_truth") is None:
        return None
    valid = relation_row.get("verdict") == "entailed"
    if conclusion["target_truth"]:
        return "sound_reasoning" if valid else "unsupported_correctness"
    return "valid_inference_from_false_premise" if valid else "unsupported_error"


def _support_soundness_row(
    scope: str, group_value: str, background: str, rows: Sequence[Mapping[str, Any]]
) -> dict[str, Any]:
    """Summarize the 2x2 over one group of relation rows."""
    infer = [row for row in rows if row.get("kind") == "infer"]
    eligible = [row for row in infer if row.get("support_cell") is not None]
    counts = Counter(row["support_cell"] for row in eligible)
    checkable = len(eligible)
    item = {
        "scope": scope,
        "group_value": group_value,
        "background": background,
        "infer_relation_count": len(infer),
        "checkable_eligible_relation_count": checkable,
        "uncheckable_infer_relation_count": sum(
            row.get("verdict") == "uncheckable" for row in infer
        ),
        "case_scoped_infer_relation_count": sum(
            bool(row.get("case_context_ids")) for row in infer
        ),
    }
    for cell in SUPPORT_CELLS:
        item[cell + "_count"] = counts[cell]
        item[cell + "_rate"] = _safe_rate(counts[cell], checkable)
    true_conclusions = counts["sound_reasoning"] + counts["unsupported_correctness"]
    false_conclusions = (
        counts["valid_inference_from_false_premise"] + counts["unsupported_error"]
    )
    item["support_validity_rate"] = _safe_rate(
        counts["sound_reasoning"] + counts["valid_inference_from_false_premise"],
        checkable,
    )
    item["conclusion_truth_rate"] = _safe_rate(true_conclusions, checkable)
    item["support_given_true_rate"] = _safe_rate(
        counts["sound_reasoning"], true_conclusions
    )
    item["support_given_false_rate"] = _safe_rate(
        counts["valid_inference_from_false_premise"], false_conclusions
    )
    return item


def _aggregate_relation_rows(
    rows: Sequence[Mapping[str, Any]], keys: Sequence[str]
) -> list[dict[str, Any]]:
    grouped: dict[tuple[Any, ...], list[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[tuple(row.get(key) for key in keys)].append(row)
    output = []
    for group, values in sorted(grouped.items(), key=lambda item: str(item[0])):
        checkable = [row for row in values if row.get("verdict") != "uncheckable"]
        valid = [
            row for row in checkable if row.get("verdict") in VALID_RELATION_VERDICTS
        ]
        item = {key: value for key, value in zip(keys, group, strict=True)}
        contingent = [row for row in values if row.get("verdict") == "contingent"]
        degenerate = [row for row in values if row.get("background_degenerate")]
        changed = [row for row in values if row.get("verdict_changed")]
        eligible = [row for row in values if row.get("support_cell") is not None]
        item.update({
            "relation_count": len(values),
            "checkable_relation_count": len(checkable),
            "valid_relation_count": len(valid),
            "relation_checkability": _safe_rate(len(checkable), len(values)),
            "stated_relation_validity": _safe_rate(len(valid), len(checkable)),
            "contingent_relation_count": len(contingent),
            "contingent_relation_rate": _safe_rate(len(contingent), len(checkable)),
            "degenerate_background_relation_count": len(degenerate),
            "verdict_changed_count": len(changed),
            "verdict_changed_nondegenerate_count": sum(
                not row.get("background_degenerate") for row in changed
            ),
            "checkable_eligible_relation_count": len(eligible),
        })
        for cell in SUPPORT_CELLS:
            count = sum(row.get("support_cell") == cell for row in eligible)
            item[cell + "_count"] = count
            item[cell + "_rate"] = _safe_rate(count, len(eligible))
        output.append(item)
    return output


def _bar_chart(
    output_dir: Path,
    stem: str,
    title: str,
    groups: Sequence[str],
    series: Sequence[tuple[str, Sequence[float], str]],
    *,
    maximum: float | None = None,
) -> list[str]:
    if not groups or not series:
        return []
    max_value = maximum or max(
        [float(value) for _, values, _ in series for value in values] or [1.0]
    )
    max_value = max(max_value, 1e-9)
    width = max(760, 100 + 92 * len(groups))
    height = 480
    left, top, right, bottom = 70, 58, width - 24, 385
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", 12)
        title_font = ImageFont.truetype("DejaVuSans-Bold.ttf", 18)
    except OSError:
        font = title_font = ImageFont.load_default()
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    draw.text((20, 18), title, fill="#26323B", font=title_font)
    draw.line((left, bottom, right, bottom), fill="#7A848C", width=1)
    draw.line((left, top, left, bottom), fill="#7A848C", width=1)
    group_width = (right - left) / len(groups)
    bar_width = min(24.0, group_width * 0.72 / len(series))
    svg = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (width, height),
        '<rect width="100%%" height="100%%" fill="white"/>',
        '<text x="20" y="32" font-family="sans-serif" font-size="18" font-weight="bold">%s</text>' % html.escape(title),
        '<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#7A848C"/>' % (left, bottom, right, bottom),
    ]
    for index, group in enumerate(groups):
        center = left + group_width * (index + 0.5)
        draw.text((center - 35, bottom + 10), str(group)[:16], fill="#37434B", font=font)
        svg.append('<text x="%.1f" y="%d" text-anchor="middle" font-family="sans-serif" font-size="11">%s</text>' % (center, bottom + 24, html.escape(str(group)[:20])))
        for series_index, (label, values, color) in enumerate(series):
            value = float(values[index])
            x = center - (len(series) * bar_width) / 2 + series_index * bar_width
            bar_height = (bottom - top) * value / max_value
            y = bottom - bar_height
            draw.rectangle((x, y, x + bar_width - 2, bottom), fill=color)
            svg.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="%s"/>' % (x, y, bar_width - 2, bar_height, color))
    legend_x = left
    for label, _, color in series:
        draw.rectangle((legend_x, 430, legend_x + 11, 441), fill=color)
        draw.text((legend_x + 16, 426), label, fill="#37434B", font=font)
        svg.append('<rect x="%d" y="430" width="11" height="11" fill="%s"/><text x="%d" y="440" font-family="sans-serif" font-size="11">%s</text>' % (legend_x, color, legend_x + 16, html.escape(label)))
        legend_x += 28 + 8 * len(label)
    svg.append("</svg>")
    png_name, svg_name = stem + ".png", stem + ".svg"
    image.save(output_dir / png_name)
    (output_dir / svg_name).write_text("\n".join(svg) + "\n", encoding="utf-8")
    return [png_name, svg_name]


def _figures(
    output_dir: Path,
    claims: Sequence[Mapping[str, Any]],
    cases: Sequence[Mapping[str, Any]],
    agent_rounds: Sequence[Mapping[str, Any]],
    debates: Sequence[Mapping[str, Any]],
    relations: Sequence[Mapping[str, Any]] = (),
) -> list[str]:
    artifacts: list[str] = []
    by_outcome = {0: [], 1: []}
    for row in claims:
        if row.get("committed") and row.get("target_truth") is not None:
            by_outcome[int(row["operational_final_correct"])].append(row)
    outcome_groups = ["final wrong", "final correct"]
    outcome_series = []
    for category in INFORMATION_TYPES:
        values = []
        for outcome in (0, 1):
            group = by_outcome[outcome]
            values.append(_safe_rate(sum(row["information_type"] == category for row in group), len(group)) or 0.0)
        outcome_series.append((category.replace("_", " "), values, COLORS[category]))
    artifacts.extend(_bar_chart(output_dir, "information-by-outcome", "Information categories by final outcome", outcome_groups, outcome_series, maximum=1.0))

    stage_groups = sorted({(int(row["stage_order"]), str(row["stage"])) for row in claims})
    stage_labels = []
    for order, stage in stage_groups:
        display_stage = {
            "initial_proposal": "initial",
            "debate_argument": "argument",
            "self_adjustment": "adjust",
            "second_proposal": "second",
            "final_decision": "final",
            "consensus_supervisor": "supervisor",
        }.get(stage, stage)
        rounds = sorted({
            int(row["round_index"])
            for row in claims
            if int(row["stage_order"]) == order
            and row["stage"] == stage
            and row.get("round_index") is not None
        })
        stage_labels.append(
            "%s r%d" % (display_stage, rounds[0])
            if len(rounds) == 1 else display_stage
        )
    stage_series = []
    for category in INFORMATION_TYPES:
        values = []
        for order, stage in stage_groups:
            group = [row for row in claims if int(row["stage_order"]) == order and row["stage"] == stage and row.get("committed") and row.get("target_truth") is not None]
            values.append(_safe_rate(sum(row["information_type"] == category for row in group), len(group)) or 0.0)
        stage_series.append((category.replace("_", " "), values, COLORS[category]))
    artifacts.extend(_bar_chart(output_dir, "information-by-stage", "Committed claim categories over stages", stage_labels, stage_series, maximum=1.0))

    agent_groups = sorted({(str(row["condition_id"]), str(row.get("agent_id") or "unknown")) for row in agent_rounds})
    agent_labels = [condition + ":" + agent for condition, agent in agent_groups]
    agent_series = []
    for label, key, color in (
        ("truth bits/claim", "truth_aligned_information_bits", COLORS["truth_aligned"]),
        ("misleading bits/claim", "misleading_information_bits", COLORS["misleading"]),
    ):
        values = []
        for condition, agent in agent_groups:
            group = [row for row in agent_rounds if row["condition_id"] == condition and str(row.get("agent_id") or "unknown") == agent]
            bits = sum(float(row[key]) for row in group)
            count = sum(int(row["scored_committed_claim_count"]) for row in group)
            values.append(_safe_rate(bits, count) or 0.0)
        agent_series.append((label, values, color))
    artifacts.extend(_bar_chart(output_dir, "agent-information", "Normalized agent information", agent_labels, agent_series))

    conditions = sorted({str(row["condition_id"]) for row in debates})
    case_series = []
    for label, field, color in (
        ("complete case coverage", "complete", COLORS["coverage"]),
        ("disposition accuracy", "accuracy", COLORS["accuracy"]),
    ):
        values = []
        for condition in conditions:
            group = [row for row in cases if row["condition_id"] == condition]
            if field == "complete":
                values.append(_safe_rate(sum(row["representability"] == "complete" for row in group), len(group)) or 0.0)
            else:
                scored = [row for row in group if row["disposition_scored"]]
                values.append(_safe_rate(sum(row["disposition_matches_assumption_viability"] is True for row in scored), len(scored)) or 0.0)
        case_series.append((label, values, color))
    artifacts.extend(_bar_chart(output_dir, "case-quality", "Flat-case coverage and disposition agreement", conditions, case_series, maximum=1.0))

    if relations:
        relation_conditions = sorted({str(row["condition_id"]) for row in relations})
        validity_series = []
        for label, predicate, color in (
            ("valid", lambda row: row["verdict"] in VALID_RELATION_VERDICTS,
             COLORS["truth_aligned"]),
            ("not entailed", lambda row: row["verdict"] == "contingent",
             COLORS["coverage"]),
        ):
            values = []
            for condition in relation_conditions:
                checkable = [
                    row for row in relations
                    if row["condition_id"] == condition
                    and row["verdict"] != "uncheckable"
                ]
                values.append(
                    _safe_rate(sum(predicate(row) for row in checkable), len(checkable))
                    or 0.0
                )
            validity_series.append((label, values, color))
        artifacts.extend(_bar_chart(
            output_dir, "relation-validity",
            "Local validity of stated relations", relation_conditions,
            validity_series, maximum=1.0,
        ))

        eligible = [row for row in relations if row.get("support_cell") is not None]
        if eligible:
            support_groups = ["final wrong", "final correct"]
            support_series = []
            for cell, color in zip(
                SUPPORT_CELLS,
                (COLORS["truth_aligned"], COLORS["coverage"],
                 COLORS["accuracy"], COLORS["misleading"]),
            ):
                values = []
                for outcome_value in (0, 1):
                    group = [
                        row for row in eligible
                        if row["operational_final_correct"] == outcome_value
                    ]
                    values.append(
                        _safe_rate(
                            sum(row["support_cell"] == cell for row in group),
                            len(group),
                        ) or 0.0
                    )
                support_series.append((cell.replace("_", " "), values, color))
            artifacts.extend(_bar_chart(
                output_dir, "support-soundness",
                "Conclusion truth by local support validity", support_groups,
                support_series, maximum=1.0,
            ))

    strata = ("correction", "persistent_failure", "lost_truth", "stable_success")
    stratum_series = []
    for index, stratum in enumerate(strata):
        values = [sum(row["condition_id"] == condition and row["behavior_stratum"] == stratum for row in debates) for condition in conditions]
        stratum_series.append((stratum.replace("_", " "), values, ("#3B8060", "#B94C43", "#D18B36", "#326B9A")[index]))
    artifacts.extend(_bar_chart(output_dir, "behavior-strata", "Behavioral strata by condition", conditions, stratum_series))
    return artifacts


def _methodology(summary: Mapping[str, Any]) -> str:
    return """# Minimal-translator reasoning analysis

## Interpretation

This report measures the truth and information content of explicit commitments,
the local validity of explicitly stated reasoning relations, and descriptive
consistency of flat hypothetical cases. It does not reconstruct whole proofs.

## Metric rules

- ASSERT and ENDORSE are scored directly; REJECT is scored through negation.
- Information uses all role assignments with exactly one spy as its baseline.
- Each commitment is measured twice. Unconditional information uses that whole
  baseline; conditional information uses only the worlds its stated premises
  still allow, following IG = log2(|W(P)| / |W(P + c)|).
- Premises come from stated INFER relations, and from the undischarged members
  of the contradiction a REDUCTIO cites. Both universes are identical, so the
  two measures coincide for a claim with no extracted premises.
- `false_premise_scoped` marks a claim whose premises had already excluded the
  verified solution: it is a distinct category from `misleading`, which marks a
  claim that eliminates a still-reachable solution.
- A relation counts as valid when its verdict is `entailed`, `valid_contradiction`,
  or `valid_reductio`. `contingent` means the conclusion does not follow from the
  premises the speaker cited, which is weaker than calling it a fallacy: an
  unstated premise reads the same way. `inconsistent_premises` is never counted
  valid, because explosion is disabled.
- `support_cell` crosses conclusion truth with local validity over INFER relations
  whose conclusion is a committed, scored claim. Case-scoped conclusions are
  hypothetical and carry no unconditional truth value, and uncheckable relations
  are held out rather than folded into "not entailed"; both are counted separately
  in `support-soundness.csv`.

## Background assumptions

Local validity is relative to the worlds left open before a step is taken, so the
background policy is a reported choice rather than a fixed fact.

- `thin` applies the knight/knave truth rule only to players whose statement-truth
  atom appears in the cited claims.
- `referenced_roles` also applies it to players named individually. This is the
  default second policy: it is a real widening, and it leaves the world set
  non-degenerate for almost every relation.
- `referenced_all` additionally fixes every player listed by a `COUNT` or `PARITY`
  atom. Because those atoms usually range over the whole roster, the world set
  then collapses to the puzzle's unique solution and `entailed` degenerates into
  "true at the solution". It remains selectable for audit only.
- A policy fixing every player is deliberately not offered, for the same reason.

`relation-background-sensitivity.csv` reports the verdict transition matrix
between the two configured policies, and every relation row carries
`local_world_count` and `background_degenerate` so a collapsed comparison is
visible per row rather than averaged away. REDUCTIO verdicts are checked
structurally and do not move with the policy.

## Relation capture

Relation extraction is the translator's weakest dimension, so every rate above is
a rate *among captured relations*, not a census of the speaker's reasoning.
Measured recall and precision per condition are recorded in `summary.json` under
`relation_capture`, taken from the configured gold evaluation rather than
restated here, and are absent where no gold evaluation is configured.
- Reports, assumptions, hypotheticals, opaque claims, and parse failures are not
  unconditional commitments and do not enter claim-accuracy denominators.
- Incomplete cases remain in coverage tables but do not enter disposition accuracy.
- Raw information totals are verbosity-sensitive; comparisons use normalized
  rates and mean bits per eligible claim.

## Research boundary

These outputs remain descriptive until a frozen multi-puzzle expert audit
validates expression fidelity, commitments, case IDs, and case dispositions.

`stated_premise_status = none_extracted` does not mean the speaker gave no
reason. The translator emits a relation only where the source explicitly
connects two already translated claims, so an omitted relation and a genuinely
unsupported assertion are indistinguishable here. Premise coverage over
committed claims is reported beside every conditional figure for that reason,
and unsupported-leap rates cannot be read off these tables.

Local dependency validity is measured, conditionally on capture and relative to a
stated background policy. It is evidence about single steps, not about how errors
travel: relations are local to one reasoning field, and error propagation across
agents and rounds, recovery, peer adoption, and causal influence are not
measured.

## Inventory

- Conditions: %(conditions)d
- Debates: %(debates)d
- Fields: %(fields)d
- Claims: %(claims)d
- Cases: %(cases)d
- Relations: %(relations)d
- Checked relations: %(checkable)d
- Locally valid relations: %(valid)d
- Relations whose verdict moves with the background policy: %(changed)d
- Committed claims with stated premises: %(premise_backed)d / %(committed)d
""" % {
        "conditions": summary["condition_count"],
        "debates": summary["debate_count"],
        "fields": summary["field_count"],
        "claims": summary["claim_count"],
        "cases": summary["case_count"],
        "relations": summary["relation_count"],
        "checkable": summary["checkable_relation_count"],
        "valid": summary["valid_relation_count"],
        "changed": summary["verdict_changed_count"],
        "premise_backed": summary["premise_backed_committed_claim_count"],
        "committed": summary["committed_claim_count"],
    }


def analyze_minimal_reasoning(config_path: Path, output_dir: Path) -> dict[str, Any]:
    """Build a multi-condition descriptive report from saved translations."""
    config = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    if int(config.get("schema_version", 0)) != SCHEMA_VERSION:
        raise ValueError("minimal reasoning analysis requires schema_version 1")
    _validate_config(config)
    backgrounds = _relation_backgrounds(config)
    primary_background = backgrounds[0]
    secondary_background = backgrounds[1] if len(backgrounds) > 1 else None
    base = config_path.parent
    dataset = _resolve(base, config["dataset"])
    questions, targets = _load_dataset_context(dataset)
    sources = list(config.get("sources") or [])
    if not sources:
        raise ValueError("minimal reasoning analysis requires at least one source")

    claims: list[dict[str, Any]] = []
    cases: list[dict[str, Any]] = []
    relations: list[dict[str, Any]] = []
    relation_capture: dict[str, Any] = {}
    fields: list[dict[str, Any]] = []
    debate_by_key: dict[tuple[str, str, int], dict[str, Any]] = {}
    seen_conditions: set[str] = set()
    seen_fields: set[tuple[str, str, int, str]] = set()

    for source_config in sources:
        condition_id = str(source_config["id"])
        if condition_id in seen_conditions:
            raise ValueError("duplicate source id: %s" % condition_id)
        seen_conditions.add(condition_id)
        condition_label = str(source_config.get("condition_label", condition_id))
        translation_path = _resolve(base, source_config["translation_file"])
        run_dir = _resolve(base, source_config["run_dir"])
        results = completed_results(run_dir)
        records = _read_jsonl(translation_path)
        gold_eval = source_config.get("relation_gold_eval")
        if gold_eval is None:
            relation_capture[condition_id] = None
        else:
            measured = json.loads(
                _resolve(base, gold_eval).read_text(encoding="utf-8")
            )
            relation_capture[condition_id] = {
                "relation_recall": measured.get("relation_recall"),
                "relation_precision": measured.get("relation_precision"),
                "relation_detection_recall": measured.get("relation_detection_recall"),
                "required_relation_count": measured.get("required_relation_count"),
                "gold_field_count": measured.get("field_count"),
                "source": str(_resolve(base, gold_eval)),
            }

        for record in records:
            source = dict(record.get("source") or {})
            task_id = str(source.get("task_id", ""))
            repetition = int(source.get("repetition", 1))
            if task_id not in questions:
                raise ValueError("unknown task id in translation: %s" % task_id)
            result = results.get((task_id, repetition))
            if result is None:
                raise ValueError(
                    "translation has no completed result: %s/%s/%d"
                    % (condition_id, task_id, repetition)
                )
            field_id = str(record.get("formalization_id") or "")
            field_key = (condition_id, task_id, repetition, field_id)
            if not field_id or field_key in seen_fields:
                raise ValueError("missing or duplicate formalization id: %s" % (field_key,))
            seen_fields.add(field_key)
            outcome_key = (condition_id, task_id, repetition)
            if outcome_key not in debate_by_key:
                debate_by_key[outcome_key] = _outcome_row(
                    condition_id, condition_label, task_id, repetition,
                    result, questions[task_id], targets[task_id],
                )
            outcome = debate_by_key[outcome_key]
            score = score_minimal_translation(
                record,
                questions[task_id],
                targets[task_id],
                relation_backgrounds=backgrounds,
            )
            source_cols = _source_columns(source)
            field_uid = ":".join((condition_id, task_id, str(repetition), field_id))
            raw_claims = {str(item["id"]): item for item in record.get("claims") or []}
            for row in score["claims"]:
                raw = raw_claims[str(row["id"])]
                expression = raw.get("expression")
                effective = expression
                if expression is not None and raw.get("commitment") == "reject":
                    effective = {"op": "not", "arg": expression}
                claims.append({
                    "condition_id": condition_id,
                    "condition_label": condition_label,
                    "task_id": task_id,
                    "repetition": repetition,
                    "field_uid": field_uid,
                    "claim_uid": field_uid + ":" + str(row["id"]),
                    **source_cols,
                    "local_claim_id": row["id"],
                    "commitment": row["commitment"],
                    "case_id": row["case_id"],
                    "attribution": ",".join(raw.get("attributions") or []) or None,
                    "expression": format_compact_expression(expression) if expression is not None else None,
                    "effective_expression": format_compact_expression(effective) if effective is not None else None,
                    "source_span": row["source_span"],
                    "committed": int(bool(row["committed"])),
                    "target_truth": row["target_truth"],
                    "expression_truth_at_target": row["expression_truth_at_target"],
                    "role_world_count": row["role_world_count"],
                    "supporting_role_world_count": row["supporting_role_world_count"],
                    "information_bits": row["information_bits"],
                    "information_type": row["information_type"],
                    "structurally_impossible": int(bool(row["structurally_impossible"])),
                    "stated_premise_claim_ids": ",".join(
                        row["stated_premise_claim_ids"]
                    ) or None,
                    "stated_premise_count": row["stated_premise_count"],
                    "stated_premise_status": row["stated_premise_status"],
                    "premise_world_count": row["premise_world_count"],
                    "conditional_supporting_world_count": row[
                        "conditional_supporting_world_count"
                    ],
                    "conditional_information_bits": row["conditional_information_bits"],
                    "conditional_information_type": row["conditional_information_type"],
                    "premises_admit_target": row["premises_admit_target"],
                    "operational_final_correct": outcome["operational_final_correct"],
                    "behavior_stratum": outcome["behavior_stratum"],
                })
            for row in score["cases"]:
                cases.append({
                    "condition_id": condition_id,
                    "condition_label": condition_label,
                    "task_id": task_id,
                    "repetition": repetition,
                    "field_uid": field_uid,
                    "case_uid": field_uid + ":" + str(row["id"]),
                    **source_cols,
                    **{key: value for key, value in row.items() if key != "hypothetical_claims"},
                    "hypothetical_claim_statuses": json.dumps(row["hypothetical_claims"], sort_keys=True),
                    "operational_final_correct": outcome["operational_final_correct"],
                    "behavior_stratum": outcome["behavior_stratum"],
                })
            raw_relations = {
                str(item["id"]): item for item in record.get("relations") or []
            }
            scored_claims = {str(row["id"]): row for row in score["claims"]}
            secondary_rows = (
                {
                    str(row["id"]): row
                    for row in score["relations_by_background"][secondary_background]
                }
                if secondary_background is not None
                else {}
            )
            for row in score["relations"]:
                raw_relation = raw_relations.get(str(row["id"]), {})
                secondary = secondary_rows.get(str(row["id"]))
                secondary_worlds = (
                    secondary.get("local_world_count") if secondary else None
                )
                relations.append({
                    "condition_id": condition_id,
                    "condition_label": condition_label,
                    "task_id": task_id,
                    "repetition": repetition,
                    "field_uid": field_uid,
                    "relation_uid": field_uid + ":" + str(row["id"]),
                    **source_cols,
                    "local_relation_id": row["id"],
                    "kind": row["kind"],
                    "verdict": row["verdict"],
                    "reason": row["reason"],
                    "counterexample_count": row["counterexample_count"],
                    "from_claim_ids": ",".join(
                        str(value) for value in raw_relation.get("from") or []
                    ) or None,
                    "to_claim_id": raw_relation.get("to"),
                    "assume_claim_id": raw_relation.get("assume"),
                    "via_relation_id": raw_relation.get("via"),
                    "case_context_ids": ",".join(row.get("case_context_ids") or [])
                    or None,
                    "uses_mixed_scope": int(bool(row.get("uses_mixed_scope"))),
                    "local_world_count": row.get("local_world_count"),
                    "premise_world_count": row.get("premise_world_count"),
                    "background": row.get("background"),
                    "support_cell": _support_cell(row, raw_relation, scored_claims),
                    "secondary_background": secondary_background,
                    "verdict_secondary": secondary.get("verdict") if secondary else None,
                    "valid_secondary": (
                        int(secondary["verdict"] in VALID_RELATION_VERDICTS)
                        if secondary
                        else None
                    ),
                    "local_world_count_secondary": secondary_worlds,
                    "verdict_changed": (
                        int(secondary["verdict"] != row["verdict"])
                        if secondary
                        else None
                    ),
                    "background_degenerate": (
                        int(secondary_worlds is not None and secondary_worlds <= 1)
                        if secondary
                        else None
                    ),
                    "source_span": row["source_span"],
                    "operational_final_correct": outcome["operational_final_correct"],
                    "behavior_stratum": outcome["behavior_stratum"],
                })
            fields.append({
                "condition_id": condition_id,
                "condition_label": condition_label,
                "task_id": task_id,
                "repetition": repetition,
                "field_uid": field_uid,
                **source_cols,
                "claim_count": score["claim_count"],
                "translated_claim_count": score["translated_claim_count"],
                "opaque_claim_count": score["opaque_claim_count"],
                "committed_claim_count": score["committed_claim_count"],
                "scored_committed_claim_count": score["scored_committed_claim_count"],
                "committed_claim_accuracy": score["committed_claim_accuracy"],
                "translation_coverage": _safe_rate(score["translated_claim_count"], score["claim_count"]),
                "semantic_coverage": _safe_rate(score["scored_committed_claim_count"], score["committed_claim_count"]),
                "case_count": score["case_count"],
                "explicit_case_disposition_count": score["explicit_case_disposition_count"],
                "scored_case_disposition_count": score["scored_case_disposition_count"],
                "case_assumption_disposition_accuracy": score["case_assumption_disposition_accuracy"],
                "stated_premise_claim_count": score["stated_premise_claim_count"],
                "committed_claim_premise_coverage": score["committed_claim_premise_coverage"],
                "relation_count": score["relation_count"],
                "checkable_relation_count": score["checkable_relation_count"],
                "valid_relation_count": score["valid_relation_count"],
                "parse_error_count": score["parse_error_count"],
                "operational_final_correct": outcome["operational_final_correct"],
                "behavior_stratum": outcome["behavior_stratum"],
            })

    debates = list(sorted(debate_by_key.values(), key=lambda row: (row["condition_id"], row["task_id"], row["repetition"])))
    agent_round_keys = (
        "condition_id", "condition_label", "task_id", "repetition",
        "stage", "stage_order", "round_index", "agent_id",
        "operational_final_correct", "behavior_stratum",
    )
    agent_rounds = _aggregate_metric_rows(claims, agent_round_keys)
    relation_summary = _aggregate_relation_rows(relations, ("condition_id",))
    debate_metrics = _aggregate_metric_rows(
        claims,
        ("condition_id", "task_id", "repetition"),
    )
    metrics_by_debate = {
        (row["condition_id"], row["task_id"], int(row["repetition"])): row
        for row in debate_metrics
    }
    relation_metrics_by_debate = {
        (row["condition_id"], row["task_id"], int(row["repetition"])): row
        for row in _aggregate_relation_rows(
            relations, ("condition_id", "task_id", "repetition")
        )
    }
    empty_relation_metrics = {
        "relation_count": 0,
        "checkable_relation_count": 0,
        "valid_relation_count": 0,
        "relation_checkability": None,
        "stated_relation_validity": None,
    }
    for row in debates:
        key = (row["condition_id"], row["task_id"], int(row["repetition"]))
        metrics = metrics_by_debate.get(key, {})
        row.update({key_: value for key_, value in metrics.items() if key_ not in {"condition_id", "task_id", "repetition"}})
        relation_metrics = relation_metrics_by_debate.get(key)
        row.update(
            empty_relation_metrics if relation_metrics is None
            else {
                key_: value for key_, value in relation_metrics.items()
                if key_ not in {"condition_id", "task_id", "repetition"}
            }
        )

    behavior_strata = [
        {
            **row,
            "case_study_eligible": int(
                int(row.get("claim_count", 0)) > 0
                and int(row.get("scored_committed_claim_count", 0)) > 0
            ),
        }
        for row in debates
    ]
    outcome_comparison = []
    for outcome in (0, 1):
        group = [row for row in debates if row["operational_final_correct"] == outcome]
        outcome_comparison.append({
            "operational_final_correct": outcome,
            "debate_count": len(group),
            "mean_committed_claim_accuracy": _mean(row.get("committed_claim_accuracy") for row in group),
            "mean_truth_aligned_claim_rate": _mean(row.get("truth_aligned_claim_rate") for row in group),
            "mean_misleading_claim_rate": _mean(row.get("misleading_claim_rate") for row in group),
            "mean_redundant_claim_rate": _mean(row.get("redundant_claim_rate") for row in group),
            "mean_contradictory_claim_rate": _mean(row.get("contradictory_claim_rate") for row in group),
            "mean_information_bits_per_claim": _mean(row.get("mean_information_bits") for row in group),
            "mean_translation_coverage": _mean(row.get("translation_coverage") for row in group),
            "mean_semantic_coverage": _mean(row.get("semantic_coverage") for row in group),
            "mean_committed_claim_premise_coverage": _mean(
                row.get("committed_claim_premise_coverage") for row in group
            ),
            "mean_conditional_truth_aligned_claim_rate": _mean(
                row.get("conditional_truth_aligned_claim_rate") for row in group
            ),
            "mean_conditional_misleading_claim_rate": _mean(
                row.get("conditional_misleading_claim_rate") for row in group
            ),
            "mean_false_premise_scoped_claim_rate": _mean(
                row.get("conditional_false_premise_scoped_claim_rate") for row in group
            ),
            "mean_stated_relation_validity": _mean(
                row.get("stated_relation_validity") for row in group
            ),
        })

    support_soundness = [
        _support_soundness_row("overall", "all", primary_background, relations)
    ]
    for outcome_value in (0, 1):
        support_soundness.append(_support_soundness_row(
            "outcome",
            str(outcome_value),
            primary_background,
            [
                row for row in relations
                if row["operational_final_correct"] == outcome_value
            ],
        ))
    for condition in sorted({row["condition_id"] for row in relations}):
        support_soundness.append(_support_soundness_row(
            "condition",
            condition,
            primary_background,
            [row for row in relations if row["condition_id"] == condition],
        ))

    background_sensitivity: list[dict[str, Any]] = []
    if secondary_background is not None:
        groups = [("all", relations)] + [
            (condition, [row for row in relations if row["condition_id"] == condition])
            for condition in sorted({row["condition_id"] for row in relations})
        ]
        for condition, group in groups:
            transitions = Counter(
                (row["verdict"], row["verdict_secondary"]) for row in group
            )
            for (primary_verdict, secondary_verdict), count in sorted(
                transitions.items(), key=lambda item: str(item[0])
            ):
                background_sensitivity.append({
                    "condition_id": condition,
                    "primary_background": primary_background,
                    "secondary_background": secondary_background,
                    "primary_verdict": primary_verdict,
                    "secondary_verdict": secondary_verdict,
                    "relation_count": count,
                    "degenerate_secondary_count": sum(
                        bool(row.get("background_degenerate"))
                        for row in group
                        if (row["verdict"], row["verdict_secondary"])
                        == (primary_verdict, secondary_verdict)
                    ),
                })

    output_dir.mkdir(parents=True, exist_ok=True)
    artifacts = []
    for name, rows in (
        ("claims.csv", claims), ("cases.csv", cases), ("fields.csv", fields),
        ("relations.csv", relations), ("relation-summary.csv", relation_summary),
        ("support-soundness.csv", support_soundness),
        ("relation-background-sensitivity.csv", background_sensitivity),
        ("agent-rounds.csv", agent_rounds), ("debates.csv", debates),
        ("behavior-strata.csv", behavior_strata),
        ("outcome-comparison.csv", outcome_comparison),
    ):
        write_csv(output_dir / name, list(rows))
        artifacts.append(name)
    figure_artifacts = _figures(
        output_dir, claims, cases, agent_rounds, debates, relations
    )
    artifacts.extend(figure_artifacts)
    summary = {
        "schema_version": SCHEMA_VERSION,
        "analysis_id": str(config.get("analysis_id", config_path.stem)),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "config": str(config_path),
        "dataset": str(dataset),
        "condition_count": len(seen_conditions),
        "debate_count": len(debates),
        "field_count": len(fields),
        "claim_count": len(claims),
        "case_count": len(cases),
        "relation_count": len(relations),
        "checkable_relation_count": sum(
            row["verdict"] != "uncheckable" for row in relations
        ),
        "valid_relation_count": sum(
            row["verdict"] in VALID_RELATION_VERDICTS for row in relations
        ),
        "committed_claim_count": sum(row["committed"] for row in claims),
        "scored_committed_claim_count": sum(row["target_truth"] is not None for row in claims if row["committed"]),
        "premise_backed_committed_claim_count": sum(
            row["stated_premise_status"] == "stated"
            for row in claims if row["committed"]
        ),
        "premise_status_counts": dict(
            Counter(row["stated_premise_status"] for row in claims if row["committed"])
        ),
        "relation_backgrounds": list(backgrounds),
        "relation_background_primary": primary_background,
        "relation_verdict_counts": dict(
            Counter(row["verdict"] for row in relations)
        ),
        "relation_kind_counts": dict(Counter(row["kind"] for row in relations)),
        "verdict_changed_count": sum(
            bool(row.get("verdict_changed")) for row in relations
        ),
        "degenerate_background_relation_count": sum(
            bool(row.get("background_degenerate")) for row in relations
        ),
        "support_soundness": support_soundness[0],
        "relation_capture": relation_capture,
        "parse_error_count": sum(int(row["parse_error_count"]) for row in fields),
        "behavior_strata": dict(Counter(row["behavior_stratum"] for row in debates)),
        "incorrect_convergence_count": sum(row["incorrect_convergence"] for row in debates),
        "research_ready": False,
        "supported_research_question": "How does final correctness correspond to the truth and information content of agents' explicit commitments?",
        "limitations": [
            "Premise-conditional information covers only explicitly stated relations;"
            " none_extracted does not mean the speaker gave no reason.",
            "Relation-derived rates are conditional on translator capture: they"
            " describe the relations the translator extracted, not every inference"
            " the speaker made. See relation_capture for measured recall and"
            " precision, which are unquantified where no gold eval is configured."
            " Those figures come from a small development gold set and"
            " characterize a translator configuration; where the analyzed fields"
            " are not that gold set, they are an estimate rather than a"
            " measurement of these fields.",
            "Local validity is checked against disclosed KKS rules, not the solved"
            " puzzle, and verdicts move with the background policy; a"
            " referenced_all background collapses to the puzzle solution whenever a"
            " relation cites a roster-wide count or parity atom, which turns"
            " validity into correctness. Such relations are flagged"
            " background_degenerate.",
            "The support-soundness table covers only INFER relations with a"
            " committed, scored conclusion. Case-scoped and uncheckable relations"
            " are excluded and counted separately. Its cells are not independent"
            " observations: one debate contributes many correlated relations.",
            "REDUCTIO verdicts do not depend on the background policy, so the"
            " sensitivity table describes INFER and CONTRADICT relations only.",
            "Case consistency is descriptive and does not validate inference.",
            "Information totals are verbosity-sensitive; use normalized rates.",
            "A frozen multi-puzzle translator audit is required before research use.",
            "Relations are local to one field; cross-agent propagation, recovery,"
            " adoption, and causal influence are not measured.",
        ],
        "artifacts": [*artifacts, "summary.json", "README.md"],
    }
    (output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (output_dir / "README.md").write_text(_methodology(summary), encoding="utf-8")
    return {
        "output_dir": str(output_dir),
        "analysis_id": summary["analysis_id"],
        "condition_count": summary["condition_count"],
        "debate_count": summary["debate_count"],
        "field_count": summary["field_count"],
        "claim_count": summary["claim_count"],
        "case_count": summary["case_count"],
        "relation_count": summary["relation_count"],
        "artifacts": summary["artifacts"],
    }
