"""Compact, non-JSON claim translation for formal-logic evaluation."""

from __future__ import annotations

import asyncio
import itertools
import json
import re
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from controlmad.harness.config import ModelConfig
from controlmad.harness.models import ModelClient, model_client_for_config

from .formal_logic_gold import load_gold_cases


ROLES = {"knight", "knave", "spy"}
TOKEN = re.compile(r"[A-Za-z_][A-Za-z0-9_-]*|\d+|[(),;]")


class CompactParseError(ValueError):
    pass


class _Parser:
    def __init__(self, text: str):
        self.tokens = TOKEN.findall(text)
        compact = "".join(self.tokens)
        if re.sub(r"\s+", "", text) != compact:
            raise CompactParseError("claim contains unsupported characters")
        self.position = 0

    def pop(self, expected: str | None = None) -> str:
        if self.position >= len(self.tokens):
            raise CompactParseError("unexpected end of claim")
        value = self.tokens[self.position]
        self.position += 1
        if expected is not None and value != expected:
            raise CompactParseError("expected %s, found %s" % (expected, value))
        return value

    def expression(self) -> dict[str, Any] | None:
        name = self.pop().upper()
        if name == "ABSTAIN":
            return None
        self.pop("(")
        if name == "ROLE":
            player = self.player()
            self.pop(",")
            role = self.pop().lower()
            if role not in ROLES:
                raise CompactParseError("unknown role: %s" % role)
            result: dict[str, Any] = {"op": "role_is", "player": player, "role": role}
        elif name == "STMT_TRUE":
            result = {"op": "statement_true", "player": self.player()}
        elif name == "SAME_ROLE":
            left = self.player()
            self.pop(",")
            result = {"op": "same_role", "players": [left, self.player()]}
        elif name == "NOT":
            result = {"op": "not", "arg": self.expression()}
            if result["arg"] is None:
                raise CompactParseError("NOT cannot contain ABSTAIN")
        elif name in {"AND", "OR", "XOR", "IFF", "IMPLIES"}:
            values = [self.expression()]
            while self.tokens[self.position] in {";", ","}:
                self.pop()
                values.append(self.expression())
            if len(values) < 2 or any(value is None for value in values):
                raise CompactParseError(
                    "compound expressions require at least two non-ABSTAIN claims"
                )
            if name == "IMPLIES" and len(values) != 2:
                raise CompactParseError("IMPLIES requires exactly two claims")
            result = values[0]
            for value in values[1:]:
                result = {"op": name.lower(), "left": result, "right": value}
        elif name == "PARITY":
            parity = self.pop().lower()
            if parity not in {"even", "odd"}:
                raise CompactParseError("unknown parity: %s" % parity)
            self.pop(",")
            role = self.pop().lower()
            if role not in ROLES:
                raise CompactParseError("unknown parity role: %s" % role)
            players = []
            while self.tokens[self.position] != ")":
                self.pop(",")
                players.append(self.player())
            result = {"op": "parity", "players": players, "role": role, "parity": parity}
        elif name == "COUNT":
            comparison = self.pop().lower()
            if comparison == "at" and self.position < len(self.tokens):
                qualifier = self.pop().lower()
                if qualifier not in {"least", "most"}:
                    raise CompactParseError(
                        "unknown count comparison: at %s" % qualifier
                    )
                comparison = "at_%s" % qualifier
            comparison = {"atleast": "at_least", "atmost": "at_most"}.get(comparison, comparison)
            if comparison not in {"exactly", "at_least", "at_most"}:
                raise CompactParseError("unknown count comparison: %s" % comparison)
            self.pop(",")
            count = int(self.pop())
            self.pop(",")
            role = self.pop().lower()
            if role not in ROLES:
                raise CompactParseError("unknown count role: %s" % role)
            players = []
            while self.tokens[self.position] != ")":
                self.pop(",")
                players.append(self.player())
            result = {
                "op": "count_role",
                "players": players,
                "role": role,
                "comparison": comparison,
                "count": count,
            }
        else:
            raise CompactParseError("unknown claim operator: %s" % name)
        self.pop(")")
        return result

    def player(self) -> int:
        player = self.pop().upper()
        if len(player) != 1 or not "A" <= player <= "Z":
            raise CompactParseError("unknown player: %s" % player)
        return ord(player) - ord("A")


def parse_compact_expression(text: str) -> dict[str, Any] | None:
    parser = _Parser(text.strip())
    try:
        value = parser.expression()
    except IndexError as exc:
        raise CompactParseError("unexpected end of claim") from exc
    if parser.position != len(parser.tokens):
        raise CompactParseError("unexpected trailing claim tokens")
    return value


def format_compact_expression(expression: Any) -> str:
    """Render a compact expression AST in the model-facing line syntax."""
    if expression is None:
        return "ABSTAIN"
    if not isinstance(expression, Mapping):
        return str(expression)
    op = str(expression.get("op"))
    player_name = lambda value: chr(ord("A") + int(value))
    if op == "role_is":
        return "ROLE(%s,%s)" % (
            player_name(expression["player"]), expression["role"]
        )
    if op == "statement_true":
        return "STMT_TRUE(%s)" % player_name(expression["player"])
    if op == "same_role":
        return "SAME_ROLE(%s)" % ",".join(
            player_name(value) for value in expression["players"]
        )
    if op == "not":
        return "NOT(%s)" % format_compact_expression(expression["arg"])
    if op in {"and", "or", "xor", "iff", "implies"}:
        return "%s(%s;%s)" % (
            op.upper(),
            format_compact_expression(expression["left"]),
            format_compact_expression(expression["right"]),
        )
    if op == "count_role":
        values = [
            expression["comparison"],
            expression["count"],
            expression["role"],
            *(player_name(value) for value in expression["players"]),
        ]
        return "COUNT(%s)" % ",".join(map(str, values))
    if op == "parity":
        values = [
            expression["parity"],
            expression["role"],
            *(player_name(value) for value in expression["players"]),
        ]
        return "PARITY(%s)" % ",".join(map(str, values))
    raise ValueError("unknown compact expression operator: %s" % op)


def parse_compact_batch(content: str, expected_ids: Sequence[str]) -> dict[str, Any]:
    parsed, errors = parse_compact_batch_partial(content, expected_ids)
    if errors:
        first = sorted(errors)[0]
        raise CompactParseError("%s: %s" % (first, errors[first]))
    return parsed


def parse_compact_batch_partial(
    content: str, expected_ids: Sequence[str]
) -> tuple[dict[str, Any], dict[str, str]]:
    expected = set(expected_ids)
    output: dict[str, Any] = {}
    errors: dict[str, str] = {}
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("```"):
            continue
        if "=" not in line:
            errors["__unassigned__"] = "expected '<id> = <claim>': %s" % line
            continue
        case_id, expression = (part.strip() for part in line.split("=", 1))
        if case_id not in expected:
            errors[case_id] = "unexpected case id"
            continue
        if case_id in output:
            errors[case_id] = "duplicate case id"
            continue
        try:
            output[case_id] = parse_compact_expression(expression)
        except CompactParseError as exc:
            errors[case_id] = str(exc)
    missing = expected - set(output)
    for case_id in missing:
        errors.setdefault(case_id, "missing case id")
    return output, errors


def expression_contains(actual: Any, expected: Any) -> bool:
    """Return whether a conjunction explicitly asserts a gold claim.

    A conjunction asserts each conjunct. A disjunction does not assert either
    disjunct independently, so descending through OR would over-credit weaker
    translations such as ``OR(A,D)`` for gold ``A``.
    """
    if expressions_equivalent(actual, expected):
        return True
    if not isinstance(actual, dict) or actual.get("op") != "and":
        return False
    return expression_contains(actual["left"], expected) or expression_contains(
        actual["right"], expected
    )


def expressions_equivalent(actual: Any, expected: Any) -> bool:
    """Return faithful semantic equivalence under the compact language's rules.

    Every referenced player has exactly one of the three roles, while statement-
    truth atoms remain independent.  The puzzle-specific exactly-one-spy rule is
    intentionally *not* imposed: translation scoring must not turn an explicitly
    stated global count into a tautology merely because the puzzle also supplies
    that rule. Expressions must also concern the same role and statement-truth
    subjects. Tautologies and contradictions require structural identity because
    their truth tables otherwise erase what the source proposition was about.
    """
    if expression_counterexample(actual, expected) is not None:
        return False
    if not isinstance(actual, dict) or not isinstance(expected, dict):
        return actual is expected
    if _semantic_subject(actual) != _semantic_subject(expected):
        return False
    actual_constant, _ = _constant_value(actual)
    expected_constant, _ = _constant_value(expected)
    if actual_constant or expected_constant:
        return _canonical(actual) == _canonical(expected)
    return True


def expression_counterexample(actual: Any, expected: Any) -> dict[str, Any] | None:
    """Return a typed valuation that distinguishes two expressions, if one exists."""
    if actual is None or expected is None:
        return None if actual is expected else {"actual": actual, "expected": expected}
    if not isinstance(actual, dict) or not isinstance(expected, dict):
        return None if _canonical(actual) == _canonical(expected) else {
            "actual": actual,
            "expected": expected,
        }
    players = sorted(_expression_players(actual) | _expression_players(expected))
    statements = sorted(
        _statement_truth_players(actual) | _statement_truth_players(expected)
    )
    for role_values in itertools.product(sorted(ROLES), repeat=len(players)):
        roles = dict(zip(players, role_values, strict=True))
        for truth_values in itertools.product((False, True), repeat=len(statements)):
            truths = dict(zip(statements, truth_values, strict=True))
            actual_value = _evaluate_typed(actual, roles, truths)
            expected_value = _evaluate_typed(expected, roles, truths)
            if actual_value != expected_value:
                return {
                    "roles": roles,
                    "statement_truth": truths,
                    "actual": actual_value,
                    "expected": expected_value,
                }
    return None


def _expression_players(expression: Mapping[str, Any]) -> set[int]:
    op = expression["op"]
    if op == "role_is":
        return {int(expression["player"])}
    if op in {"same_role", "count_role", "parity"}:
        return set(map(int, expression["players"]))
    if op == "statement_true":
        return set()
    if op == "not":
        return _expression_players(expression["arg"])
    if op in {"and", "or", "xor", "iff", "implies"}:
        return _expression_players(expression["left"]) | _expression_players(
            expression["right"]
        )
    raise ValueError("unknown compact expression operator: %s" % op)


def _statement_truth_players(expression: Mapping[str, Any]) -> set[int]:
    op = expression["op"]
    if op == "statement_true":
        return {int(expression["player"])}
    if op == "not":
        return _statement_truth_players(expression["arg"])
    if op in {"and", "or", "xor", "iff", "implies"}:
        return _statement_truth_players(
            expression["left"]
        ) | _statement_truth_players(expression["right"])
    return set()


def _semantic_subject(
    expression: Mapping[str, Any],
) -> tuple[frozenset[int], frozenset[int]]:
    """Return role-variable and statement-truth subjects without puzzle axioms."""
    return (
        frozenset(_expression_players(expression)),
        frozenset(_statement_truth_players(expression)),
    )


def _constant_value(expression: Mapping[str, Any]) -> tuple[bool, bool | None]:
    """Return whether an expression is constant and, if so, its Boolean value."""
    players = sorted(_expression_players(expression))
    statements = sorted(_statement_truth_players(expression))
    first: bool | None = None
    for role_values in itertools.product(sorted(ROLES), repeat=len(players)):
        roles = dict(zip(players, role_values, strict=True))
        for truth_values in itertools.product((False, True), repeat=len(statements)):
            truths = dict(zip(statements, truth_values, strict=True))
            value = _evaluate_typed(expression, roles, truths)
            if first is None:
                first = value
            elif value != first:
                return False, None
    return True, first


def _evaluate_typed(
    expression: Mapping[str, Any],
    roles: Mapping[int, str],
    statement_truth: Mapping[int, bool],
) -> bool:
    op = expression["op"]
    if op == "role_is":
        return roles[int(expression["player"])] == expression["role"]
    if op == "statement_true":
        return statement_truth[int(expression["player"])]
    if op == "same_role":
        left, right = map(int, expression["players"])
        return roles[left] == roles[right]
    if op in {"count_role", "parity"}:
        count = sum(
            roles[int(player)] == expression["role"]
            for player in expression["players"]
        )
        if op == "parity":
            return count % 2 == (0 if expression["parity"] == "even" else 1)
        target = int(expression["count"])
        return {
            "exactly": count == target,
            "at_least": count >= target,
            "at_most": count <= target,
        }[expression["comparison"]]
    if op == "not":
        return not _evaluate_typed(expression["arg"], roles, statement_truth)
    left = _evaluate_typed(expression["left"], roles, statement_truth)
    right = _evaluate_typed(expression["right"], roles, statement_truth)
    if op == "and":
        return left and right
    if op == "or":
        return left or right
    if op == "xor":
        return left != right
    if op == "iff":
        return left == right
    if op == "implies":
        return not left or right
    raise ValueError("unknown compact expression operator: %s" % op)


def _and_expressions(expressions: Sequence[Mapping[str, Any]]) -> Mapping[str, Any] | None:
    combined: Mapping[str, Any] | None = None
    for expression in expressions:
        combined = (
            expression
            if combined is None
            else {"op": "and", "left": combined, "right": expression}
        )
    return combined


def expressions_satisfiable(expressions: Sequence[Mapping[str, Any]]) -> bool:
    """Return whether typed role/truth assignments can satisfy all expressions."""
    combined = _and_expressions(expressions)
    if combined is None:
        return True
    constant, value = _constant_value(combined)
    return not (constant and value is False)


def expressions_entail(
    premises: Sequence[Mapping[str, Any]], conclusion: Mapping[str, Any]
) -> bool:
    """Return entailment under compact typed semantics without puzzle axioms."""
    if not expressions_satisfiable(premises):
        return False
    counterexample = [*premises, {"op": "not", "arg": conclusion}]
    return not expressions_satisfiable(counterexample)


def compact_prompt(cases: Sequence[Mapping[str, Any]]) -> str:
    items = "\n".join("%s: %s" % (case["id"], case["source_span"]) for case in cases)
    return """Translate each isolated KKS claim into the compact claim language below.

Players: A, B, C, D. Roles: knight, knave, spy.

Grammar:
  ROLE(A,knight)
  STMT_TRUE(D)
  NOT(ROLE(D,knight))
  NOT(STMT_TRUE(C))
  AND(ROLE(C,knave);ROLE(D,spy))
  OR(ROLE(D,spy);ROLE(D,knave))
  COUNT(exactly,1,spy,A,B,C,D)
  ABSTAIN

Translate what the source literally claims, even when the claim is logically wrong.
Preserve every negation. Use ABSTAIN when the meaning cannot be represented faithfully.
This evaluation measures only the embedded proposition, not attribution or stance.

Return exactly one plain-text line per case in the original order:
<id> = <compact claim>

Do not return JSON, Markdown, explanations, confidence, or additional text.

Cases:
%s""" % items


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


async def evaluate_compact_translator(
    gold_path: Path,
    model_config: Path,
    output_path: Path,
    *,
    batch_size: int = 10,
    concurrency: int = 5,
    timeout_seconds: float = 300,
    model_client: ModelClient | None = None,
) -> dict[str, Any]:
    if batch_size < 1 or concurrency < 1:
        raise ValueError("batch_size and concurrency must be positive")
    cases = load_gold_cases(gold_path)
    model = ModelConfig(**(yaml.safe_load(model_config.read_text(encoding="utf-8")) or {}))
    client = model_client or model_client_for_config(model)
    batches = [cases[index:index + batch_size] for index in range(0, len(cases), batch_size)]
    semaphore = asyncio.Semaphore(concurrency)
    started = time.monotonic()

    async def run_batch(index: int, batch: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
        async with semaphore:
            response = await client.complete(
                model,
                [
                    {
                        "role": "system",
                        "content": (
                            "You are a literal claim translator. Preserve polarity exactly "
                            "and follow the compact output grammar without commentary."
                        ),
                    },
                    {"role": "user", "content": compact_prompt(batch)},
                ],
                timeout_seconds,
            )
        parsed, errors = parse_compact_batch_partial(
            response.content, [str(case["id"]) for case in batch]
        )
        return {
            "batch_index": index,
            "case_ids": [case["id"] for case in batch],
            "content": response.content,
            "parsed": parsed,
            "parse_errors": errors,
            "usage": response.usage,
            "model": response.model,
        }

    batch_results = await asyncio.gather(*(
        run_batch(index, batch) for index, batch in enumerate(batches, start=1)
    ))
    predictions = {
        case_id: value
        for batch in batch_results
        for case_id, value in batch["parsed"].items()
    }
    rows = []
    for case in cases:
        actual = predictions.get(str(case["id"]), "__missing__")
        expected = case.get("expected_conclusion")
        exact = actual != "__missing__" and _canonical(actual) == _canonical(expected)
        contains = actual != "__missing__" and expression_contains(actual, expected)
        rows.append({
            "id": case["id"],
            "source_span": case["source_span"],
            "expected_conclusion": expected,
            "actual_conclusion": None if actual == "__missing__" else actual,
            "exact_match": exact,
            "contains_expected_claim": contains,
        })
    usage: dict[str, float] = {}
    for batch in batch_results:
        for key, value in batch["usage"].items():
            if isinstance(value, (int, float)):
                usage[key] = usage.get(key, 0.0) + float(value)
    passed_count = sum(bool(row["exact_match"]) for row in rows)
    contained_count = sum(bool(row["contains_expected_claim"]) for row in rows)
    report = {
        "model_config": str(model_config),
        "model": model.model,
        "reasoning_effort": model.params.get("reasoning_effort"),
        "format": "compact-claim-v1",
        "json_model_output": False,
        "case_count": len(cases),
        "passed_count": passed_count,
        "failed_count": len(cases) - passed_count,
        "conclusion_fidelity": passed_count / len(cases) if cases else None,
        "contained_claim_count": contained_count,
        "contained_claim_rate": contained_count / len(cases) if cases else None,
        "batch_count": len(batches),
        "batch_size": batch_size,
        "concurrency": concurrency,
        "wall_time_seconds": time.monotonic() - started,
        "usage": usage,
        "parse_error_count": sum(
            len(batch["parse_errors"]) for batch in batch_results
        ),
        "batches": batch_results,
        "rows": rows,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return report


def run_compact_evaluation(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return asyncio.run(evaluate_compact_translator(*args, **kwargs))


def rescore_compact_report(report_path: Path, gold_path: Path) -> dict[str, Any]:
    """Rescore stored raw batch responses without making new model calls."""
    report = json.loads(report_path.read_text(encoding="utf-8"))
    cases = load_gold_cases(gold_path)
    predictions: dict[str, Any] = {}
    parse_errors: dict[str, str] = {}
    for batch in report.get("batches", []):
        parsed, errors = parse_compact_batch_partial(
            str(batch.get("content", "")),
            [str(case_id) for case_id in batch.get("case_ids", [])],
        )
        batch["parsed"] = parsed
        batch["parse_errors"] = errors
        batch.pop("parse_error", None)
        predictions.update(parsed)
        parse_errors.update(errors)
    rows = []
    for case in cases:
        actual = predictions.get(str(case["id"]), "__missing__")
        expected = case.get("expected_conclusion")
        exact = actual != "__missing__" and _canonical(actual) == _canonical(expected)
        contains = actual != "__missing__" and expression_contains(actual, expected)
        rows.append({
            "id": case["id"],
            "source_span": case["source_span"],
            "expected_conclusion": expected,
            "actual_conclusion": None if actual == "__missing__" else actual,
            "exact_match": exact,
            "contains_expected_claim": contains,
        })
    exact_count = sum(bool(row["exact_match"]) for row in rows)
    contained_count = sum(bool(row["contains_expected_claim"]) for row in rows)
    report.update({
        "passed_count": exact_count,
        "failed_count": len(cases) - exact_count,
        "conclusion_fidelity": exact_count / len(cases) if cases else None,
        "contained_claim_count": contained_count,
        "contained_claim_rate": contained_count / len(cases) if cases else None,
        "parse_error_count": len(parse_errors),
        "rows": rows,
        "rescored_from_stored_responses": True,
    })
    report_path.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return report
