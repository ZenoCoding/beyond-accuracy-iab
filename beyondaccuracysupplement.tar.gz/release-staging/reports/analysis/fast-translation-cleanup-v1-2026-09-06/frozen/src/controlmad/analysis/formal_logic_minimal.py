"""Minimal claims, cases, and local reasoning relations for KKS debates."""

from __future__ import annotations

import asyncio
import json
import math
import re
import time
import unicodedata
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from controlmad.harness.config import ModelConfig
from controlmad.harness.models import ModelClient, model_client_for_config
from controlmad.harness.runner import config_from_resolved_dict
from controlmad.harness.storage import ExperimentStorage
from controlmad_replication.benchmarks.kks.dataset import dataset_sizes, read_jsonl
from controlmad_replication.benchmarks.kks.logic import (
    assignments,
    evaluate_expr,
    referenced_players,
    solve,
    statement_values,
)

from .core import completed_results
from .formal_logic import ReasoningSource, _load_question, extract_reasoning_sources
from .formal_logic_compact import (
    CompactParseError,
    expressions_equivalent,
    format_compact_expression,
    parse_compact_expression,
)
from .formal_logic_field_gold import evaluate_field_gold, load_field_gold
from .formal_logic_compact_fields import load_initial_manifest
from .prompt_templates import load_prompt, render_prompt


FORMAT_VERSION = "kks-minimal-relations-v2"
PROMPT_VERSION = "kks-minimal-relations-prompt-v5"
RELATION_PROMPT_VERSION = "kks-minimal-relation-pass-prompt-v2"
CLAIM_PROMPT_PROFILES = {
    "stable": ("minimal_claims_v5.md", PROMPT_VERSION),
    "explicit": ("minimal_claims.md", "kks-minimal-relations-prompt-v6"),
}
RELATION_PROMPT_PROFILES = {
    "v1": ("minimal_relations_v1.md", "kks-minimal-relation-pass-prompt-v1"),
    "explicit": ("minimal_relations.md", RELATION_PROMPT_VERSION),
}
STABLE_RELATION_PROMPT_VERSION = RELATION_PROMPT_PROFILES["v1"][1]
RELATION_KINDS = ("infer", "contradict", "reductio")
RELATION_VERDICTS = (
    "entailed",
    "contingent",
    "contradicted",
    "valid_contradiction",
    "not_contradictory",
    "valid_reductio",
    "inconsistent_premises",
    "uncheckable",
)
VALID_RELATION_VERDICTS = frozenset(
    {"entailed", "valid_contradiction", "valid_reductio"}
)
RELATION_BACKGROUNDS = ("thin", "referenced_roles", "referenced_all")
SYSTEM_PROMPT = load_prompt("minimal_system.md")
CLAIM_CASE_SYSTEM_PROMPT = load_prompt("minimal_claim_case_system.md")
CLAIM_ID = re.compile(r"c[1-9][0-9]*$")
CASE_ID = re.compile(r"h[1-9][0-9]*$")
RELATION_ID = re.compile(r"e[1-9][0-9]*$")
COMMITMENT = re.compile(
    r"(ASSERT|OPAQUE)"
    r"|(ASSUME|HYPOTHETICAL)\((h[1-9][0-9]*)\)"
    r"|(REPORT|ENDORSE|REJECT)\(((?:player|agent):[A-Za-z0-9_.-]+"
    r"(?:,(?:player|agent):[A-Za-z0-9_.-]+)*)\)$"
)
ATTRIBUTED_COMMITMENT = re.compile(
    r"ATTRIBUTED\((NEUTRAL|ENDORSE|REJECT);"
    r"((?:player|agent):[A-Za-z0-9_.-]+"
    r"(?:,(?:player|agent):[A-Za-z0-9_.-]+)*)\)$"
)
CASE = re.compile(r"CASE\((ACCEPTED|REJECTED|UNRESOLVED)\)$")
CLAIM_REFS = re.compile(r"(?:c[1-9][0-9]*)(?:,c[1-9][0-9]*)*$")

_COUNT_PARITY_SURFACE = re.compile(
    r"\bCOUNT\s*\(\s*(odd|even)\s*,\s*(knight|knave|spy)\s*"
    r"((?:,\s*[A-Z]\s*)+)\)",
    re.IGNORECASE,
)

_TYPOGRAPHIC_EQUIVALENTS = str.maketrans({
    "\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2013": "-",
    "\u2014": "-", "\u2015": "-", "\u2212": "-", "\ufe58": "-",
    "\ufe63": "-", "\uff0d": "-", "\u2018": "'", "\u2019": "'",
    "\u201c": '"', "\u201d": '"', "\u00a0": " ",
})


def _normalized_span_with_offsets(text: str) -> tuple[str, list[int]]:
    """Normalize harmless typography while retaining source offsets."""
    output: list[str] = []
    offsets: list[int] = []
    for index, char in enumerate(text):
        normalized = unicodedata.normalize("NFKC", char).translate(
            _TYPOGRAPHIC_EQUIVALENTS
        )
        output.extend(normalized)
        offsets.extend([index] * len(normalized))
    return "".join(output), offsets


def _canonical_source_span(span: str, source_text: str) -> str | None:
    """Return the unique exact source substring for a typography-only variant."""
    if span in source_text:
        return span
    normalized_source, offsets = _normalized_span_with_offsets(source_text)
    normalized_span, _ = _normalized_span_with_offsets(span)
    if not normalized_span:
        return None
    starts = [
        match.start()
        for match in re.finditer("(?=%s)" % re.escape(normalized_span), normalized_source)
    ]
    if len(starts) != 1:
        return None
    start = starts[0]
    end = start + len(normalized_span) - 1
    return source_text[offsets[start]:offsets[end] + 1]


def _minimal_covering_source_span(source_text: str, anchors: Sequence[str]) -> str | None:
    """Find the shortest exact source interval containing one copy of each anchor."""
    positions: list[list[tuple[int, int]]] = []
    for anchor in anchors:
        found = [
            (match.start(), match.start() + len(anchor))
            for match in re.finditer("(?=%s)" % re.escape(anchor), source_text)
        ]
        if not found:
            return None
        positions.append(found)
    choices: list[tuple[int, int]] = [(0, 0)]
    for found in positions:
        choices = [
            (min(start, item_start), max(end, item_end))
            for start, end in choices
            for item_start, item_end in found
        ]
    start, end = min(choices, key=lambda item: (item[1] - item[0], item[0]))
    return source_text[start:end]


def _normalize_count_parity_surface(
    expression_text: str,
) -> tuple[str, list[dict[str, str]]]:
    """Normalize only COUNT(parity,role,players...) into canonical PARITY."""
    normalizations: list[dict[str, str]] = []

    def replace(match: re.Match[str]) -> str:
        players = [
            item.strip().upper()
            for item in match.group(3).split(",")
            if item.strip()
        ]
        if not players or len(players) != len(set(players)):
            return match.group(0)
        parity = match.group(1).lower()
        role = match.group(2).lower()
        canonical = "PARITY(%s,%s,%s)" % (parity, role, ",".join(players))
        normalizations.append({
            "kind": "count_parity_to_parity",
            "original": match.group(0),
            "canonical": canonical,
        })
        return canonical

    normalized = _COUNT_PARITY_SURFACE.sub(replace, expression_text)
    return normalized, normalizations


def _parse_minimal_expression(
    expression_text: str,
) -> tuple[dict[str, Any] | None, str, list[dict[str, str]]]:
    """Parse strictly, then try the single deterministic surface recovery."""
    try:
        return parse_compact_expression(expression_text), expression_text, []
    except CompactParseError as original_error:
        normalized, normalizations = _normalize_count_parity_surface(expression_text)
        if not normalizations:
            raise original_error
        try:
            return parse_compact_expression(normalized), normalized, normalizations
        except CompactParseError:
            # Never partially recover a larger malformed expression.
            raise original_error


def _parse_commitment(text: str) -> tuple[str, str | None, list[str]]:
    # Model-facing attributed syntax keeps source and attitude in one family,
    # while the saved schema remains backward-compatible with the established
    # report/endorse/reject commitment values.
    if text.startswith("ATTRIBUTED(") and text.endswith(")"):
        prefix, body = text.split(";", 1) if ";" in text else (text, "")
        if body:
            body = body[:-1]
            targets = [
                "agent:" + target
                if re.fullmatch(r"agent-[A-Za-z0-9_.-]+", target)
                else target
                for target in body.split(",")
            ]
            text = "%s;%s)" % (prefix, ",".join(targets))
        attributed = ATTRIBUTED_COMMITMENT.fullmatch(text)
        if not attributed:
            raise ValueError("invalid commitment %r" % text)
        attributions = str(attributed.group(2)).split(",")
        if len(attributions) != len(set(attributions)):
            raise ValueError("duplicate attribution target")
        commitment = {
            "NEUTRAL": "report",
            "ENDORSE": "endorse",
            "REJECT": "reject",
        }[str(attributed.group(1))]
        return commitment, None, attributions
    # Repair a common mechanically recoverable namespace omission.  The
    # contract already disambiguates targets by their ``agent-`` spelling.
    if text.startswith(("REPORT(", "ENDORSE(", "REJECT(")) and text.endswith(")"):
        prefix, body = text.split("(", 1)
        targets = body[:-1].split(",")
        targets = [
            "agent:" + target if re.fullmatch(r"agent-[A-Za-z0-9_.-]+", target)
            else target
            for target in targets
        ]
        text = "%s(%s)" % (prefix, ",".join(targets))
    match = COMMITMENT.fullmatch(text)
    if not match:
        raise ValueError("invalid commitment %r" % text)
    if match.group(1):
        return match.group(1).lower(), None, []
    if match.group(2):
        return match.group(2).lower(), match.group(3), []
    attributions = str(match.group(5)).split(",")
    if len(attributions) != len(set(attributions)):
        raise ValueError("duplicate attribution target")
    return str(match.group(4)).lower(), None, attributions


def _parse_claim_refs(text: str, label: str) -> list[str]:
    prefix = "%s(" % label
    if not text.startswith(prefix) or not text.endswith(")"):
        raise ValueError("expected %s(c...)" % label)
    body = text[len(prefix):-1]
    if not CLAIM_REFS.fullmatch(body):
        raise ValueError("invalid %s claim list" % label)
    return body.split(",")


def _parse_single_ref(text: str, label: str, pattern: re.Pattern[str]) -> str:
    prefix = "%s(" % label
    if not text.startswith(prefix) or not text.endswith(")"):
        raise ValueError("expected %s(...)" % label)
    value = text[len(prefix):-1]
    if not pattern.fullmatch(value):
        raise ValueError("invalid %s reference" % label)
    return value


def parse_minimal_translation(
    content: str,
    source_text: str,
    *,
    deterministic_normalizations: list[dict[str, Any]] | None = None,
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[str],
]:
    """Parse claims, flat cases, and explicitly stated local relations.

    Claim lines:
    ``c1 :: ASSERT|ASSUME(h1)|... :: EXPRESSION :: exact source span``

    Case lines:
    ``h1 :: CASE(REJECTED|ACCEPTED|UNRESOLVED) :: exact source span``

    A malformed line does not invalidate later lines. Cases referenced by valid
    claims are retained as unresolved even when their explicit disposition line
    is missing or malformed.
    """
    claims: list[dict[str, Any]] = []
    relations: list[dict[str, Any]] = []
    explicit_cases: dict[str, dict[str, Any]] = {}
    referenced_cases: set[str] = set()
    seen_claims: set[str] = set()
    seen_relations: set[str] = set()
    errors: list[str] = []

    for line_number, raw in enumerate(content.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("```"):
            continue
        first = line.split(" :: ", 1)[0].strip()
        if CASE_ID.fullmatch(first):
            parts = [part.strip() for part in line.split(" :: ", 2)]
            if len(parts) != 3:
                errors.append(
                    "line %d: case lines require three ' :: '-separated fields"
                    % line_number
                )
                continue
            case_id, disposition_text, source_span = parts
            disposition_match = CASE.fullmatch(disposition_text)
            if not disposition_match:
                errors.append("line %d: invalid case disposition" % line_number)
                continue
            if case_id in explicit_cases:
                errors.append(
                    "line %d: duplicate case id %r" % (line_number, case_id)
                )
                continue
            source_span = _canonical_source_span(source_span, source_text)
            if source_span is None:
                errors.append("line %d: source span is not verbatim" % line_number)
                continue
            explicit_cases[case_id] = {
                "id": case_id,
                "disposition": disposition_match.group(1).lower(),
                "source_span": source_span,
                "explicit": True,
            }
            continue

        if RELATION_ID.fullmatch(first):
            parts = [part.strip() for part in line.split(" :: ")]
            relation_id = parts[0]
            if relation_id in seen_relations:
                errors.append(
                    "line %d: duplicate relation id %r" % (line_number, relation_id)
                )
                continue
            try:
                kind = parts[1].lower()
                if kind == "infer" and len(parts) == 5:
                    relation = {
                        "id": relation_id,
                        "kind": kind,
                        "from": _parse_claim_refs(parts[2], "FROM"),
                        "to": _parse_single_ref(parts[3], "TO", CLAIM_ID),
                        "source_span": parts[4],
                    }
                elif kind == "contradict" and len(parts) == 4:
                    relation = {
                        "id": relation_id,
                        "kind": kind,
                        "from": _parse_claim_refs(parts[2], "FROM"),
                        "source_span": parts[3],
                    }
                elif kind == "reductio" and len(parts) == 6:
                    relation = {
                        "id": relation_id,
                        "kind": kind,
                        "assume": _parse_single_ref(parts[2], "ASSUME", CLAIM_ID),
                        "via": _parse_single_ref(parts[3], "VIA", RELATION_ID),
                        "to": _parse_single_ref(parts[4], "TO", CLAIM_ID),
                        "source_span": parts[5],
                    }
                else:
                    raise ValueError("invalid relation shape")
            except (IndexError, ValueError) as exc:
                errors.append("line %d: %s" % (line_number, exc))
                continue
            canonical_span = _canonical_source_span(
                str(relation["source_span"]), source_text
            )
            if canonical_span is None:
                errors.append("line %d: relation source span is not verbatim" % line_number)
                continue
            relation["source_span"] = canonical_span
            relations.append(relation)
            seen_relations.add(relation_id)
            continue

        parts = [part.strip() for part in line.split(" :: ", 3)]
        if len(parts) != 4:
            errors.append(
                "line %d: claim lines require four ' :: '-separated fields"
                % line_number
            )
            continue
        claim_id, commitment_text, expression_text, source_span = parts
        if not CLAIM_ID.fullmatch(claim_id) or claim_id in seen_claims:
            errors.append(
                "line %d: invalid or duplicate claim id %r"
                % (line_number, claim_id)
            )
            continue
        try:
            commitment, case_id, attributions = _parse_commitment(commitment_text)
        except ValueError as exc:
            errors.append("line %d: %s" % (line_number, exc))
            continue
        source_span = _canonical_source_span(source_span, source_text)
        if source_span is None:
            errors.append("line %d: source span is not verbatim" % line_number)
            continue
        try:
            expression, normalized_expression, expression_normalizations = (
                _parse_minimal_expression(expression_text)
            )
        except CompactParseError as exc:
            errors.append("line %d: %s" % (line_number, exc))
            continue
        if commitment == "opaque" and expression is not None:
            errors.append(
                "line %d: OPAQUE commitment requires ABSTAIN expression"
                % line_number
            )
            continue
        if (
            commitment not in {"opaque", "report", "assume", "hypothetical"}
            and expression is None
        ):
            errors.append(
                "line %d: ABSTAIN expression is not valid for this commitment"
                % line_number
            )
            continue
        claim = {
            "id": claim_id,
            "commitment": commitment,
            "case_id": case_id,
            "attributions": attributions,
            "expression": expression,
            "source_span": source_span,
        }
        claims.append(claim)
        seen_claims.add(claim_id)
        if expression_normalizations and deterministic_normalizations is not None:
            deterministic_normalizations.append({
                "kind": "count_parity_to_parity",
                "line_number": line_number,
                "claim_id": claim_id,
                "original_expression": expression_text,
                "normalized_expression": normalized_expression,
                "source_span": source_span,
                "replacements": expression_normalizations,
            })
        if case_id:
            referenced_cases.add(case_id)

    cases = []
    for case_id in sorted(referenced_cases | set(explicit_cases)):
        cases.append(
            explicit_cases.get(
                case_id,
                {
                    "id": case_id,
                    "disposition": "unresolved",
                    "source_span": None,
                    "explicit": False,
                },
            )
        )
    claim_by_id = {claim["id"]: claim for claim in claims}
    relation_by_id = {relation["id"]: relation for relation in relations}
    for relation in relations:
        if relation["kind"] == "reductio":
            claim_refs = [relation["assume"], relation["to"]]
            relation_refs = [relation["via"]]
        else:
            claim_refs = list(relation["from"])
            if relation["kind"] == "infer":
                claim_refs.append(relation["to"])
            relation_refs = []
        anchors = [str(relation["source_span"])]
        anchors.extend(
            str(claim_by_id[claim_id]["source_span"])
            for claim_id in claim_refs
            if claim_id in claim_by_id
        )
        anchors.extend(
            str(relation_by_id[relation_id]["source_span"])
            for relation_id in relation_refs
            if relation_id in relation_by_id
        )
        if any(anchor not in relation["source_span"] for anchor in anchors[1:]):
            expanded = _minimal_covering_source_span(source_text, anchors)
            if expanded is not None:
                relation["source_span"] = expanded
        for claim_id in claim_refs:
            claim = claim_by_id.get(claim_id)
            if claim is None:
                errors.append("%s: missing claim reference %s" % (relation["id"], claim_id))
            elif claim["source_span"] not in relation["source_span"]:
                errors.append(
                    "%s: relation span does not contain %s source span"
                    % (relation["id"], claim_id)
                )
        for relation_id in relation_refs:
            prior = relation_by_id.get(relation_id)
            if prior is None:
                errors.append(
                    "%s: missing relation reference %s" % (relation["id"], relation_id)
                )
            elif prior["source_span"] not in relation["source_span"]:
                errors.append(
                    "%s: relation span does not contain %s source span"
                    % (relation["id"], relation_id)
                )
    return claims, cases, relations, errors


def minimal_claim_prompt(
    question: Mapping[str, Any],
    source: ReasoningSource,
    debate_agent_ids: Sequence[str] = (),
    profile: str = "stable",
) -> str:
    """Build the compact claim and explicit-discourse translation prompt."""
    if profile not in CLAIM_PROMPT_PROFILES:
        raise ValueError("unknown claim prompt profile %r" % profile)
    statements = [
        "%s :: %s :: %s" % (
            item["speaker"],
            item["text"],
            format_compact_expression(item["ast"]),
        )
        for item in question["statements"]
    ]
    location = ", ".join(
        "%s=%s" % item for item in sorted(source.location.items())
    )
    submitted = ", ".join(
        "%s=%s" % item for item in sorted(source.submitted_roles.items())
    ) or "none"
    return render_prompt(
        CLAIM_PROMPT_PROFILES[profile][0],
        statements="\n".join(statements),
        location=location,
        debate_agents=", ".join(debate_agent_ids) or "not supplied",
        submitted=submitted,
        source_text=source.text,
    )


def minimal_claim_case_prompt(
    question: Mapping[str, Any],
    source: ReasoningSource,
    debate_agent_ids: Sequence[str] = (),
    profile: str = "stable",
) -> str:
    """Build stage 1 of the two-stage translator: claims and cases only.

    This intentionally reuses the mature inventory prompt. The final override is
    narrow and machine-checkable; any relation lines a model nevertheless emits
    are discarded before stage 2.
    """
    prompt = minimal_claim_prompt(question, source, debate_agent_ids, profile)
    terminal = "Return only claim, case, and relation lines, without Markdown or explanation."
    return prompt.replace(terminal, load_prompt("minimal_claim_case_override.md"))


def _format_claim_for_relation_prompt(
    claim: Mapping[str, Any], *, attributed_syntax: bool = True
) -> str:
    commitment = str(claim["commitment"])
    if commitment in {"assume", "hypothetical"}:
        commitment_text = "%s(%s)" % (
            commitment.upper(), claim["case_id"]
        )
    elif commitment in {"report", "endorse", "reject"}:
        targets = ",".join(claim.get("attributions") or [])
        if attributed_syntax:
            attitude = {
                "report": "NEUTRAL", "endorse": "ENDORSE", "reject": "REJECT"
            }[commitment]
            commitment_text = "ATTRIBUTED(%s;%s)" % (attitude, targets)
        else:
            commitment_text = "%s(%s)" % (commitment.upper(), targets)
    else:
        commitment_text = commitment.upper()
    expression = (
        format_compact_expression(claim["expression"])
        if claim.get("expression") is not None
        else "ABSTAIN"
    )
    return "%s :: %s :: %s :: %s" % (
        claim["id"], commitment_text, expression, claim["source_span"]
    )


def _format_fixed_claim_case_output(
    claims: Sequence[Mapping[str, Any]], cases: Sequence[Mapping[str, Any]]
) -> str:
    """Serialize the immutable stage-1 artifact without any model-emitted edges."""
    lines = [_format_claim_for_relation_prompt(claim) for claim in claims]
    lines.extend(
        "%s :: CASE(%s) :: %s" % (
            case["id"], str(case["disposition"]).upper(), case["source_span"]
        )
        for case in cases
        if case.get("explicit") and case.get("source_span")
    )
    return "\n".join(lines)


def _format_fixed_relation_output(
    relations: Sequence[Mapping[str, Any]],
) -> str:
    """Serialize only accepted relations for the combined saved artifact."""
    lines = []
    for relation in relations:
        kind = str(relation["kind"])
        if kind == "infer":
            body = "INFER :: FROM(%s) :: TO(%s)" % (
                ",".join(relation["from"]), relation["to"]
            )
        elif kind == "contradict":
            body = "CONTRADICT :: FROM(%s)" % ",".join(relation["from"])
        elif kind == "reductio":
            body = "REDUCTIO :: ASSUME(%s) :: VIA(%s) :: TO(%s)" % (
                relation["assume"], relation["via"], relation["to"]
            )
        else:
            raise ValueError("cannot serialize relation kind %r" % kind)
        lines.append("%s :: %s :: %s" % (
            relation["id"], body, relation["source_span"]
        ))
    return "\n".join(lines)


def minimal_relation_prompt(
    source_text: str,
    claims: Sequence[Mapping[str, Any]],
    cases: Sequence[Mapping[str, Any]],
    profile: str = "v1",
) -> str:
    """Build stage 2 over an immutable claim and case inventory."""
    if profile not in RELATION_PROMPT_PROFILES:
        raise ValueError("unknown relation prompt profile %r" % profile)
    fixed_claims = "\n".join(
        _format_claim_for_relation_prompt(
            claim, attributed_syntax=profile != "v1"
        )
        for claim in claims
    ) or "(none)"
    fixed_cases = "\n".join(
        "%s :: CASE(%s)%s" % (
            case["id"],
            str(case["disposition"]).upper(),
            (" :: " + str(case["source_span"])) if case.get("source_span") else "",
        )
        for case in cases
    ) or "(none)"
    values = {
        "source_text": source_text,
        "fixed_claims": fixed_claims,
        "fixed_cases": fixed_cases,
        "fixed_inventory": "Claims:\n%s\n\nCases:\n%s" % (
            fixed_claims, fixed_cases
        ),
    }
    return render_prompt(RELATION_PROMPT_PROFILES[profile][0], **values)


def parse_minimal_relations(
    content: str,
    source_text: str,
    claims: Sequence[Mapping[str, Any]],
) -> tuple[list[dict[str, Any]], list[str]]:
    """Parse relation-only output while making claim mutation impossible."""
    if content.strip() == "NONE":
        return [], []
    errors: list[str] = []
    relation_lines: list[str] = []
    for line_number, raw in enumerate(content.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("```"):
            relation_lines.append("")
            continue
        if line == "NONE":
            errors.append(
                "line %d: NONE must be the entire relation response" % line_number
            )
            relation_lines.append("")
            continue
        first = line.split(" :: ", 1)[0].strip()
        if not RELATION_ID.fullmatch(first):
            errors.append(
                "line %d: relation pass permits only eN relation lines"
                % line_number
            )
            relation_lines.append("")
            continue
        relation_lines.append(line)
    fixed_claim_lines = [
        _format_claim_for_relation_prompt(claim) for claim in claims
    ]
    _, _, relations, parser_errors = parse_minimal_translation(
        "\n".join([*fixed_claim_lines, *relation_lines]), source_text
    )
    offset = len(fixed_claim_lines)
    for error in parser_errors:
        match = re.match(r"line ([1-9][0-9]*):(.*)", error)
        if match and int(match.group(1)) > offset:
            errors.append(
                "line %d:%s" % (int(match.group(1)) - offset, match.group(2))
            )
        elif not match:
            errors.append(error)
    return relations, errors


def minimal_relation_format_repair_prompt(
    source_text: str,
    claims: Sequence[Mapping[str, Any]],
    cases: Sequence[Mapping[str, Any]],
    raw_response: str,
    errors: Sequence[str],
) -> str:
    """Request syntax and reference repair for relation-only output."""
    return render_prompt(
        "minimal_relation_format_repair.md",
        relation_instructions=minimal_relation_prompt(source_text, claims, cases),
        raw_response=raw_response,
        errors="\n".join("- " + error for error in errors),
    )


def minimal_format_repair_prompt(
    source_text: str,
    raw_response: str,
    errors: Sequence[str],
) -> str:
    """Request parser-only repair without laundering semantic mistakes."""
    return render_prompt(
        "minimal_format_repair.md",
        source_text=source_text,
        raw_response=raw_response,
        errors="\n".join("- " + error for error in errors),
    )


def _format_repair_preserves_valid_items(
    initial: Sequence[Mapping[str, Any]],
    repaired: Sequence[Mapping[str, Any]],
    allowed_new_ids: set[str],
) -> bool:
    """Preserve valid items and add only IDs from parser-rejected lines."""
    initial_ids = {str(item["id"]) for item in initial}
    repaired_by_id = {str(item["id"]): item for item in repaired}
    preserved = all(
        repaired_by_id.get(str(item["id"])) == item
        for item in initial
    )
    added_ids = set(repaired_by_id) - initial_ids
    return preserved and added_ids <= allowed_new_ids


def _repairable_item_ids(raw_response: str, errors: Sequence[str]) -> set[str]:
    """Recover the leading item IDs of only those lines the parser rejected."""
    lines = raw_response.splitlines()
    output: set[str] = set()
    for error in errors:
        prefix = error.split(":", 1)[0]
        if re.fullmatch(r"[ceh][1-9][0-9]*", prefix):
            output.add(prefix)
            continue
        match = re.fullmatch(r"line ([1-9][0-9]*)", prefix)
        if not match:
            continue
        index = int(match.group(1)) - 1
        if index >= len(lines):
            continue
        item_id = lines[index].split("::", 1)[0].strip()
        if re.fullmatch(r"[ceh][1-9][0-9]*", item_id):
            output.add(item_id)
    return output


def _canonical_commitment(
    commitment: str | None,
    attributions: Sequence[Any],
    speaker_agent_id: str | None,
) -> str | None:
    """Treat a report attributed to the current speaker as an endorsement."""
    if (
        commitment in {"report", "endorse"}
        and speaker_agent_id
        and "agent:%s" % speaker_agent_id in set(map(str, attributions))
    ):
        return "endorse"
    return commitment


def _effective_commitment_expression(
    claim: Mapping[str, Any], speaker_agent_id: str | None = None
) -> Any:
    expression = claim.get("expression")
    if expression is None:
        return None
    # Neutral attribution quotes content; rejection records an attitude. Neither
    # licenses the proposition or its negation as a truth-bearing premise.
    commitment = _canonical_commitment(
        str(claim.get("commitment")),
        claim.get("attributions") or [],
        speaker_agent_id,
    )
    if commitment in {"report", "reject"}:
        return None
    return expression


def _truth_status(values: Sequence[bool]) -> str:
    if not values:
        return "uncheckable"
    if all(values):
        return "entailed"
    if not any(values):
        return "contradicted"
    return "contingent"


def _statement_truth_players(expression: Mapping[str, Any]) -> set[int]:
    op = expression["op"]
    if op == "statement_true":
        return {int(expression["player"])}
    if op == "not":
        return _statement_truth_players(expression["arg"])
    if op in {"and", "or", "xor", "iff", "implies"}:
        return _statement_truth_players(expression["left"]) | _statement_truth_players(
            expression["right"]
        )
    return set()


def _referenced_role_players(expression: Mapping[str, Any]) -> set[int]:
    """Players a claim names individually, excluding roster-wide aggregate atoms.

    `count_role` and `parity` range over a player list that is usually the whole
    roster. Fixing every listed player's truth-telling rule would shrink the world
    set to the puzzle's unique solution, which silently turns local validity into
    correctness, so those atoms contribute no players here.
    """
    op = expression["op"]
    if op in {"role_is", "statement_true"}:
        return {int(expression["player"])}
    if op == "same_role":
        return {int(player) for player in expression["players"]}
    if op == "not":
        return _referenced_role_players(expression["arg"])
    if op in {"and", "or", "xor", "iff", "implies"}:
        return _referenced_role_players(expression["left"]) | _referenced_role_players(
            expression["right"]
        )
    return set()


BACKGROUND_PLAYERS = {
    "thin": _statement_truth_players,
    "referenced_roles": _referenced_role_players,
    "referenced_all": referenced_players,
}


def _local_worlds(
    statements: Sequence[Mapping[str, Any]],
    expressions: Sequence[Mapping[str, Any]],
    background: str = "thin",
) -> list[tuple[str, ...]]:
    """Apply disclosed KKS rules to the players the background policy fixes.

    `thin` fixes only players whose STMT_TRUE atom appears in the cited claims.
    `referenced_roles` also fixes players named individually. `referenced_all`
    additionally fixes every player listed by an aggregate atom, which collapses
    to the puzzle solution whenever a relation cites a roster-wide count.
    """
    if background not in BACKGROUND_PLAYERS:
        raise ValueError("unknown relation background: %r" % background)
    select_players = BACKGROUND_PLAYERS[background]
    truth_players: set[int] = set()
    for expression in expressions:
        truth_players.update(select_players(expression))
    worlds = []
    for world in assignments(len(statements)):
        values = statement_values(statements, world)
        if all(
            world[player] == "spy"
            or (world[player] == "knight") == values[player]
            for player in truth_players
        ):
            worlds.append(world)
    return worlds


def _relation_row(
    relation_id: str,
    kind: str,
    verdict: str,
    *,
    background: str,
    reason: str | None = None,
    counterexample_count: int | None = None,
    source_span: Any = None,
    case_context_ids: Sequence[str] | None = None,
    uses_mixed_scope: bool = False,
    local_world_count: int | None = None,
    premise_world_count: int | None = None,
) -> dict[str, Any]:
    """Build a relation row with the full key set on every code path.

    Every return site shares this constructor so downstream CSV writers see a
    stable column order and can tell a missing world count from a false flag.
    """
    return {
        "id": relation_id,
        "kind": kind,
        "verdict": verdict,
        "reason": reason,
        "counterexample_count": counterexample_count,
        "source_span": source_span,
        "case_context_ids": list(case_context_ids or []),
        "uses_mixed_scope": uses_mixed_scope,
        "local_world_count": local_world_count,
        "premise_world_count": premise_world_count,
        "background": background,
    }


def check_minimal_relations(
    claims: Sequence[Mapping[str, Any]],
    cases: Sequence[Mapping[str, Any]],
    relations: Sequence[Mapping[str, Any]],
    statements: Sequence[Mapping[str, Any]],
    speaker_agent_id: str | None = None,
    *,
    background: str = "thin",
) -> list[dict[str, Any]]:
    """Check each relation locally without importing the solved puzzle."""
    if background not in BACKGROUND_PLAYERS:
        raise ValueError("unknown relation background: %r" % background)
    claim_by_id = {str(claim["id"]): claim for claim in claims}
    case_by_id = {str(case["id"]): case for case in cases}
    relation_by_id = {str(relation["id"]): relation for relation in relations}
    row_by_id: dict[str, dict[str, Any]] = {}
    visiting: set[str] = set()

    def expressions_for(ids: Sequence[str]) -> list[Mapping[str, Any]] | None:
        output = []
        for claim_id in ids:
            claim = claim_by_id.get(claim_id)
            expression = _effective_commitment_expression(
                claim or {}, speaker_agent_id
            )
            if expression is None:
                return None
            output.append(expression)
        return output

    def evaluate_relation(relation_id: str) -> dict[str, Any]:
        if relation_id in row_by_id:
            return row_by_id[relation_id]
        relation = relation_by_id.get(relation_id)
        if relation is None:
            return _relation_row(
                relation_id,
                "missing",
                "uncheckable",
                background=background,
                reason="missing_reference",
            )
        if relation_id in visiting:
            return _relation_row(
                relation_id,
                str(relation["kind"]),
                "uncheckable",
                background=background,
                reason="cyclic_relation_reference",
                source_span=relation.get("source_span"),
            )
        visiting.add(relation_id)
        relation_id = str(relation["id"])
        kind = str(relation["kind"])
        verdict = "uncheckable"
        reason: str | None = None
        counterexample_count: int | None = None
        case_context_ids: list[str] = []
        uses_mixed_scope = False
        local_world_count: int | None = None
        premise_world_count: int | None = None
        if kind in {"infer", "contradict"}:
            premise_ids = [str(value) for value in relation.get("from") or []]
            premise_exprs = expressions_for(premise_ids)
            uses_unasserted_content = any(
                _canonical_commitment(
                    str(claim_by_id.get(claim_id, {}).get("commitment")),
                    claim_by_id.get(claim_id, {}).get("attributions") or [],
                    speaker_agent_id,
                ) in {"report", "reject"}
                for claim_id in premise_ids
            )
            scoped_ids = [
                *premise_ids,
                *(
                    [str(relation["to"])]
                    if kind == "infer" and relation.get("to")
                    else []
                ),
            ]
            case_ids = {
                str(claim_by_id[claim_id]["case_id"])
                for claim_id in scoped_ids
                if claim_id in claim_by_id
                and claim_by_id[claim_id].get("case_id") is not None
            }
            case_context_ids = sorted(case_ids)
            uses_mixed_scope = bool(case_ids) and any(
                claim_id in claim_by_id
                and claim_by_id[claim_id].get("case_id") is None
                and claim_by_id[claim_id].get("commitment") != "report"
                for claim_id in scoped_ids
            )
            conclusion = (
                expressions_for([str(relation["to"])])
                if kind == "infer" and relation.get("to")
                else []
            )
            if len(case_ids) > 1 or uses_mixed_scope:
                reason = "mixed_case_scope"
            elif uses_unasserted_content:
                reason = "uses_unasserted_content"
            elif premise_exprs is None or conclusion is None:
                reason = "missing_or_opaque_claim"
            else:
                if case_ids:
                    case_id = next(iter(case_ids))
                    case_assumptions = [
                        claim
                        for claim in claims
                        if str(claim.get("case_id")) == case_id
                        and claim.get("commitment") == "assume"
                    ]
                    assumption_exprs = [
                        _effective_commitment_expression(claim, speaker_agent_id)
                        for claim in case_assumptions
                    ]
                    if any(expr is None for expr in assumption_exprs):
                        reason = "missing_or_opaque_case_assumption"
                    else:
                        premise_exprs = [*assumption_exprs, *premise_exprs]
                if reason is not None:
                    row = _relation_row(
                        relation_id,
                        kind,
                        verdict,
                        background=background,
                        reason=reason,
                        counterexample_count=counterexample_count,
                        source_span=relation.get("source_span"),
                        case_context_ids=case_context_ids,
                        uses_mixed_scope=uses_mixed_scope,
                    )
                    row_by_id[relation_id] = row
                    visiting.remove(relation_id)
                    return row
                all_exprs = [*premise_exprs, *conclusion]
                worlds = _local_worlds(statements, all_exprs, background)
                local_world_count = len(worlds)
                premise_worlds = [
                    world
                    for world in worlds
                    if all(evaluate_expr(expr, world, statements) for expr in premise_exprs)
                ]
                premise_world_count = len(premise_worlds)
                if kind == "contradict":
                    verdict = (
                        "valid_contradiction" if not premise_worlds else "not_contradictory"
                    )
                    counterexample_count = len(premise_worlds)
                elif not premise_worlds:
                    verdict = "inconsistent_premises"
                    reason = "explosion_disabled"
                    counterexample_count = 0
                else:
                    values = [
                        evaluate_expr(conclusion[0], world, statements)
                        for world in premise_worlds
                    ]
                    verdict = _truth_status(values)
                    counterexample_count = sum(value is False for value in values)
        elif kind == "reductio":
            assumption = claim_by_id.get(str(relation.get("assume")))
            conclusion = claim_by_id.get(str(relation.get("to")))
            via = relation_by_id.get(str(relation.get("via")))
            via_row = evaluate_relation(str(relation.get("via")))
            if not assumption or not conclusion or not via or not via_row:
                reason = "missing_reference"
            elif assumption.get("commitment") != "assume" or not assumption.get("case_id"):
                reason = "assumption_claim_required"
            elif via.get("kind") != "contradict" or via_row["verdict"] != "valid_contradiction":
                reason = "invalid_contradiction"
            elif assumption["id"] not in (via.get("from") or []):
                reason = "contradiction_does_not_use_assumption"
            elif any(
                claim_by_id.get(str(claim_id), {}).get("case_id")
                not in {None, assumption.get("case_id")}
                for claim_id in via.get("from") or []
            ):
                reason = "mixed_case_scope"
            elif case_by_id.get(str(assumption["case_id"]), {}).get("disposition") != "rejected":
                reason = "case_not_rejected"
            elif assumption.get("expression") is None or conclusion.get("expression") is None:
                reason = "missing_or_opaque_claim"
            elif not expressions_equivalent(
                conclusion["expression"],
                {"op": "not", "arg": assumption["expression"]},
            ):
                reason = "conclusion_too_strong"
            else:
                verdict = "valid_reductio"
        else:
            reason = "unknown_relation_kind"
        row = _relation_row(
            relation_id,
            kind,
            verdict,
            background=background,
            reason=reason,
            counterexample_count=counterexample_count,
            source_span=relation.get("source_span"),
            case_context_ids=case_context_ids,
            uses_mixed_scope=uses_mixed_scope,
            local_world_count=local_world_count,
            premise_world_count=premise_world_count,
        )
        row_by_id[relation_id] = row
        visiting.remove(relation_id)
        return row

    return [evaluate_relation(str(relation["id"])) for relation in relations]


def _information_type(
    *, committed: bool, target_truth: bool | None,
    supporting_worlds: int | None, total_worlds: int,
) -> str:
    """Classify a commitment without treating impossibility as infinite bits."""
    if not committed or target_truth is None or supporting_worlds is None:
        return "unscored"
    if supporting_worlds == 0:
        return "contradictory"
    if supporting_worlds == total_worlds:
        return "redundant"
    return "truth_aligned" if target_truth else "misleading"


def _stated_premise_sets(
    relations: Sequence[Mapping[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Collect the premises a source explicitly states for each claim.

    ``INFER`` contributes its ``FROM`` claims. ``REDUCTIO`` discharges its own
    assumption, so its conclusion rests on the remaining members of the cited
    contradiction. A relation whose conclusion appears among its own premises is
    marked unresolved rather than silently reduced.
    """
    relation_by_id = {str(relation["id"]): relation for relation in relations}
    premise_sets: dict[str, dict[str, Any]] = {}

    def record(target: str, premise_ids: Sequence[str], unresolved: bool) -> None:
        entry = premise_sets.setdefault(
            target, {"premise_ids": [], "unresolved": False}
        )
        for premise_id in premise_ids:
            if premise_id == target:
                entry["unresolved"] = True
            elif premise_id not in entry["premise_ids"]:
                entry["premise_ids"].append(premise_id)
        entry["unresolved"] = entry["unresolved"] or unresolved

    for relation in relations:
        kind = str(relation["kind"])
        target = str(relation.get("to") or "")
        if not target:
            continue
        if kind == "infer":
            record(target, [str(value) for value in relation.get("from") or []], False)
        elif kind == "reductio":
            via = relation_by_id.get(str(relation.get("via")))
            assumption = str(relation.get("assume"))
            if via is None or str(via.get("kind")) != "contradict":
                record(target, [], True)
            else:
                record(
                    target,
                    [
                        str(value)
                        for value in via.get("from") or []
                        if str(value) != assumption
                    ],
                    False,
                )
    return premise_sets


def _resolve_premises(
    claim_id: str,
    premise_sets: Mapping[str, Mapping[str, Any]],
    claim_by_id: Mapping[str, Mapping[str, Any]],
) -> tuple[str, list[str], list[Mapping[str, Any]] | None]:
    """Resolve the premises stated for one claim into checkable expressions.

    ``none_extracted`` does not mean the speaker gave no reason. The translator
    records only explicitly connected relations, so an omitted relation and a
    genuinely unsupported assertion are indistinguishable at this layer.
    """
    stated = premise_sets.get(claim_id)
    if stated is None:
        return "none_extracted", [], []
    premise_ids = [str(value) for value in stated["premise_ids"]]
    if stated["unresolved"]:
        return "unresolved_reference", premise_ids, None
    expressions: list[Mapping[str, Any]] = []
    for premise_id in premise_ids:
        premise = claim_by_id.get(premise_id)
        if premise is None:
            return "unresolved_reference", premise_ids, None
        if (
            premise.get("case_id") is not None
            and premise.get("commitment") != "report"
        ):
            return "mixed_case_scope", premise_ids, None
        expression = _effective_commitment_expression(premise)
        if expression is None:
            return "unresolved_reference", premise_ids, None
        expressions.append(expression)
    return "stated", premise_ids, expressions


def _conditional_information_type(
    *,
    premise_world_count: int,
    joint_world_count: int,
    premises_admit_target: bool,
    target_truth: bool,
) -> str:
    """Classify a commitment against the worlds its stated premises still allow.

    ``false_premise_scoped`` keeps a valid step from a premise set that has
    already lost the verified solution separate from a claim that eliminates it.
    """
    if premise_world_count == 0:
        return "inconsistent_premises"
    if joint_world_count == 0:
        return "contradictory"
    if joint_world_count == premise_world_count:
        return "redundant"
    if not premises_admit_target:
        return "false_premise_scoped"
    return "truth_aligned" if target_truth else "misleading"


def _conditional_information(
    *,
    expression: Mapping[str, Any] | None,
    committed: bool,
    status: str,
    premise_ids: Sequence[str],
    premise_exprs: Sequence[Mapping[str, Any]] | None,
    role_worlds: Sequence[tuple[str, ...]],
    statements: Sequence[Mapping[str, Any]],
    target_assignment: tuple[str, ...],
) -> dict[str, Any]:
    """Measure information gain against the premises the source actually stated.

    With no extracted premises the premise set is empty, so the conditional
    measure coincides with the unconditional one; ``stated_premise_status``
    carries that caveat instead of a missing value.
    """
    row: dict[str, Any] = {
        "stated_premise_claim_ids": list(premise_ids),
        "stated_premise_count": len(premise_ids),
        "stated_premise_status": status,
        "premise_world_count": None,
        "conditional_supporting_world_count": None,
        "conditional_information_bits": None,
        "premises_admit_target": None,
        "conditional_information_type": "unscored",
    }
    if premise_exprs is None or expression is None or not committed:
        return row
    premise_worlds = [
        world
        for world in role_worlds
        if all(evaluate_expr(expr, world, statements) for expr in premise_exprs)
    ]
    joint_worlds = [
        world
        for world in premise_worlds
        if evaluate_expr(expression, world, statements)
    ]
    admits_target = all(
        evaluate_expr(expr, target_assignment, statements)
        for expr in premise_exprs
    )
    row["premise_world_count"] = len(premise_worlds)
    row["conditional_supporting_world_count"] = len(joint_worlds)
    row["premises_admit_target"] = admits_target
    if premise_worlds and joint_worlds:
        row["conditional_information_bits"] = math.log2(
            len(premise_worlds) / len(joint_worlds)
        )
    row["conditional_information_type"] = _conditional_information_type(
        premise_world_count=len(premise_worlds),
        joint_world_count=len(joint_worlds),
        premises_admit_target=admits_target,
        target_truth=bool(evaluate_expr(expression, target_assignment, statements)),
    )
    return row


def score_minimal_translation(
    record: Mapping[str, Any],
    question: Mapping[str, Any],
    target: Sequence[str],
    *,
    relation_backgrounds: Sequence[str] = ("thin",),
) -> dict[str, Any]:
    """Compute non-proof metrics for one minimal translation.

    Information is measured against the role-search universe (exactly one spy),
    not the already-solved puzzle, so informative true claims receive credit.
    Each commitment is measured twice: unconditionally against that universe, and
    conditionally against the worlds its explicitly stated premises still allow.
    Case metrics are descriptive consistency checks and do not claim to validate
    the missing inference steps.

    Relations are checked once per requested background policy. The first entry
    is primary: it populates `relations` and the relation counters, so the
    default call is identical to a single-background check.
    """
    if not relation_backgrounds:
        raise ValueError("at least one relation background is required")
    statements = [item["ast"] for item in question["statements"]]
    target_assignment = tuple(target)
    role_worlds = list(assignments(len(statements)))
    puzzle_worlds = solve(statements)
    claims = list(record.get("claims") or [])
    relations = list(record.get("relations") or [])
    claim_case_parse_errors = record.get("claim_case_parse_errors")
    if claim_case_parse_errors is None:
        claim_case_parse_errors = record.get("parse_errors") or []
    source = record.get("source") or {}
    speaker_agent_id = (
        str(source.get("agent_id")) if source.get("agent_id") else None
    )

    claim_rows = []
    premise_sets = _stated_premise_sets(relations)
    claim_by_id = {str(claim["id"]): claim for claim in claims}
    for claim in claims:
        expression = _effective_commitment_expression(claim, speaker_agent_id)
        commitment = str(claim.get("commitment"))
        effective_commitment = _canonical_commitment(
            commitment, claim.get("attributions") or [], speaker_agent_id
        )
        committed = effective_commitment in {"assert", "endorse"}
        if expression is None:
            target_truth = None
            supporting_worlds = None
            information_bits = None
        else:
            target_truth = bool(
                evaluate_expr(expression, target_assignment, statements)
            )
            supporting_worlds = sum(
                evaluate_expr(expression, world, statements)
                for world in role_worlds
            )
            information_bits = (
                math.log2(len(role_worlds) / supporting_worlds)
                if supporting_worlds
                else None
            )
        premise_status, premise_ids, premise_exprs = _resolve_premises(
            str(claim["id"]), premise_sets, claim_by_id
        )
        claim_rows.append(
            {
                "id": claim.get("id"),
                "commitment": commitment,
                "case_id": claim.get("case_id"),
                "source_span": claim.get("source_span"),
                "committed": committed,
                "target_truth": target_truth if committed else None,
                "expression_truth_at_target": target_truth,
                "supporting_role_world_count": supporting_worlds,
                "role_world_count": len(role_worlds),
                "information_bits": information_bits,
                "structurally_impossible": supporting_worlds == 0,
                "information_type": _information_type(
                    committed=committed,
                    target_truth=target_truth if committed else None,
                    supporting_worlds=supporting_worlds,
                    total_worlds=len(role_worlds),
                ),
                **_conditional_information(
                    expression=expression,
                    committed=committed,
                    status=premise_status,
                    premise_ids=premise_ids,
                    premise_exprs=premise_exprs,
                    role_worlds=role_worlds,
                    statements=statements,
                    target_assignment=target_assignment,
                ),
            }
        )

    case_rows = []
    for case in record.get("cases") or []:
        case_id = str(case["id"])
        member_claims = [
            claim for claim in claims if claim.get("case_id") == case_id
        ]
        assumption_members = [
            claim for claim in member_claims
            if claim.get("commitment") == "assume"
        ]
        opaque_members = [
            claim for claim in member_claims if claim.get("expression") is None
        ]
        if claim_case_parse_errors:
            representability = "parse_uncertain"
        elif not assumption_members:
            representability = "missing_assumption"
        elif opaque_members:
            representability = "opaque"
        else:
            representability = "complete"
        assumptions = [
            claim["expression"]
            for claim in claims
            if claim.get("case_id") == case_id
            and claim.get("commitment") == "assume"
            and claim.get("expression") is not None
        ]
        hypothetical = [
            claim["expression"]
            for claim in claims
            if claim.get("case_id") == case_id
            and claim.get("commitment") == "hypothetical"
            and claim.get("expression") is not None
        ]
        assumption_worlds = [
            world
            for world in puzzle_worlds
            if all(evaluate_expr(expr, world, statements) for expr in assumptions)
        ]
        trace_worlds = [
            world
            for world in assumption_worlds
            if all(evaluate_expr(expr, world, statements) for expr in hypothetical)
        ]
        disposition = str(case.get("disposition", "unresolved"))
        disposition_scored = (
            representability == "complete"
            and disposition in {"accepted", "rejected"}
        )
        if disposition_scored and disposition == "rejected":
            assumption_match = len(assumption_worlds) == 0
            trace_match = len(trace_worlds) == 0
        elif disposition_scored and disposition == "accepted":
            assumption_match = len(assumption_worlds) > 0
            trace_match = len(trace_worlds) > 0
        else:
            assumption_match = None
            trace_match = None
        conditional_rows = []
        for claim in claims:
            if (
                claim.get("case_id") != case_id
                or claim.get("commitment") != "hypothetical"
                or claim.get("expression") is None
            ):
                continue
            values = [
                evaluate_expr(claim["expression"], world, statements)
                for world in assumption_worlds
            ]
            conditional_rows.append(
                {"id": claim["id"], "status_given_assumptions": _truth_status(values)}
            )
        case_rows.append(
            {
                "id": case_id,
                "disposition": disposition,
                "explicit": bool(case.get("explicit", False)),
                "source_span": case.get("source_span"),
                "representability": representability,
                "disposition_scored": disposition_scored,
                "member_claim_count": len(member_claims),
                "opaque_member_claim_count": len(opaque_members),
                "assumption_claim_count": len(assumptions),
                "hypothetical_claim_count": len(hypothetical),
                "puzzle_world_count_given_assumptions": len(assumption_worlds),
                "puzzle_world_count_given_full_case_trace": len(trace_worlds),
                "disposition_matches_assumption_viability": assumption_match,
                "disposition_matches_trace_consistency": trace_match,
                "hypothetical_claims": conditional_rows,
            }
        )

    committed_rows = [row for row in claim_rows if row["committed"]]
    premise_backed_count = sum(
        row["stated_premise_status"] == "stated" for row in committed_rows
    )
    scored_committed = [row for row in committed_rows if row["target_truth"] is not None]
    true_committed = sum(row["target_truth"] is True for row in scored_committed)
    explicit_cases = [case for case in case_rows if case["disposition"] != "unresolved"]
    scored_cases = [case for case in explicit_cases if case["disposition_scored"]]
    assumption_matches = [
        case["disposition_matches_assumption_viability"] for case in scored_cases
    ]
    relations_by_background = {
        name: check_minimal_relations(
            claims,
            record.get("cases") or [],
            relations,
            statements,
            speaker_agent_id,
            background=name,
        )
        for name in dict.fromkeys(relation_backgrounds)
    }
    relation_rows = relations_by_background[relation_backgrounds[0]]
    return {
        "format_version": FORMAT_VERSION,
        "formalization_id": record.get("formalization_id"),
        "source": record.get("source"),
        "claim_count": len(claims),
        "role_world_count": len(role_worlds),
        "translated_claim_count": sum(claim.get("expression") is not None for claim in claims),
        "opaque_claim_count": sum(claim.get("expression") is None for claim in claims),
        "committed_claim_count": len(committed_rows),
        "scored_committed_claim_count": len(scored_committed),
        "true_committed_claim_count": true_committed,
        "committed_claim_accuracy": (
            true_committed / len(scored_committed) if scored_committed else None
        ),
        "stated_premise_claim_count": premise_backed_count,
        "committed_claim_premise_coverage": (
            premise_backed_count / len(committed_rows) if committed_rows else None
        ),
        "case_count": len(case_rows),
        "explicit_case_disposition_count": len(explicit_cases),
        "scored_case_disposition_count": len(scored_cases),
        "case_assumption_disposition_accuracy": (
            sum(value is True for value in assumption_matches) / len(assumption_matches)
            if assumption_matches
            else None
        ),
        "relation_count": len(relation_rows),
        "checkable_relation_count": sum(
            row["verdict"] != "uncheckable" for row in relation_rows
        ),
        "valid_relation_count": sum(
            row["verdict"] in VALID_RELATION_VERDICTS for row in relation_rows
        ),
        "parse_error_count": len(record.get("parse_errors") or []),
        "claims": claim_rows,
        "cases": case_rows,
        "relations": relation_rows,
        "relations_by_background": relations_by_background,
    }


def _load_dataset_context(
    dataset_path: Path,
) -> tuple[dict[str, dict[str, Any]], dict[str, tuple[str, ...]]]:
    questions: dict[str, dict[str, Any]] = {}
    targets: dict[str, tuple[str, ...]] = {}
    for size in dataset_sizes(dataset_path):
        for question in read_jsonl(dataset_path / "questions" / ("%d.jsonl" % size)):
            questions[str(question["id"])] = question
        for label in read_jsonl(dataset_path / "labels" / ("%d.jsonl" % size)):
            question = questions[str(label["id"])]
            targets[str(label["id"])] = tuple(
                str(label["roles"][player]) for player in question["players"]
            )
    return questions, targets


def score_minimal_file(
    input_path: Path,
    dataset_path: Path,
    *,
    relation_backgrounds: Sequence[str] = ("thin",),
) -> dict[str, Any]:
    """Score saved translations without model calls."""
    records = [
        json.loads(line)
        for line in input_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    questions, targets = _load_dataset_context(dataset_path)
    rows = []
    for record in records:
        if record.get("format_version") not in {None, FORMAT_VERSION}:
            raise ValueError(
                "cannot score %s records as %s"
                % (record.get("format_version"), FORMAT_VERSION)
            )
        task_id = str((record.get("source") or {}).get("task_id", ""))
        if task_id not in questions:
            raise ValueError("unknown task id in translation: %s" % task_id)
        rows.append(
            score_minimal_translation(
                record,
                questions[task_id],
                targets[task_id],
                relation_backgrounds=relation_backgrounds,
            )
        )
    committed = sum(row["committed_claim_count"] for row in rows)
    scored_committed = sum(row["scored_committed_claim_count"] for row in rows)
    true_committed = sum(row["true_committed_claim_count"] for row in rows)
    explicit_cases = sum(row["explicit_case_disposition_count"] for row in rows)
    scored_cases = sum(row["scored_case_disposition_count"] for row in rows)
    correct_cases = sum(
        sum(
            case["disposition_matches_assumption_viability"] is True
            for case in row["cases"]
            if case["disposition_scored"]
        )
        for row in rows
    )
    return {
        "format_version": FORMAT_VERSION,
        "input": str(input_path),
        "dataset": str(dataset_path),
        "field_count": len(rows),
        "claim_count": sum(row["claim_count"] for row in rows),
        "opaque_claim_count": sum(row["opaque_claim_count"] for row in rows),
        "committed_claim_count": committed,
        "scored_committed_claim_count": scored_committed,
        "true_committed_claim_count": true_committed,
        "committed_claim_accuracy": (
            true_committed / scored_committed if scored_committed else None
        ),
        "explicit_case_disposition_count": explicit_cases,
        "scored_case_disposition_count": scored_cases,
        "case_assumption_disposition_accuracy": (
            correct_cases / scored_cases if scored_cases else None
        ),
        "relation_count": sum(row["relation_count"] for row in rows),
        "checkable_relation_count": sum(row["checkable_relation_count"] for row in rows),
        "valid_relation_count": sum(row["valid_relation_count"] for row in rows),
        "parse_error_count": sum(row["parse_error_count"] for row in rows),
        "rows": rows,
    }


def rescore_minimal_file(input_path: Path, output_path: Path | None = None) -> dict[str, Any]:
    """Reparse stored raw responses after parser-only corrections."""
    records = [
        json.loads(line)
        for line in input_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    for record in records:
        if record.get("format_version") != FORMAT_VERSION:
            raise ValueError(
                "rescoring does not migrate %s records to %s"
                % (record.get("format_version"), FORMAT_VERSION)
            )
        source_text = str(record["source_text"])
        deterministic_normalizations: list[dict[str, Any]] = []
        if record.get("relation_pass_enabled"):
            claim_response = (
                record.get("repair_raw_response")
                if record.get("repair_accepted")
                else record.get("initial_raw_response")
            ) or record["raw_response"]
            claims, cases, discarded, claim_errors = parse_minimal_translation(
                str(claim_response),
                source_text,
                deterministic_normalizations=deterministic_normalizations,
            )
            relation_response = (
                record.get("relation_repair_raw_response")
                if record.get("relation_repair_accepted")
                else record.get("relation_raw_response")
            ) or "NONE"
            relations, relation_errors = parse_minimal_relations(
                str(relation_response),
                source_text,
                claims,
            )
            errors = [*claim_errors, *relation_errors]
            record["initial_parse_errors"] = claim_errors
            record["relation_initial_parse_errors"] = relation_errors
            record["stage_1_discarded_relation_count"] = len(discarded)
            record["raw_response"] = "\n".join(
                part for part in (
                    _format_fixed_claim_case_output(claims, cases),
                    _format_fixed_relation_output(relations),
                ) if part
            )
        else:
            response = (
                record.get("repair_raw_response")
                if record.get("repair_accepted")
                else record.get("initial_raw_response")
            ) or record["raw_response"]
            claims, cases, relations, errors = parse_minimal_translation(
                str(response),
                source_text,
                deterministic_normalizations=deterministic_normalizations,
            )
            record["initial_parse_errors"] = errors
            record["raw_response"] = "\n".join(
                part for part in (
                    _format_fixed_claim_case_output(claims, cases),
                    _format_fixed_relation_output(relations),
                ) if part
            )
        record["claims"] = claims
        record["cases"] = cases
        record["relations"] = relations
        record["parse_errors"] = errors
        record["deterministic_normalizations"] = deterministic_normalizations
    destination = output_path or input_path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in records),
        encoding="utf-8",
    )
    report = _summarize_generation(records, 0.0)
    report.update({
        "input": str(input_path),
        "output": str(destination),
        "rescored_from_stored_responses": True,
    })
    return report


def evaluate_minimal_gold_file(
    input_path: Path,
    gold_path: Path | Sequence[Path],
    dataset_path: Path | None = None,
) -> dict[str, Any]:
    """Evaluate expression and commitment fidelity against existing field gold.

    Dependency scores from the shared evaluator are retained only for diagnostic
    compatibility and are explicitly marked non-primary: this format never asks
    the model to produce dependencies.
    """
    records = [
        json.loads(line)
        for line in input_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    semantic_rows: dict[str, dict[str, Mapping[str, Any]]] = {}
    if dataset_path is not None:
        questions, targets = _load_dataset_context(dataset_path)
        for record in records:
            task_id = str((record.get("source") or {}).get("task_id", ""))
            if task_id not in questions:
                raise ValueError("unknown task id in translation: %s" % task_id)
            score = score_minimal_translation(
                record, questions[task_id], targets[task_id]
            )
            semantic_rows[str(record.get("formalization_id"))] = {
                str(row["id"]): row for row in score["relations"]
            }
    normalized = []
    stance_map = {
        "assert": "assert",
        "assume": "hypothetical",
        "hypothetical": "hypothetical",
        "report": "report",
        "endorse": "endorse",
        "reject": "reject",
        "opaque": "abstain",
    }
    for record in records:
        claims = []
        record_source = record.get("source") or {}
        speaker_agent_id = (
            str(record_source.get("agent_id"))
            if record_source.get("agent_id") else None
        )
        for claim in record.get("claims") or []:
            agents = [
                str(attribution).removeprefix("agent:")
                for attribution in claim.get("attributions") or []
                if str(attribution).startswith("agent:")
            ]
            # Preserve a multi-agent report as one metadata-bearing claim.  The
            # legacy evaluator historically saw only one clone per agent, which
            # made an exactly attributed REPORT(agent-1,agent-2) impossible to
            # match.  Keep the per-agent clones as compatibility alternatives
            # for older gold that explicitly requests union aggregation.
            agent_groups = [agents]
            if len(agents) > 1:
                agent_groups.extend([[agent] for agent in agents])
            for agent_group in agent_groups:
                normalized_commitment = _canonical_commitment(
                    str(claim["commitment"]),
                    claim.get("attributions") or [],
                    speaker_agent_id,
                )
                claims.append(
                    {
                        "id": (
                            "%s@%s" % (claim["id"], "+".join(agent_group))
                            if agent_group else claim["id"]
                        ),
                        "stance": stance_map[str(normalized_commitment)],
                        "agents": agent_group,
                        "expression": claim.get("expression"),
                        "dependencies": [],
                        "source_span": claim["source_span"],
                    }
                )
        normalized.append({**record, "claims": claims})
    gold_paths = (
        [gold_path] if isinstance(gold_path, Path) else list(gold_path)
    )
    gold_fields = [
        field
        for path in gold_paths
        for field in load_field_gold(path)
    ]
    gold_ids = [str(field["id"]) for field in gold_fields]
    duplicate_gold_ids = sorted(
        item for item, count in Counter(gold_ids).items() if count > 1
    )
    if duplicate_gold_ids:
        raise ValueError(
            "duplicate gold field ids across shards: %s"
            % ", ".join(duplicate_gold_ids)
        )
    legacy_gold_fields = []
    for field in gold_fields:
        field_source = field.get("source") or {}
        speaker_agent_id = (
            str(field_source.get("agent_id"))
            if field_source.get("agent_id") else None
        )
        required_claims = []
        for claim in field["required_claims"]:
            if claim.get("expression") is None:
                continue
            commitment = _canonical_commitment(
                str(claim.get("commitment")),
                claim.get("attributions") or [],
                speaker_agent_id,
            )
            required_claims.append({
                **claim,
                "stance": stance_map.get(str(commitment), claim.get("stance")),
            })
        legacy_gold_fields.append({**field, "required_claims": required_claims})
    report = evaluate_field_gold(normalized, legacy_gold_fields)
    report["dependency_metrics_applicable"] = False
    relation_required = relation_pass = case_required = case_pass = 0
    case_disposition_pass = case_member_required = case_member_pass = 0
    verdict_required = verdict_covered = verdict_pass = 0
    v2_claim_required = v2_claim_pass = 0
    exhaustive_claim_actual = exhaustive_claim_matched = 0
    exhaustive_relation_actual = exhaustive_relation_matched = 0
    relation_detection_required = relation_detection_pass = 0
    relation_detection_actual = relation_detection_matched = 0
    explicit_capture_required = explicit_capture_pass = 0
    relation_capture_actual = relation_capture_matched = 0
    relation_rows: list[dict[str, Any]] = []

    def source_matches(actual: Mapping[str, Any], anchor: str) -> bool:
        span = str(actual.get("source_span", ""))
        return bool(span) and (anchor in span or span in anchor)

    def claim_source_matches(
        actual: Mapping[str, Any], gold_claim: Mapping[str, Any]
    ) -> bool:
        anchors = gold_claim.get("source_span_options") or [
            gold_claim.get("source_span", "")
        ]
        return any(source_matches(actual, str(anchor)) for anchor in anchors)

    for field in gold_fields:
        matching_records = [
            record
            for record in records
            if all(
                str((record.get("source") or {}).get(key)) == str(value)
                for key, value in (field.get("source") or {}).items()
            )
        ]
        if len(matching_records) != 1:
            continue
        record = matching_records[0]
        field_source = field.get("source") or {}
        speaker_agent_id = (
            str(field_source.get("agent_id"))
            if field_source.get("agent_id") else None
        )
        actual_claims = list(record.get("claims") or [])
        gold_claims = {str(item["id"]): item for item in field["required_claims"]}
        claim_candidates: dict[str, set[str]] = {}

        def commitments_match(
            actual_claim: Mapping[str, Any], gold_claim: Mapping[str, Any]
        ) -> bool:
            expected = gold_claim.get("commitment")
            if expected is None:
                return True
            return _canonical_commitment(
                str(actual_claim.get("commitment")),
                actual_claim.get("attributions") or [],
                speaker_agent_id,
            ) == _canonical_commitment(
                str(expected),
                gold_claim.get("attributions") or [],
                speaker_agent_id,
            )

        for gold_id, gold_claim in gold_claims.items():
            claim_candidates[gold_id] = {
                str(claim["id"])
                for claim in actual_claims
                if claim_source_matches(claim, gold_claim)
                and (
                    claim.get("expression") is None
                    and gold_claim.get("expression") is None
                    or claim.get("expression") is not None
                    and gold_claim.get("expression") is not None
                    and expressions_equivalent(
                        claim["expression"], gold_claim["expression"]
                    )
                )
                and commitments_match(claim, gold_claim)
                and (
                    "attributions" not in gold_claim
                    or set(map(str, claim.get("attributions") or []))
                    == set(map(str, gold_claim["attributions"]))
                )
            }
            if "commitment" in gold_claim or "attributions" in gold_claim:
                v2_claim_required += 1
                v2_claim_pass += bool(claim_candidates[gold_id])
        field_v2_claim_rows = [
            {
                "id": gold_id,
                "passed": bool(claim_candidates[gold_id]),
                "actual_claim_ids": sorted(claim_candidates[gold_id]),
            }
            for gold_id in gold_claims
        ]
        matched_claim_ids = set().union(*claim_candidates.values())
        # An exhaustive inventory should not call a repeated, semantically
        # equivalent mention a false positive merely because its verbatim span
        # differs from the reviewed anchor.  Recall remains source-anchored;
        # this relaxation affects precision only and still requires identical
        # commitment and attribution metadata.  Opaque claims are excluded
        # because two ABSTAIN records are not semantically interchangeable.
        for claim in actual_claims:
            if str(claim["id"]) in matched_claim_ids or claim.get("expression") is None:
                continue
            anchored_metadata_error = any(
                gold_claim.get("expression") is not None
                and claim_source_matches(claim, gold_claim)
                and expressions_equivalent(
                    claim.get("expression"), gold_claim.get("expression")
                )
                and (
                    (
                        gold_claim.get("commitment") is not None
                        and not commitments_match(claim, gold_claim)
                    )
                    or (
                        "attributions" in gold_claim
                        and set(map(str, claim.get("attributions") or []))
                        != set(map(str, gold_claim.get("attributions") or []))
                    )
                )
                for gold_claim in gold_claims.values()
            )
            if anchored_metadata_error:
                continue
            if any(
                gold_claim.get("expression") is not None
                and expressions_equivalent(
                    claim.get("expression"), gold_claim.get("expression")
                )
                and commitments_match(claim, gold_claim)
                and (
                    "attributions" not in gold_claim
                    or set(map(str, claim.get("attributions") or []))
                    == set(map(str, gold_claim.get("attributions") or []))
                )
                for gold_claim in gold_claims.values()
            ):
                matched_claim_ids.add(str(claim["id"]))
        unexpected_claim_ids = sorted(
            str(claim["id"])
            for claim in actual_claims
            if str(claim["id"]) not in matched_claim_ids
        )
        if field.get("claims_exhaustive"):
            exhaustive_claim_actual += len(actual_claims)
            exhaustive_claim_matched += len(matched_claim_ids)

        actual_claim_by_id = {
            str(claim["id"]): claim for claim in actual_claims
        }

        def relation_ref_matches(actual_id: str, gold_id: str) -> bool:
            if actual_id in claim_candidates.get(gold_id, set()):
                return True
            # Relation structure depends on the endpoint proposition and source
            # anchor, not on whether the claim stage mislabeled its attribution.
            # Keep that metadata error in claim scoring while avoiding a second,
            # spurious relation-stage miss.
            actual_claim = actual_claim_by_id.get(actual_id)
            gold_claim = gold_claims.get(gold_id)
            if actual_claim is None or gold_claim is None:
                return False
            if not claim_source_matches(actual_claim, gold_claim):
                return False
            actual_expression = actual_claim.get("expression")
            gold_expression = gold_claim.get("expression")
            return (
                actual_expression is not None
                and gold_expression is not None
                and expressions_equivalent(actual_expression, gold_expression)
            )

        def refs_match(actual_ids: Sequence[str], gold_ids: Sequence[str]) -> bool:
            if len(actual_ids) != len(gold_ids):
                return False
            remaining = list(map(str, actual_ids))

            def assign(index: int) -> bool:
                if index == len(gold_ids):
                    return not remaining
                for position, actual_id in enumerate(list(remaining)):
                    if not relation_ref_matches(
                        actual_id, str(gold_ids[index])
                    ):
                        continue
                    remaining.pop(position)
                    if assign(index + 1):
                        return True
                    remaining.insert(position, actual_id)
                return False

            return assign(0)

        actual_relations = list(record.get("relations") or [])
        matched_relation_ids: dict[str, set[str]] = {}
        used_relation_ids: set[str] = set()
        field_relation_rows = []
        for gold_relation in field.get("required_relations", []):
            relation_required += 1
            kind = str(gold_relation["kind"])
            candidates = []
            for actual in actual_relations:
                if str(actual["id"]) in used_relation_ids:
                    continue
                if actual.get("kind") != kind or not source_matches(
                    actual, str(gold_relation["source_span"])
                ):
                    continue
                if kind in {"infer", "contradict"}:
                    from_options = gold_relation.get("from_options") or [
                        gold_relation.get("from") or []
                    ]
                    if not any(
                        refs_match(actual.get("from") or [], option)
                        for option in from_options
                    ):
                        continue
                if kind == "infer" and not relation_ref_matches(
                    str(actual.get("to")), str(gold_relation.get("to"))
                ):
                    continue
                if kind == "reductio":
                    if str(actual.get("assume")) not in claim_candidates.get(
                        str(gold_relation.get("assume")), set()
                    ) or str(actual.get("to")) not in claim_candidates.get(
                        str(gold_relation.get("to")), set()
                    ):
                        continue
                    if str(actual.get("via")) not in matched_relation_ids.get(
                        str(gold_relation.get("via")), set()
                    ):
                        continue
                candidates.append(str(actual["id"]))
            passed = bool(candidates)
            relation_pass += passed
            if candidates:
                used_relation_ids.add(candidates[0])
                candidates = candidates[:1]
            matched_relation_ids[str(gold_relation["id"])] = set(candidates)
            expected_verdict = gold_relation.get("local_verdict")
            expected_verdicts = [
                str(item)
                for item in (
                    gold_relation.get("local_verdict_options")
                    or ([expected_verdict] if expected_verdict is not None else [])
                )
            ]
            verdict_ok: bool | None = None
            actual_verdicts: list[str] = []
            if expected_verdict is not None and dataset_path is not None:
                verdict_required += 1
                verdict_covered += bool(candidates)
                actual_verdicts = [
                    str(semantic_rows.get(str(record.get("formalization_id")), {})
                        .get(actual_id, {}).get("verdict"))
                    for actual_id in candidates
                ]
                verdict_ok = any(
                    expected in actual_verdicts
                    for expected in expected_verdicts
                )
                verdict_pass += verdict_ok
            field_relation_rows.append({
                "id": gold_relation["id"],
                "tier": gold_relation.get("tier", "explicit"),
                "passed": passed,
                "actual_relation_ids": candidates,
                "expected_local_verdict": expected_verdict,
                "expected_local_verdict_options": expected_verdicts,
                "actual_local_verdicts": actual_verdicts,
                "local_verdict_pass": verdict_ok,
            })

        # Primary relation capture deliberately ignores the exact premise set.
        # It asks whether the translator noticed the stated move and reached
        # the reviewed conclusion. Exact endpoints remain available above as
        # the stricter proof-reconstruction diagnostic.
        gold_relations = list(field.get("required_relations", []))
        capture_candidates: dict[int, list[int]] = {}
        for gold_index, gold_relation in enumerate(gold_relations):
            candidates = []
            for actual_index, actual in enumerate(actual_relations):
                kind = str(gold_relation["kind"])
                if actual.get("kind") != kind or not source_matches(
                    actual, str(gold_relation.get("source_span", ""))
                ):
                    continue
                if kind == "infer" and not relation_ref_matches(
                    str(actual.get("to")), str(gold_relation.get("to"))
                ):
                    continue
                if kind == "reductio" and (
                    not relation_ref_matches(
                        str(actual.get("assume")),
                        str(gold_relation.get("assume")),
                    )
                    or not relation_ref_matches(
                        str(actual.get("to")), str(gold_relation.get("to"))
                    )
                ):
                    continue
                candidates.append(actual_index)
            capture_candidates[gold_index] = candidates

        capture_owner: dict[int, int] = {}

        def assign_capture(gold_index: int, seen: set[int]) -> bool:
            for actual_index in capture_candidates[gold_index]:
                if actual_index in seen:
                    continue
                seen.add(actual_index)
                owner = capture_owner.get(actual_index)
                if owner is None or assign_capture(owner, seen):
                    capture_owner[actual_index] = gold_index
                    return True
            return False

        for gold_index in sorted(
            range(len(gold_relations)),
            key=lambda index: (len(capture_candidates[index]), index),
        ):
            assign_capture(gold_index, set())
        captured_gold_indices = set(capture_owner.values())
        explicit_indices = {
            index
            for index, item in enumerate(gold_relations)
            if item.get("tier", "explicit") == "explicit"
        }
        explicit_capture_owner: dict[int, int] = {}

        def assign_explicit_capture(gold_index: int, seen: set[int]) -> bool:
            for actual_index in capture_candidates[gold_index]:
                if actual_index in seen:
                    continue
                seen.add(actual_index)
                owner = explicit_capture_owner.get(actual_index)
                if owner is None or assign_explicit_capture(owner, seen):
                    explicit_capture_owner[actual_index] = gold_index
                    return True
            return False

        for gold_index in sorted(
            explicit_indices,
            key=lambda index: (len(capture_candidates[index]), index),
        ):
            assign_explicit_capture(gold_index, set())
        captured_explicit_gold_indices = set(explicit_capture_owner.values())
        explicit_capture_required += len(explicit_indices)
        explicit_capture_pass += len(explicit_capture_owner)
        for index, row in enumerate(field_relation_rows):
            row["capture_passed"] = index in captured_gold_indices
            row["explicit_capture_passed"] = index in captured_explicit_gold_indices

        if field.get("relations_exhaustive"):
            exhaustive_relation_actual += len(actual_relations)
            exhaustive_relation_matched += len(
                set().union(*matched_relation_ids.values())
                if matched_relation_ids else set()
            )
            # Diagnose relation extraction independently from endpoint claim
            # fidelity.  A source/kind match says the model noticed the stated
            # link; strict relation scoring above still requires exact reviewed
            # endpoints and therefore remains the primary metric.
            gold_relations = list(field.get("required_relations", []))
            detection_candidates = {
                gold_index: [
                    actual_index
                    for actual_index, actual in enumerate(actual_relations)
                    if actual.get("kind") == gold_relation.get("kind")
                    and source_matches(
                        actual, str(gold_relation.get("source_span", ""))
                    )
                ]
                for gold_index, gold_relation in enumerate(gold_relations)
            }
            actual_owner: dict[int, int] = {}

            def assign_detection(gold_index: int, seen: set[int]) -> bool:
                for actual_index in detection_candidates[gold_index]:
                    if actual_index in seen:
                        continue
                    seen.add(actual_index)
                    owner = actual_owner.get(actual_index)
                    if owner is None or assign_detection(owner, seen):
                        actual_owner[actual_index] = gold_index
                        return True
                return False

            for gold_index in sorted(
                range(len(gold_relations)),
                key=lambda index: (len(detection_candidates[index]), index),
            ):
                assign_detection(gold_index, set())
            detected = len(actual_owner)
            relation_detection_required += len(gold_relations)
            relation_detection_pass += detected
            relation_detection_actual += len(actual_relations)
            relation_detection_matched += detected
            relation_capture_actual += len(actual_relations)
            relation_capture_matched += len(capture_owner)

        matched_actual_relation_ids = (
            set().union(*matched_relation_ids.values())
            if matched_relation_ids else set()
        )
        unexpected_relation_ids = sorted(
            str(relation["id"])
            for relation in actual_relations
            if str(relation["id"]) not in matched_actual_relation_ids
        )

        actual_cases = {str(case["id"]): case for case in record.get("cases") or []}
        field_case_rows = []
        for gold_case in field.get("required_cases", []):
            case_required += 1
            assumption_ids = claim_candidates.get(
                str(gold_case["assumption_claim"]), set()
            )
            matching_case_ids = {
                str(claim["case_id"])
                for claim in actual_claims
                if str(claim["id"]) in assumption_ids and claim.get("case_id")
            }
            member_gold_ids = list(map(str, gold_case.get("member_claims", [])))

            def member_matches_case(member_id: str, case_id: str) -> bool:
                # A character's fixed statement content is true report metadata,
                # not a case-local assertion. Its truth evaluation and deductions
                # are case-local and still require the matching case ID.
                is_fixed_report = (
                    gold_claims.get(member_id, {}).get("commitment") == "report"
                )
                return any(
                    str(claim["id"])
                    in claim_candidates.get(member_id, set())
                    and (
                        is_fixed_report
                        or str(claim.get("case_id")) == case_id
                    )
                    for claim in actual_claims
                )

            disposition_passed = any(
                actual_cases.get(case_id, {}).get("disposition")
                == gold_case["disposition"]
                for case_id in matching_case_ids
            )
            member_results = {
                member_id: any(
                    member_matches_case(member_id, case_id)
                    for case_id in matching_case_ids
                )
                for member_id in member_gold_ids
            }
            case_disposition_pass += disposition_passed
            case_member_required += len(member_results)
            case_member_pass += sum(member_results.values())
            passed = any(
                actual_cases.get(case_id, {}).get("disposition")
                == gold_case["disposition"]
                and all(
                    member_matches_case(member_id, case_id)
                    for member_id in member_gold_ids
                )
                for case_id in matching_case_ids
            )
            case_pass += passed
            field_case_rows.append({
                "id": gold_case["id"],
                "passed": passed,
                "disposition_passed": disposition_passed,
                "actual_case_ids": sorted(matching_case_ids),
                "required_member_claims": member_gold_ids,
                "member_results": member_results,
            })
        relation_rows.append({
            "id": field["id"],
            "required_v2_claims": field_v2_claim_rows,
            "unexpected_claim_ids": unexpected_claim_ids,
            "unexpected_relation_ids": unexpected_relation_ids,
            "required_relations": field_relation_rows,
            "required_cases": field_case_rows,
        })

    report["relation_metrics_applicable"] = relation_required > 0
    report["v2_claim_metrics_applicable"] = v2_claim_required > 0
    report["required_v2_claim_count"] = v2_claim_required
    report["v2_claim_pass_count"] = v2_claim_pass
    report["v2_claim_recall"] = (
        v2_claim_pass / v2_claim_required if v2_claim_required else None
    )
    report["commitment_attribution_accuracy"] = (
        report["metadata_pass_count"] / report["expression_pass_count"]
        if report["expression_pass_count"] else None
    )
    report["required_relation_count"] = relation_required
    report["relation_pass_count"] = relation_pass
    report["relation_recall"] = (
        relation_pass / relation_required if relation_required else None
    )
    report["strict_relation_recall"] = report["relation_recall"]
    report["explicit_relation_capture_pass_count"] = explicit_capture_pass
    report["explicit_relation_capture_required_count"] = explicit_capture_required
    report["explicit_relation_capture_recall"] = (
        explicit_capture_pass / explicit_capture_required
        if explicit_capture_required else None
    )
    report["relation_capture_matched_count"] = relation_capture_matched
    report["relation_capture_actual_count"] = relation_capture_actual
    report["relation_capture_precision"] = (
        relation_capture_matched / relation_capture_actual
        if relation_capture_actual else None
    )
    report["claim_precision_applicable"] = exhaustive_claim_actual > 0
    report["exhaustive_claim_actual_count"] = exhaustive_claim_actual
    report["exhaustive_claim_matched_count"] = exhaustive_claim_matched
    report["claim_precision"] = (
        exhaustive_claim_matched / exhaustive_claim_actual
        if exhaustive_claim_actual else None
    )
    report["relation_precision_applicable"] = exhaustive_relation_actual > 0
    report["exhaustive_relation_actual_count"] = exhaustive_relation_actual
    report["exhaustive_relation_matched_count"] = exhaustive_relation_matched
    report["relation_precision"] = (
        exhaustive_relation_matched / exhaustive_relation_actual
        if exhaustive_relation_actual else None
    )
    report["relation_detection_recall"] = (
        relation_detection_pass / relation_detection_required
        if relation_detection_required else None
    )
    report["relation_detection_precision"] = (
        relation_detection_matched / relation_detection_actual
        if relation_detection_actual else None
    )
    report["relation_detection_pass_count"] = relation_detection_pass
    report["relation_detection_required_count"] = relation_detection_required
    report["relation_detection_matched_count"] = relation_detection_matched
    report["relation_detection_actual_count"] = relation_detection_actual
    report["local_verdict_metrics_applicable"] = verdict_required > 0
    report["required_local_verdict_count"] = verdict_required
    report["covered_local_verdict_count"] = verdict_covered
    report["local_verdict_pass_count"] = verdict_pass
    report["local_verdict_gold_recall"] = (
        verdict_pass / verdict_required if verdict_required else None
    )
    report["local_verdict_accuracy"] = (
        verdict_pass / verdict_covered if verdict_covered else None
    )
    report["case_metrics_applicable"] = case_required > 0
    report["required_case_count"] = case_required
    report["case_pass_count"] = case_pass
    report["case_disposition_pass_count"] = case_disposition_pass
    report["case_disposition_recall"] = (
        case_disposition_pass / case_required if case_required else None
    )
    report["required_case_member_count"] = case_member_required
    report["case_member_pass_count"] = case_member_pass
    report["case_member_recall"] = (
        case_member_pass / case_member_required if case_member_required else None
    )
    report["complete_case_recall"] = (
        case_pass / case_required if case_required else None
    )
    report["case_recall"] = case_pass / case_required if case_required else None
    report["minimal_structure_rows"] = relation_rows
    report["primary_metrics"] = {
        "expression_recall": report["expression_recall"],
        "commitment_attribution_accuracy": report[
            "commitment_attribution_accuracy"
        ],
        "parse_error_count": report["parse_error_count"],
        "forbidden_violation_count": report["forbidden_violation_count"],
    }
    if report["relation_metrics_applicable"]:
        report["primary_metrics"]["relation_recall"] = report[
            "explicit_relation_capture_recall"
        ]
        report["primary_metrics"]["strict_relation_recall"] = report[
            "strict_relation_recall"
        ]
        report["primary_metrics"]["relation_capture_precision"] = report[
            "relation_capture_precision"
        ]
    if report["v2_claim_metrics_applicable"]:
        report["primary_metrics"]["v2_claim_recall"] = report[
            "v2_claim_recall"
        ]
    if report["claim_precision_applicable"]:
        report["primary_metrics"]["claim_precision"] = report["claim_precision"]
    if report["relation_precision_applicable"]:
        report["primary_metrics"]["relation_precision"] = report["relation_precision"]
    if report["local_verdict_metrics_applicable"]:
        report["primary_metrics"]["local_verdict_accuracy"] = report[
            "local_verdict_accuracy"
        ]
        report["primary_metrics"]["local_verdict_gold_recall"] = report[
            "local_verdict_gold_recall"
        ]
    if report["case_metrics_applicable"]:
        report["primary_metrics"]["case_disposition_recall"] = report[
            "case_disposition_recall"
        ]
        report["primary_metrics"]["case_member_recall"] = report[
            "case_member_recall"
        ]
    return report


def _summarize_generation(
    records: Sequence[Mapping[str, Any]], wall_time: float
) -> dict[str, Any]:
    commitments: Counter[str] = Counter()
    relation_kinds: Counter[str] = Counter()
    usage: dict[str, float] = {}
    for record in records:
        commitments.update(claim["commitment"] for claim in record["claims"])
        relation_kinds.update(
            relation["kind"] for relation in record.get("relations") or []
        )
        for key, value in record.get("usage", {}).items():
            if isinstance(value, (int, float)):
                usage[key] = usage.get(key, 0.0) + float(value)
    return {
        "format_version": FORMAT_VERSION,
        "field_count": len(records),
        "claim_count": sum(len(record["claims"]) for record in records),
        "case_count": sum(len(record["cases"]) for record in records),
        "relation_count": sum(len(record.get("relations") or []) for record in records),
        "parse_error_count": sum(len(record["parse_errors"]) for record in records),
        "deterministic_normalization_count": sum(
            len(record.get("deterministic_normalizations") or [])
            for record in records
        ),
        "commitment_counts": dict(sorted(commitments.items())),
        "relation_kind_counts": dict(sorted(relation_kinds.items())),
        "wall_time_seconds": wall_time,
        "usage": usage,
    }


async def _translate_source(
    question: Mapping[str, Any],
    source: ReasoningSource,
    model: ModelConfig,
    client: ModelClient,
    semaphore: asyncio.Semaphore,
    timeout_seconds: float,
    debate_agent_ids: Sequence[str] = (),
    repair_model: ModelConfig | None = None,
    repair_client: ModelClient | None = None,
    relation_model: ModelConfig | None = None,
    relation_client: ModelClient | None = None,
) -> dict[str, Any]:
    async with semaphore:
        response = await client.complete(
            model,
            [
                {"role": "system", "content": (
                    CLAIM_CASE_SYSTEM_PROMPT
                    if relation_model is not None else SYSTEM_PROMPT
                )},
                {
                    "role": "user",
                    "content": (
                        minimal_claim_case_prompt(question, source, debate_agent_ids)
                        if relation_model is not None
                        else minimal_claim_prompt(question, source, debate_agent_ids)
                    ),
                },
            ],
            timeout_seconds,
        )
    initial_normalizations: list[dict[str, Any]] = []
    claims, cases, relations, errors = parse_minimal_translation(
        response.content,
        source.text,
        deterministic_normalizations=initial_normalizations,
    )
    initial_errors = list(errors)
    initial_claims = claims
    initial_cases = cases
    initial_relations = relations
    initial_response = response
    repair_response = None
    repair_accepted: bool | None = None
    repair_rejection_reason: str | None = None
    if errors and repair_model is not None and repair_client is not None:
        async with semaphore:
            repair_response = await repair_client.complete(
                repair_model,
                [
                    {"role": "system", "content": (
                        "Perform format-only repair. Preserve substantive translation "
                        "choices, including logically questionable relations."
                    )},
                    {"role": "user", "content": minimal_format_repair_prompt(
                        source.text, response.content, errors
                    )},
                ],
                timeout_seconds,
            )
        repaired_normalizations: list[dict[str, Any]] = []
        repaired_claims, repaired_cases, repaired_relations, repaired_errors = parse_minimal_translation(
            repair_response.content,
            source.text,
            deterministic_normalizations=repaired_normalizations,
        )
        repairable_ids = _repairable_item_ids(response.content, initial_errors)
        preserved = all((
            _format_repair_preserves_valid_items(
                initial_claims, repaired_claims, repairable_ids
            ),
            _format_repair_preserves_valid_items(
                initial_cases, repaired_cases, repairable_ids
            ),
            _format_repair_preserves_valid_items(
                initial_relations, repaired_relations, repairable_ids
            ),
        ))
        reduced_errors = len(repaired_errors) < len(initial_errors)
        repair_accepted = preserved and reduced_errors
        if repair_accepted:
            claims, cases, relations, errors = (
                repaired_claims, repaired_cases, repaired_relations, repaired_errors
            )
            selected_normalizations = repaired_normalizations
        else:
            claims, cases, relations, errors = (
                initial_claims, initial_cases, initial_relations, initial_errors
            )
            repair_rejection_reason = (
                "changed_valid_items" if not preserved else "did_not_reduce_errors"
            )
            selected_normalizations = initial_normalizations
    else:
        selected_normalizations = initial_normalizations
    selected_claim_response = (
        repair_response.content
        if repair_response is not None and repair_accepted
        else initial_response.content
    )
    stage_1_errors = list(errors)
    stage_1_relation_count = len(relations)
    relation_response = None
    relation_repair_response = None
    relation_initial_errors: list[str] = []
    relation_repair_accepted: bool | None = None
    relation_repair_rejection_reason: str | None = None
    if relation_model is not None and relation_client is not None:
        # Relations emitted by stage 1 are never retained. Stage 2 sees only the
        # immutable parsed claim inventory, so it cannot mutate claims or cases.
        relations = []
        async with semaphore:
            relation_response = await relation_client.complete(
                relation_model,
                [
                    {"role": "system", "content": (
                        "Extract local relation records only. The supplied claims "
                        "are immutable; do not reconstruct a complete proof."
                    )},
                    {"role": "user", "content": minimal_relation_prompt(
                        source.text, claims, cases
                    )},
                ],
                timeout_seconds,
            )
        relations, relation_initial_errors = parse_minimal_relations(
            relation_response.content, source.text, claims
        )
        errors = [*stage_1_errors, *relation_initial_errors]
        if relation_initial_errors and repair_model is not None and repair_client is not None:
            async with semaphore:
                relation_repair_response = await repair_client.complete(
                    repair_model,
                    [
                        {"role": "system", "content": (
                            "Perform format-only repair of relation records. "
                            "Claims and substantive relation choices are immutable."
                        )},
                        {"role": "user", "content": minimal_relation_format_repair_prompt(
                            source.text, claims, cases, relation_response.content,
                            relation_initial_errors,
                        )},
                    ],
                    timeout_seconds,
                )
            repaired_relations, repaired_relation_errors = parse_minimal_relations(
                relation_repair_response.content, source.text, claims
            )
            repairable_relation_ids = _repairable_item_ids(
                relation_response.content, relation_initial_errors
            )
            preserved_relations = _format_repair_preserves_valid_items(
                relations, repaired_relations, repairable_relation_ids
            )
            reduced_relation_errors = (
                len(repaired_relation_errors) < len(relation_initial_errors)
            )
            relation_repair_accepted = (
                preserved_relations and reduced_relation_errors
            )
            if relation_repair_accepted:
                relations = repaired_relations
                errors = [*stage_1_errors, *repaired_relation_errors]
            else:
                relation_repair_rejection_reason = (
                    "changed_valid_items"
                    if not preserved_relations
                    else "did_not_reduce_errors"
                )
    usage: dict[str, float] = {}
    for candidate in (
        initial_response, repair_response, relation_response,
        relation_repair_response,
    ):
        if candidate is None:
            continue
        for key, value in candidate.usage.items():
            if isinstance(value, (int, float)):
                usage[key] = usage.get(key, 0.0) + float(value)
    return {
        "formalization_id": source.id,
        "format_version": FORMAT_VERSION,
        "prompt_version": PROMPT_VERSION,
        "relation_prompt_version": (
            STABLE_RELATION_PROMPT_VERSION if relation_response else None
        ),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "source": source.location,
        "source_text": source.text,
        "submitted_roles": source.submitted_roles,
        "claims": claims,
        "cases": cases,
        "relations": relations,
        "parse_errors": errors,
        "deterministic_normalizations": selected_normalizations,
        "initial_parse_errors": initial_errors,
        "claim_case_parse_errors": stage_1_errors,
        "repair_attempted": repair_response is not None,
        "repair_accepted": repair_accepted,
        "repair_rejection_reason": repair_rejection_reason,
        "repair_model_config_id": repair_model.id if repair_response else None,
        "repair_model_configured_id": repair_model.id if repair_model else None,
        "repair_model_metadata": (
            repair_response.response_metadata if repair_response else None
        ),
        "initial_raw_response": initial_response.content,
        "repair_raw_response": repair_response.content if repair_response else None,
        "relation_pass_enabled": relation_response is not None,
        "stage_1_discarded_relation_count": (
            stage_1_relation_count if relation_response else 0
        ),
        "relation_model_config_id": (
            relation_model.id if relation_response and relation_model else None
        ),
        "relation_model_metadata": (
            relation_response.response_metadata if relation_response else None
        ),
        "relation_initial_parse_errors": relation_initial_errors,
        "relation_raw_response": (
            relation_response.content if relation_response else None
        ),
        "relation_repair_attempted": relation_repair_response is not None,
        "relation_repair_accepted": relation_repair_accepted,
        "relation_repair_rejection_reason": relation_repair_rejection_reason,
        "relation_repair_raw_response": (
            relation_repair_response.content if relation_repair_response else None
        ),
        "model": response.model,
        "model_config_id": model.id,
        "model_metadata": response.response_metadata,
        "usage": usage,
        "raw_response": (
            (
                _format_fixed_claim_case_output(claims, cases)
                if relation_response else selected_claim_response
            )
            + (
                ("\n" + _format_fixed_relation_output(relations))
                if relation_response and relations else ""
            )
        ),
    }


async def generate_minimal_claims(
    run_dir: Path,
    task_id: str,
    model_config: Path,
    output: Path,
    *,
    timeout_seconds: float = 300,
    concurrency: int = 5,
    model_client: ModelClient | None = None,
) -> dict[str, Any]:
    """Translate every reasoning field for one completed KKS task."""
    if concurrency < 1:
        raise ValueError("concurrency must be positive")
    storage = ExperimentStorage(str(run_dir))
    resolved = config_from_resolved_dict(storage.load_resolved_config())
    if resolved.benchmark.kind != "kks":
        raise ValueError("minimal claim translation supports only KKS")
    dataset_path = Path(resolved.benchmark.path)
    if not dataset_path.is_absolute():
        dataset_path = Path(resolved.config_root) / dataset_path
    question = _load_question(dataset_path.resolve(), task_id)
    results = [
        value
        for (candidate, _), value in completed_results(run_dir).items()
        if candidate == task_id
    ]
    if not results:
        raise ValueError("No completed result for task %s" % task_id)
    debate_agent_ids = sorted({
        str(agent_id)
        for result in results
        for agent_id in (result.get("initial_proposals") or {})
    })
    model = ModelConfig(
        **(yaml.safe_load(model_config.read_text(encoding="utf-8")) or {})
    )
    client = model_client or model_client_for_config(model)
    sources: list[ReasoningSource] = []
    for result in sorted(results, key=lambda value: int(value.get("repetition", 1))):
        for source in extract_reasoning_sources(result):
            location = {
                "run_id": result["run_id"],
                "task_id": task_id,
                "repetition": int(result.get("repetition", 1)),
                **source.location,
            }
            sources.append(
                ReasoningSource(location, source.text, source.submitted_roles)
            )
    semaphore = asyncio.Semaphore(concurrency)
    started = time.monotonic()

    records = await asyncio.gather(*(
        _translate_source(
            question, source, model, client, semaphore, timeout_seconds,
            debate_agent_ids,
        )
        for source in sources
    ))
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in records),
        encoding="utf-8",
    )
    return {
        "output": str(output),
        "model": model.model,
        "reasoning_effort": model.params.get("reasoning_effort"),
        **_summarize_generation(records, time.monotonic() - started),
    }


def run_minimal_claims(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return asyncio.run(generate_minimal_claims(*args, **kwargs))


async def generate_minimal_initials(
    run_dir: Path,
    manifest_path: Path,
    model_config: Path,
    output: Path,
    *,
    timeout_seconds: float = 300,
    concurrency: int = 5,
    model_client: ModelClient | None = None,
) -> dict[str, Any]:
    """Translate exactly the initial explanations selected by a frozen manifest."""
    if concurrency < 1:
        raise ValueError("concurrency must be positive")
    manifest = load_initial_manifest(manifest_path)
    storage = ExperimentStorage(str(run_dir))
    resolved = config_from_resolved_dict(storage.load_resolved_config())
    if resolved.benchmark.kind != "kks":
        raise ValueError("minimal claim translation supports only KKS")
    dataset_path = Path(resolved.benchmark.path)
    if not dataset_path.is_absolute():
        dataset_path = Path(resolved.config_root) / dataset_path
    completed = completed_results(run_dir)
    selected: list[tuple[dict[str, Any], ReasoningSource, list[str]]] = []
    for item in manifest:
        task_id, agent_id = item["task_id"], item["agent_id"]
        candidates = [
            value for (candidate, _), value in completed.items()
            if candidate == task_id
        ]
        if len(candidates) != 1:
            raise ValueError(
                "manifest task %s must have exactly one completed result" % task_id
            )
        result = candidates[0]
        proposal = (result.get("initial_proposals") or {}).get(agent_id)
        if not isinstance(proposal, Mapping):
            raise ValueError("missing initial proposal for %s/%s" % (task_id, agent_id))
        text = str(proposal.get("explanation", "")).strip()
        if not text:
            raise ValueError("empty initial explanation for %s/%s" % (task_id, agent_id))
        location = {
            "run_id": result["run_id"],
            "task_id": task_id,
            "repetition": int(result.get("repetition", 1)),
            "stage": "initial_proposal",
            "agent_id": agent_id,
            "field": "explanation",
        }
        selected.append((
            _load_question(dataset_path.resolve(), task_id),
            ReasoningSource(location, text, dict(proposal.get("roles") or {})),
            sorted(map(str, (result.get("initial_proposals") or {}).keys())),
        ))

    model = ModelConfig(
        **(yaml.safe_load(model_config.read_text(encoding="utf-8")) or {})
    )
    client = model_client or model_client_for_config(model)
    semaphore = asyncio.Semaphore(concurrency)
    started = time.monotonic()

    records = await asyncio.gather(
        *(
            _translate_source(
                question, source, model, client, semaphore, timeout_seconds,
                debate_agent_ids,
            )
            for question, source, debate_agent_ids in selected
        )
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in records),
        encoding="utf-8",
    )
    return {
        "output": str(output),
        "manifest": str(manifest_path),
        "model": model.model,
        "reasoning_effort": model.params.get("reasoning_effort"),
        **_summarize_generation(records, time.monotonic() - started),
    }


def run_minimal_initials(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return asyncio.run(generate_minimal_initials(*args, **kwargs))


def load_minimal_source_manifest(path: Path) -> list[dict[str, Any]]:
    """Load exact reasoning-source selectors for a mixed-stage canary."""
    items = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    seen: set[str] = set()
    for index, item in enumerate(items, start=1):
        if set(item) != {"id", "task_id", "source"}:
            raise ValueError("manifest line %d has invalid keys" % index)
        item_id = str(item["id"])
        if not item_id or item_id in seen:
            raise ValueError("manifest IDs must be non-empty and unique")
        if not isinstance(item["source"], Mapping) or not item["source"]:
            raise ValueError("manifest line %d requires a source selector" % index)
        if "stage" not in item["source"] or "agent_id" not in item["source"]:
            raise ValueError("manifest source requires stage and agent_id")
        seen.add(item_id)
    return items


def validate_minimal_development_gold(
    run_dir: Path,
    manifest_path: Path,
    gold_path: Path,
) -> dict[str, Any]:
    """Validate exhaustive development gold against immutable run sources."""
    manifest = load_minimal_source_manifest(manifest_path)
    fields = load_field_gold(gold_path)
    manifest_by_id = {str(item["id"]): item for item in manifest}
    field_by_id = {str(field["id"]): field for field in fields}
    if set(manifest_by_id) != set(field_by_id):
        raise ValueError("gold IDs must exactly match manifest IDs")
    completed = completed_results(run_dir)
    claim_count = relation_count = case_count = 0
    for item_id, item in manifest_by_id.items():
        task_id = str(item["task_id"])
        candidates = [
            value for (candidate, _), value in completed.items()
            if candidate == task_id
        ]
        if len(candidates) != 1:
            raise ValueError("manifest task %s does not resolve uniquely" % task_id)
        sources = [
            source
            for source in extract_reasoning_sources(candidates[0])
            if all(
                str(source.location.get(key)) == str(value)
                for key, value in item["source"].items()
            )
        ]
        if len(sources) != 1:
            raise ValueError("manifest item %s does not resolve uniquely" % item_id)
        source_text = sources[0].text
        field = field_by_id[item_id]
        if field.get("source_text") != source_text:
            raise ValueError("gold source text drift for %s" % item_id)
        if not field.get("claims_exhaustive") or not field.get("relations_exhaustive"):
            raise ValueError("gold field %s must be marked exhaustive" % item_id)
        for claim in field["required_claims"]:
            span = str(claim.get("source_span", ""))
            if not span or span not in source_text:
                raise ValueError("non-verbatim gold claim span in %s" % item_id)
            if "commitment" not in claim or "attributions" not in claim:
                raise ValueError("v2 gold claim metadata missing in %s" % item_id)
            claim_count += 1
        for relation in field.get("required_relations", []):
            span = str(relation.get("source_span", ""))
            if not span or span not in source_text:
                raise ValueError("non-verbatim gold relation span in %s" % item_id)
            if relation.get("local_verdict") not in {
                "entailed", "contradicted", "contingent",
                "inconsistent_premises", "valid_contradiction",
                "not_contradictory", "valid_reductio", "uncheckable",
            }:
                raise ValueError("gold relation verdict missing or invalid in %s" % item_id)
            relation_count += 1
        case_count += len(field.get("required_cases", []))
    return {
        "manifest": str(manifest_path),
        "gold": str(gold_path),
        "field_count": len(fields),
        "claim_count": claim_count,
        "case_count": case_count,
        "relation_count": relation_count,
        "valid": True,
    }


def _write_minimal_records_atomic(
    output: Path,
    records_by_id: Mapping[str, Mapping[str, Any]],
    manifest_ids: Sequence[str],
) -> None:
    """Checkpoint translated records in manifest order without partial JSONL."""
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + ".tmp")
    temporary.write_text(
        "".join(
            json.dumps(records_by_id[item_id], sort_keys=True) + "\n"
            for item_id in manifest_ids
            if item_id in records_by_id
        ),
        encoding="utf-8",
    )
    temporary.replace(output)


def _load_resumable_manifest_records(
    output: Path,
    selected_by_id: Mapping[str, tuple[dict[str, Any], ReasoningSource, list[str]]],
    model: ModelConfig,
    repair_model: ModelConfig | None,
    relation_model: ModelConfig | None,
) -> dict[str, dict[str, Any]]:
    """Load and validate records that are safe to reuse for a manifest rerun."""
    if not output.exists():
        return {}
    records: dict[str, dict[str, Any]] = {}
    for line_number, line in enumerate(
        output.read_text(encoding="utf-8").splitlines(), start=1
    ):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(
                "cannot resume from invalid JSONL line %d" % line_number
            ) from exc
        source = record.get("source") or {}
        manifest_id = str(source.get("manifest_id") or "")
        if not manifest_id or manifest_id not in selected_by_id:
            raise ValueError(
                "resume output line %d has unknown manifest_id %r"
                % (line_number, manifest_id)
            )
        if manifest_id in records:
            raise ValueError("resume output has duplicate manifest_id %s" % manifest_id)
        _, expected_source, _ = selected_by_id[manifest_id]
        if record.get("source_text") != expected_source.text:
            raise ValueError("resume source text drift for %s" % manifest_id)
        if record.get("model_config_id") != model.id:
            raise ValueError("resume claim model mismatch for %s" % manifest_id)
        if record.get("repair_model_configured_id") != (
            repair_model.id if repair_model else None
        ):
            raise ValueError("resume repair model mismatch for %s" % manifest_id)
        expected_relation_id = relation_model.id if relation_model else None
        if record.get("relation_model_config_id") != expected_relation_id:
            raise ValueError("resume relation model mismatch for %s" % manifest_id)
        if record.get("prompt_version") != PROMPT_VERSION:
            raise ValueError("resume claim prompt mismatch for %s" % manifest_id)
        expected_relation_prompt = (
            STABLE_RELATION_PROMPT_VERSION if relation_model else None
        )
        if record.get("relation_prompt_version") != expected_relation_prompt:
            raise ValueError("resume relation prompt mismatch for %s" % manifest_id)
        records[manifest_id] = record
    return records


async def generate_minimal_manifest(
    run_dir: Path,
    manifest_path: Path,
    model_config: Path,
    output: Path,
    *,
    timeout_seconds: float = 300,
    concurrency: int = 5,
    model_client: ModelClient | None = None,
    repair_model_config: Path | None = None,
    repair_model_client: ModelClient | None = None,
    relation_model_config: Path | None = None,
    relation_model_client: ModelClient | None = None,
    resume: bool = False,
    checkpoint_every: int = 10,
    max_retries: int = 2,
    retry_backoff_seconds: float = 1.0,
) -> dict[str, Any]:
    """Translate exact initial or debate fields selected by a manifest."""
    if concurrency < 1:
        raise ValueError("concurrency must be positive")
    if checkpoint_every < 1:
        raise ValueError("checkpoint_every must be positive")
    if max_retries < 0:
        raise ValueError("max_retries cannot be negative")
    if retry_backoff_seconds < 0:
        raise ValueError("retry_backoff_seconds cannot be negative")
    manifest = load_minimal_source_manifest(manifest_path)
    storage = ExperimentStorage(str(run_dir))
    resolved = config_from_resolved_dict(storage.load_resolved_config())
    if resolved.benchmark.kind != "kks":
        raise ValueError("minimal claim translation supports only KKS")
    dataset_path = Path(resolved.benchmark.path)
    if not dataset_path.is_absolute():
        dataset_path = Path(resolved.config_root) / dataset_path
    completed = completed_results(run_dir)
    selected: list[tuple[dict[str, Any], ReasoningSource, list[str]]] = []
    for item in manifest:
        task_id = str(item["task_id"])
        candidates = [
            value for (candidate, _), value in completed.items()
            if candidate == task_id
        ]
        if len(candidates) != 1:
            raise ValueError(
                "manifest task %s must have exactly one completed result" % task_id
            )
        result = candidates[0]
        matches = []
        for source in extract_reasoning_sources(result):
            if all(
                str(source.location.get(key)) == str(value)
                for key, value in item["source"].items()
            ):
                matches.append(source)
        if len(matches) != 1:
            raise ValueError(
                "manifest item %s matched %d sources" % (item["id"], len(matches))
            )
        matched = matches[0]
        location = {
            "run_id": result["run_id"],
            "task_id": task_id,
            "repetition": int(result.get("repetition", 1)),
            "manifest_id": str(item["id"]),
            **matched.location,
        }
        selected.append((
            _load_question(dataset_path.resolve(), task_id),
            ReasoningSource(location, matched.text, matched.submitted_roles),
            sorted(map(str, (result.get("initial_proposals") or {}).keys())),
        ))

    model = ModelConfig(
        **(yaml.safe_load(model_config.read_text(encoding="utf-8")) or {})
    )
    client = model_client or model_client_for_config(model)
    repair_model = None
    repair_client = None
    if repair_model_config is not None:
        repair_model = ModelConfig(
            **(yaml.safe_load(
                repair_model_config.read_text(encoding="utf-8")
            ) or {})
        )
        repair_client = repair_model_client or model_client_for_config(repair_model)
    relation_model = None
    relation_client = None
    if relation_model_config is not None:
        relation_model = ModelConfig(
            **(yaml.safe_load(
                relation_model_config.read_text(encoding="utf-8")
            ) or {})
        )
        relation_client = (
            relation_model_client or model_client_for_config(relation_model)
        )
    manifest_ids = [str(item["id"]) for item in manifest]
    selected_by_id = {
        str(source.location["manifest_id"]): (question, source, debate_agent_ids)
        for question, source, debate_agent_ids in selected
    }
    records_by_id = (
        _load_resumable_manifest_records(
            output, selected_by_id, model, repair_model, relation_model
        )
        if resume else {}
    )
    pending = [
        (item_id, selected_by_id[item_id])
        for item_id in manifest_ids
        if item_id not in records_by_id
    ]
    semaphore = asyncio.Semaphore(concurrency)
    # Bound complete source translations, not only individual model calls. Without
    # this guard, every stage-one call can queue ahead of stage two, delaying the
    # first durable record checkpoint until much of the manifest has run.
    record_semaphore = asyncio.Semaphore(concurrency)
    started = time.monotonic()
    completed_since_checkpoint = 0
    failures: list[tuple[str, str]] = []

    async def translate_pending(
        item_id: str,
        item: tuple[dict[str, Any], ReasoningSource, list[str]],
    ) -> tuple[str, dict[str, Any] | None, Exception | None]:
        question, source, debate_agent_ids = item
        for attempt in range(max_retries + 1):
            try:
                async with record_semaphore:
                    record = await _translate_source(
                        question, source, model, client, semaphore, timeout_seconds,
                        debate_agent_ids, repair_model, repair_client,
                        relation_model, relation_client,
                    )
                return item_id, record, None
            except Exception as exc:
                if attempt >= max_retries:
                    return item_id, None, exc
                if retry_backoff_seconds:
                    await asyncio.sleep(retry_backoff_seconds * (2 ** attempt))
        raise AssertionError("unreachable retry loop")

    tasks = [
        asyncio.create_task(translate_pending(item_id, item))
        for item_id, item in pending
    ]
    for completed_task in asyncio.as_completed(tasks):
        item_id, record, error = await completed_task
        if error is not None:
            failures.append((item_id, "%s: %s" % (type(error).__name__, error)))
            continue
        assert record is not None
        records_by_id[item_id] = record
        completed_since_checkpoint += 1
        if completed_since_checkpoint >= checkpoint_every:
            _write_minimal_records_atomic(output, records_by_id, manifest_ids)
            completed_since_checkpoint = 0
    _write_minimal_records_atomic(output, records_by_id, manifest_ids)
    if failures:
        raise RuntimeError(
            "%d manifest translations failed after checkpointing %d/%d records; "
            "rerun with --resume (%s)"
            % (
                len(failures), len(records_by_id), len(manifest_ids),
                "; ".join(
                    "%s: %s" % (item_id, detail)
                    for item_id, detail in failures[:3]
                ),
            )
        )
    records = [records_by_id[item_id] for item_id in manifest_ids]
    return {
        "output": str(output),
        "manifest": str(manifest_path),
        "model": model.model,
        "reasoning_effort": model.params.get("reasoning_effort"),
        "repair_model": repair_model.model if repair_model else None,
        "repair_reasoning_effort": (
            repair_model.params.get("reasoning_effort") if repair_model else None
        ),
        "relation_model": relation_model.model if relation_model else None,
        "relation_reasoning_effort": (
            relation_model.params.get("reasoning_effort")
            if relation_model else None
        ),
        "concurrency": concurrency,
        "resumed_field_count": len(manifest_ids) - len(pending),
        "translated_field_count": len(pending),
        "checkpoint_every": checkpoint_every,
        "max_retries": max_retries,
        **_summarize_generation(records, time.monotonic() - started),
    }


def run_minimal_manifest(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return asyncio.run(generate_minimal_manifest(*args, **kwargs))


def _saved_claim_case_errors(record: Mapping[str, Any]) -> list[str]:
    saved = record.get("claim_case_parse_errors")
    if saved is not None:
        return list(map(str, saved))
    combined = Counter(map(str, record.get("parse_errors") or []))
    prior_relations = Counter(map(
        str, record.get("relation_initial_parse_errors") or []
    ))
    return list((combined - prior_relations).elements())


async def _rerun_fixed_record_relations(
    record: Mapping[str, Any],
    relation_model: ModelConfig,
    relation_client: ModelClient,
    semaphore: asyncio.Semaphore,
    timeout_seconds: float,
    repair_model: ModelConfig | None = None,
    repair_client: ModelClient | None = None,
    relation_prompt_profile: str = "v1",
) -> dict[str, Any]:
    """Replace relations while preserving a saved claim/case artifact exactly."""
    claims = record.get("claims")
    cases = record.get("cases")
    source_text = record.get("source_text")
    if not isinstance(claims, list) or not isinstance(cases, list):
        raise ValueError("relation rerun requires list-valued claims and cases")
    if not isinstance(source_text, str) or not source_text:
        raise ValueError("relation rerun requires non-empty source_text")
    claims_signature = json.dumps(claims, sort_keys=True, separators=(",", ":"))
    cases_signature = json.dumps(cases, sort_keys=True, separators=(",", ":"))
    async with semaphore:
        response = await relation_client.complete(
            relation_model,
            [
                {"role": "system", "content": (
                    "Extract local relation records only. The supplied claims "
                    "and cases are immutable; do not reconstruct a complete proof."
                )},
                {"role": "user", "content": minimal_relation_prompt(
                    source_text, claims, cases, relation_prompt_profile
                )},
            ],
            timeout_seconds,
        )
    relations, initial_errors = parse_minimal_relations(
        response.content, source_text, claims
    )
    final_errors = list(initial_errors)
    repair_response = None
    repair_accepted: bool | None = None
    repair_rejection_reason: str | None = None
    if initial_errors and repair_model is not None and repair_client is not None:
        async with semaphore:
            repair_response = await repair_client.complete(
                repair_model,
                [
                    {"role": "system", "content": (
                        "Perform format-only repair of relation records. Claims, "
                        "cases, and substantive relation choices are immutable."
                    )},
                    {"role": "user", "content": minimal_relation_format_repair_prompt(
                        source_text, claims, cases, response.content, initial_errors
                    )},
                ],
                timeout_seconds,
            )
        repaired_relations, repaired_errors = parse_minimal_relations(
            repair_response.content, source_text, claims
        )
        repairable_ids = _repairable_item_ids(response.content, initial_errors)
        preserved = _format_repair_preserves_valid_items(
            relations, repaired_relations, repairable_ids
        )
        reduced_errors = len(repaired_errors) < len(initial_errors)
        repair_accepted = preserved and reduced_errors
        if repair_accepted:
            relations = repaired_relations
            final_errors = repaired_errors
        else:
            repair_rejection_reason = (
                "changed_valid_items" if not preserved else "did_not_reduce_errors"
            )
    relation_usage: dict[str, float] = {}
    for candidate in (response, repair_response):
        if candidate is None:
            continue
        for key, value in candidate.usage.items():
            if isinstance(value, (int, float)):
                relation_usage[key] = relation_usage.get(key, 0.0) + float(value)
    combined_usage = {
        key: float(value)
        for key, value in (record.get("usage") or {}).items()
        if isinstance(value, (int, float))
    }
    for key, value in relation_usage.items():
        combined_usage[key] = combined_usage.get(key, 0.0) + value
    prior_parse_errors = list(record.get("parse_errors") or [])
    claim_case_errors = _saved_claim_case_errors(record)
    output = {
        **record,
        "relations": relations,
        "parse_errors": [*claim_case_errors, *final_errors],
        "claim_case_parse_errors": claim_case_errors,
        "relation_pass_enabled": True,
        "relation_rerun_at": datetime.now(timezone.utc).isoformat(),
        "relation_prompt_version": RELATION_PROMPT_PROFILES[
            relation_prompt_profile
        ][1],
        "relation_prompt_profile": relation_prompt_profile,
        "prior_relation_count": len(record.get("relations") or []),
        "prior_parse_errors": prior_parse_errors,
        "relation_model_config_id": relation_model.id,
        "relation_model": response.model,
        "relation_model_metadata": response.response_metadata,
        "relation_initial_parse_errors": initial_errors,
        "relation_raw_response": response.content,
        "relation_repair_attempted": repair_response is not None,
        "relation_repair_accepted": repair_accepted,
        "relation_repair_rejection_reason": repair_rejection_reason,
        "relation_repair_model_config_id": (
            repair_model.id if repair_response and repair_model else None
        ),
        "relation_repair_model_metadata": (
            repair_response.response_metadata if repair_response else None
        ),
        "relation_repair_raw_response": (
            repair_response.content if repair_response else None
        ),
        "relation_pass_usage": relation_usage,
        "usage": combined_usage,
        "raw_response": _format_fixed_claim_case_output(claims, cases)
        + (("\n" + _format_fixed_relation_output(relations)) if relations else ""),
    }
    if json.dumps(output["claims"], sort_keys=True, separators=(",", ":")) != claims_signature:
        raise AssertionError("relation rerun mutated claims")
    if json.dumps(output["cases"], sort_keys=True, separators=(",", ":")) != cases_signature:
        raise AssertionError("relation rerun mutated cases")
    return output


async def generate_minimal_relation_rerun(
    input_path: Path,
    relation_model_config: Path,
    output: Path,
    *,
    timeout_seconds: float = 300,
    concurrency: int = 5,
    relation_model_client: ModelClient | None = None,
    repair_model_config: Path | None = None,
    repair_model_client: ModelClient | None = None,
    relation_prompt_profile: str = "v1",
) -> dict[str, Any]:
    """Run only relation extraction over existing minimal JSONL records."""
    if concurrency < 1:
        raise ValueError("concurrency must be positive")
    if relation_prompt_profile not in RELATION_PROMPT_PROFILES:
        raise ValueError("unknown relation prompt profile %r" % relation_prompt_profile)
    records = [
        json.loads(line)
        for line in input_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    for record in records:
        if record.get("format_version") != FORMAT_VERSION:
            raise ValueError(
                "relation rerun requires %s records" % FORMAT_VERSION
            )
    relation_model = ModelConfig(
        **(yaml.safe_load(
            relation_model_config.read_text(encoding="utf-8")
        ) or {})
    )
    relation_client = (
        relation_model_client or model_client_for_config(relation_model)
    )
    repair_model = None
    repair_client = None
    if repair_model_config is not None:
        repair_model = ModelConfig(
            **(yaml.safe_load(
                repair_model_config.read_text(encoding="utf-8")
            ) or {})
        )
        repair_client = repair_model_client or model_client_for_config(repair_model)
    semaphore = asyncio.Semaphore(concurrency)
    started = time.monotonic()
    results = await asyncio.gather(*(
        _rerun_fixed_record_relations(
            record, relation_model, relation_client, semaphore, timeout_seconds,
            repair_model, repair_client, relation_prompt_profile,
        )
        for record in records
    ), return_exceptions=True)
    output_records: list[dict[str, Any]] = []
    model_failures: list[dict[str, str]] = []
    for record, result in zip(records, results, strict=True):
        if not isinstance(result, BaseException):
            output_records.append(result)
            continue
        error = "%s: %s" % (type(result).__name__, result)
        source = record.get("source") or {}
        model_failures.append({
            "id": str(source.get("manifest_id") or record.get("formalization_id")),
            "error": error,
        })
        claim_case_errors = _saved_claim_case_errors(record)
        output_records.append({
            **record,
            "relations": [],
            "parse_errors": [*claim_case_errors, "relation_model_error: " + error],
            "claim_case_parse_errors": claim_case_errors,
            "prior_relation_count": len(record.get("relations") or []),
            "prior_parse_errors": list(record.get("parse_errors") or []),
            "relation_pass_enabled": True,
            "relation_rerun_at": datetime.now(timezone.utc).isoformat(),
            "relation_prompt_version": RELATION_PROMPT_PROFILES[
                relation_prompt_profile
            ][1],
            "relation_prompt_profile": relation_prompt_profile,
            "relation_model_config_id": relation_model.id,
            "relation_model_error": error,
            "relation_initial_parse_errors": [],
            "relation_raw_response": None,
            "relation_repair_attempted": False,
            "relation_repair_accepted": None,
            "relation_repair_rejection_reason": None,
            "relation_repair_raw_response": None,
            "relation_pass_usage": {},
            "raw_response": _format_fixed_claim_case_output(
                record.get("claims") or [], record.get("cases") or []
            ),
        })
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in output_records),
        encoding="utf-8",
    )
    return {
        "input": str(input_path),
        "output": str(output),
        "relation_model": relation_model.model,
        "relation_reasoning_effort": relation_model.params.get("reasoning_effort"),
        "repair_model": repair_model.model if repair_model else None,
        "relation_prompt_profile": relation_prompt_profile,
        "relation_model_failure_count": len(model_failures),
        "relation_model_failures": model_failures,
        **_summarize_generation(output_records, time.monotonic() - started),
    }


def run_minimal_relation_rerun(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return asyncio.run(generate_minimal_relation_rerun(*args, **kwargs))


async def generate_minimal_end_to_end_rerun(
    input_path: Path,
    dataset_path: Path,
    claim_model_config: Path,
    relation_model_config: Path,
    output: Path,
    *,
    timeout_seconds: float = 300,
    concurrency: int = 5,
    claim_model_client: ModelClient | None = None,
    relation_model_client: ModelClient | None = None,
    repair_model_config: Path | None = None,
    repair_model_client: ModelClient | None = None,
) -> dict[str, Any]:
    """Rerun the true claim/case then relation pipeline from saved sources only."""
    if concurrency < 1:
        raise ValueError("concurrency must be positive")
    saved_records = [
        json.loads(line)
        for line in input_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    debate_agent_ids: set[str] = set()
    for record in saved_records:
        source = record.get("source") or {}
        agent_id = source.get("agent_id") if isinstance(source, Mapping) else None
        if agent_id:
            debate_agent_ids.add(str(agent_id))
        # Old semantic items are never passed to either model. Their agent
        # attributions are consulted only to reconstruct the debate roster.
        for claim in record.get("claims") or []:
            for attribution in claim.get("attributions") or []:
                text = str(attribution)
                if text.startswith("agent:"):
                    debate_agent_ids.add(text.removeprefix("agent:"))
    fixed_debate_agent_ids = sorted(debate_agent_ids)
    selected: list[tuple[dict[str, Any], ReasoningSource]] = []
    for index, record in enumerate(saved_records, start=1):
        location = record.get("source")
        source_text = record.get("source_text")
        submitted_roles = record.get("submitted_roles") or {}
        if not isinstance(location, Mapping) or not location.get("task_id"):
            raise ValueError("input record %d requires source.task_id" % index)
        if not isinstance(source_text, str) or not source_text:
            raise ValueError("input record %d requires source_text" % index)
        if not isinstance(submitted_roles, Mapping):
            raise ValueError("input record %d has invalid submitted_roles" % index)
        task_id = str(location["task_id"])
        selected.append((
            _load_question(dataset_path, task_id),
            ReasoningSource(dict(location), source_text, dict(submitted_roles)),
        ))
    claim_model = ModelConfig(
        **(yaml.safe_load(claim_model_config.read_text(encoding="utf-8")) or {})
    )
    relation_model = ModelConfig(
        **(yaml.safe_load(
            relation_model_config.read_text(encoding="utf-8")
        ) or {})
    )
    claim_client = claim_model_client or model_client_for_config(claim_model)
    relation_client = (
        relation_model_client or model_client_for_config(relation_model)
    )
    repair_model = None
    repair_client = None
    if repair_model_config is not None:
        repair_model = ModelConfig(
            **(yaml.safe_load(
                repair_model_config.read_text(encoding="utf-8")
            ) or {})
        )
        repair_client = repair_model_client or model_client_for_config(repair_model)
    semaphore = asyncio.Semaphore(concurrency)
    started = time.monotonic()
    output_records = await asyncio.gather(*(
        _translate_source(
            question,
            source,
            claim_model,
            claim_client,
            semaphore,
            timeout_seconds,
            fixed_debate_agent_ids,
            repair_model,
            repair_client,
            relation_model,
            relation_client,
        )
        for question, source in selected
    ))
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in output_records),
        encoding="utf-8",
    )
    return {
        "input": str(input_path),
        "dataset": str(dataset_path),
        "output": str(output),
        "claim_model": claim_model.model,
        "claim_reasoning_effort": claim_model.params.get("reasoning_effort"),
        "relation_model": relation_model.model,
        "relation_reasoning_effort": relation_model.params.get("reasoning_effort"),
        "repair_model": repair_model.model if repair_model else None,
        "debate_agent_ids": fixed_debate_agent_ids,
        "rerun_from_saved_sources_only": True,
        **_summarize_generation(output_records, time.monotonic() - started),
    }


def run_minimal_end_to_end_rerun(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return asyncio.run(generate_minimal_end_to_end_rerun(*args, **kwargs))
