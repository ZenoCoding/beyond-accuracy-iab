"""Expanded size-6/8 AUCs with non-role proposition–recipient uptake.

Run: .venv/bin/python scripts/remake_expanded_nonrole_auc.py
"""
import numpy as np
import pandas as pd

from analyze_reasoning_features import ROOT, OUT, SIZE6, SIZE8, KEY, FEATURES, WINDOW, COMMITMENTS, SCORED, auc_table

DEST = ROOT / "reports/analysis/expanded-nonrole-auc-2026-09-06"
LABELS = {
    "initial_net_bits": "Net initial information",
    "any_initial_correct": "At least one correct initial solution",
    "initial_precision": "Initial claim precision",
    "initial_true_bits": "Truth-aligned initial bits",
    "selectivity": "True uptake minus false uptake (non-role pairs)",
    "false_resistance": "False-claim resistance (non-role pairs)",
    "initial_correct_propositions": "Correct distinct initial propositions",
    "uptake_true": "True-claim adaptation (non-role pairs)",
    "initial_distinct": "Distinct initial propositions",
    "post_initial_distinct_before_final": "Distinct later propositions, excluding final decisions",
    "post_initial_distinct": "Distinct later propositions, including final decisions",
}


def build():
    frame = pd.read_csv(OUT / "debate-features.csv")
    assert len(frame) == 120 and frame.operational_final_correct.sum() == 73
    assert not frame.duplicated(["dataset"] + KEY).any()
    assert frame.groupby("stratum").size().eq(20).all()
    records, exposures = [], []
    for dataset, source in [("size6", SIZE6), ("size8", SIZE8)]:
        raw = pd.read_csv(source / "claims.csv", low_memory=False)
        agents = raw[raw.stage_order.eq(0)].groupby(KEY).agent_id.apply(set)
        assert agents.apply(len).eq(3).all()
        claims = raw[raw.commitment.isin(COMMITMENTS) & raw.information_type.isin(SCORED)].copy()
        claims["expr"] = claims.effective_expression.fillna(claims.expression)
        assert claims.expr.notna().all()
        for key, group in claims.groupby(KEY):
            assert group.groupby("expr").target_truth.nunique().eq(1).all()
            first = group.sort_values("stage_order").drop_duplicates("expr")
            record = dict(zip(KEY, key), dataset=dataset)
            record["initial_correct_propositions"] = int((first.stage_order.eq(0) & first.target_truth.eq(True)).sum())
            record["post_initial_distinct"] = int(first.stage_order.gt(0).sum())
            record["post_initial_distinct_before_final"] = int((first.stage_order.gt(0) & first.stage.ne("final_decision")).sum())
            counts = {"truth_aligned": [0, 0], "misleading": [0, 0]}
            for expr, prop in group.groupby("expr"):
                kind = prop.information_type.iloc[0]
                if kind not in counts or prop.stage_order.min() != 0 or "ROLE(" in expr:
                    continue
                introducers = set(prop.loc[prop.stage_order.eq(0), "agent_id"])
                takers = set(prop.loc[prop.stage_order.gt(0) & prop.stage_order.lt(10010), "agent_id"])
                for recipient in sorted(agents.loc[key] - introducers):
                    adopted = int(recipient in takers)
                    counts[kind][0] += adopted
                    counts[kind][1] += 1
                    exposures.append(dict(zip(KEY, key), dataset=dataset, expression=expr,
                                          recipient=recipient, information_type=kind, adopted=adopted))
            for kind, name in [("truth_aligned", "true"), ("misleading", "false")]:
                hits, eligible = counts[kind]
                record[f"eligible_{name}_pairs"] = eligible
                record[f"adopted_{name}_pairs"] = hits
                record[f"uptake_{name}"] = hits / eligible if eligible else np.nan
            record["false_resistance"] = 1 - record["uptake_false"]
            record["selectivity"] = record["uptake_true"] - record["uptake_false"]
            records.append(record)
    pairs = pd.DataFrame(exposures)
    old = pd.read_csv(ROOT / "reports/analysis/conflicting-uptake-2026-09-05/exposure-pairs.csv")
    old = old[~old.expression.str.contains("ROLE(", regex=False)]
    cols = KEY + ["recipient", "expression", "information_type", "adopted"]
    pd.testing.assert_frame_equal(old[cols].sort_values(cols).reset_index(drop=True),
                                  pairs.loc[pairs.dataset.eq("size6"), cols].sort_values(cols).reset_index(drop=True),
                                  check_dtype=False)
    frame = frame.drop(columns=["uptake_true", "uptake_false", "false_resistance", "selectivity"])
    frame = frame.merge(pd.DataFrame(records), on=["dataset"] + KEY, validate="one_to_one", how="left")
    assert frame.eligible_true_pairs.notna().all()
    assert (frame.post_initial_distinct >= frame.post_initial_distinct_before_final).all()
    return frame, pairs


def main():
    frame, pairs = build()
    DEST.mkdir(parents=True, exist_ok=True)
    frame.to_csv(DEST / "debate-features.csv", index=False)
    pairs.to_csv(DEST / "exposure-pairs.csv", index=False)
    conditions = frame.groupby(["dataset", "condition_id"]).operational_final_correct.agg(debates="size", correct="sum").reset_index()
    conditions["incorrect"] = conditions.debates - conditions.correct
    conditions.to_csv(DEST / "condition-counts.csv", index=False)
    WINDOW.update(initial_correct_propositions="initial", post_initial_distinct="whole-debate",
                  post_initial_distinct_before_final="mid-debate")
    features = {**FEATURES, **LABELS}
    table = auc_table(frame, features)
    # The pre-existing function sorts all features by within-condition AUC.
    indexed = table.set_index("feature")
    assert np.isclose(indexed.loc["false_resistance", "auc_within_condition"] + indexed.loc["uptake_false", "auc_within_condition"], 1)
    # Expose how many debates and outcome pairs actually contribute within strata.
    for i, row in table.iterrows():
        eligible = frame[frame[row.feature].notna()]
        contributing, comparison_pairs = 0, 0
        for _, group in eligible.groupby("stratum"):
            correct = int(group.operational_final_correct.sum())
            incorrect = len(group) - correct
            if correct and incorrect:
                contributing += len(group)
                comparison_pairs += correct * incorrect
        table.loc[i, "n_within_contributing"] = contributing
        table.loc[i, "within_comparison_pairs"] = comparison_pairs
    table.to_csv(DEST / "feature-auc.csv", index=False)
    paper = table[table.feature.isin(LABELS)]
    paper.to_csv(DEST / "paper-auc.csv", index=False)
    lines = ["# Expanded AUC: non-role proposition–recipient uptake", "",
        "120 debates: four size-6 conditions (strong/weak × heterogeneous/homogeneous) plus "
        "both fresh size-8 compositions. 73 correct, 47 incorrect. Size-8 heterogeneous: 15/20 "
        "correct; homogeneous: 20/20 correct. The latter contributes to pooled AUC but no "
        "within-condition correct–incorrect pairs.", "",
        "Reproduce: `.venv/bin/python scripts/remake_expanded_nonrole_auc.py`", "",
        "| Metric | Eligible debates | Pooled AUC (95% CI) | Within-condition AUC (95% CI) |",
        "|---|---:|---:|---:|"]
    for r in paper.itertuples():
        lines.append(f"| {LABELS[r.feature]} | {r.n} | {r.auc_pooled:.3f} [{r.pooled_ci_low:.3f}, {r.pooled_ci_high:.3f}] | {r.auc_within_condition:.3f} [{r.within_ci_low:.3f}, {r.within_ci_high:.3f}] |")
    lines += ["",
        "Uptake correction: eligible units are (initial proposition, non-introducer recipient) "
        "pairs. A hit requires the same effective proposition to be expressed by that recipient "
        "after initial proposals and before the final decision. Expressions containing ROLE( "
        "anywhere are excluded. True/false uptake retains the existing truth_aligned/misleading "
        "eligibility (informative propositions; redundant and contradictory propositions do not "
        "enter these denominators). The size-6 exposure pairs exactly reproduce the existing "
        "non-role subset underlying Table 2. Debate-level pair rates feed the AUC, rather than "
        "tier-pooled rates. Zero eligible pairs yield missing uptake, not zero. Resistance is "
        "one minus false uptake; selectivity is true minus false uptake.", "",
        "The non-role restriction applies to uptake/resistance/selectivity only. Initial supply "
        "and introduction counts retain role propositions. Correct initial counts include true "
        "redundant propositions; later counts include all scored commitments, deduplicated by "
        "exact effective expression and assigned to their earliest stage. These counts are not "
        "adjusted for debate length. Initial supply features otherwise retain the original "
        "120-debate definitions and missing values.", "",
        "Within-condition AUC compares outcomes only inside the same size/composition/strength "
        "condition, weighted by eligible correct–incorrect pairs, ties at 0.5. Eligible debates "
        "include conditions with only one outcome; feature-auc.csv additionally reports the "
        "number of contributing debates and comparison pairs. Confidence intervals preserve "
        "the original method: 2,000 percentile bootstrap draws, seed 20260905, debates resampled "
        "separately within condition. Shared puzzles are not jointly resampled across conditions. "
        "Changes from the old table reflect both the expanded sample and corrected uptake "
        "definition. The older size-6 table is retained unchanged and uses all-role, "
        "proposition-level uptake, so it is not a like-for-like robustness comparison.", "",
        "Sorted by within-condition AUC. AUC below 0.5 indicates a negative association. "
        "AUC does not establish causality or incremental importance beyond initial accuracy. "
        "The full feature CSV retains whole-debate reasoning features that include final decisions; "
        "the paper table omits those except the explicitly labeled later-introduction count.", ""]
    (DEST / "README.md").write_text("\n".join(lines))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
