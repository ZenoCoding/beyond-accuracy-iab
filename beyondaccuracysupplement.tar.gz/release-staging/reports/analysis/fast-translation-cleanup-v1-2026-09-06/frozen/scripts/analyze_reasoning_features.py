"""Which formal-logic features of a debate are associated with final accuracy.

Three questions, one sample:

1. Supply and quality. How much distinct formal content does each condition put
   on the table, how truthful is it, and how many bits does it carry?
2. Selection. Given exposure to a peer proposition, how often does an agent
   take it up, split by the truth of the proposition and by model tier? A tier
   that adopts true and false content at the same rate is not discriminating.
3. Association with accuracy. For each feature, the rank statistic
   AUC = P(feature higher in a correct debate) with debate-level bootstrap CIs,
   reported pooled and stratified by condition so the tier gap cannot carry it.

Reproduce:
    .venv/bin/python scripts/analyze_reasoning_features.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "reports/analysis/reasoning-features-2026-09-05"
SIZE6 = ROOT / "reports/analysis/minimal-reasoning-size6-strength-comparison-2026-09-04"
SIZE8 = ROOT / "reports/analysis/fresh-size8-heterogeneity-2026-09-05/base"
SUPPLY = ROOT / "reports/analysis/supply-and-selection-2026-09-05"
CONFLICT = ROOT / "reports/analysis/conflicting-uptake-2026-09-05"

COMMITMENTS = ["assert", "endorse", "reject"]
SCORED = ["truth_aligned", "misleading", "redundant", "contradictory"]
KEY = ["condition_id", "task_id", "repetition"]
SEED = 20260905
BOOT = 2000


# ---------------------------------------------------------------- features

def initial_features(source: Path) -> pd.DataFrame:
    """Distinct formal content available before any peer has spoken.

    Deduplicated by effective expression within a debate, matching the claim
    introduction analyses, so a proposition three agents state independently is
    one unit of supply.
    """
    claims = pd.read_csv(source / "claims.csv", low_memory=False)
    claims = claims[claims.commitment.isin(COMMITMENTS) & claims.information_type.isin(SCORED)]
    claims = claims[claims.stage_order == 0].copy()
    claims["expr"] = claims.effective_expression.fillna(claims.expression)

    rows = []
    for key, group in claims.groupby(KEY):
        props = group.groupby("expr").agg(
            kind=("information_type", "first"),
            bits=("information_bits", "first"),
        )
        counts = props.kind.value_counts()
        bits = props.groupby("kind").bits.sum()
        n_true = int(counts.get("truth_aligned", 0))
        n_false = int(counts.get("misleading", 0))
        signed = n_true + n_false
        rows.append(
            dict(
                zip(KEY, key),
                initial_distinct=int(len(props)),
                initial_true=n_true,
                initial_false=n_false,
                initial_precision=n_true / signed if signed else np.nan,
                initial_true_bits=float(bits.get("truth_aligned", 0.0)),
                initial_false_bits=float(bits.get("misleading", 0.0)),
                initial_net_bits=float(bits.get("truth_aligned", 0.0) - bits.get("misleading", 0.0)),
            )
        )
    return pd.DataFrame(rows)


def load(dataset: str, source: Path, supply_file: str) -> pd.DataFrame:
    debates = pd.read_csv(source / "debates.csv", low_memory=False)
    frame = debates.merge(initial_features(source), on=KEY, how="left")
    selection = pd.read_csv(SUPPLY / supply_file)[KEY + ["uptake_true", "uptake_false", "selectivity"]]
    frame = frame.merge(selection, on=KEY, how="left")
    # The debate-level signal in selection sits in the false half
    # (check_uptake_not_answer_restatement.py, section 6b of the report), so
    # resistance is reported as the primary selection axis and the symmetric
    # selectivity difference as a secondary one.
    frame["false_resistance"] = 1 - frame.uptake_false
    frame["dataset"] = dataset
    frame["stratum"] = dataset + ":" + frame.condition_id
    return frame


# --------------------------------------------------------------------- AUC

def auc(x: np.ndarray, y: np.ndarray) -> float:
    """Mann-Whitney AUC with ties at 0.5; NaN features are dropped pairwise."""
    ok = ~np.isnan(x)
    x, y = x[ok], y[ok]
    pos, neg = x[y == 1], x[y == 0]
    if not len(pos) or not len(neg):
        return np.nan
    diff = pos[:, None] - neg[None, :]
    return float(((diff > 0).sum() + 0.5 * (diff == 0).sum()) / diff.size)


def stratified_auc(frame: pd.DataFrame, feature: str) -> float:
    """Concordant pairs counted only within condition, then pooled.

    Weak and medium teams differ enormously in accuracy, so a pooled AUC on a
    feature that merely tracks capability would look predictive without saying
    anything about a debate's own reasoning.
    """
    num = den = 0.0
    for _, group in frame.groupby("stratum"):
        x = group[feature].to_numpy(float)
        y = group.operational_final_correct.to_numpy(int)
        ok = ~np.isnan(x)
        x, y = x[ok], y[ok]
        pos, neg = x[y == 1], x[y == 0]
        if not len(pos) or not len(neg):
            continue
        diff = pos[:, None] - neg[None, :]
        num += (diff > 0).sum() + 0.5 * (diff == 0).sum()
        den += diff.size
    return float(num / den) if den else np.nan


def auc_table(frame: pd.DataFrame, features: dict[str, str]) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    index = np.arange(len(frame))
    strata = frame.stratum.to_numpy()
    resamples = []
    for _ in range(BOOT):
        pick = np.concatenate([
            rng.choice(index[strata == s], size=(strata == s).sum(), replace=True)
            for s in np.unique(strata)
        ])
        resamples.append(pick)

    rows = []
    y = frame.operational_final_correct.to_numpy(int)
    for feature, label in features.items():
        x = frame[feature].to_numpy(float)
        boots_pooled, boots_strat = [], []
        for pick in resamples:
            boots_pooled.append(auc(x[pick], y[pick]))
            boots_strat.append(stratified_auc(frame.iloc[pick], feature))
        boots_pooled = np.array(boots_pooled, float)
        boots_strat = np.array(boots_strat, float)
        rows.append(
            {
                "feature": feature,
                "window": WINDOW[feature],
                "label": label,
                "n": int((~np.isnan(x)).sum()),
                "auc_pooled": auc(x, y),
                "pooled_ci_low": np.nanpercentile(boots_pooled, 2.5),
                "pooled_ci_high": np.nanpercentile(boots_pooled, 97.5),
                "auc_within_condition": stratified_auc(frame, feature),
                "within_ci_low": np.nanpercentile(boots_strat, 2.5),
                "within_ci_high": np.nanpercentile(boots_strat, 97.5),
            }
        )
    table = pd.DataFrame(rows)
    return table.sort_values("auc_within_condition", ascending=False, na_position="last")


# -------------------------------------------------------------- acceptance

def acceptance() -> tuple[pd.DataFrame, pd.DataFrame]:
    """Uptake of an exposed peer proposition, by model tier and truth.

    `conflicting` marks pairs where the proposition is false under the
    recipient's own initial assignment, so uptake means abandoning a position
    rather than restating agreement.
    """
    pairs = pd.read_csv(CONFLICT / "exposure-pairs.csv")
    pairs["tier"] = np.where(pairs.condition_id.str.contains("medium"), "medium", "weak")
    pairs["truth"] = np.where(pairs.information_type == "truth_aligned", "true", "false")
    pairs["debate"] = pairs.condition_id + "|" + pairs.task_id + "|" + pairs.repetition.astype(str)

    def rates(sample: pd.DataFrame) -> dict[str, float]:
        out = {}
        for tier in ("weak", "medium"):
            tier_rows = sample[sample.tier == tier]
            for scope, rows in (("all", tier_rows), ("conflicting", tier_rows[tier_rows.conflicting])):
                for truth in ("true", "false"):
                    sel = rows[rows.truth == truth]
                    out[f"{tier}|{scope}|{truth}"] = sel.adopted.mean() if len(sel) else np.nan
                out[f"{tier}|{scope}|gap"] = out[f"{tier}|{scope}|true"] - out[f"{tier}|{scope}|false"]
        return out

    point = rates(pairs)
    rng = np.random.default_rng(SEED)
    debates = pairs.debate.unique()
    grouped = {name: group for name, group in pairs.groupby("debate")}
    boots = []
    for _ in range(BOOT):
        pick = rng.choice(debates, size=len(debates), replace=True)
        boots.append(rates(pd.concat([grouped[d] for d in pick], ignore_index=True)))
    boots = pd.DataFrame(boots)

    rows = []
    for cell, value in point.items():
        tier, scope, truth = cell.split("|")
        sel = pairs[(pairs.tier == tier) & ((pairs.conflicting) | (scope == "all"))]
        sel = sel if truth == "gap" else sel[sel.truth == truth]
        rows.append(
            {
                "tier": tier,
                "scope": scope,
                "quantity": "discrimination (true - false)" if truth == "gap" else f"{truth} claims",
                "n_pairs": len(sel),
                "acceptance": value,
                "ci_low": boots[cell].quantile(0.025),
                "ci_high": boots[cell].quantile(0.975),
            }
        )
    table = pd.DataFrame(rows)

    contrasts = []
    for scope in ("all", "conflicting"):
        for quantity in ("true", "false", "gap"):
            delta = boots[f"medium|{scope}|{quantity}"] - boots[f"weak|{scope}|{quantity}"]
            contrasts.append(
                {
                    "scope": scope,
                    "quantity": "discrimination" if quantity == "gap" else f"{quantity} claims",
                    "medium_minus_weak": point[f"medium|{scope}|{quantity}"] - point[f"weak|{scope}|{quantity}"],
                    "ci_low": delta.quantile(0.025),
                    "ci_high": delta.quantile(0.975),
                }
            )
    return table, pd.DataFrame(contrasts)


# ------------------------------------------------------- supply contrasts

SUPPLY_METRICS = [
    "initial_distinct",
    "initial_true",
    "initial_false",
    "initial_precision",
    "initial_true_bits",
    "initial_false_bits",
    "initial_net_bits",
]


def paired_contrasts(frame: pd.DataFrame) -> pd.DataFrame:
    """Heterogeneous minus homogeneous on the same puzzle, within tier."""
    rng = np.random.default_rng(SEED)
    rows = []
    family = frame.stratum.str.replace(r"-?(het|hom)$", "", regex=True).str.rstrip(":")
    for group_name, group in frame.groupby(family):
        het = group[group.condition_id.str.endswith("het")].set_index("task_id")
        hom = group[group.condition_id.str.endswith("hom")].set_index("task_id")
        if het.empty or hom.empty:
            continue
        shared = sorted(set(het.index) & set(hom.index))
        if not shared:
            continue
        for metric in SUPPLY_METRICS + ["operational_final_correct"]:
            delta = (het.loc[shared, metric] - hom.loc[shared, metric]).to_numpy(float)
            draws = rng.choice(delta[~np.isnan(delta)], size=(BOOT, (~np.isnan(delta)).sum()), replace=True)
            boots = draws.mean(axis=1)
            rows.append(
                {
                    "comparison": group_name,
                    "metric": metric,
                    "het_mean": het.loc[shared, metric].mean(),
                    "hom_mean": hom.loc[shared, metric].mean(),
                    "difference": np.nanmean(delta),
                    "ci_low": np.percentile(boots, 2.5),
                    "ci_high": np.percentile(boots, 97.5),
                    "paired_puzzles": int((~np.isnan(delta)).sum()),
                }
            )
    return pd.DataFrame(rows)


def supply_by_selection(frame: pd.DataFrame) -> pd.DataFrame:
    """Is more information helpful on its own, or only when selection is good?

    Both cuts are at the pooled median, computed on debates where selectivity
    is defined (a debate whose agents were exposed to no false proposition has
    no selectivity to measure).
    """
    tables = []
    for axis in ("false_resistance", "selectivity"):
        sample = frame.dropna(subset=[axis, "initial_net_bits"]).copy()
        bits_cut = sample.initial_net_bits.median()
        axis_cut = sample[axis].median()
        sample["supply"] = np.where(sample.initial_net_bits > bits_cut, "high", "low")
        sample["selection"] = np.where(sample[axis] > axis_cut, "high", "low")
        table = (
            sample.groupby(["supply", "selection"])
            .agg(n=("operational_final_correct", "size"), accuracy=("operational_final_correct", "mean"))
            .reset_index()
        )
        table.insert(0, "selection_axis", axis)
        table["bits_cut"] = bits_cut
        table["selection_cut"] = axis_cut
        tables.append(table)
    return pd.concat(tables, ignore_index=True)


# -------------------------------------------------------------------- main

FEATURES = {
    "initial_distinct": "distinct propositions supplied in the initial proposals",
    "initial_true": "distinct true propositions supplied initially",
    "initial_false": "distinct false propositions supplied initially",
    "initial_precision": "share of signed initial propositions that are true",
    "initial_true_bits": "truth-aligned bits supplied initially",
    "initial_false_bits": "misleading bits supplied initially",
    "initial_net_bits": "truth-aligned minus misleading bits, initially",
    "false_resistance": "share of false peer propositions NOT taken up",
    "selectivity": "uptake of true minus uptake of false peer propositions",
    "uptake_true": "uptake rate of true peer propositions",
    "uptake_false": "uptake rate of false peer propositions",
    "stated_relation_validity": "share of checkable stated inferences that are valid",
    "relation_checkability": "share of stated relations that could be checked",
    "committed_claim_premise_coverage": "share of commitments citing a premise",
    "sound_reasoning_rate": "true conclusion from a valid stated inference",
    "unsupported_error_rate": "false conclusion, invalid stated inference",
    "redundant_claim_rate": "commitments adding no information over their premises",
    "any_initial_correct": "at least one exactly correct initial solution",
}
# When a feature is measured matters for how it can be read. Initial features
# are fixed before any peer content exists; mid-debate features exclude the
# final decision by construction; whole-debate features include the final
# decision stage, so a debate that ends correctly mechanically scores better on
# them. Only the first two groups are usable as antecedents of the outcome.
WINDOW = {
    "initial_distinct": "initial",
    "initial_true": "initial",
    "initial_false": "initial",
    "initial_precision": "initial",
    "initial_true_bits": "initial",
    "initial_false_bits": "initial",
    "initial_net_bits": "initial",
    "any_initial_correct": "initial",
    "false_resistance": "mid-debate",
    "selectivity": "mid-debate",
    "uptake_true": "mid-debate",
    "uptake_false": "mid-debate",
    "stated_relation_validity": "whole-debate",
    "relation_checkability": "whole-debate",
    "committed_claim_premise_coverage": "whole-debate",
    "sound_reasoning_rate": "whole-debate",
    "unsupported_error_rate": "whole-debate",
    "redundant_claim_rate": "whole-debate",
}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    frame = pd.concat(
        [
            load("size6", SIZE6, "size6-per-debate.csv"),
            load("size8", SIZE8, "size8-per-debate.csv"),
        ],
        ignore_index=True,
    )
    frame.to_csv(OUT / "debate-features.csv", index=False)

    auc_table(frame, FEATURES).to_csv(OUT / "feature-auc.csv", index=False)

    by_condition = (
        frame.groupby(["dataset", "condition_id"])
        .agg(
            n=("task_id", "size"),
            accuracy=("operational_final_correct", "mean"),
            **{m: (m, "mean") for m in SUPPLY_METRICS},
            false_resistance=("false_resistance", "mean"),
            selectivity=("selectivity", "mean"),
        )
        .reset_index()
    )
    by_condition.to_csv(OUT / "supply-by-condition.csv", index=False)
    paired_contrasts(frame).to_csv(OUT / "heterogeneity-contrasts.csv", index=False)
    supply_by_selection(frame).to_csv(OUT / "supply-by-selection.csv", index=False)

    table, contrasts = acceptance()
    table.to_csv(OUT / "acceptance-by-tier.csv", index=False)
    contrasts.to_csv(OUT / "acceptance-contrasts.csv", index=False)

    print(by_condition.to_string(index=False))
    print()
    print(table.to_string(index=False))
    print()
    print(contrasts.to_string(index=False))
    print()
    print(pd.read_csv(OUT / "feature-auc.csv").to_string(index=False))
    print()
    print(pd.read_csv(OUT / "heterogeneity-contrasts.csv").to_string(index=False))
    print()
    print(pd.read_csv(OUT / "supply-by-selection.csv").to_string(index=False))


if __name__ == "__main__":
    main()
