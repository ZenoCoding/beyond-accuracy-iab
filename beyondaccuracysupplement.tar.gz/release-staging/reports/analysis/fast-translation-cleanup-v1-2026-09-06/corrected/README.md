Translation correction overlay v1. See ../README.md for the bounded review scope, before/after comparison and remaining ambiguities.

# Expanded AUC: non-role proposition–recipient uptake

120 debates: four size-6 conditions (strong/weak × heterogeneous/homogeneous) plus both fresh size-8 compositions. 73 correct, 47 incorrect. Size-8 heterogeneous: 15/20 correct; homogeneous: 20/20 correct. The latter contributes to pooled AUC but no within-condition correct–incorrect pairs.

Reproduce: `PYTHONPATH=src python reports/analysis/fast-translation-cleanup-v1-2026-09-06/recompute.py` (with the dependencies listed in ../README.md)

| Metric | Eligible debates | Pooled AUC (95% CI) | Within-condition AUC (95% CI) |
|---|---:|---:|---:|
| At least one correct initial solution | 120 | 0.870 [0.822, 0.915] | 0.901 [0.837, 0.954] |
| Net initial information | 119 | 0.823 [0.747, 0.888] | 0.862 [0.729, 0.953] |
| False-claim resistance (non-role pairs) | 77 | 0.812 [0.706, 0.900] | 0.860 [0.667, 0.993] |
| Initial claim precision | 118 | 0.800 [0.716, 0.875] | 0.850 [0.728, 0.945] |
| Truth-aligned initial bits | 119 | 0.733 [0.639, 0.818] | 0.802 [0.661, 0.913] |
| Correct distinct initial propositions | 120 | 0.665 [0.567, 0.755] | 0.800 [0.677, 0.907] |
| True uptake minus false uptake (non-role pairs) | 71 | 0.855 [0.753, 0.939] | 0.787 [0.533, 0.968] |
| True-claim adaptation (non-role pairs) | 96 | 0.724 [0.617, 0.821] | 0.643 [0.453, 0.809] |
| Distinct initial propositions | 119 | 0.462 [0.359, 0.563] | 0.532 [0.349, 0.717] |
| Distinct later propositions, including final decisions | 120 | 0.734 [0.662, 0.810] | 0.272 [0.131, 0.437] |
| Distinct later propositions, excluding final decisions | 120 | 0.727 [0.655, 0.804] | 0.258 [0.121, 0.427] |

Uptake correction: eligible units are (initial proposition, non-introducer recipient) pairs. A hit requires the same effective proposition to be expressed by that recipient after initial proposals and before the final decision. Expressions containing ROLE( anywhere are excluded. True/false uptake retains the existing truth_aligned/misleading eligibility (informative propositions; redundant and contradictory propositions do not enter these denominators). The uncorrected baseline reproduced the saved exposure pairs exactly. This output uses the reviewed translation overlay; changed pairs are recorded in ../affected-pairs.csv. Debate-level pair rates feed the AUC, rather than tier-pooled rates. Zero eligible pairs yield missing uptake, not zero. Resistance is one minus false uptake; selectivity is true minus false uptake.

The non-role restriction applies to uptake/resistance/selectivity only. Initial supply and introduction counts retain role propositions. Correct initial counts include true redundant propositions; later counts include all scored commitments, deduplicated by exact effective expression and assigned to their earliest stage. These counts are not adjusted for debate length. Initial supply features otherwise retain the original 120-debate definitions and missing values.

Within-condition AUC compares outcomes only inside the same size/composition/strength condition, weighted by eligible correct–incorrect pairs, ties at 0.5. Eligible debates include conditions with only one outcome; feature-auc.csv additionally reports the number of contributing debates and comparison pairs. Confidence intervals preserve the original method: 2,000 percentile bootstrap draws, seed 20260905, debates resampled separately within condition. Shared puzzles are not jointly resampled across conditions. For this before/after comparison the expanded cohort, uptake definition and bootstrap estimator are held fixed; changes come from the translation overlay. The older size-6 table is retained unchanged and uses all-role, proposition-level uptake, so it is not a like-for-like robustness comparison.

Sorted by within-condition AUC. AUC below 0.5 indicates a negative association. AUC does not establish causality or incremental importance beyond initial accuracy. The full feature CSV retains whole-debate reasoning features that include final decisions; the paper table omits those except the explicitly labeled later-introduction count.
