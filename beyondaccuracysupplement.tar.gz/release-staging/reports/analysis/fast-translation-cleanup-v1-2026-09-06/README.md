# Targeted translation cleanup v1: updated 120-debate AUC

Completed a bounded translation correction pass and reran the exact updated analysis: **80 original size-6 debates plus the fresh 40 size-8 debates**. The baseline reproduces all 990 saved exposure pairs, all 21 feature rows, the 11-row paper table, and all six condition counts. The cohort remains 120 debates / 73 correct, including fresh size-8 heterogeneous 15/20 and homogeneous GPT-OSS 20/20. Historical size-8 and the separate conditional analysis are not substituted.

Within-condition false-resistance AUC decreases from **0.889 to 0.860**, and selectivity from **0.828 to 0.787**. Initial correctness, net initial information and initial precision retain their within-condition AUCs. Their stability as rank statistics does not mean every underlying feature value is unchanged. This is a targeted cleanup, not full semantic validation.

## Before / after paper table

Same 2,000-draw percentile bootstrap, seed 20260905; debates resampled independently within each original condition. AUC and all eligibility rules are unchanged. Within-condition comparisons exclude cross-condition pairs and count ties as 0.5. No puzzle-cluster estimator is mixed into this comparison.

| Metric | Eligible debates before → after | Within AUC before → after | Corrected 95% CI |
|---|---:|---:|---:|
| At least one correct initial solution | 120 → 120 | 0.901 → 0.901 | [0.837, 0.954] |
| False-claim resistance (non-role pairs) | 79 → 77 | 0.889 → 0.860 | [0.667, 0.993] |
| Net initial information | 119 → 119 | 0.862 → 0.862 | [0.729, 0.953] |
| Initial claim precision | 118 → 118 | 0.850 → 0.850 | [0.728, 0.945] |
| True uptake minus false uptake (non-role pairs) | 73 → 71 | 0.828 → 0.787 | [0.533, 0.968] |
| Correct distinct initial propositions | 120 → 120 | 0.802 → 0.800 | [0.677, 0.907] |
| Truth-aligned initial bits | 119 → 119 | 0.802 → 0.802 | [0.661, 0.913] |
| True-claim adaptation (non-role pairs) | 97 → 96 | 0.641 → 0.643 | [0.453, 0.809] |
| Distinct initial propositions | 119 → 119 | 0.546 → 0.532 | [0.349, 0.717] |
| Distinct later propositions, including final decisions | 120 → 120 | 0.267 → 0.272 | [0.131, 0.437] |
| Distinct later propositions, excluding final decisions | 120 → 120 | 0.265 → 0.258 | [0.121, 0.427] |

`before-after-paper-auc.csv` contains every paper row with before/after pooled and within-condition AUCs, both sets of intervals, eligible debate counts and contributing comparison counts. The full 21-feature tables are `baseline/feature-auc.csv` and `corrected/feature-auc.csv`. For false resistance, contributing within-condition pairs change from 81 to 75; for selectivity, 58 to 54. Wide intervals remain.

## What was reviewed and corrected

Three Sol review assignments checked disjoint initial, uptake and recurring-pattern scopes; a second Sol pass independently checked all eight additional polarity candidates. The primary assistant inspected the source prose and integrated the proposals. No new debate or broad model translation was run.

- Original clear-error scope: all 42 claims in U05/U10/U14’s three fields; five targeted existing claims and two omissions in F06/F07, with complete source context.
- Recurring search: all 5,826 fields in the six exact translation sources were scanned for two narrow patterns, joined to the saved scored claims. It found 66 candidate fields, including three core fields. Of the 63 remaining, 20 fields / 61 candidate claim occurrences were manually reviewed: all eight remaining direct false-to-positive fields, plus the lexicographically first six generic-closure fields from each puzzle size. Selection did not use outcome.
- The recurring review found 19 fields requiring correction and one faithful translation left unchanged. **43 additional generic-closure candidate fields remain unreviewed.** The pattern search does not establish completeness for other kinds of translation failure.
- In total, 25 fields received the bounded manual source review; 24 were changed, across 22 debates (15 size-6 and seven fresh size-8). Of 75 claim operations, **25 are replacements, 48 removals, and two additions**. Raw record counts change from 35,000 to 34,976 for size-6 and 25,254 to 25,232 for fresh size-8.

Generic consistency statements such as “All statements check out” now retain one opaque record instead of invented player-truth expansions. Literal false statements have the correct negation. In two fields the correct negative already existed with identical span and metadata; the incorrect positive was removed rather than duplicated. The initial pass restores three quoted player reports, one omitted C report, and the explicit omitted A-knave assertion. The wrong negation target in F06 is expressed as the literal falsehood of the quoted count; the agent’s inconsistent later role conclusion remains intact.

## Overlay, dependencies and regeneration

`correction-ledger.jsonl` contains stable condition/task/field/claim IDs, exact before/after objects, source spans, source hashes, rationales, primary decisions and independently reviewed source-file hashes. `overlay-manifest.json` points to the six complete corrected translation files under `overlay/translations/`, with original/overlay hashes. All **5,802 untouched fields are preserved byte for byte**. Original raw response strings remain evidence of the model output; the overlay ledger explicitly identifies postprocessing changes to parsed records.

Claims retain stable IDs where possible. Removed duplicate/unsupported records have no remaining dependent endpoints. Every retained relation endpoint resolves. No existing relation record was removed; one explicit “is false, so A is knave” edge was added for the restored assertion. `dependency-ledger.json` explains retained dependencies, including qualitative consistency relations that become uncheckable when their endpoints are opaque. `affected-relation-scores.json` gives the mechanical before/after consequences. Case objects remain unchanged. Restoring explicit player reports corrects their individual attribution/scope labels under the existing extraction rule; unresolved hypothetical deductions are not promoted.

The official `analyze_minimal_reasoning` function regenerates all fields, cases, relations and debate metrics in affected debates, before and after correction. Regenerated original claims and debate rows reproduce the saved originals; unaffected fields and all unaffected debates match. Source prose is matched against the frozen original complete debate results in `frozen/debate-results/`. Corrected source-level CSVs are merged into the same full cohort under `corrected-inputs/size6/` and `corrected-inputs/size8/`.

The author’s initial-feature function then rebuilds initial supply from corrected claims, and the author’s expanded build/main routines regenerate pair eligibility, uptake and all AUC features. The harness only redirects input/output paths and removes the old assertion requiring corrected pairs to equal the uncorrected historical snapshot. `scorer-adapter.json` records that assertion. No numerical rule, matching rule, non-role filter, raw-tag commitment filter, stage boundary, missing-value policy or bootstrap definition was changed.

The final pair set has **968 opportunities**, versus 990 before. `affected-pairs.csv` records **26 removals, four additions and four 1→0 adoption changes**. `affected-debate-features.csv` records changed paper-feature values in 18 debates. Initial additions/removals can change who already expressed a proposition and hence eligibility; these consequences are calculated from the corrected source records, not patched into aggregate counts.

## Remaining uncertainty

`pending-ambiguities.json` retains the F06/F07 conditional-scope questions and U10’s initial-commitment ambiguity. The earlier human-review packet contains the other previously unresolved source/initial-wording cases. The user requested an explanation of hypothetical versus committed claims; these labels remain unchanged under the earlier instruction to defer ambiguous judgments. Exact-string versus semantic-equivalence matching, semantic role exclusion and the handling of self-attributed reports/rejections remain methodology questions outside this correction pass. This cleanup does not validate claim recall, corpus-wide fidelity or causal information transfer.

## Reproduce

Frozen repository commit: `002bb2e0b2032ea5b8faccd1c4443e01a8a49bac`. Use Python 3.11+ with NumPy, pandas, PyYAML and Pillow; exact versions from this run are in `runtime-versions.json`. From the repository root:

```sh
PYTHONPATH=src python reports/analysis/fast-translation-cleanup-v1-2026-09-06/integrate_reviews.py
PYTHONPATH=src python reports/analysis/fast-translation-cleanup-v1-2026-09-06/recompute.py
PYTHONPATH=src python reports/analysis/fast-translation-cleanup-v1-2026-09-06/summarize_and_verify.py
```

`prepare_baseline.py` independently freezes/reproduces the original expanded table. Reproduction verifies source hashes and fails on drift. The actual local run used the bundled Python interpreter plus PyYAML 6.0.3 installed under `/tmp/fast-translation-cleanup-deps`; that temporary directory is not needed if PyYAML is installed in the selected interpreter. No commit, push or manuscript edit was made.
