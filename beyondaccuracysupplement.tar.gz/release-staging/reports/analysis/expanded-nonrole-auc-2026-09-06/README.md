# Expanded AUC: non-role proposition–recipient uptake

120 debates: four size-6 conditions (strong/weak × heterogeneous/homogeneous) plus both fresh size-8 compositions. 73 correct, 47 incorrect. Size-8 heterogeneous: 15/20 correct; homogeneous: 20/20 correct. The latter contributes to pooled AUC but no within-condition correct–incorrect pairs.

Reproduce: `.venv/bin/python scripts/remake_expanded_nonrole_auc.py`

| Metric | Eligible debates | Pooled AUC (95% CI) | Within-condition AUC (95% CI) |
|---|---:|---:|---:|
| At least one correct initial solution | 120 | 0.870 [0.822, 0.915] | 0.901 [0.837, 0.954] |
| False-claim resistance (non-role pairs) | 79 | 0.824 [0.720, 0.908] | 0.889 [0.712, 1.000] |
| Net initial information | 119 | 0.822 [0.747, 0.888] | 0.862 [0.729, 0.953] |
| Initial claim precision | 118 | 0.798 [0.713, 0.874] | 0.850 [0.728, 0.945] |
| True uptake minus false uptake (non-role pairs) | 73 | 0.861 [0.763, 0.940] | 0.828 [0.600, 1.000] |
| Correct distinct initial propositions | 120 | 0.670 [0.574, 0.759] | 0.802 [0.679, 0.908] |
| Truth-aligned initial bits | 119 | 0.736 [0.643, 0.819] | 0.802 [0.661, 0.913] |
| True-claim adaptation (non-role pairs) | 97 | 0.726 [0.620, 0.824] | 0.641 [0.449, 0.811] |
| Distinct initial propositions | 119 | 0.473 [0.368, 0.573] | 0.546 [0.363, 0.728] |
| Distinct later propositions, including final decisions | 120 | 0.732 [0.658, 0.807] | 0.267 [0.128, 0.431] |
| Distinct later propositions, excluding final decisions | 120 | 0.727 [0.653, 0.804] | 0.265 [0.127, 0.435] |

Uptake correction: eligible units are (initial proposition, non-introducer recipient) pairs. A hit requires the same effective proposition to be expressed by that recipient after initial proposals and before the final decision. Expressions containing ROLE( anywhere are excluded. True/false uptake retains the existing truth_aligned/misleading eligibility (informative propositions; redundant and contradictory propositions do not enter these denominators). The size-6 exposure pairs exactly reproduce the existing non-role subset underlying Table 2. Debate-level pair rates feed the AUC, rather than tier-pooled rates. Zero eligible pairs yield missing uptake, not zero. Resistance is one minus false uptake; selectivity is true minus false uptake.

The non-role restriction applies to uptake/resistance/selectivity only. Initial supply and introduction counts retain role propositions. Correct initial counts include true redundant propositions; later counts include all scored commitments, deduplicated by exact effective expression and assigned to their earliest stage. These counts are not adjusted for debate length. Initial supply features otherwise retain the original 120-debate definitions and missing values.

Within-condition AUC compares outcomes only inside the same size/composition/strength condition, weighted by eligible correct–incorrect pairs, ties at 0.5. Eligible debates include conditions with only one outcome; feature-auc.csv additionally reports the number of contributing debates and comparison pairs. Confidence intervals preserve the original method: 2,000 percentile bootstrap draws, seed 20260905, debates resampled separately within condition. Shared puzzles are not jointly resampled across conditions. Changes from the old table reflect both the expanded sample and corrected uptake definition. The older size-6 table is retained unchanged and uses all-role, proposition-level uptake, so it is not a like-for-like robustness comparison.

Sorted by within-condition AUC. AUC below 0.5 indicates a negative association. AUC does not establish causality or incremental importance beyond initial accuracy. The full feature CSV retains whole-debate reasoning features that include final decisions; the paper table omits those except the explicitly labeled later-introduction count.
