# Size-8-only AUC: non-role proposition–recipient uptake

40 debates: 20 heterogeneous (15 correct, 5 incorrect) and 20 homogeneous (all correct), on the same 20 puzzles. Within-condition AUC therefore uses only the heterogeneous condition; homogeneous debates contribute only to pooled AUC.

Reproduce: `.venv/bin/python scripts/remake_size8_nonrole_auc.py`

Source: `../debate-features.csv`, restricted to size8. All feature definitions and exclusions match the expanded non-role analysis.

| Metric | Eligible debates | Pooled AUC (95% CI) | Within-condition AUC (95% CI) |
|---|---:|---:|---:|
| False-claim resistance (non-role pairs) | 26 | 0.909 [0.800, 1.000] | 1.000 [1.000, 1.000] |
| At least one correct initial solution | 40 | 0.857 [0.779, 0.926] | 0.867 [0.750, 0.969] |
| True uptake minus false uptake (non-role pairs) | 21 | 0.750 [0.417, 1.000] | 0.806 [0.389, 1.000] |
| Correct distinct initial propositions | 40 | 0.751 [0.582, 0.901] | 0.793 [0.580, 0.965] |
| Initial claim precision | 38 | 0.861 [0.734, 0.968] | 0.787 [0.560, 0.976] |
| Net initial information | 39 | 0.782 [0.613, 0.921] | 0.733 [0.500, 0.942] |
| Truth-aligned initial bits | 39 | 0.688 [0.472, 0.882] | 0.667 [0.388, 0.907] |
| Distinct initial propositions | 39 | 0.574 [0.305, 0.824] | 0.653 [0.320, 0.941] |
| True-claim adaptation (non-role pairs) | 28 | 0.529 [0.181, 0.893] | 0.500 [0.179, 0.864] |
| Distinct later propositions, including final decisions | 40 | 0.651 [0.289, 0.914] | 0.453 [0.130, 0.813] |
| Distinct later propositions, excluding final decisions | 40 | 0.643 [0.275, 0.910] | 0.440 [0.119, 0.804] |

Uptake uses informative initial proposition–recipient pairs, excluding expressions containing ROLE(. Recipients must not have initially stated the proposition; adoption is subsequent expression before the final decision. No eligible pairs means missing uptake. Supply and introduction features retain role-assignment propositions. Initial correct counts include true redundant propositions; later counts include true and false propositions.

Confidence intervals preserve the original method: 2,000 percentile bootstrap samples, seed 20260905, resampling debates independently within each condition. Shared puzzles are not jointly resampled. Replicates lacking an eligible correct or incorrect debate have undefined AUC and are excluded from interval quantiles. With only five failures overall and potentially fewer eligible for uptake metrics, estimates are imprecise. Eligible debates include homogeneous debates; the full CSV separately records the within-condition contributing debates and correct–incorrect comparison pairs.

Sorted by within-condition AUC. Values below 0.5 indicate negative association. These observational associations do not establish causation or incremental predictive value beyond initial accuracy.

False-claim resistance perfectly separates the eligible heterogeneous outcomes in this sample. Its [1.000, 1.000] percentile-bootstrap interval is degenerate: resampling observed perfectly separated values cannot reveal population uncertainty. It must not be interpreted as certainty of perfect discrimination in new debates.
