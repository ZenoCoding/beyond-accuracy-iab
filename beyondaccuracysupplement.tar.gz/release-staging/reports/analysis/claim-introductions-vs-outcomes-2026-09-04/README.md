# Claim introductions vs. outcomes

Size-6 weak and medium translated samples, 20 debates per condition. X is the pooled proportion of distinct scored committed claims first appearing after initial proposals, including final decisions. Claims are deduplicated by effective expression within each debate and earliest-stage ties split credit, matching the introduction figures. Y is either operational_final_correct (final answer accuracy) or final_unanimous (all agents agree on their final assignment), averaged across debates. Agreement does not imply correctness. These four condition aggregates describe the sample; they do not identify a causal effect of claim introduction.

Sources: the weak and medium claim-introductions CSVs and minimal-reasoning-size6-strength-comparison-2026-09-04/debates.csv. Reproduce with `.venv/bin/python scripts/plot_claim_introductions_vs_outcomes.py`.
